<?php

/**
 * Class WPML_TF_Feedback_Update_Exception
 *
 * @author OnTheGoSystems
 */
class WPML_TF_Feedback_Update_Exception extends Exception {

}
