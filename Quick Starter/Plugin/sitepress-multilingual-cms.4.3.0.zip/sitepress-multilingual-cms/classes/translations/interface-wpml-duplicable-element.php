<?php

/**
 * @author OnTheGo Systems
 */
interface WPML_Duplicable_Element {

}
