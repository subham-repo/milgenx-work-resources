<?php
/**
 * @author OnTheGo Systems
 */
interface IWPML_Frontend_Action extends IWPML_Action {
}
