<?php

interface IWPML_AJAX_Action_Run {
	public function run();
}