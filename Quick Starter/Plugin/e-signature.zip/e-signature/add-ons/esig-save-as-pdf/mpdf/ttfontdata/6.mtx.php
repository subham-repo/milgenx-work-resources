<?php
$name='HerrVonMuellerhoff-Regular';
$type='TTF';
$desc=array (
  'CapHeight' => 644,
  'XHeight' => 269,
  'FontBBox' => '[-369 -497 1316 925]',
  'Flags' => 4,
  'Ascent' => 925,
  'Descent' => -497,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 220,
);
$unitsPerEm=1000;
$up=-75;
$ut=50;
$strp=250;
$strs=50;
$ttffile='/home/graceiss/public_html/dev.approveme.me/testserver/wp-content/plugins/e-signature/add-ons/esig-save-as-pdf/mpdf/ttfonts/HerrVonMuellerhoff-Regular.ttf';
$TTCfontID='0';
$originalsize=46624;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='6';
$panose=' 0 0 2 0 5 6 0 0 0 2 0 4';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 925, -497, 0
// usWinAscent/usWinDescent = 925, -497
// hhea Ascent/Descent/LineGap = 925, -497, 0
$useOTL=0x0000;
$rtlPUAstr='';
?>