<?php
$name='DawningofaNewDay';
$type='TTF';
$desc=array (
  'CapHeight' => 799.0,
  'XHeight' => 213.0,
  'FontBBox' => '[-213 -451 1423 1124]',
  'Flags' => 4,
  'Ascent' => 1124.0,
  'Descent' => -451.0,
  'Leading' => 0.0,
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 618.0,
);
$unitsPerEm=1024;
$up=0;
$ut=0;
$strp=250;
$strs=50;
$ttffile='F:/xampp/htdocs/project/1.5.2/wp-content/plugins/e-signature/add-ons/esig-save-as-pdf/mpdf/ttfonts/DawningofaNewDay.ttf';
$TTCfontID='0';
$originalsize=65344;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='5';
$panose=' 0 0 2 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 1124, -488, 0
// usWinAscent/usWinDescent = 1124, -488
// hhea Ascent/Descent/LineGap = 1124, -488, 0
$useOTL=0x0000;
$rtlPUAstr='';
?>