<?php
/**
 * Represents the view for the public-facing component of the plugin.
 */
?>

<!-- This file is used to markup the public facing aspect of the plugin. -->
