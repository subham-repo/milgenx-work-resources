(function ($) {
    "use strict";

    $(function () {



    });

    $('#sifreadonly').removeClass('esig-sif-textfield');
    $('#sifreadonly').addClass('esig-sifreadonly');

    

} (jQuery));

