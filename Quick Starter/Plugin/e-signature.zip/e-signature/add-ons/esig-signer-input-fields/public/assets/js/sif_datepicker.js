jQuery(document).ready(function () {
    
    jQuery('#EsigDate').datepicker({
       
        dateFormat: 'D M yy'
    });
});