<div id="installation-check-passed" class="installation-check-passed">

    <div class="heading icon-success-check"></div>
      
    <div class="top">
        
     <div class="passed"><b><?php _e("Install Check Passed","esig");?></b></div>
       
     <p class="passed-description"><b><?php _e("Excellent! Looks like everything is installed correctly.Click Continue below to start using ApproveMe","esig");?></b></p>  
        
    </div> 
       
     
      
      <button id="esig-checklist-success-continue" class="continue"><b><?php _e("Continue","esig");?></b></button>

  </div>
