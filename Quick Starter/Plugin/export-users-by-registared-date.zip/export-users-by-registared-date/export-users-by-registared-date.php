<?php
/*
Plugin Name: Export Users By Registered Date
description: Export Users to CSV Plugin.
Version: 1.0
Author: Amit Singh

*/

function eu_register_export_page() 
{
	add_submenu_page('tools.php', 'Export Users', 'Export Users', 'manage_options', 'wp-export-users', 'eu_export_users_page');
}
add_action('admin_menu', 'eu_register_export_page');

function eu_export_users($start_date,$end_date)
{
	if(!empty($start_date) && !empty($end_date))
	{		
		$start_date = date("Y-m-d",strtotime($start_date));
		$end_date = date("Y-m-d",strtotime($end_date));
		global $wpdb;
		$sql='SELECT * FROM '. $wpdb->users.' WHERE user_registered BETWEEN "'.$start_date.'" AND "'.$end_date.'"';		
		$users=$wpdb->get_results($sql);
			
		$datas=array();
		$headers = array('S.No','ID','Username','Email','Display Name','First Name','Last Name','Registered Date');
			
		$filename=time()."_"."user-details.csv";
		$file = fopen('php://output', 'w');	
		header('Content-type: application/csv');
		header('Content-Disposition: attachment; filename='.$filename);	
		fputcsv($file, $headers);	
		
		$sno=1;
		if($users)
		{
			foreach($users as $user)
			{
				$user_meta=get_userdata($user->ID);
				$user_data=$sno."|".$user->ID."|".$user->user_login."|".$user->user_email."|".$user->display_name."|".$user_meta->first_name."|".$user_meta->last_name."|".$user->user_registered;
						
				$datas[]=$user_data;
				$sno++;
			}
		}
		foreach ($datas as $data)
		{
			fputcsv($file,explode('|',$data));
		}
		exit();
	}
}

function eu_export_users_page()
{
	if(isset($_POST['export_users_csv']) && isset($_POST['daterange']) && !empty($_POST['daterange']))
	{
		$daterange = $_POST['daterange'];
		$dateExplode = explode("-",$daterange);
		$start_date = trim($dateExplode[0]);
		$end_date = trim($dateExplode[1]);
		ob_clean();
		eu_export_users($start_date,$end_date);
	}
	
?>
	<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
	<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
	<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
	<style type="text/css">
		.filter_wrapper {
		    display: flex;
		    justify-content: center;
		    margin: 40px 0;
		    position: relative;
		}
	</style>
	<div class="wrap">
		<div class="filter_wrapper">
			<h1>Export Users</h1><br/>
			<form method="post">
				<input type="text" name="daterange" value="" />
				<input type="submit" name="export_users_csv" value="Export Users">
			</form>
		</div>
	</div>
	<script>
	$(function() {
	  $('input[name="daterange"]').daterangepicker({
	    opens: 'left',
	    locale: {
	      format: 'YYYY/MM/DD'
	    }
	  }, function(start, end, label) {
	    
	  });
	});
	$('input[name="dates"]').daterangepicker();
	</script>
	
<?php 	
}