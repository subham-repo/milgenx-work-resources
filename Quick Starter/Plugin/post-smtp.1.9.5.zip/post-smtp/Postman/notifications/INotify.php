<?php
interface Postman_Notify {
    public function send_message( $message );
}