#This folder is intentionally left empty

## Changes in WooCommerce 2.2 reports
Class `Aelia\CurrencySwitcher\WC22\Reports` just implements some new logic for
the dashboard widgets, which use different queries. It's no longer necessaey to
override report classes.
