 === WP Event Manager - Woocommerce Paid Listings ===

Contributors: ashokdudhat
Requires at least: 4.1
Tested up to: 5.2.2
Stable tag: 1.1.3
License: GNU General Public License v3.0

Lets attendees submit registrations to events which are stored on the organizers events page(event dashboard), rather than simply emailed.

= Support Policy =

I will happily patch any confirmed bugs with this plugin, however, I will not offer support for:

1. Customisations of this plugin or any plugins it relies upon
2. Conflicts with "premium" themes from ThemeForest and similar marketplaces (due to bad practice and not being readily available to test)
3. CSS Styling (this is customisation work)

If you need help with customisation you will need to find and hire a developer capable of making the changes.

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Changelog ==


= 1.1.3 =

*Fixed - some js and new design css improved.

= 1.1.2 =

* Added - New design responsive structure
* Added - Layout type attribute in events shortcode
* Added - CSS Improved
* Added - All Templates Improved
* Fixed - Minor Bugs


= 1.0 =
* First release.