<?php
global $post;
$post_id = $post->ID;
?>
<div class="options_group show_if_event_package show_if_event_package_subscription">
	<?php woocommerce_wp_select( array(
		'id' => '_event_listing_package_subscription_type',
		'wrapper_class' => 'hide_if_event_package show_if_event_package_subscription',
		'label' => __( 'Subscription Type', 'wp-event-manager-wc-paid-listings' ),
		'description' => __( 'Choose how subscriptions affect this package', 'wp-event-manager-wc-paid-listings' ),
		'value' => get_post_meta( $post_id, '_package_subscription_type', true ),
		'desc_tip' => true,
		'options' => array(
			'package' => __( 'Link the subscription to the package (renew listing limit every subscription term)', 'wp-event-manager-wc-paid-listings' ),
			'listing' => __( 'Link the subscription to posted listings (renew posted listings every subscription term)', 'wp-event-manager-wc-paid-listings' ),
		),
	) ); ?>

	<?php woocommerce_wp_text_input( array(
		'id' => '_event_listing_limit',
		'label' => __( 'Event listing limit', 'wp-event-manager-wc-paid-listings' ),
		'description' => __( 'The number of event listings a user can post with this package.', 'wp-event-manager-wc-paid-listings' ),
		'value' => ( $limit = get_post_meta( $post_id, '_event_listing_limit', true ) ) ? $limit : '',
		'placeholder' => __( 'Unlimited', 'wp-event-manager-wc-paid-listings' ),
		'type' => 'number',
		'desc_tip' => true,
		'custom_attributes' => array(
		'min'   => '',
		'step' 	=> '1',
		),
	) ); ?>

	<?php woocommerce_wp_text_input( array(
		'id' => '_event_listing_duration',
		'label' => __( 'Event listing duration', 'wp-event-manager-wc-paid-listings' ),
		'description' => __( 'The number of days that the event listing will be active.', 'wp-event-manager-wc-paid-listings' ),
		'value' => get_post_meta( $post_id, '_event_listing_duration', true ),
		'placeholder' => get_option( 'event_manager_submission_duration' ),
		'desc_tip' => true,
		'type' => 'number',
		'custom_attributes' => array(
		'min'   => '',
		'step' 	=> '1',
		),
	) ); ?>

	<?php woocommerce_wp_checkbox( array(
		'id' => '_event_listing_featured',
		'label' => __( 'Feature Listings?', 'wp-event-manager-wc-paid-listings' ),
		'description' => __( 'Feature this event listing - it will be styled differently and sticky.', 'wp-event-manager-wc-paid-listings' ),
		'value' => get_post_meta( $post_id, '_event_listing_featured', true ),
	) ); ?>

	<script type="text/javascript">
		jQuery(function(){
			jQuery('#product-type').change( function() {
				jQuery('#woocommerce-product-data').removeClass(function(i, classNames) {
					var classNames = classNames.match(/is\_[a-zA-Z\_]+/g);
					if ( ! classNames ) {
						return '';
					}
					return classNames.join(' ');
				});
				jQuery('#woocommerce-product-data').addClass( 'is_' + jQuery(this).val() );
			} );
			jQuery('.pricing').addClass( 'show_if_event_package' );
			jQuery('._tax_status_field').closest('div').addClass( 'show_if_event_package show_if_event_package_subscription' );
			jQuery('.show_if_subscription, .options_group.pricing').addClass( 'show_if_event_package_subscription' );
			jQuery('.options_group.pricing ._regular_price_field').addClass( 'hide_if_event_package_subscription' );
			jQuery('#product-type').change();
			jQuery('#_event_listing_package_subscription_type').change(function(){
				if ( jQuery(this).val() === 'listing' ) {
					jQuery('#_event_listing_duration').closest('.form-field').hide().val('');
				} else {
					jQuery('#_event_listing_duration').closest('.form-field').show();
				}
			}).change();
		});
	</script>
</div>
