<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

$options = array(
		'wpem_sendinblue_version',
		'organizer_field',
		'organizer_sendinblue_field',
		'registration_field',
		'registration_sendinblue_field',
		'sendinblue_list',
		'sendinblue_sync_type',
		'sendinblue_sync_via',
		'sendinblue_sync_schedule',
);

foreach ( $options as $option ) {
	delete_option( $option );
}
