<?php

if (!function_exists('get_sendinblue_sync_type')) {

    /**
     * Event Sendinblue Sync Type
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_sync_type() {
        return apply_filters('sendinblue_sync_type', array(
            'auto' => __('Auto', 'wp-event-manager-sendinblue'),
            'manual' => __('Manual', 'wp-event-manager-sendinblue'),
        ));
    }

}

if (!function_exists('get_sendinblue_sync_schedule')) {

    /**
     * Event Sendinblue Sync Schedule
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_sync_schedule() {
        return apply_filters('sendinblue_sync_schedule', array(
            '5min' => __('5 Min', 'wp-event-manager-sendinblue'),
            'daily' => __('Daily', 'wp-event-manager-sendinblue'),
            'weekly' => __('Weekly', 'wp-event-manager-sendinblue'),
            'monthly' => __('Monthly', 'wp-event-manager-sendinblue'),
            'yearly' => __('Yearly', 'wp-event-manager-sendinblue'),
        ));
    }

}

if (!function_exists('get_sendinblue_sync_via')) {

    /**
     * Event Sendinblue Sync Type
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_sync_via() {
        return apply_filters('sendinblue_sync_via', array(
            'when_created' => __('When new created', 'wp-event-manager-sendinblue'),
            'cron_job' => __('Cron Job', 'wp-event-manager-sendinblue'),
        ));
    }

}

if (!function_exists('get_sendinblue_settings_by_user')) {

    /**
     * Get Sendinblue Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_settings_by_user() {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        $sendinblue_settings = [];

        if (current_user_can('manage_options')) {
            $sendinblue_settings = get_option('sendinblue_settings');
        } else {
            $sendinblue_settings = get_user_meta($user_id, 'sendinblue_settings', true);
        }

        return $sendinblue_settings;
    }

}

if (!function_exists('get_sendinblue_settings_by_user_id')) {

    /**
     * Get Sendinblue Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_settings_by_user_id($user_id = '') {

        $user_meta = get_userdata($user_id);

        $sendinblue_settings = [];

        if (isset($user_meta->roles) && in_array('administrator', $user_meta->roles)) {
            $sendinblue_settings = get_option('sendinblue_settings');
        } elseif (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $sendinblue_settings = get_option('sendinblue_settings');
        } else {
            $sendinblue_settings = get_user_meta($user_id, 'sendinblue_settings', true);
        }

        return $sendinblue_settings;
    }

}

if (!function_exists('update_sendinblue_settings_by_user')) {

    /**
     * update Sendinblue Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function update_sendinblue_settings_by_user($field_key = '', $field_value = '') {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        if (current_user_can('manage_options')) {
            update_option($field_key, $field_value);
        } else {
            update_user_meta($user_id, $field_key, $field_value);
        }
    }

}

if (!function_exists('delete_sendinblue_settings_by_user')) {

    /**
     * update Sendinblue Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function delete_sendinblue_settings_by_user($field_key = '') {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        if (current_user_can('manage_options')) {
            delete_option($field_key);
        } else {
            delete_user_meta($user_id, $field_key);
        }
    }

}

if (!function_exists('get_sync_fields_by_user')) {

    /**
     * Get Sendinblue Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sync_fields_by_user($user_id = '', $fields_key = '') {
        $sync_fields = [];

        $user_meta = get_userdata($user_id);

        if ((isset($user_meta->roles) && in_array('administrator', $user_meta->roles)) || current_user_can('manage_options')) {
            $sync_fields = get_option($fields_key);
        } else if (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $sync_fields = get_option($fields_key);
        } else {
            $sync_fields = get_user_meta($user_id, $fields_key, true);
        }

        return $sync_fields;
    }

}

if (!function_exists('get_sendinblue_sync_fields_by_user')) {

    /**
     * Get Sendinblue Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_sync_fields_by_user($user_id = '', $fields_key = '') {
        $sendinblue_sync_fields = [];

        $user_meta = get_userdata($user_id);

        if ((isset($user_meta->roles) && in_array('administrator', $user_meta->roles)) || current_user_can('manage_options')) {
            $sendinblue_sync_fields = get_option($fields_key);
        } else if (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $sendinblue_sync_fields = get_option($fields_key);
        } else {
            $sendinblue_sync_fields = get_user_meta($user_id, $fields_key, true);
        }

        return $sendinblue_sync_fields;
    }

}

if (!function_exists('sendinblue_request')) {

    /**
     * Sendinblue request
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function sendinblue_request($sendinblue_api_key = '', $end_point = '', $args = []) {

        $response_body = '';

        if ($sendinblue_api_key != '' && $end_point != '') {
            $url = 'https://api.sendinblue.com/v3/' . $end_point;

            $response = wp_remote_post($url, $args);

            $result = json_decode(wp_remote_retrieve_body($response), true);
        }

        return $result;
    }

}

if (!function_exists('check_sendinblue_key')) {

    /**
     * Check sendinblue key
     *
     * @access public
     * @param
     * @return bool
     * @since 1.0.0
     */
    function check_sendinblue_key($sendinblue_api_key = '') {

        $response_body = [];

        if ($sendinblue_api_key != '') {
            $args = ['method' => 'GET', 'count' => '1', 'headers' => ['content-type' => 'application/json', 'api-key' => $sendinblue_api_key]];

            $end_point = 'contacts/lists/';

            $response_body = sendinblue_request($sendinblue_api_key, $end_point, $args);
        }

        return $response_body;
    }

}

if (!function_exists('get_sendinblue_lists')) {

    /**
     * Get sendinblue list
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_lists($sendinblue_api_key = '') {

        $user_id = get_current_user_id();

        $arr_sendinblue_lists = get_sync_fields_by_user($user_id, 'sendinblue_lists');

        $arr_sendinblue_lists = [];

        if ($sendinblue_api_key != '') {
            $args = ['method' => 'GET', 'count' => '20', 'headers' => ['content-type' => 'application/json', 'api-key' => $sendinblue_api_key]];

            $end_point = 'contacts/lists/';

            $response_body = sendinblue_request($sendinblue_api_key, $end_point, $args);

            if (!empty($response_body['lists'])) {
                $arr_sendinblue_lists[] = __('Event based selection', 'wp-event-manager-sendinblue');

                foreach ($response_body['lists'] as $sendinblue_list) {
                    $arr_sendinblue_lists[$sendinblue_list['id']] = $sendinblue_list['name'];
                }
            }
        }

        update_sendinblue_settings_by_user('sendinblue_lists', $arr_sendinblue_lists);

        return $arr_sendinblue_lists;
    }

}

if (!function_exists('get_event_organization_form_field_lists')) {

    /**
     * Get event registration form fields
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_event_organization_form_field_lists() {

        // organizer fields
        $GLOBALS['event_manager']
                ->forms
                ->get_form('submit-organizer', array());
        $form_submit_organizer_instance = call_user_func(array(
            'WP_Event_Manager_Form_Submit_Organizer',
            'instance'
        ));
        $organizer_form_fields = $form_submit_organizer_instance->merge_with_custom_fields('frontend');

        $organizer_fields = $organizer_form_fields['organizer'];

        return $organizer_fields;
    }

}

if (!function_exists('get_sendinblue_list_static_field')) {

    /**
     * Event Sendinblue List Static Field
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_list_static_field() {
        $fields = array(
            'email' => __('Email', 'wp-event-manager-sendinblue'),
            'FIRSTNAME' => __('First Name', 'wp-event-manager-sendinblue'),
            'LASTNAME' => __('Last Name', 'wp-event-manager-sendinblue'),
            'SMS' => __('Phone', 'wp-event-manager-sendinblue'),
        );

        $fields = apply_filters('sendinblue_list_static_field', $fields);

        return $fields;
    }

}

if (!function_exists('get_sendinblue_list_dynamic_field')) {

    /**
     * Event Sendinblue List dynamin Field
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_list_dynamic_field($sendinblue_api_key = '', $sendinblue_list = '') {
        $user_id = get_current_user_id();

        if ($sendinblue_api_key != '' && $sendinblue_list != '') {
            $fields = get_sync_fields_by_user($user_id, 'sendinblue_list_dynamic_field_' . $sendinblue_list);

            if (empty($fields)) {
                $args = ['method' => 'GET', 'headers' => ['content-type' => 'application/json', 'api-key' => $sendinblue_api_key]];

                $end_point = 'contacts/lists/';

                $response_body = sendinblue_request($sendinblue_api_key, $end_point, $args);

                $fields = [
                    'email' => __('Email', 'wp-event-manager-sendinblue'),
                ];

                if (!empty($response_body['attributes'])) {
                    foreach ($response_body['attributes'] as $field) {

                        $fields[$field['tag']] = sprintf(__('%s', 'wp-event-manager-sendinblue'), $field['name']);
                    }
                }

                $fields['FIRSTNAME'] = __('First Name', 'wp-event-manager-sendinblue');
                $fields['LASTNAME'] = __('Last Name', 'wp-event-manager-sendinblue');
                $fields['SMS'] = __('Phone', 'wp-event-manager-sendinblue');


                update_sendinblue_settings_by_user('sendinblue_list_dynamic_field_' . $sendinblue_list, $fields);
            }
        } else {
            $fields = get_sendinblue_list_static_field();
        }

        $fields = apply_filters('sendinblue_list_dynamic_field', $fields);

        return $fields;
    }

}

if (!function_exists('get_sendinblue_field_static_format')) {

    /**
     * Sendinblue List static Field format
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_field_static_format() {
        return apply_filters('sendinblue_field_static_format', array(
            'email' => __('Email', 'wp-event-manager-sendinblue'),
            'status' => __('Status', 'wp-event-manager-sendinblue'),
            'attributes' => array(
                'FIRSTNAME' => __('First Name', 'wp-event-manager-sendinblue'),
                'LASTNAME' => __('Last Name', 'wp-event-manager-sendinblue'),
                'SMS' => __('Phone', 'wp-event-manager-sendinblue'),
            ),
        ));
    }

}

if (!function_exists('get_sendinblue_field_dynamic_format')) {

    /**
     * Event Sendinblue List Field
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sendinblue_field_dynamic_format($sendinblue_api_key = '', $sendinblue_list = '') {
        if ($sendinblue_api_key != '' && $sendinblue_list != '') {
            $args = ['method' => 'GET', 'headers' => ['content-type' => 'application/json', 'api-key' => $sendinblue_api_key]];

            $end_point = 'contacts/lists/';

            $response_body = sendinblue_request($sendinblue_api_key, $end_point, $args);

            $fields = [
                'email' => __('Email', 'wp-event-manager-sendinblue'),
                'status' => __('Status', 'wp-event-manager-sendinblue'),
                'attributes' => array(
                    'FIRSTNAME' => __('First Name', 'wp-event-manager-sendinblue'),
                    'LASTNAME' => __('Last Name', 'wp-event-manager-sendinblue'),
                    'SMS' => __('Phone', 'wp-event-manager-sendinblue'),
                ),];

            if (!empty($response_body['attributes'])) {
                foreach ($response_body['attributes'] as $field) {
                    $fields['attributes'][$field['tag']] = __($field['name'], 'wp-event-manager-sendinblue');
                }
            }
        } else {
            $fields = get_sendinblue_field_static_format();
        }

        return $fields;
    }

}

if (!function_exists('get_default_sendinblue_registration_matches_attribute')) {

    /**
     * Default Sendinblue Registration Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_sendinblue_registration_matches_attribute() {
        $registration_sendinblue_field = [];

        $registration_form_field = get_event_registration_form_fields();

        foreach ($registration_form_field as $key => $field) {
            if (in_array('from_email', $field['rules'])) {
                $registration_sendinblue_field['email'] = $key;
            } else if (in_array('from_name', $field['rules'])) {
                $registration_sendinblue_field['FIRSTNAME'] = $key;
            }
        }

        return $registration_sendinblue_field;
    }

}

if (!function_exists('get_default_sendinblue_organizer_matches_attribute')) {

    /**
     * Default Sendinblue Organizer Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_sendinblue_organizer_matches_attribute() {
        $organizer_sendinblue_field = [];

        $organizer_sendinblue_field['email'] = 'organizer_email';
        $organizer_sendinblue_field['FIRSTNAME'] = 'organizer_name';

        return $organizer_sendinblue_field;
    }

}

if (!function_exists('get_event_by_user_id')) {

    /**
     * Get event by user id
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_event_by_user_id($user_id = '') {
        return get_posts(array(
            'posts_per_page' => - 1,
            'post_type' => 'event_listing',
            'post_status' => 'publish',
            'suppress_filters' => 'false',
            'author' => $user_id,
            'fields' => 'ids',
        ));
    }

}

if (!function_exists('get_registration_attendee_list')) {

    /**
     * Get event registration attendee list
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_registration_attendee_list($atts = [], $filters = []) {
        $user_id = get_current_user_id();

        extract($atts = shortcode_atts(array(
            'event_id' => '',
            'posts_per_page' => 20,
            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                ), $atts));

        $registration_sendinblue_field = get_sendinblue_sync_fields_by_user($user_id, 'registration_sendinblue_field');
        if (empty($registration_sendinblue_field)) {
            $registration_sendinblue_field = get_default_sendinblue_registration_matches_attribute();
        }

        $args = array(
            'post_type' => 'event_registration',
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'post_parent' => $event_id,
            'author' => $user_id,
            'meta_query' => ['relation' => 'AND',
            ]
        );

        if (isset($registration_sendinblue_field['email']) && !empty($registration_sendinblue_field['email'])) {
            $args['meta_query'][] = ['key' => $registration_sendinblue_field['email'], 'value' => '', 'compare' => '!='];
        }

        if (!empty($filters)) {
            foreach ($filters as $key => $value) {
                if ($key != '' && $value != '') {
                    $args['meta_query'][] = ['key' => $key, 'value' => $value, 'compare' => 'LIKE',];
                }
            }
        }

        $registrations = new WP_Query($args);

        return $registrations;
    }

}

if (!function_exists('get_guest_lists_guest_list')) {

    /**
     * Get event registration attendee list
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_guest_lists_guest_list($atts = [], $filters = []) {
        $user_id = get_current_user_id();

        extract($atts = shortcode_atts(array(
            'event_id' => '',
            'posts_per_page' => 20,
            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                ), $atts));

        $guest_list_sendinblue_field = get_sendinblue_sync_fields_by_user($user_id, 'guest_list_sendinblue_field');
        if (empty($guest_list_sendinblue_field)) {
            $guest_list_sendinblue_field = get_default_sendinblue_guest_list_matches_attribute();
        }

        $args = array(
            'post_type' => 'event_guest_list',
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'post_parent' => $event_id,
            'author' => $user_id,
            'meta_query' => [
                'relation' => 'AND',
            ]
        );

        if (isset($guest_list_sendinblue_field['email']) && !empty($guest_list_sendinblue_field['email'])) {
            $args['meta_query'][] = ['key' => $guest_list_sendinblue_field['email'], 'value' => '', 'compare' => '!='];
        }

        if (!empty($filters)) {
            foreach ($filters as $key => $value) {
                if ($key != '' && $value != '') {
                    $args['meta_query'][] = ['key' => $key, 'value' => $value, 'compare' => 'LIKE',];
                }
            }
        }

        $guests = new WP_Query($args);

        return $guests;
    }

}

if (!function_exists('sync_data_in_sendinblue_list')) {

    /**
     * Sync attendees in sendinblue
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function sync_data_in_sendinblue_list($sendinblue_api_key = '', $sendinblue_list = '', $registration_sendinblue_field = [], $post_id = '') {
        $response_body = [];

        if ($sendinblue_api_key != '' && $sendinblue_list != '' && !empty($registration_sendinblue_field) && $post_id != '') {
            $params = [];
            $field_sendinblue = get_sendinblue_field_dynamic_format($sendinblue_api_key, $sendinblue_list);

            foreach ($field_sendinblue as $field_name => $field_value) {
                if (is_array($field_value)) {
                    foreach ($field_value as $field_name2 => $field_value2) {
                        if (is_array($field_value2)) {
                            foreach ($field_value2 as $field_name3 => $field_value3) {
                                if (array_key_exists($field_name3, $registration_sendinblue_field)) {
                                    $params[$field_name][$field_name2][$field_name3] = get_post_meta($post_id, $registration_sendinblue_field[$field_name3], true);
                                }
                            }
                        } else {
                            if (array_key_exists($field_name2, $registration_sendinblue_field)) {
                                $params[$field_name][$field_name2] = get_post_meta($post_id, $registration_sendinblue_field[$field_name2], true);
                            }
                        }
                    }
                } else {
                    if (array_key_exists($field_name, $registration_sendinblue_field)) {
                        $params[$field_name] = get_post_meta($post_id, $registration_sendinblue_field[$field_name], true);
                    }
                }
            }

            $params['listIds'] = array_map('intval', array($sendinblue_list));

            $params['status'] = 'subscribed';
            $args = [
                'method' => 'POST',
                'headers' => [
                    'Accept' => 'application/json',
                    'content-type' => 'application/json',
                    'api-key' => $sendinblue_api_key
                ],
                'body' => json_encode($params)
            ];
            $end_point = '/contacts/';
            $response_body = sendinblue_request($sendinblue_api_key, $end_point, $args);
        }
        return $response_body;
    }

}

if (!function_exists('add_attendees_in_sendinblue_list')) {

    /**
     * Add attendees in sendinblue
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function add_attendees_in_sendinblue_list($user_id = '', $arr_attendees_id = []) {
        $response = [];

        if ($user_id != '' && !empty($arr_attendees_id)) {
            $sendinblue_settings = get_sendinblue_settings_by_user_id($user_id);

            $sendinblue_api_key = isset($sendinblue_settings['sendinblue_api_key']) ? $sendinblue_settings['sendinblue_api_key'] : '';
            $sendinblue_list = isset($sendinblue_settings['sendinblue_list']) ? $sendinblue_settings['sendinblue_list'] : 0;

            $registration_field = get_sync_fields_by_user($user_id, 'registration_field');

            $registration_sendinblue_field = get_sendinblue_sync_fields_by_user($user_id, 'registration_sendinblue_field');

            if (empty($registration_sendinblue_field)) {
                $registration_sendinblue_field = get_default_sendinblue_registration_matches_attribute();
            }

            foreach ($arr_attendees_id as $attendees_id) {
                $_is_sendinblue_sync = get_post_meta($attendees_id, '_is_sendinblue_sync', true);

                $attendees = get_post($attendees_id);
                if (!empty($attendees)) {
                    if (isset($sendinblue_settings['sendinblue_list']) && $sendinblue_settings['sendinblue_list'] == false) {
                        $event_id = $attendees->post_parent;
                        $event_sendinblue_list = get_post_meta($event_id, 'sendinblue_list', true);
                        if ($event_sendinblue_list == false) {
                            $response['message'] = __('Synchronization disabled for this event.', 'wp-event-manager-sendinblue');
                            continue;
                        }

                        if (!empty($event_sendinblue_list)) {
                            $sendinblue_list = $event_sendinblue_list;
                        }
                    }
                }

                if ($_is_sendinblue_sync != 'subscribed') {

                    $result = sync_data_in_sendinblue_list($sendinblue_api_key, $sendinblue_list, $registration_sendinblue_field, $attendees_id);

                    if (isset($result['id']) && $result['id'] != '') {
                        update_post_meta($attendees_id, '_is_sendinblue_sync', 'subscribed');
                    }
                    if (isset($result['code']) && ($result['code'] == 'duplicate_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else if (isset($result['code']) && ($result['code'] == 'invalid_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else {
                        $response['code'] = 200;
                        $response['message'] = __('Subscribed', 'wp-event-manager-sendinblue');
                    }
                } else {
                    $response['code'] = 400;
                    $response['message'] = __('The contact already exists.', 'wp-event-manager-sendinblue');
                }
            }
        }

        return $response;
    }

}

if (!function_exists('add_guests_in_sendinblue_list')) {

    /**
     * Add guests in sendinblue
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function add_guests_in_sendinblue_list($user_id = '', $arr_guests_id = []) {
        $response = [];

        if ($user_id != '' && !empty($arr_guests_id)) {
            $sendinblue_settings = get_sendinblue_settings_by_user_id($user_id);

            $sendinblue_api_key = isset($sendinblue_settings['sendinblue_api_key']) ? $sendinblue_settings['sendinblue_api_key'] : '';
            $sendinblue_list = isset($sendinblue_settings['sendinblue_list']) ? $sendinblue_settings['sendinblue_list'] : 0;

            $guest_list_field = get_sync_fields_by_user($user_id, 'guest_list_field');
            $guest_list_sendinblue_field = get_sendinblue_sync_fields_by_user($user_id, 'guest_list_sendinblue_field');

            if (empty($guest_list_sendinblue_field)) {
                $guest_list_sendinblue_field = get_default_sendinblue_guest_list_matches_attribute();
            }

            foreach ($arr_guests_id as $guest_id) {
                $_is_sendinblue_sync = get_post_meta($guest_id, '_is_sendinblue_sync', true);

                $guest = get_post($guest_id);
                if (!empty($guest)) {

                    if (isset($sendinblue_settings['sendinblue_list']) && $sendinblue_settings['sendinblue_list'] == false) {
                        $event_id = $guest->post_parent;
                        $event_sendinblue_list = get_post_meta($event_id, 'sendinblue_list', true);

                        if ($event_sendinblue_list == false) {
                            $response['message'] = __('Synchronization disabled for this event.', 'wp-event-manager-sendinblue');
                            continue;
                        }

                        if (!empty($event_sendinblue_list)) {
                            $sendinblue_list = $event_sendinblue_list;
                        }
                    }
                }

                if ($_is_sendinblue_sync != 'subscribed') {
                    $result = sync_data_in_sendinblue_list($sendinblue_api_key, $sendinblue_list, $guest_list_sendinblue_field, $guest_id);

                    if (isset($result['id']) && $result['id'] != '') {
                        update_post_meta($guest_id, '_is_sendinblue_sync', 'subscribed');
                    }
                    if (isset($result['code']) && ($result['code'] == 'duplicate_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else if (isset($result['code']) && ($result['code'] == 'invalid_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else {
                        $response['code'] = 200;
                        $response['message'] = __('Subscribed', 'wp-event-manager-sendinblue');
                    }
                } else {
                    $response['code'] = 200;
                    $response['message'] = __('The contact already exists.', 'wp-event-manager-sendinblue');
                }
            }
        }

        return $response;
    }

}

if (!function_exists('sync_data_in_sendinblue_list_2')) {

    /**
     * Sync attendees in sendinblue
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function sync_data_in_sendinblue_list_2($sendinblue_api_key = '', $sendinblue_list = '', $registration_sendinblue_field = [], $data = []) {
        $response_body = [];

        if ($sendinblue_api_key != '' && $sendinblue_list != '' && !empty($registration_sendinblue_field) && $data != '') {
            $params = [];
            $field_sendinblue = get_sendinblue_field_dynamic_format($sendinblue_api_key, $sendinblue_list);

            foreach ($field_sendinblue as $field_name => $field_value) {
                if (is_array($field_value)) {
                    foreach ($field_value as $field_name2 => $field_value2) {
                        if (is_array($field_value2)) {
                            foreach ($field_value2 as $field_name3 => $field_value3) {
                                if (array_key_exists($field_name3, $registration_sendinblue_field)) {
                                    $params[$field_name][$field_name2][$field_name3] = $data[$registration_sendinblue_field[$field_name3]];
                                }
                            }
                        } else {
                            if (array_key_exists($field_name2, $registration_sendinblue_field)) {
                                $vdata = isset($data[$registration_sendinblue_field[$field_name2]]) ? $data[$registration_sendinblue_field[$field_name2]] : '' ;
                                $params[$field_name][$field_name2] = $vdata;
                            }
                        }
                    }
                } else {
                    if (array_key_exists($field_name, $registration_sendinblue_field)) {
                        $params[$field_name] = $data[$registration_sendinblue_field[$field_name]];
                    }
                }
            }

            $params['listIds'] = array_map('intval', array($sendinblue_list));

            $params['status'] = 'subscribed';

            $args = ['method' => 'POST', 'headers' => ['Accept' => 'application/json', 'content-type' => 'application/json', 'api-key' => $sendinblue_api_key], 'body' => json_encode($params)];

            $end_point = '/contacts/';

            $response_body = sendinblue_request($sendinblue_api_key, $end_point, $args);
        }
        return $response_body;
    }

}

/**
 * add sendinblue cron schedules
 *
 * @access public
 * @param
 * @return array
 * @since 1.0.0
 */
add_filter('cron_schedules', 'sendinblue_cron_schedules');

function sendinblue_cron_schedules($schedules) {
    if (!isset($schedules["5min"])) {
        $schedules["5min"] = array(
            'interval' => 5 * 60,
            'display' => __('5 Min', 'wp-event-manager-sendinblue')
        );
    }
    if (!isset($schedules["weekly"])) {
        $schedules["weekly"] = array(
            'interval' => 60 * 60 * 24 * 7,
            'display' => __('Once Weekly', 'wp-event-manager-sendinblue')
        );
    }
    if (!isset($schedules["monthly"])) {
        $schedules["monthly"] = array(
            'interval' => 60 * 60 * 24 * 30,
            'display' => __('Once Monthly', 'wp-event-manager-sendinblue')
        );
    }
    if (!isset($schedules["yearly"])) {
        $schedules["yearly"] = array(
            'interval' => 60 * 60 * 24 * 365,
            'display' => __('Once Yearly', 'wp-event-manager-sendinblue')
        );
    }
    return $schedules;
}

if (!function_exists('get_default_sendinblue_guest_list_matches_attribute')) {

    /**
     * Default Sendinblue guest_list Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_sendinblue_guest_list_matches_attribute() {
        $guest_list_sendinblue_field = [];

        $guest_list_form_field = get_event_guest_lists_form_fields();

        foreach ($guest_list_form_field as $key => $field) {
            if (in_array('from_email', $field['rules'])) {
                $guest_list_sendinblue_field['email'] = $key;
            } else if (in_array('from_name', $field['rules'])) {
                $guest_list_sendinblue_field['FIRSTNAME'] = $key;
            }
        }

        return $guest_list_sendinblue_field;
    }

}

if (!function_exists('get_default_sendinblue_contact_organizer_matches_attribute')) {

    /**
     * Default Sendinblue contact_organizer Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_sendinblue_contact_organizer_matches_attribute() {
        $guest_list_sendinblue_field = [];

        $guest_list_form_field = get_contact_organizer_form_fields();

        foreach ($guest_list_form_field as $key => $field) {
            if (isset($field['rules']) && in_array('from_email', $field['rules'])) {
                $guest_list_sendinblue_field['email'] = $key;
            } else if (isset($field['rules']) && in_array('from_name', $field['rules'])) {
                $guest_list_sendinblue_field['FIRSTNAME'] = $key;
            }
        }

        return $guest_list_sendinblue_field;
    }

}

/**
 * event_manager_auto_sendinblue_sync_admin_callback function.
 *
 * @access public
 * @param mixed $arr_post_type
 * @return void
 * @since 1.0.0
 */
function event_manager_auto_sendinblue_sync_admin_callback($arr_post_type = []) {
    $args = array(
        'post_type' => $arr_post_type,
        'posts_per_page' => - 1,
    );

    $result = new WP_Query($args);
    $response = [];

    if ($result->found_posts > 0) {
        $sendinblue_api_key = get_option('sendinblue_settings')['sendinblue_api_key'];
        $sendinblue_list = get_option('sendinblue_settings')['sendinblue_list'];
        $sendinblue_sync_type = get_option('sendinblue_settings')['sendinblue_sync_type'];

        $organizer_sendinblue_field = get_option('organizer_sendinblue_field');
        $registration_sendinblue_field = get_option('registration_sendinblue_field');
        $guest_list_sendinblue_field = get_option('guest_list_sendinblue_field');


        foreach ($result->posts as $result) {

            if (isset(get_option('sendinblue_settings')['sendinblue_list']) && get_option('sendinblue_settings')['sendinblue_list'] == false) {
                $event_id = $result->post_parent;
                $event_sendinblue_list = get_post_meta($event_id, 'sendinblue_list', true);
                if ($event_sendinblue_list == false) {
                    $response['message'] = __('Synchronization disabled for this event.', 'wp-event-manager-sendinblue');
                    continue;
                }

                if (!empty($event_sendinblue_list)) {
                    $sendinblue_list = $event_sendinblue_list;
                }
            }

            if ($result->post_type == 'event_organizer') {
                $sendinblue_sync_field = $organizer_sendinblue_field;

                if (empty($sendinblue_sync_field)) {
                    $sendinblue_sync_field = get_default_sendinblue_organizer_matches_attribute();
                }

            } else if ($result->post_type == 'event_registration') {

                $sendinblue_sync_field = $registration_sendinblue_field;

                if (empty($sendinblue_sync_field)) {
                    $sendinblue_sync_field = get_default_sendinblue_registration_matches_attribute();
                }
            } else if ($result->post_type == 'event_guest_list') {

                $sendinblue_sync_field = $guest_list_sendinblue_field;

                if (empty($sendinblue_sync_field)) {
                    $sendinblue_sync_field = get_default_sendinblue_guest_list_matches_attribute();
                }
            }

            sync_data_in_sendinblue_list($sendinblue_api_key, $sendinblue_list, $sendinblue_sync_field, $result->ID);
        }
    }
}
