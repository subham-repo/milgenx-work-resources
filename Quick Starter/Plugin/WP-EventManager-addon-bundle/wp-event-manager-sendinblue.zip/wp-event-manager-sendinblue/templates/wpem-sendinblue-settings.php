<div id="wpem_sendinblue" class="wpem-sendinblue">

    <?php do_action('wpem_sendinblue_dashboard_before'); ?>

    <?php $check_sendinblue_key = check_sendinblue_key($sendinblue_api_key); ?>

    <?php if (isset($check_sendinblue_key['code']) && $check_sendinblue_key['code'] == "unauthorized") { ?>

        <p class="event-manager-message wpem-alert wpem-alert-danger">
            <?php echo __('The API key entered is invalid.', 'wp-event-manager-sendinblue'); ?>
        </p>

    <?php } ?>

    <div class="wpem-main wpem-sendinblue-wrapper event-sendinblue">
        <div class="wpem-sendinblue-matches-attribute-header wpem-form-wrapper">
            <h3 class="wpem-form-title wpem-heading-text"><?php _e('Sendinblue Settings', 'wp-event-manager-sendinblue'); ?></h3>

            <?php
            if (isset($check_sendinblue_key['count']) && $check_sendinblue_key['count'] > 0) :
                ?>
                <form class="wpem-sendinblue-disconnect wpem-form-wrapper" method="POST">

                    <input type="hidden" name="action" value="show_sendinblue" />
                    <?php if (!empty($_GET['page_id'])) : ?>
                        <input type="hidden" name="page_id" value="<?php echo absint($_GET['page_id']); ?>" />
                    <?php endif; ?>

                    <button type="submit" name="wp_event_manager_sendinblue_disconnect" class="wpem-theme-button wpem-theme-button-disconnect" value="<?php esc_attr_e('Disconnect', 'wp-event-manager-sendinblue'); ?>"><?php esc_attr_e('Disconnect', 'wp-event-manager-sendinblue'); ?></button>

                    <?php wp_nonce_field('event_manager_sendinblue_disconnect'); ?>

                </form>
            <?php endif; ?>
        </div>
        <div class="wpem-sendinblue-body">
            <form class="wpem-sendinblue wpem-form-wrapper" method="POST">
                <div class="wpem-sendinblue-field">
                    <div class="wpem-row">

                        <?php
                        $style = '';
                        if ($sendinblue_api_key != '') {
                            if (isset($check_sendinblue_key['code']) && $check_sendinblue_key['code'] == "unauthorized") {
                                $style = 'style="display: block;"';
                            } else {
                                $style = 'style="display: none;"';
                            }
                        }
                        ?>
                        <div class="wpem-col-md-6" <?php echo $style; ?>>
                            <div class="wpem-form-group">
                                <?php
                                $readonly = '';
                                if ($sendinblue_api_key != '') {
                                    if (isset($check_sendinblue_key['code']) && $check_sendinblue_key['code'] != "unauthorized") {
                                        $readonly = 'readonly';
                                    }
                                }
                                ?>
                                <input type="text" name="sendinblue_api_key" id="sendinblue-api-key" class="sendinblue-api-key" placeholder="<?php _e('Enter Sendinblue API Key', 'wp-event-manager-sendinblue'); ?>" value="<?php echo $sendinblue_api_key; ?>" <?php echo $readonly; ?> />
                            </div>
                        </div>

                        <?php if (isset($check_sendinblue_key['code']) && $check_sendinblue_key['code'] == "unauthorized") : ?>
                        <?php else : ?>
                            <?php if (!empty($sendinblue_api_key)) : ?>
                                <div class="wpem-col-md-6">
                                    <div class="wpem-form-group">
                                        <select name="sendinblue_list" class="sendinblue-list" >
                                            <?php foreach (get_sendinblue_lists($sendinblue_api_key) as $id => $label) : ?>
                                                <option value="<?php echo esc_attr($id); ?>" <?php selected($sendinblue_list, $id); ?>><?php echo esc_html($label); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if (!empty($sendinblue_api_key)) : ?>
                                    <div class="wpem-col-md-6">
                                        <div class="wpem-form-group">
                                            <select required name="sendinblue_sync_type" class="sendinblue-sync-type" id="sendinblue-sync-type">
                                                <option value=""><?php _e('Select Sendinblue Sync Type', 'wp-event-manager-sendinblue'); ?>...</option>
                                                <?php foreach (get_sendinblue_sync_type() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($sendinblue_sync_type, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php
                                    $style = '';
                                    if ($sendinblue_sync_type == 'manual') {
                                        $style = 'style="display: none;"';
                                    }
                                    ?>
                                    <div class="wpem-col-md-6" id="sendinblue_sync_via" <?php echo $style; ?>>
                                        <div class="wpem-form-group">
                                            <select name="sendinblue_sync_via" class="sendinblue-sync-via" id="sendinblue-sync-via">
                                                <option value=""><?php _e('Select Sendinblue Sync Via', 'wp-event-manager-sendinblue'); ?>...</option>
                                                <?php foreach (get_sendinblue_sync_via() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($sendinblue_sync_via, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <?php
                                    $style = '';
                                    if ($sendinblue_sync_type == 'manual' || $sendinblue_sync_via == 'when_created') {
                                        $style = 'style="display: none;"';
                                    }
                                    ?>
                                    <div class="wpem-col-md-6" id="sendinblue_sync_schedule" <?php echo $style; ?>>
                                        <div class="wpem-form-group">
                                            <select name="sendinblue_sync_schedule" class="sendinblue-sync-schedule" id="sendinblue-sync-schedule">
                                                <option value=""><?php _e('Select Sendinblue Sync Schedule', 'wp-event-manager-sendinblue'); ?>...</option>
                                                <?php foreach (get_sendinblue_sync_schedule() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($sendinblue_sync_schedule, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                <?php endif; ?>
                            <?php endif; ?>

                        <?php endif; ?>

                        <div class="wpem-col-12">
                            <div class="wpem-form-group">
                                <input type="hidden" name="action" value="show_sendinblue" />
                                <button type="submit" name="wp_event_manager_sendinblue" class="wpem-theme-button" value="<?php esc_attr_e('Save Setting', 'wp-event-manager-sendinblue'); ?>"><?php esc_attr_e('Save Setting', 'wp-event-manager-sendinblue'); ?></button>

                                <?php wp_nonce_field('event_manager_sendinblue'); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>

    <?php do_action('wpem_sendinblue_dashboard_after'); ?>

</div>
