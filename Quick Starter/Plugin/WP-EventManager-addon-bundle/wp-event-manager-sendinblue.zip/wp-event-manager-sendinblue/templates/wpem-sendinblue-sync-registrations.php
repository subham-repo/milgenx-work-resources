<div id="wpem-sendinblue-sync-registrations" class="wpem-sendinblue-sync-registrations">
    
    <p class="event-manager-message wpem-alert wpem-alert-danger" style="display: none;">
        <?php _e('Please Select Attendees to sync.', 'wp-event-manager-sendinblue'); ?>
    </p>
    
    <div class="wpem-main wpem-sendinblue-sync-wrapper event-sendinblue-sync">
        <div class="wpem-sendinblue-sync-header wpem-form-wrapper">
            <h3 class="wpem-form-title wpem-heading-text"><?php _e('Sync Attendees', 'wp-event-manager-sendinblue'); ?></h3>
        </div>

        <div class="wpem-sendinblue-sync-body wpem-dashboard-main-header">

            <form method="GET" class="wpem-sendinblue-sync-list-filter wpem-form-wrapper">
                <div class="wpem-events-filter">
                    <div class="wpem-events-filter-block">
                        <div class="wpem-form-group">
                            <select name="event_id" id="event_id">
                                <option value=""><?php _e('Select Event', 'wp-event-manager'); ?></option>
                                <?php if (!empty($events)) : ?>
                                    <?php foreach ($events as $key => $event) : ?>
                                        <option value="<?php echo esc_html($event->ID); ?>" <?php selected($event_id, $event->ID); ?>><?php echo esc_html($event->post_title); ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="wpem-events-filter-block">
                        <div class="wpem-form-group">
                            <select name="sync_filter_field" class="registration-field">
                                <option value=""><?php _e('Select field', 'wp-event-manager-sendinblue'); ?>...</option>
                                <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_filter_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="wpem-events-filter-block">
                        <div class="wpem-form-group">
                            <input type="text" name="sync_filter_value" placeholder="<?php _e('Enter value', 'wp-event-manager-sendinblue'); ?>" value="<?php echo $sync_filter_value; ?>" />
                        </div>
                    </div>
                    <div class="wpem-events-filter-block wpem-events-filter-submit">
                        <div class="wpem-form-group">
                            <input type="hidden" name="action" value="wpem_sendinblue_sync_registrations" />

                            <button type="submit" class="wpem-theme-button" name="wpem_sendinblue_filter" value="<?php esc_attr_e('Filter', 'wp-event-manager-sendinblue'); ?>"><?php _e('Filter', 'wp-event-manager-sendinblue'); ?></button>
                        </div>
                    </div>
                </div>
            </form>

            <form method="post" class="wpem-sendinblue-sync-attendees">
                <div class="wpem-scrollable-table-block">
                    <table class="wpem-main">
                        <thead>
                            <tr>
                                <th class="wpem-heading-text">
                                    <input type="checkbox" id="all_select">
                                    <input type="hidden" name="attendees_ids" id="attendees_ids" value="">
                                </th>
                                <?php
                                $fields = get_sendinblue_list_dynamic_field($sendinblue_api_key, $sendinblue_list);

                                foreach ($registration_sendinblue_field as $sync_field => $form_field) {
                                    echo '<th class="wpem-heading-text">' . $fields[$sync_field] . '</th>';
                                }
                                ?>
                                <th class="wpem-heading-text"><?php _e('Sendinblue Sync', 'wp-event-manager-sendinblue'); ?></th>
                            </tr>
                        </thead>

                        <?php
                        if ($total_registrations > 0) {
                            foreach ($registrations as $registration) {
                                echo '<tr class="attendees-id-' . $registration->ID . '">';

                                echo '<td><input type="checkbox" class="attende-id" name="attendees_id[]" value="' . $registration->ID . '" ></td>';
                                foreach ($registration_sendinblue_field as $form_field) {
                                    $field_value = get_post_meta($registration->ID, $form_field, true);
                                    echo '<td data-title="">' . $field_value . '</td>';
                                }

                                $_is_sendinblue_sync = get_post_meta($registration->ID, "_is_sendinblue_sync", true);
                                if ($_is_sendinblue_sync == '') {
                                    $_is_sendinblue_sync = __('-', 'wp-event-manager-sendinblue');
                                }
                                echo '<td class="sync-status">' . $_is_sendinblue_sync . '</td>';

                                echo '</tr>';
                            }
                        } else {
                            echo '<tr>';
                            echo '<td colspan="' . count($registration_sendinblue_field) . '">' . __('No records found.', 'wp-event-manager-sendinblue') . '</td>';
                            echo '</tr>';
                        }
                        ?>
                        <tfoot>
                            <?php $count = count($registration_sendinblue_field); ?>
                            <?php $count = $count + 2; ?>
                            <tr>
                                <td colspan="2">
                                    <input type="hidden" name="event_id" id="event_id" value="<?php echo absint($event_id); ?>" />
                                    <button type="button" class="wpem-theme-button sync-attendees-button" id="sync-attendees-button"><?php _e('Sync', 'wp-event-manager-sendinblue'); ?></button>
                                    <?php wp_nonce_field('event_manager_sendinblue_sync_attendees'); ?>
                                </td>
                                <td  colspan="<?php echo $count; ?>"></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </form>

            <?php
            get_event_manager_template(
                    'pagination.php',
                    array(
                        'max_num_pages' => $max_num_pages
                    )
            );
            ?>

            <?php wp_reset_postdata(); ?>
        </div>

    </div>

</div>
