<?php

/*
  Plugin Name: WP Event Manager - Sendinblue
  Plugin URI: http://www.wp-eventmanager.com/plugins/

  Description: The WP event manager Sendinblue  plugin helps you grow Sendinblue lists as it automates the Syncing process of the registered attendee data of your WordPress website in your Sendinblue list.
  Author: WP Event Manager
  Author URI: http://www.wp-eventmanager.com

  Text Domain: wp-event-manager-sendinblue
  Domain Path: /languages
  Version: 1.0.0
  Since: 1.0.0

  Requires WordPress Version at least: 4.1
  Copyright: 2019 WP Event Manager
  License: GNU General Public License v3.0
  License URI: http://www.gnu.org/licenses/gpl-3.0.html

 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WPEM_Updater')) {
    include( 'autoupdater/wpem-updater.php' );
}

include_once(ABSPATH . 'wp-admin/includes/plugin.php');

function pre_check_before_installing_sendinblue() {
    /*
     * Check weather WP Event Manager is installed or not
     */
    if (!is_plugin_active('wp-event-manager/wp-event-manager.php')) {
        global $pagenow;
        if ($pagenow == 'plugins.php') {
            echo '<div id="error" class="error notice is-dismissible"><p>';
            echo __('WP Event Manager is require to use WP Event Manager - Sendinblue', 'wp-event-manager-sendinblue');
            echo '</p></div>';
        }
        return false;
    }
}

add_action('admin_notices', 'pre_check_before_installing_sendinblue');

/**
 * WPEM_Sendinblue_Integration class.
 */
class WPEM_Sendinblue extends WPEM_Updater {

    /**
     * The single instance of the class.
     *
     * @var self
     * @since  1.0
     */
    private static $_instance = null;

    /**
     * Main WP Event Manager Sendinblue Instance.
     *
     * Ensures only one instance of WP Event Manager Sendinblue is loaded or can be loaded.
     *
     * @since  1.0
     * @static
     * @see WPEM_Sendinblue()
     * @return self Main instance.
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * __construct function.
     */
    public function __construct() {
        //if wp event manager not active return from the plugin
        if (!is_plugin_active('wp-event-manager/wp-event-manager.php'))
            return;

        // Define constants
        define('WPEM_SENDINBLUE_VERSION', '1.0.0');
        define('WPEM_SENDINBLUE_FILE', __FILE__);
        define('WPEM_SENDINBLUE_PLUGIN_DIR', untrailingslashit(plugin_dir_path(__FILE__)));
        define('WPEM_SENDINBLUE_PLUGIN_URL', untrailingslashit(plugins_url(basename(plugin_dir_path(__FILE__)), basename(__FILE__))));


        include( 'wp-event-manager-sendinblue-functions.php' );

        //includes
        include( 'includes/wpem-sendinblue-install.php' );
        include( 'includes/wpem-sendinblue-dashboard.php' );
        if (is_plugin_active('wp-event-manager-registrations/wp-event-manager-registrations.php')) {
            include( 'includes/wpem-sendinblue-registrations.php' );
        }
        if (is_plugin_active('wp-event-manager-guest-lists/wp-event-manager-guest-lists.php')) {
            include( 'includes/wpem-sendinblue-guest-lists.php' );
        }
        if (is_plugin_active('wp-event-manager-contact-organizer/wp-event-manager-contact-organizer.php')) {
            include( 'includes/wpem-sendinblue-contact-organizer.php' );
        }

        if (is_admin()) {
            include( 'admin/wpem-sendinblue-admin.php' );
        }

        // admin cron
        add_action('event_manager_auto_sendinblue_sync_admin', 'event_manager_auto_sendinblue_sync_admin_callback');

        // Activation - works with symlinks
        register_activation_hook(basename(dirname(__FILE__)) . '/' . basename(__FILE__), array($this, 'activate'));

        // Add actions
        add_action('init', array($this, 'load_plugin_textdomain'), 12);

        add_action('admin_init', array($this, 'updater'));
    }

    /**
     * activate function.
     *
     * @access public
     * @param 
     * @return 
     * @since 1.0
     */
    public function activate() {

        WPEM_Sendinblue_Install::install();
    }

    /**
     * updater function.
     *
     * @access public
     * @param 
     * @return 
     * @since 1.0
     */
    public function updater() {
        if (version_compare(WPEM_SENDINBLUE_VERSION, get_option('wpem_sendinblue_version'), '>')) {

            WPEM_Sendinblue_Install::install();
            flush_rewrite_rules();
        }
    }

    /**
     * Localisation
     * */
    public function load_plugin_textdomain() {
        $domain = 'wp-event-manager-sendinblue';
        $locale = apply_filters('plugin_locale', get_locale(), $domain);
        load_textdomain($domain, WP_LANG_DIR . "/wp-event-manager-sendinblue/" . $domain . "-" . $locale . ".mo");
        load_plugin_textdomain($domain, false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }

}

/**
 * Main instance of WP Event Manager Sendinblue.
 *
 * Returns the main instance of WP Event Manager Sendinblue to prevent the need to use globals.
 *
 * @since  1.0
 * @return WPEM_Sendinblue_
 */
function WPEM_Sendinblue() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName
    return WPEM_Sendinblue::instance();
}

$GLOBALS['event_manager_sendinblue'] = WPEM_Sendinblue();
