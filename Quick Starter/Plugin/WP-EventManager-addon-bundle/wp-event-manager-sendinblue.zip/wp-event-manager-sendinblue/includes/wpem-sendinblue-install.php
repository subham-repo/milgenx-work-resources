<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Sendinblue_Install class.
 */
class WPEM_Sendinblue_Install {

    /**
     * install function.
     *
     * @access public static
     * @param 
     * @return 
     * @since 1.0
     */
    public static function install() {
        update_option('wpem_sendinblue_version', WPEM_SENDINBLUE_VERSION);
    }

}
