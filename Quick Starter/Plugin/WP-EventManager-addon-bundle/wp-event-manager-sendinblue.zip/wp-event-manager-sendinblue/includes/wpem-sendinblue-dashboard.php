<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Sendinblue_Integration_Dashboard class.
 */
class WPEM_Sendinblue_Dashboard {

    /**
     * __construct function.
     */
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'frontend_scripts'));
        add_action('wp_loaded', array($this, 'edit_handler'));

        //wpem dashboard column and content
        add_filter('wpem_dashboard_menu', array($this, 'wpem_dashboard_menu_add'));
        add_action('event_manager_event_dashboard_content_wpem_sendinblue_settings', array($this, 'wpem_sendinblue_settings'));



        add_filter('event_manager_event_dashboard_columns', array($this, 'add_sendinblue_columns'));
        add_action('event_manager_event_dashboard_column_sendinblue', array($this, 'sendinblue_column'));

        // Ajax on event dashboard for perticular event sendinblue list selection
        add_action('wp_ajax_event_manager_sendinblue_save_list_event', array($this, 'event_manager_sendinblue_save_list_event'));

        // cron
        add_action('event_manager_auto_sendinblue_sync_attendees', array($this, 'event_manager_auto_sendinblue_sync_attendees_callback'));
    }

    /**
     * frontend_scripts function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function frontend_scripts() {
        wp_register_script('wpem-sendinblue-dashboard', WPEM_SENDINBLUE_PLUGIN_URL . '/assets/js/sendinblue-dashboard.js', array('jquery'), WPEM_SENDINBLUE_VERSION, true);

        wp_localize_script('wpem-sendinblue-dashboard', 'wpem_sendinblue', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'wpem_sendinblue_dashboard_security' => wp_create_nonce("_nonce_wpem_sendinblue_dashboard_security"),
            'in_queue_icon' => EVENT_MANAGER_PLUGIN_URL . '/assets/images/ajax-loader.gif',
        ));

        wp_enqueue_style('wpem-sendinblue-frontend', WPEM_SENDINBLUE_PLUGIN_URL . '/assets/css/frontend.css');
    }

    /**
     * add dashboard menu function.
     *
     * @access public
     * @return void
     */
    public function wpem_dashboard_menu_add($menus) {
        $menus['wpem_sendinblue'] = array(
            'title' => __('Sendinblue', 'wp-event-manager-sendinblue'),
            'icon' => 'wpem-icon-mail3',
            'submenu' => array('wpem_sendinblue_settings' => array(
                    'title' => __('Settings', 'wp-event-manager'),
                    'query_arg' => ['action' => 'wpem_sendinblue_settings'],
                ))
        );

        $enable_sendinblue_registration = get_option('enable_sendinblue_registration', true);
        $enable_sendinblue_guest_list = get_option('enable_sendinblue_guest_list', true);
        $enable_sendinblue_organizer = get_option('enable_sendinblue_organizer', true);
        $sendinblue_settings = get_sendinblue_settings_by_user();

        $sync_type = isset($sendinblue_settings['sendinblue_sync_type']) ? $sendinblue_settings['sendinblue_sync_type'] : 'auto';

        if (is_plugin_active('wp-event-manager-registrations/wp-event-manager-registrations.php') && $enable_sendinblue_registration == true && $sync_type == 'manual') {
            $menus['wpem_sendinblue']['submenu']['wpem_sendinblue_sync_registrations'] = array(
                'title' => __('Sync Registrations', 'wp-event-manager'),
                'query_arg' => ['action' => 'wpem_sendinblue_sync_registrations'],
            );
        }

        if (is_plugin_active('wp-event-manager-guest-lists/wp-event-manager-guest-lists.php') && $enable_sendinblue_guest_list == true && $sync_type == 'manual') {
            $menus['wpem_sendinblue']['submenu']['wpem_sendinblue_sync_guest_list'] = array(
                'title' => __('Sync Guests', 'wp-event-manager'),
                'query_arg' => ['action' => 'wpem_sendinblue_sync_guest_list'],
            );
        }
        
        return $menus;
    }

    /**
     * Export Event and Other Data
     */
    public function wpem_sendinblue_settings() {

        $user_id = get_current_user_id();

        wp_enqueue_script('wpem-sendinblue-dashboard');

        $sendinblue_settings = get_sendinblue_settings_by_user();

        get_event_manager_template(
                'wpem-sendinblue-settings.php',
                array(
                    'user_id' => $user_id,
                    'sendinblue_api_key' => isset($sendinblue_settings['sendinblue_api_key']) ? $sendinblue_settings['sendinblue_api_key'] : '',
                    'sendinblue_list' => isset($sendinblue_settings['sendinblue_list']) ? $sendinblue_settings['sendinblue_list'] : '',
                    'sendinblue_sync_type' => isset($sendinblue_settings['sendinblue_sync_type']) ? $sendinblue_settings['sendinblue_sync_type'] : 'auto',
                    'sendinblue_sync_via' => isset($sendinblue_settings['sendinblue_sync_via']) ? $sendinblue_settings['sendinblue_sync_via'] : 'cron_job',
                    'sendinblue_sync_schedule' => isset($sendinblue_settings['sendinblue_sync_schedule']) ? $sendinblue_settings['sendinblue_sync_schedule'] : 'weekly',
                ),
                'wp-event-manager-sendinblue',
                WPEM_SENDINBLUE_PLUGIN_DIR . '/templates/'
        );
    }

    /**
     * edit_handler function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function edit_handler() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wp_event_manager_sendinblue']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_sendinblue')) {
            $sendinblue_api_key = !empty($_POST['sendinblue_api_key']) ? sanitize_text_field($_POST['sendinblue_api_key']) : '';
            $sendinblue_list = !empty($_POST['sendinblue_list']) ? sanitize_text_field($_POST['sendinblue_list']) : '';
            $sendinblue_sync_type = !empty($_POST['sendinblue_sync_type']) ? sanitize_text_field($_POST['sendinblue_sync_type']) : 'auto';
            $sendinblue_sync_via = !empty($_POST['sendinblue_sync_via']) ? sanitize_text_field($_POST['sendinblue_sync_via']) : 'cron_job';
            $sendinblue_sync_schedule = !empty($_POST['sendinblue_sync_schedule']) ? sanitize_text_field($_POST['sendinblue_sync_schedule']) : 'weekly';

            $sendinblue_settings = [
                'sendinblue_api_key' => $sendinblue_api_key,
                'sendinblue_list' => $sendinblue_list,
                'sendinblue_sync_type' => $sendinblue_sync_type,
                'sendinblue_sync_schedule' => $sendinblue_sync_schedule,
                'sendinblue_sync_via' => $sendinblue_sync_via,
            ];

            update_sendinblue_settings_by_user('sendinblue_settings', $sendinblue_settings);

            wp_clear_scheduled_hook('event_manager_auto_sendinblue_sync_attendees', array($user_id));
            if ($sendinblue_sync_type == 'auto' && $sendinblue_sync_via == 'cron_job') {
                switch ($sendinblue_sync_schedule) {
                    case '5min' :
                        $next = strtotime('+5 minutes');
                        break;
                    case 'daily' :
                        $next = strtotime('+1 day');
                        break;
                    case 'weekly' :
                        $next = strtotime('+1 week');
                        break;
                    case 'monthly' :
                        $next = strtotime('+1 month');
                        break;
                    case 'yearly' :
                        $next = strtotime('+1 year');
                        break;
                    default :
                        $next = strtotime('+1 week');
                        break;
                }

                // Create cron
                wp_schedule_event($next, $sendinblue_sync_schedule, 'event_manager_auto_sendinblue_sync_attendees', array($user_id));
            }
        }

        if (!empty($_POST['wp_event_manager_sendinblue_disconnect']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_sendinblue_disconnect')) {
            $arr_sendinblue_lists = get_sync_fields_by_user($user_id, 'sendinblue_lists');

            if (!empty($arr_sendinblue_lists)) {
                foreach ($arr_sendinblue_lists as $sendinblue_list => $sendinblue_name) {
                    delete_sendinblue_settings_by_user('sendinblue_list_dynamic_field_' . $sendinblue_list);
                }
            }

            wp_clear_scheduled_hook('event_manager_auto_sendinblue_sync_attendees', array($user_id));

            delete_sendinblue_settings_by_user('sendinblue_lists');
            delete_sendinblue_settings_by_user('sendinblue_settings');
        }
    }

    /**
     * add_sendinblue_columns function.
     *
     * @access public
     * @param $columns
     * @return void
     * @since 1.0.0
     */
    public function add_sendinblue_columns($columns) {
        $sendinblue_settings = get_sendinblue_settings_by_user();
        $sendinblue_list = isset($sendinblue_settings['sendinblue_list']) ? $sendinblue_settings['sendinblue_list'] : 0;
        //if user not set event based settings then do not add column
        if ($sendinblue_list != false)
            return $columns;


        $columns['sendinblue'] = __('Sendinblue', 'wp-event-manager-sendinblue');
        return $columns;
    }

    /**
     * sendinblue_column function.
     *
     * @access public
     * @param $event
     * @return void
     * @since 1.0.0
     */
    public function sendinblue_column($event) {
        $user_id = get_current_user_id();
        $event_id = $event->ID;

        $event_sendinblue_list = get_post_meta($event_id, 'sendinblue_list', true);

        $sendinblue_settings = get_sendinblue_settings_by_user();

        $sendinblue_api_key = isset($sendinblue_settings['sendinblue_api_key']) ? $sendinblue_settings['sendinblue_api_key'] : '';
        $sendinblue_list = isset($sendinblue_settings['sendinblue_list']) ? $sendinblue_settings['sendinblue_list'] : 0;

        if ($sendinblue_list != false)
            return;

        wp_enqueue_script('wpem-sendinblue-dashboard');

        $sendinblue_lists = get_sendinblue_lists($sendinblue_api_key);

        if (count($sendinblue_lists) > 0) {
            if (isset($sendinblue_lists[0]))
                $sendinblue_lists[0] = __('Disable for this event', 'wp-event-manager-sendinblue');
            ?>
            <div class="wpem-form-wrapper wpem-sendinblue">
                <div class="wpem-form-group">
                    <select name="sendinblue_list" class="sendinblue-list" data-event-id="<?php echo $event->ID; ?>">
            <?php foreach ($sendinblue_lists as $id => $label) : ?>
                            <option value="<?php echo esc_attr($id); ?>" <?php selected($event_sendinblue_list, $id); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <?php
        } else {
            echo __('Please connect with Sendinblue.', 'wp-event-manager-sendinblue');
        }
    }

    public function event_manager_sendinblue_save_list_event() {
        check_ajax_referer('_nonce_wpem_sendinblue_dashboard_security', 'security');

        $event_id = isset($_REQUEST['event_id']) ? absint($_REQUEST['event_id']) : '';
        $sendinblue_list = isset($_REQUEST['sendinblue_list']) ? $_REQUEST['sendinblue_list'] : 0;

        if (!empty($event_id)) {
            update_post_meta($event_id, 'sendinblue_list', $sendinblue_list);
            return wp_send_json(array(
                'message' => __('Updated sucessfully.', 'wp-event-manager-sendinblue')));
        }



        wp_die();
    }

    /**
     * event_manager_auto_sendinblue_sync_attendees_callback function.
     *
     * @access public
     * @param $event_id
     * @return void
     * @since 1.0.0
     */
    public function event_manager_auto_sendinblue_sync_attendees_callback($user_id) {
        $event_ids = get_event_by_user_id($user_id);

        if (!empty($event_ids)) {
            foreach ($event_ids as $event_id) {
                $registrations = get_registration_attendee_list(['event_id' => $event_id, 'posts_per_page' => -1]);

                $arr_attendees_id = [];

                if ($registrations->found_posts > 0) {
                    foreach ($registrations->posts as $registration) {
                        $arr_attendees_id[] = $registration->ID;
                    }

                    add_attendees_in_sendinblue_list($user_id, $arr_attendees_id);
                }

                $guests = get_guest_lists_guest_list(['event_id' => $event_id, 'posts_per_page' => -1]);

                $arr_guest_id = [];

                if ($guests->found_posts > 0) {
                    foreach ($guests->posts as $guest) {
                        $arr_guest_id[] = $guest->ID;
                    }

                    add_guests_in_sendinblue_list($user_id, $arr_guest_id);
                }
            }
        }
    }

}

new WPEM_Sendinblue_Dashboard();
