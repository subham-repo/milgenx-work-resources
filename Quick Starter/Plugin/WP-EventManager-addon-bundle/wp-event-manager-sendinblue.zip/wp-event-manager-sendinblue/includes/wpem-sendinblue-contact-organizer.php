<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Sendinblue_Contact_Organizer class.
 */
class WPEM_Sendinblue_Contact_Organizer {

    /**
     * __construct function.
     */
    public function __construct() {
        add_action('wpem_sendinblue_dashboard_after', array($this, 'contact_organizer_fields_matches_attribute'), 10);

        add_action('wp_loaded', array($this, 'edit_handler'));

        add_action('event_manager_contact_organizer_send_mail_after', [$this, 'sendinblue_sync_via_add_new_contact_organizer'], 10, 3);
    }

    /**
     * fields_matches function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function contact_organizer_fields_matches_attribute() {
        $user_id = get_current_user_id();

        $sendinblue_settings = get_sendinblue_settings_by_user();

        $sendinblue_api_key = isset($sendinblue_settings['sendinblue_api_key']) ? $sendinblue_settings['sendinblue_api_key'] : '';
        $sendinblue_list = isset($sendinblue_settings['sendinblue_list']) ? $sendinblue_settings['sendinblue_list'] : '';
        
        $check_sendinblue_key = check_sendinblue_key($sendinblue_api_key);
        if (isset($check_sendinblue_key['code']) && $check_sendinblue_key['code'] == "unauthorized")
            return; 

        if (!empty($sendinblue_api_key)) {

            $contact_organizer_field = get_sync_fields_by_user($user_id, 'contact_organizer_field');
            $contact_organizer_sendinblue_field = get_sendinblue_sync_fields_by_user($user_id, 'contact_organizer_sendinblue_field');

            $field_not_mapping_message = '';
            if (empty($contact_organizer_sendinblue_field)) {
                $contact_organizer_sendinblue_field = get_default_sendinblue_contact_organizer_matches_attribute();

                $field_not_mapping_message = __('Name and Email are compulsory fields for Sendinblue synchronization.', 'wp-event-manager-sendinblue');
            }

            get_event_manager_template(
                    'wpem-sendinblue-contact-organizer-field-mapping.php',
                    array(
                        'user_id' => $user_id,
                        'sendinblue_api_key' => $sendinblue_api_key,
                        'sendinblue_list' => $sendinblue_list,
                        'contact_organizer_sendinblue_field' => $contact_organizer_sendinblue_field,
                        'field_not_mapping_message' => $field_not_mapping_message,
                    ),
                    'wp-event-manager-sendinblue',
                    WPEM_SENDINBLUE_PLUGIN_DIR . '/templates/'
            );
        }
    }

    /**
     * edit_handler function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function edit_handler() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wp_event_manager_sendinblue_contact_organizer_matches_attribute']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_sendinblue_contact_organizer_matches_attribute')) {
            $contact_organizer_field = !empty($_POST['contact_organizer_field']) ? array_filter($_POST['contact_organizer_field']) : '';
            $contact_organizer_sendinblue_field = !empty($_POST['contact_organizer_sendinblue_field']) ? array_filter($_POST['contact_organizer_sendinblue_field']) : '';

            update_sendinblue_settings_by_user('contact_organizer_field', $contact_organizer_field);

            $new_sendinblue_field = [];

            if (!empty($contact_organizer_sendinblue_field)) {
                foreach ($contact_organizer_sendinblue_field as $key => $value) {
                    $new_sendinblue_field[$value] = $contact_organizer_field[$key];
                }
            }

            update_sendinblue_settings_by_user('contact_organizer_sendinblue_field', $new_sendinblue_field);
        }
    }

    /**
     * sendinblue_sync_via_add_new_registration function.
     *
     * @access public
     * @param $data
     * @return void
     * @since 1.0.0
     */
    public function sendinblue_sync_via_add_new_contact_organizer($data, $event_id, $organizer_id) {
        $event = get_post($event_id);
        $user_id = $event->post_author;

        $sendinblue_settings = get_sendinblue_settings_by_user_id($user_id);

        $sendinblue_api_key = isset($sendinblue_settings['sendinblue_api_key']) ? $sendinblue_settings['sendinblue_api_key'] : '';
        $sendinblue_list = isset($sendinblue_settings['sendinblue_list']) ? $sendinblue_settings['sendinblue_list'] : '';

        if ($sendinblue_api_key != '') {
            if ($sendinblue_list == '') {
                $event_sendinblue_list = get_post_meta($event_id, 'sendinblue_list', true);
                if (!empty($event_sendinblue_list)) {
                    $sendinblue_list = $event_sendinblue_list;
                }
            }

            $contact_organizer_field = get_sync_fields_by_user($user_id, 'contact_organizer_field');
            $contact_organizer_sendinblue_field = get_sendinblue_sync_fields_by_user($user_id, 'contact_organizer_sendinblue_field');

            if (empty($contact_organizer_sendinblue_field)) {
                $contact_organizer_sendinblue_field = get_default_sendinblue_contact_organizer_matches_attribute();
            }
            $result = sync_data_in_sendinblue_list_2($sendinblue_api_key, $sendinblue_list, $contact_organizer_sendinblue_field, $data);
        }
    }

}

new WPEM_Sendinblue_Contact_Organizer();
