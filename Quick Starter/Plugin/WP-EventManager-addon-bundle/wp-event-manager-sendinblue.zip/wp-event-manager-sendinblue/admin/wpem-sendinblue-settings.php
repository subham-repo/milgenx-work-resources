<?php

/*
 * This file use for setings at admin site for event sendinblue integration settings.
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * WPEM_Sendinblue_Integration_Settings class.
 */
class WPEM_Sendinblue_Settings {

    /**
     * __construct function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function __construct() {
        
    }

    /**
     * wp_event_sendinblue_settings function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wp_event_sendinblue_settings() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wp_event_sendinblue_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'event_sendinblue_disconnect_settings')) {
            $arr_sendinblue_lists = get_sync_fields_by_user($user_id, 'sendinblue_lists');

            if (!empty($arr_sendinblue_lists)) {
                foreach ($arr_sendinblue_lists as $sendinblue_list => $sendinblue_name) {
                    delete_sendinblue_settings_by_user('sendinblue_list_dynamic_field_' . $sendinblue_list);
                }
            }
            delete_sendinblue_settings_by_user('sendinblue_lists');
            delete_sendinblue_settings_by_user('sendinblue_settings');

            $arr_post_type = ['event_organizer', 'event_registration', 'event_guest_list'];
            wp_clear_scheduled_hook('event_manager_auto_sendinblue_sync_admin', array($arr_post_type));
        }

        if (!empty($_POST['wp_event_sendinblue_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'event_sendinblue_settings')) {
            $sendinblue_api_key = !empty($_POST['sendinblue_api_key']) ? sanitize_text_field($_POST['sendinblue_api_key']) : '';
            $sendinblue_list = !empty($_POST['sendinblue_list']) ? sanitize_text_field($_POST['sendinblue_list']) : '';
            $sendinblue_sync_type = !empty($_POST['sendinblue_sync_type']) ? sanitize_text_field($_POST['sendinblue_sync_type']) : 'auto';
            $sendinblue_sync_via = !empty($_POST['sendinblue_sync_via']) ? sanitize_text_field($_POST['sendinblue_sync_via']) : 'cron_job';
            $sendinblue_sync_schedule = !empty($_POST['sendinblue_sync_schedule']) ? sanitize_text_field($_POST['sendinblue_sync_schedule']) : 'weekly';

            $sendinblue_settings = [
                'sendinblue_api_key' => $sendinblue_api_key,
                'sendinblue_list' => $sendinblue_list,
                'sendinblue_sync_type' => $sendinblue_sync_type,
                'sendinblue_sync_schedule' => $sendinblue_sync_schedule,
                'sendinblue_sync_via' => $sendinblue_sync_via,
            ];

            update_sendinblue_settings_by_user('sendinblue_settings', $sendinblue_settings);

            $arr_post_type = ['event_organizer', 'event_registration', 'event_guest_list'];
            wp_clear_scheduled_hook('event_manager_auto_sendinblue_sync_admin', array($arr_post_type));

            if ($sendinblue_sync_type == 'auto' && $sendinblue_sync_via == 'cron_job') {
                switch ($sendinblue_sync_schedule) {
                    case '5min':
                        $next = strtotime('+5 minutes');
                        break;
                    case 'daily':
                        $next = strtotime('+1 day');
                        break;
                    case 'weekly':
                        $next = strtotime('+1 week');
                        break;
                    case 'monthly':
                        $next = strtotime('+1 month');
                        break;
                    case 'yearly':
                        $next = strtotime('+1 year');
                        break;
                    default:
                        $next = strtotime('+1 week');
                        break;
                }

                // Create cron
                wp_schedule_event($next, $sendinblue_sync_schedule, 'event_manager_auto_sendinblue_sync_admin', array($arr_post_type));
            }
        }

        $sendinblue_settings = get_sendinblue_settings_by_user();

        $sendinblue_api_key = isset($sendinblue_settings['sendinblue_api_key']) ? $sendinblue_settings['sendinblue_api_key'] : '';
        $sendinblue_list = isset($sendinblue_settings['sendinblue_list']) ? $sendinblue_settings['sendinblue_list'] : '';
        $sendinblue_sync_type = isset($sendinblue_settings['sendinblue_sync_type']) && !empty($sendinblue_settings['sendinblue_sync_type']) ? $sendinblue_settings['sendinblue_sync_type'] : 'auto';
        $sendinblue_sync_via = isset($sendinblue_settings['sendinblue_sync_via']) && !empty($sendinblue_settings['sendinblue_sync_via']) ? $sendinblue_settings['sendinblue_sync_via'] : 'cron_job';
        $sendinblue_sync_schedule = isset($sendinblue_settings['sendinblue_sync_schedule']) ? $sendinblue_settings['sendinblue_sync_schedule'] : '';

        $check_sendinblue_key = check_sendinblue_key($sendinblue_api_key);

        include('templates/sendinblue-settings.php');
    }

}
