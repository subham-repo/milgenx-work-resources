<div class="white-background">
    <form method="post" class="wpem-sendinblue-registration-matches-attribute">
        <div class="wpem-sendinblue-settings-organizer">
            <label><strong>Sync Registrations</strong> <input id="setting-enable_sendinblue_registration" name="enable_sendinblue_registration" type="checkbox" <?php checked($enable_sendinblue_registration, true); ?> value="1"> <?php _e('Enable registration sync with sendinblue.', 'wp-event-manager-sendinblue'); ?></label>
        </div>
        <h3><?php _e('Registration Field Mapping with Sendinblue', 'wp-event-manager-sendinblue'); ?></h3>
        <table class="widefat wpem-sendinblue-field-maping-table">
            <thead>
                <tr>
                    <th ><?php _e('Registration Field', 'wp-event-manager-sendinblue'); ?></th>
                    <th ><?php _e('Sendinblue Field', 'wp-event-manager-sendinblue'); ?></th>
                    <th class="wpem-sendinblue-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($registration_sendinblue_field)) : ?>
                    <?php foreach ($registration_sendinblue_field as $sync_field => $form_field) : ?>
                        <tr>
                            <td>
                                <select name="registration_field[]" class="registration-field">
                                    <option value=""><?php _e('Select registration Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                    <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="registration_sendinblue_field[]" class="sendinblue-registration-field">
                                    <option value=""><?php _e('Select Sendinblue Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                    <?php foreach (get_sendinblue_list_dynamic_field($sendinblue_api_key, $sendinblue_list) as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-sendinblue'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="registration_field[]" class="registration-field">
                                <option value=""><?php _e('Select registration Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="registration_sendinblue_field[]" class="sendinblue-registration-field">
                                <option value=""><?php _e('Select Sendinblue Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                <?php foreach (get_sendinblue_list_dynamic_field($sendinblue_api_key, $sendinblue_list) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">
                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-sendinblue'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td >
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wp-event-manager-sendinblue'); ?></a>
                    </td>
                    <td colspan="2">
                        <?php wp_nonce_field('wpem_sendinblue_admin_registration_field_mapping'); ?>
                        <input type="submit" class="button-primary wpem-field-maping-save" name="submit_sendinblue_admin_registration_mapping" value="<?php esc_attr_e('Save', 'wp-event-manager-sendinblue'); ?>" />
                    </td>
                </tr>
            </tfoot>
        </table>
    </form>	
</div>

