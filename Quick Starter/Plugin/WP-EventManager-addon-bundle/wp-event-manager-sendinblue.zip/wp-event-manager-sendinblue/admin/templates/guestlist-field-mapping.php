<div class="white-background">
    <form method="post" class="wpem-sendinblue-guest-list-matches-attribute">
        <div class="wpem-sendinblue-settings-guest-list">

            <label><strong><?php _e('Sync Guest Lists', 'wp-event-manager-sendinblue'); ?></strong> <input id="setting-enable_sendinblue_guest_list" name="enable_sendinblue_guest_list" type="checkbox" <?php checked($enable_sendinblue_guest_list, true); ?> value="1"> <?php _e('Enable guest list sync with sendinblue.', 'wp-event-manager-sendinblue'); ?></label>
        </div>
        <h3><?php _e('Guest Field Mapping with Sendinblue', 'wp-event-manager-sendinblue'); ?></h3>
        <table class="widefat wpem-sendinblue-field-maping-table">
            <thead>
                <tr>
                    <th><?php _e('Guest List Field', 'wp-event-manager-sendinblue'); ?></th>
                    <th><?php _e('Sendinblue Field', 'wp-event-manager-sendinblue'); ?></th>
                    <th class="wpem-sendinblue-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>

            <tbody>
                <?php if (!empty($guest_list_sendinblue_field)) : ?>
                    <?php foreach ($guest_list_sendinblue_field as $sync_field => $form_field) : ?>
                        <tr>
                            <td>
                                <select name="guest_list_field[]" class="guest-list-field">
                                    <option value=""><?php _e('Select Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                    <?php foreach (get_event_guest_lists_form_fields() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="guest_list_sendinblue_field[]" class="sendinblue-guest-list-field">
                                    <option value=""><?php _e('Select Sendinblue Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                    <?php foreach (get_sendinblue_list_dynamic_field($sendinblue_api_key, $sendinblue_list) as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-sendinblue'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="guest_list_field[]" class="guest-list-field">
                                <option value=""><?php _e('Select Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                <?php foreach (get_event_guest_lists_form_fields() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="guest_list_sendinblue_field[]" class="sendinblue-guest-list-field">
                                <option value=""><?php _e('Select Sendinblue Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                <?php foreach (get_sendinblue_list_dynamic_field($sendinblue_api_key, $sendinblue_list) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">
                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-sendinblue'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td>
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wp-event-manager-sendinblue'); ?></a>
                    </td>
                    <td colspan="2">
                        <?php wp_nonce_field('wpem_admin_sendinblue_guest_list_field_mapping'); ?>
                        <input type="submit" class="button-primary wpem-field-maping-save" name="submit_sendinblue_admin_guest_list_field_mapping" value="<?php esc_attr_e('Save', 'wp-event-manager-sendinblue'); ?>" />
                    </td>

                </tr>
            </tfoot>

        </table>
    </form>
</div>		
