<div class="white-background">
    <form method="post" class="wpem-sendinblue-organizer-matches-attribute">
        <div class="wpem-sendinblue-settings-organizer">
            <label><input id="setting-enable_sendinblue_organizer" name="enable_sendinblue_organizer" type="checkbox" <?php checked($enable_sendinblue_organizer, true); ?> value="1" > <?php _e('Enable organizer sync with sendinblue.', 'wp-event-manager-sendinblue'); ?></label>
        </div>
        <h3><?php _e('Organizer Field Mapping with Sendinblue', 'wp-event-manager-sendinblue'); ?></h3>
        <table class="widefat wpem-sendinblue-field-maping-table">
            <thead>
                <tr>
                    <th ><?php _e('Organizer Field', 'wp-event-manager-sendinblue'); ?></th>
                    <th ><?php _e('Sendinblue Field', 'wp-event-manager-sendinblue'); ?></th>
                    <th class="wpem-sendinblue-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>

            <tbody>
                <?php if (!empty($organizer_sendinblue_field)) : ?>
                    <?php foreach ($organizer_sendinblue_field as $sync_field => $form_field) : ?>
                        <tr>
                            <td>
                                <select name="organizer_field[]" class="organization-field">
                                    <option value=""><?php _e('Select Organizer Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                    <?php foreach (get_event_organization_form_field_lists() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="organizer_sendinblue_field[]" class="sendinblue-organization-field">
                                    <option value=""><?php _e('Select Sendinblue Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                    <?php foreach (get_sendinblue_list_dynamic_field($sendinblue_api_key, $sendinblue_list) as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-sendinblue'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="organizer_field[]" class="organization-field">
                                <option value=""><?php _e('Select Organizer Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                <?php foreach (get_event_organization_form_field_lists() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="organizer_sendinblue_field[]" class="sendinblue-organization-field">
                                <option value=""><?php _e('Select Sendinblue Field', 'wp-event-manager-sendinblue'); ?>...</option>
                                <?php foreach (get_sendinblue_list_dynamic_field($sendinblue_api_key, $sendinblue_list) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">

                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-sendinblue'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td >
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wp-event-manager-sendinblue'); ?></a>
                    </td>	                    	
                    <td colspan="2">
                        <input type="submit" class="button-primary wpem-field-maping-save" name="wp_event_sendinblue_organizer_matches_attribute" value="<?php esc_attr_e('Save', 'wp-event-manager-sendinblue'); ?>" />

                        <?php wp_nonce_field('event_sendinblue_organizer_matches_attribute'); ?>
                    </td>
                </tr>
            </tfoot>

        </table>
    </form>		
</div>