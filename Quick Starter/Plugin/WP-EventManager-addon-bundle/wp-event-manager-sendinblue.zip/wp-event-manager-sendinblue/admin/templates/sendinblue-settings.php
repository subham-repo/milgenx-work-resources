<div class="wrap wp_event_manager wpem-sendinblue-admin-wrap">
    <h2><?php _e('WP Event Manager Sendinblue Settings', 'wp-event-manager-sendinblue'); ?></h2>

    <?php do_action('wp_event_sendinblue_settings_before'); ?>

    <div class="wpem-sendinblue-setting-wrapper">
        <div class="wpem-sendinblue-setting">
            <div class="wpem-sendinblue-image">
                <img src="<?php echo WPEM_SENDINBLUE_PLUGIN_URL ?>/assets/images/sendinblue_logo_small.png" alt="sendinblue">
            </div>
            <div class="wpem-sendinblue-settings-container">
                <?php $check_sendinblue_key = check_sendinblue_key($sendinblue_api_key); ?>
                <?php if (isset($check_sendinblue_key['code']) && $check_sendinblue_key['code'] == "unauthorized") { ?>

                    <div class="error">
                        <p>
                            <?php echo __('The API key entered is invalid.', 'wp-event-manager-sendinblue'); ?>
                        </p>
                    </div>

                <?php } ?>
                <div class="wpem-sendinblue-info">
                    <h1><?php _e('Sendinblue Settings', 'wp-event-manager-sendinblue'); ?></h1>
                    <?php if (isset($check_sendinblue_key['count']) && $check_sendinblue_key['count'] > 0) : ?>

                        <form method="post" class="wp-event-sendinblue-disconnect-settings">
                            <input type="submit" class="wpem-theme-button wpem-theme-button-disconnect" name="wp_event_sendinblue_settings" value="<?php esc_attr_e('Disconnect', 'wp-event-manager-sendinblue'); ?>">

                            <?php wp_nonce_field('event_sendinblue_disconnect_settings'); ?>
                        </form>


                    <?php endif; ?>
                    <p><?php _e('Integrate Sendinblue with WP Event Manager', 'wp-event-manager-sendinblue'); ?></p>
                </div>
                <form method="post" class="wpem-sendinblue-form">
                    <div class="wpem-sendinblue-form-container">
                        <input type="text" class="sendinblue-api-key" name="sendinblue_api_key" placeholder="<?php _e('Sendinblue API Key', 'wp-event-manager-sendinblue'); ?>" value="<?php echo $sendinblue_api_key; ?>">

                        <?php if (isset($check_sendinblue_key['code']) && $check_sendinblue_key['code'] == "unauthorized") : ?>

                        <?php else : ?>
                            <?php if ($sendinblue_api_key != '') : ?>
                                <select name="sendinblue_list" class="sendinblue-list">
                                    <?php foreach (get_sendinblue_lists($sendinblue_api_key) as $id => $label) : ?>
                                        <option value="<?php echo esc_attr($id); ?>" <?php selected($sendinblue_list, $id); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>

                            <?php if ($sendinblue_api_key != '') : ?>
                                <select name="sendinblue_sync_type" class="sendinblue-sync-type" id="sendinblue-sync-type">
                                    <option value=""><?php _e('Select Sendinblue Sync Type', 'wp-event-manager-sendinblue'); ?></option>
                                    <?php foreach (get_sendinblue_sync_type() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sendinblue_sync_type, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <?php
                                $style = '';
                                if ($sendinblue_sync_type == 'manual') {
                                    $style = 'style="display: none;"';
                                }
                                ?>
                                <select id="sendinblue-sync-via" <?php echo $style; ?> name="sendinblue_sync_via" class="sendinblue-sync-via">
                                    <option value=""><?php _e('Select Sendinblue Sync Via', 'wp-event-manager-sendinblue'); ?></option>
                                    <?php foreach (get_sendinblue_sync_via() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sendinblue_sync_via, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <?php
                                $style = '';
                                if ($sendinblue_sync_type == 'manual' || $sendinblue_sync_via == 'when_created') {
                                    $style = 'style="display: none;"';
                                }
                                ?>
                                <select id="sendinblue_sync_schedule" <?php echo $style; ?> name="sendinblue_sync_schedule" class="sendinblue-sync-schedule">
                                    <?php foreach (get_sendinblue_sync_schedule() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sendinblue_sync_schedule, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>

                        <?php endif; ?>

                        <input type="submit" class="wpem-theme-button" name="wp_event_sendinblue_settings" value="<?php esc_attr_e('Save Setting', 'wp-event-manager-sendinblue'); ?>" />

                        <?php wp_nonce_field('event_sendinblue_settings'); ?>

                    </div>
                </form>

            </div>
        </div>
    </div>

    <?php do_action('wp_event_sendinblue_settings_after'); ?>

</div>
