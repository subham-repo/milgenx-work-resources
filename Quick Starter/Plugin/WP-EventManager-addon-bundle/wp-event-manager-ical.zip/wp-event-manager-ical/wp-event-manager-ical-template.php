<?php if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Convert times to iCalendar format. They require a block for yyyymmdd and then another block
// for the time, which is in hhiiss. Both of those blocks are separated by a "T". The Z is
// declared at the end for UTC time, but shouldn't be included in the date conversion.

// iCal date format: yyyymmddThhiissZ
// PHP equiv format: Ymd\This
function wpem_ical_date_to_cal($time) {

    $time = get_gmt_from_date($time); // this function requires Y-m-d H:i:s
    $time = strtotime($time);

    //return date('Ymd\ThisA', $time).'Z' ;
    return date('Ymd\THis', $time).'Z' ;
}

/**
 * event_manager_ical Generate ical file.
 * This function will make ical file template.
 */
function event_manager_ical()
{
    global $post;

    $user_id = get_current_user_id();

    $proid = "WP EVENT Manager Ical";
    // - start collecting output -
    ob_start();

    $file_name = "event-calendar" . date("Y-m-d h:i") . ".ics";
    
    // - file header -
    header('Content-type: text/calendar');
    header('Content-Disposition: attachment; filename="' . $file_name . '" ');
    

    // - content header -
?>
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//<?php echo $proid; ?>//NONSGML Events //EN
CALSCALE:GREGORIAN
<?php
    // - get today date -
    $today = date("Y-m-d");
    // - query -
    global $wpdb;
    $query = "
       SELECT *
        FROM $wpdb->posts wposts, $wpdb->postmeta metastart, $wpdb->postmeta metaend
        WHERE (wposts.ID = metastart.post_id AND wposts.ID = metaend.post_id)
        AND (metaend.meta_key = '_event_end_date'  AND metaend.meta_value > $today )
        AND metastart.meta_key = '_event_end_date'
        AND wposts.post_type = 'event_listing'
        AND wposts.post_status = 'publish'
        AND wposts.post_author = $user_id
        ORDER BY metastart.meta_value ASC
     ";

    $events = $wpdb->get_results($query, OBJECT);

    // - loop -
    if ($events):

        foreach ($events as $post):
            setup_postdata($post);

            $startdate = get_post_meta($post->ID, '_event_start_date', true);
            $enddate   = get_post_meta($post->ID, '_event_end_date', true);
            $location   = get_post_meta($post->ID, '_event_location', true);

            $starttime = wpem_ical_date_to_cal($startdate);
            $endtime   = wpem_ical_date_to_cal($enddate);
            // - item output -
?>
BEGIN:VEVENT

DTSTART:<?php echo $starttime; ?>

DTEND:<?php echo $endtime; ?>

LOCATION:<?php echo $location; ?>

SUMMARY:<?php echo html_entity_decode( get_the_title() ); ?>

DESCRIPTION:<?php the_excerpt_rss('', TRUE, '', 50); ?>

END:VEVENT
<?php
        endforeach;
    endif;
    ?>
END:VCALENDAR
<?php
    // - full output -
    $eventcontents = ob_get_contents();
    ob_end_clean();
    echo $eventcontents;
}

function wpem_single_event_ical()
{
    global $post;
    $proid = "WP EVENT Manager Ical";
    $file_name = "event-calendar" . date("Y-m-d h:i") . ".ics";

    ob_start();

    
    // - file header -
    header('Content-type: text/calendar');
    header('Content-Disposition: attachment; filename="' . $file_name . '" ');
    // - content header -

    $startdate = get_post_meta($post->ID, '_event_start_date', true);
    $enddate   = get_post_meta($post->ID, '_event_end_date', true);
    $location   = get_post_meta($post->ID, '_event_location', true);

    $starttime = wpem_ical_date_to_cal($startdate);
    $endtime   = wpem_ical_date_to_cal($enddate);
    
    // - item output -
?>
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//<?php echo $proid; ?>//NONSGML Events //EN
CALSCALE:GREGORIAN

BEGIN:VEVENT

DTSTART:<?php echo $starttime; ?>

DTEND:<?php echo $endtime; ?>

LOCATION:<?php echo $location; ?>

SUMMARY:<?php echo html_entity_decode( get_the_title() ); ?>

DESCRIPTION:<?php the_excerpt_rss('', TRUE, '', 50); ?>

END:VEVENT
END:VCALENDAR
<?php

    $eventcontents = ob_get_contents();
    ob_end_clean();
    echo $eventcontents;
}
