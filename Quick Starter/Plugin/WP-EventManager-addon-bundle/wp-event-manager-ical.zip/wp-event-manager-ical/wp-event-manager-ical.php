<?php 
/*
Plugin Name: WP Event Manager - iCal
Plugin URI: http://www.wp-eventmanager.com/
Description: Download events into iCal file.
Author: WP Event Manager
Author URI: http://www.wp-eventmanager.com/
Text Domain: wp-event-manager-ical
Domain Path: /languages
Version: 1.1.2
Since: 1.0
Requires WordPress Version at least: 4.1
Copyright: 2017 WP Event Manager
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPEM_Updater' ) ) {
	include( 'autoupdater/wpem-updater.php' );
}

include_once(ABSPATH.'wp-admin/includes/plugin.php');
function pre_check_before_installing_iCal() 
{
    /*
    * Check weather WP Event Manager is installed or not
    */
    if ( !is_plugin_active( 'wp-event-manager/wp-event-manager.php') ) 
    {
        global $pagenow;
    	if( $pagenow == 'plugins.php' )
    	{
            echo '<div id="error" class="error notice is-dismissible"><p>';
            echo __( 'WP Event Manager is require to use WP Event Manager - iCal' , 'wp-event-manager-ical');
            echo '</p></div>';		
    	} 		
    }
}
add_action( 'admin_notices', 'pre_check_before_installing_iCal' );	

/**
 * WP_Event_Manager_Ical class.
 */
class WP_Event_Manager_Ical extends WPEM_Updater {	
	
	public function __construct()
	{
		//if wp event manager not active return from the plugin
		if ( !is_plugin_active( 'wp-event-manager/wp-event-manager.php') )
			return;

		/** update restriction removed
		$plugin_slug = str_replace( '.php', '', basename( __FILE__ ) );
		$activation_key = get_option( $plugin_slug . '_licence_key' );
		if(!$activation_key) return;
		**/
		// Define constants
		define( 'WPEM_ICAL_VERSION', '1.1.2' );
		define( 'WPEM_ICAL_PLUGIN_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
		define( 'WPEM_ICAL_PLUGIN_URL', untrailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) ) );
		
		//include
		include('wp-event-manager-ical-template.php');

		//external
		include('external/external.php');

		add_action('init',array($this,'add_events_ical_feed') );
		
		//add download link to dashboard
		add_action( 'event_manager_event_dashboard_button_action_end', array( $this, 'add_ical_link' ) );
		add_action( 'single_event_sidebar_end', array( $this, 'add_single_event_ical_link' ));
		
		// Init updates
		$this->init_updates( __FILE__ );
	}
	
	/**
	 * Localisation
	 */
	public function load_plugin_textdomain() {
		$domain = 'wp-event-manager-ical';       
        $locale = apply_filters('plugin_locale', get_locale(), $domain);
		load_textdomain( $domain, WP_LANG_DIR . "/wp-event-manager-ical/".$domain."-" .$locale. ".mo" );
		load_plugin_textdomain($domain, false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}
		
	/**
	* add_events_ical_feed add rss feed.
	*/
	public function add_events_ical_feed () 
	{
		// - add it to WP RSS feeds -
		add_feed('event-listings-ical', 'event_manager_ical');
		add_feed('single-event-listings-ical', 'wpem_single_event_ical');
	}
	
	/**
	* Add a ical file download link to the event dashboard
	*/
	public function add_ical_link() 
	{
		//echo '<div class="wpem-fr"><a href="?feed=event-listings-ical" class="wpem-theme-button wpem-mt-2 wpem-event-ical-button"><span><i class="wpem-icon-calendar wpem-mr-1"></i>' . sprintf(__('Download Events iCal', 'wp-event-manager-ical')) . '</span></a></div>';

		echo '<a href="?feed=event-listings-ical" title="'. __('Download Events iCal','wp-event-manager') . '" class="wpem-dashboard-header-btn"><i class="wpem-icon-ical"></i></a>';
	}

	/**
	* Add a ical file download link to the single event
	*/
	public function add_single_event_ical_link()
	{
	    //echo '<div class="clearfix">&nbsp;</div><a href="?feed=single-event-listings-ical" class="wpem-icon-text-button wpem-theme-button-2"><span><i class="wpem-icon-ical wpem-mr-1"></i>'. __('Download Events ical', 'wp-event-manager-ical') .'</span></a>';

	    echo '<div class="clearfix">&nbsp;</div><a href="?feed=single-event-listings-ical" class="wpem-icon-text-button"><span><i class="wpem-icon-ical wpem-mr-1"></i>'. __('Download Events ical', 'wp-event-manager-ical') .'</span></a>';

	   
	}
	
} // end class

$GLOBALS['event_manager_ical'] =new WP_Event_Manager_Ical();
