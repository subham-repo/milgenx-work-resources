var MailchimpIntegrationDashboard = function () {

    return {

        init: function ()
        {
            jQuery('select#mailchimp-sync-type').on('change', MailchimpIntegrationDashboard.actions.syncType);
            jQuery('select#mailchimp-sync-via').on('change', MailchimpIntegrationDashboard.actions.syncVia);

            jQuery('body').on('click', '.wpem-mailchimp-matches-attribute .add-field', MailchimpIntegrationDashboard.actions.addField);
            jQuery('body').on('click', '.wpem-mailchimp-matches-attribute .delete-field', MailchimpIntegrationDashboard.actions.deleteField);

            jQuery('body').on('click', '.wpem-mailchimp-sync-list-filter .add-filter', MailchimpIntegrationDashboard.actions.addFilter);
            jQuery('body').on('click', '.wpem-mailchimp-sync-list-filter .delete-filter', MailchimpIntegrationDashboard.actions.deleteFilter);

            jQuery('body').on('click', '.wpem-event-dashboard-information-wrapper .mailchimp-list', MailchimpIntegrationDashboard.actions.addMailchimpList);

            jQuery('body').on('change', '.wpem-mailchimp-sync-registrations #all_select', MailchimpIntegrationDashboard.actions.allSelectAttendees);
            jQuery('body').on('change', '.wpem-mailchimp-sync-registrations .attende-id', MailchimpIntegrationDashboard.actions.selectAttendees);
            jQuery('#sync-attendees-button').on('click', MailchimpIntegrationDashboard.actions.syncAttendees);

            jQuery('body').on('change', '.wpem-mailchimp-sync-guests #all_select', MailchimpIntegrationDashboard.actions.allSelectGuests);
            jQuery('body').on('change', '.wpem-mailchimp-sync-guests .attende-id', MailchimpIntegrationDashboard.actions.selectGuests);
            jQuery('body').on('click', '.wpem-mailchimp-sync-guests .sync-guests-button', MailchimpIntegrationDashboard.actions.syncGuests);
        },

        actions:
                {
                    /**
                     * syncType function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    syncType: function (e)
                    {
                        var mailchimp_sync_type = jQuery(e.target).val();
                        if (mailchimp_sync_type === 'auto')
                        {
                            jQuery('#mailchimp_sync_via').show();

                            var mailchimp_sync_via = jQuery('#mailchimp_sync_via select.mailchimp-sync-via').val();
                            if (mailchimp_sync_via == 'when_created')
                            {
                                jQuery('#mailchimp_sync_schedule').hide();
                            } else
                            {
                                jQuery('#mailchimp_sync_schedule').show();
                            }
                        } else
                        {
                            jQuery('#mailchimp_sync_schedule').hide();
                            jQuery('#mailchimp_sync_via').hide();
                        }
                    },

                    /**
                     * syncVia function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    syncVia: function (e)
                    {
                        var mailchimp_sync_via = jQuery(e.target).val();

                        if (mailchimp_sync_via == 'cron_job')
                        {
                            jQuery('#mailchimp_sync_schedule').show();
                        } else
                        {
                            jQuery('#mailchimp_sync_schedule').hide();
                        }
                    },

                    /**
                     * addField function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    addField: function (e)
                    {
                        var $wrap = jQuery(this).closest('table');

                        var cloned_tr = $wrap.find('tbody.wpem-mc-block-editor-table-body tr:last').html();

                        cloned_tr = cloned_tr.replace('selected="selected"', '');
                        cloned_tr = cloned_tr.replace('selected="selected"', '');

                        $wrap.find('tbody.wpem-mc-block-editor-table-body').append('<tr>' + cloned_tr + '</tr>');
                    },

                    /**
                     * deleteField function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    deleteField: function (e)
                    {
                        jQuery(e.target).closest('tr').remove();
                    },

                    /**
                     * addFilter function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    addFilter: function (e)
                    {
                        var html = jQuery(e.target).closest('.wpem-row').html();
                        html = html.replace('selected="selected"', '');
                        html = html.replace('selected="selected"', '');
                        jQuery('.wpem-mailchimp-sync-list-filter .wpem-form-wrapper-body').append('<div class="wpem-row">' + html + '</div>');
                        jQuery('.wpem-mailchimp-sync-list-filter .wpem-form-wrapper-body .wpem-row').last().find('.wpem-col-md-5 input.sync-filter-value').val('');
                    },

                    /**
                     * deleteFilter function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    deleteFilter: function (e)
                    {
                        jQuery(e.target).closest('.wpem-row').remove();
                    },

                    /**
                     * addMailchimpList function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    addMailchimpList: function (e)
                    {
                        var event_id = jQuery(e.target).data('event-id');
                        var mailchimp_list = jQuery(e.target).val();

                        jQuery.ajax({
                            url: wpem_mailchimp.ajax_url,
                            type: 'POST',
                            dataType: 'JSON',
                            data: {
                                action: 'event_manager_mailchimp_save_list_event',
                                security: wpem_mailchimp.wpem_mailchimp_dashboard_security,
                                event_id: event_id,
                                mailchimp_list: mailchimp_list,
                            },
                            success: function (responce)
                            {

                            }
                        });
                    },

                    /**
                     * allSelectAttendees function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    allSelectAttendees: function (e)
                    {
                        if (jQuery(e.target).prop("checked") == true) {
                            jQuery('.wpem-mailchimp-sync-attendees input[type="checkbox"]').prop('checked', true);
                        } else if (jQuery(e.target).prop("checked") == false) {
                            jQuery('.wpem-mailchimp-sync-attendees input[type="checkbox"]').prop('checked', false);
                        }

                        var allSelectAttendees = [];

                        jQuery.each(jQuery('.wpem-mailchimp-sync-attendees input.attende-id:checked'), function () {
                            allSelectAttendees.push(jQuery(this).val());
                        });

                        jQuery('.wpem-mailchimp-sync-attendees input#attendees_ids').val(allSelectAttendees.toString());
                    },

                    /**
                     * selectAttendees function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    selectAttendees: function (e)
                    {
                        var allSelectAttendees = [];

                        jQuery.each(jQuery('.wpem-mailchimp-sync-attendees input.attende-id:checked'), function () {
                            allSelectAttendees.push(jQuery(this).val());
                        });

                        jQuery('.wpem-mailchimp-sync-attendees input#attendees_ids').val(allSelectAttendees.toString());
                    },

                    /**
                     * syncAttendees function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    syncAttendees: function (e)
                    {
                        var attendees_ids = jQuery('.wpem-mailchimp-sync-attendees input#attendees_ids').val();

                        var arr_attendees_ids = [];

                        if (attendees_ids != '')
                        {
                            arr_attendees_ids = attendees_ids.split(',');
                            jQuery('.wpem-mailchimp-sync-registrations .wpem-alert').css('display', 'none');
                        } else {
                            jQuery('.wpem-mailchimp-sync-registrations .wpem-alert').css('display', 'block');
                        }

                        var newData = {};
                        newData['event_id'] = jQuery('.wpem-mailchimp-sync-attendees input#event_id').val();

                        if (arr_attendees_ids.length > 0) {
                            jQuery.each(arr_attendees_ids, function (index, value) {
                                newData['attendees_id'] = [value];

                                var data = {
                                    action: 'event_manager_mailchimp_sync_attendees',
                                    form_data: newData,
                                    security: wpem_mailchimp.wpem_mailchimp_dashboard_security
                                };

                                jQuery('.attendees-id-' + value + ' .sync-status').html('<img src="' + wpem_mailchimp.in_queue_icon + '" width="20" height="20">');

                                jQuery.post(wpem_mailchimp.ajax_url, data, function (response) {
                                    jQuery('.attendees-id-' + value + ' .sync-status').html(response.message);
                                }, 'json');
                            });
                        }

                        return false;
                    },

                    /**
                     * allSelectGuests function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    allSelectGuests: function (e)
                    {
                        if (jQuery(e.target).prop("checked") == true) {
                            jQuery('.wpem-mailchimp-sync-guests input[type="checkbox"]').prop('checked', true);
                        } else if (jQuery(e.target).prop("checked") == false) {
                            jQuery('.wpem-mailchimp-sync-guests input[type="checkbox"]').prop('checked', false);
                        }

                        var allSelectGuests = [];

                        jQuery.each(jQuery('.wpem-mailchimp-sync-guests input.attende-id:checked'), function () {
                            allSelectGuests.push(jQuery(this).val());
                        });

                        jQuery('.wpem-mailchimp-sync-guests input#guests_ids').val(allSelectGuests.toString());
                    },

                    /**
                     * selectGuests function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    selectGuests: function (e)
                    {
                        var allSelectGuests = [];

                        jQuery.each(jQuery('.wpem-mailchimp-sync-guests input.attende-id:checked'), function () {
                            allSelectGuests.push(jQuery(this).val());
                        });

                        jQuery('.wpem-mailchimp-sync-guests input#guests_ids').val(allSelectGuests.toString());
                    },

                    /**
                     * syncGuests function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    syncGuests: function (e)
                    {
                        var guests_ids = jQuery('.wpem-mailchimp-sync-guests input#guests_ids').val();

                        var arr_guests_ids = [];

                        if (guests_ids != '')
                        {
                            arr_guests_ids = guests_ids.split(',');
                            jQuery('.wpem-mailchimp-sync-guests .wpem-alert').css('display', 'none');
                        } else {
                            jQuery('.wpem-mailchimp-sync-guests .wpem-alert').css('display', 'block');
                        }

                        //console.log(arr_guests_ids);
                        var newData = {};
                        newData['event_id'] = jQuery('.wpem-mailchimp-sync-guests input#event_id').val();

                        if (arr_guests_ids.length > 0) {
                            jQuery.each(arr_guests_ids, function (index, value) {
                                newData['guests_id'] = [value];

                                var data = {
                                    action: 'event_manager_mailchimp_sync_guests',
                                    form_data: newData,
                                    security: wpem_mailchimp.wpem_mailchimp_dashboard_security
                                };

                                jQuery('.guests-id-' + value + ' .sync-status').html('<img src="' + wpem_mailchimp.in_queue_icon + '" width="20" height="20">');

                                jQuery.post(wpem_mailchimp.ajax_url, data, function (response) {
                                    jQuery('.guests-id-' + value + ' .sync-status').html(response.message);
                                }, 'json');
                            });
                        }

                        return false;
                    },

                } /* end of action */

    }; /* enf of return */

}; /* end of class */

MailchimpIntegrationDashboard = MailchimpIntegrationDashboard();

jQuery(document).ready(function ($)
{
    MailchimpIntegrationDashboard.init();
});
