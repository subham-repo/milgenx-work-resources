var AdminMailchimpIntegration = function () {

    return {

        init: function() 
        {
            jQuery( 'select#mailchimp-sync-type' ).on('change', AdminMailchimpIntegration.actions.syncType);
            jQuery( 'select#mailchimp-sync-via' ).on('change', AdminMailchimpIntegration.actions.syncVia);

            jQuery( 'body' ).on('click', '.wpem-mailchimp-organizer-matches-attribute .add-field', AdminMailchimpIntegration.actions.addFieldOrganization);
            jQuery( 'body' ).on('click', '.wpem-mailchimp-organizer-matches-attribute .delete-field', AdminMailchimpIntegration.actions.deleteFieldOrganization);

            jQuery( 'body' ).on('click', '.wpem-mailchimp-registration-matches-attribute .add-field', AdminMailchimpIntegration.actions.addFieldRegistration);
            jQuery( 'body' ).on('click', '.wpem-mailchimp-registration-matches-attribute .delete-field', AdminMailchimpIntegration.actions.deleteFieldRegistration);

            jQuery( 'body' ).on('click', '.wpem-mailchimp-guest-list-matches-attribute .add-field', AdminMailchimpIntegration.actions.addFieldGuest);
            jQuery( 'body' ).on('click', '.wpem-mailchimp-guest-list-matches-attribute .delete-field', AdminMailchimpIntegration.actions.deleteFieldGuest);

           },


        actions:
        {

            /**
             * syncType function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            syncType: function (e) 
            {
            
                var mailchimp_sync_type = jQuery(e.target).val();            
                if(mailchimp_sync_type === 'auto')
                {
                    jQuery('#mailchimp-sync-via').show();

                    var mailchimp_sync_via = jQuery('#mailchimp-sync-via').val();
                    if(mailchimp_sync_via == 'when_created')
                    {
                        jQuery('#mailchimp_sync_schedule').hide();
                    }
                    else
                    {
                        jQuery('#mailchimp_sync_schedule').show();
                    }
                }
                else
                {
                    jQuery('#mailchimp-sync-via').hide();
                    jQuery('#mailchimp_sync_schedule').hide();
                }
            },

            /**
             * syncVia function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            syncVia: function (e) 
            {  
                var mailchimp_sync_via = jQuery(e.target).val();
                if(mailchimp_sync_via == 'cron_job')
                {
                    jQuery('#mailchimp_sync_schedule').show();
                }
                else
                {
                    jQuery('#mailchimp_sync_schedule').hide();
                }
            },

            /**
             * addFieldOrganization function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            addFieldOrganization: function (e) 
            {   
                //var html = jQuery(e.target).closest('tr').html();
                var html = jQuery('.wpem-mailchimp-organizer-matches-attribute tbody tr').last().html();
                html = html.replace('selected="selected"', '');
                html = html.replace('selected="selected"', '');
                jQuery('.wpem-mailchimp-organizer-matches-attribute tbody').append('<tr>' + html + '</tr>');
            },

            /**
             * deleteFieldOrganization function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            deleteFieldOrganization: function (e) 
            {   
                jQuery(e.target).closest('tr').remove();
            },

            /**
             * addFieldRegistration function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            addFieldRegistration: function (e) 
            {   
                //var html = jQuery(e.target).closest('tr').html();
                var html = jQuery('.wpem-mailchimp-registration-matches-attribute tbody tr').last().html();
                html = html.replace('selected="selected"', '');
                html = html.replace('selected="selected"', '');
                jQuery('.wpem-mailchimp-registration-matches-attribute tbody').append('<tr>' + html + '</tr>');
            },

            /**
             * deleteFieldRegistration function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            deleteFieldRegistration: function (e) 
            {   
                jQuery(e.target).closest('tr').remove();
            },

            /**
             * addFieldGuest function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            addFieldGuest: function (e) 
            {   
                //var html = jQuery(e.target).closest('tr').html();
                var html = jQuery('.wpem-mailchimp-guest-list-matches-attribute tbody tr').last().html();
                html = html.replace('selected="selected"', '');
                html = html.replace('selected="selected"', '');
                jQuery('.wpem-mailchimp-guest-list-matches-attribute tbody').append('<tr>' + html + '</tr>');
            },

            /**
             * deleteFieldGuest function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            deleteFieldGuest: function (e) 
            {   
                jQuery(e.target).closest('tr').remove();
            },
        
        } /* end of action */

    }; /* enf of return */

}; /* end of class */

AdminMailchimpIntegration = AdminMailchimpIntegration();

jQuery(document).ready(function() 
{
   AdminMailchimpIntegration.init();
});
