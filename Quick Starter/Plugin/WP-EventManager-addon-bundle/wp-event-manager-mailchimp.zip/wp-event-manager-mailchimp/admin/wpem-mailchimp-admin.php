<?php

/*
 * This file use for setings at admin site for event mailchimp integration admin.
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * WPEM_Mailchimp_Integration_Admin class.
 */
class WPEM_Mailchimp_Admin {

    /**
     * The single instance of the class.
     *
     * @var self
     * @since  2.5
     */
    private static $_instance = null;

    /**
     * Main WP Event Manager Instance.
     *
     * Ensures only one instance of WP Event Manager is loaded or can be loaded.
     *
     * @since  2.5
     * @static
     * @see WP_Event_Manager()
     * @return self Main instance.
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * __construct function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function __construct() {
        include ('wpem-mailchimp-settings.php');
        $this->settings_class = new WPEM_Mailchimp_Settings();

        add_action('admin_menu', array($this, 'admin_menu'), 12);

        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));

        if (get_option('enable_event_organizer')) {
            //add_action( 'wp_event_mailchimp_settings_after', array( $this, 'wp_event_mailchimp_organization_matches_attribute' ) );

            add_filter('manage_edit-event_organizer_columns', array($this, 'event_organizer_columns'), 12);
            add_action('manage_event_organizer_posts_custom_column', array($this, 'event_organizer_content'));
        }

        if (is_plugin_active('wp-event-manager-registrations/wp-event-manager-registrations.php')) {
            add_action('wp_event_mailchimp_settings_after', array($this, 'wpem_mailchimp_admin_registration_field_mapping'));

            add_filter('manage_edit-event_registration_columns', array($this, 'event_registration_columns'), 12);
            add_action('manage_event_registration_posts_custom_column', array($this, 'event_registration_content'));

            //manual registration bulk action
            add_filter('bulk_actions-edit-event_registration', array($this, 'register_registration_bulk_actions'));
            add_filter('handle_bulk_actions-edit-event_registration', array($this, 'wpem_sync_attendee_bulk_handler'), 10, 3);
            add_action('admin_notices', array($this, 'registration_sync_bulk_action_admin_notice'));

            //manual Gust list bulk action
            add_filter('bulk_actions-edit-event_guest_list', array($this, 'register_guest_list_bulk_actions'));
            add_filter('handle_bulk_actions-edit-event_guest_list', array($this, 'wpem_sync_guest_bulk_handler'), 10, 3);
            add_action('admin_notices', array($this, 'guest_sync_bulk_action_admin_notice'));
        }

        if (is_plugin_active('wp-event-manager-guest-lists/wp-event-manager-guest-lists.php')) {
            add_action('wp_event_mailchimp_settings_after', array($this, 'wpem_mailchimp_guest_lists_field_mapping'));

            add_filter('manage_edit-event_guest_list_columns', array($this, 'event_guest_list_columns'), 12);
            add_action('manage_event_guest_list_posts_custom_column', array($this, 'event_guest_list_content'));
        }

        // while new create
        add_action('wp_insert_post', array($this, 'mailchimp_sync_via_add_new_create'), 10, 3);

        // Ajax
        add_action('wp_ajax_event_manager_mailchimp_sync_admin', array($this, 'event_manager_mailchimp_sync_admin'));
    }

    /**
     * admin_menu function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function admin_menu() {
        add_submenu_page('edit.php?post_type=event_listing', __('WP Event Manager Mailchimp Settings', 'wp-event-manager-mailchimp'), __('Mailchimp', 'wp-event-manager-mailchimp'), 'manage_options', 'event-manager-mailchimp-settings', array($this->settings_class, 'wp_event_mailchimp_settings'), 7);
    }

    /**
     * admin_enqueue_scripts function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function admin_enqueue_scripts() {
        wp_enqueue_style('wpem-mailchimp-admin', WPEM_MAILCHIMP_PLUGIN_URL . '/assets/css/admin.css', '', WPEM_MAILCHIMP_VERSION);

        wp_register_script('wpem-mailchimp-admin', WPEM_MAILCHIMP_PLUGIN_URL . '/assets/js/admin-mailchimp.js', array('jquery'), WPEM_MAILCHIMP_VERSION, true);

        $mailchimp_settings = get_mailchimp_settings_by_user();

        $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
        $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : '';
        $mailchimp_sync_type = isset($mailchimp_settings['mailchimp_sync_type']) ? $mailchimp_settings['mailchimp_sync_type'] : '';

        $add_sync_button = 'no';

        if ($mailchimp_sync_type === 'manual') {
            $check_mailchimp_key = check_mailchimp_key($mailchimp_api_key);
            if (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] == 401 && $mailchimp_list == '') {
                $add_sync_button = 'no';
            } else if ($mailchimp_api_key == '' || $mailchimp_list == '') {
                $add_sync_button = 'no';
            } else {
                $add_sync_button = 'yes';
            }
        }

        wp_localize_script('wpem-mailchimp-admin', 'wpem_mailchimp_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'wpem_mailchimp_admin_security' => wp_create_nonce('_nonce_wpem_mailchimp_admin_security'),
            'in_queue_icon' => EVENT_MANAGER_PLUGIN_URL . '/assets/images/ajax-loader.gif',
                //'sync_button_text' => __( 'Sync with Mailchimp', 'wp-event-manager-mailchimp'),
                //'add_sync_button' => $add_sync_button,
                )
        );

        wp_enqueue_script('wpem-mailchimp-admin');
    }

    /**
     * wp_event_mailchimp_organization_matches_attribute function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wp_event_mailchimp_organization_matches_attribute() {


        if (!empty($_POST['wp_event_mailchimp_organizer_matches_attribute']) && wp_verify_nonce($_POST['_wpnonce'], 'event_mailchimp_organizer_matches_attribute')) {
            $organizer_field = !empty($_POST['organizer_field']) ? array_filter($_POST['organizer_field']) : '';

            $enable_mailchimp_organizer = isset($_POST['enable_mailchimp_organizer']) ? $_POST['enable_mailchimp_organizer'] : 0;
            $organizer_mailchimp_field = !empty($_POST['organizer_mailchimp_field']) ? array_filter($_POST['organizer_mailchimp_field']) : '';

            update_option('organizer_field', $organizer_field);

            $new_organizer_mailchimp_field = [];

            if (!empty($organizer_mailchimp_field)) {
                foreach ($organizer_mailchimp_field as $key => $value) {
                    if (isset($organizer_field[$key]))
                        $new_organizer_mailchimp_field[$value] = $organizer_field[$key];
                }
            }
            update_option('organizer_mailchimp_field', $new_organizer_mailchimp_field);

            update_option('enable_mailchimp_organizer', $enable_mailchimp_organizer);
        }

        $enable_mailchimp_organizer = get_option('enable_mailchimp_organizer', true);

        $mailchimp_settings = get_mailchimp_settings_by_user();

        $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
        $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : '';
        $check_mailchimp_key = check_mailchimp_key($mailchimp_api_key);

        $organizer_field = get_option('organizer_field');
        $organizer_mailchimp_field = get_option('organizer_mailchimp_field');

        if (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] == 401)
            return;

        if ($mailchimp_api_key != '' && is_array($check_mailchimp_key)) :
            include('templates/organizer-field-mapping.php');
        endif;
    }

    /**
     * event_organizer_columns function.
     *
     * @access public
     * @param mixed $columns
     * @return void
     * @since 1.0.0
     */
    public function event_organizer_columns($columns) {
        foreach ($columns as $key => $column) {
            $new_columns[$key] = $column;

            if ('organizer_email' === $key) {
                $new_columns['is_mailchimp_sync'] = '<span class="tips dashicons dashicons-email" data-tip="' . __("Mailchimp", 'wp-event-manager-mailchimp') . '">' . __("Mailchimp", 'wp-event-manager') . '</span>';
            }
        }

        return $new_columns;
    }

    /**
     * event_organizer_content function.
     *
     * @access public
     * @param mixed $column_name
     * @return void
     * @since 1.0.0
     */
    public function event_organizer_content($column_name) {
        global $post;

        if ($column_name == 'is_mailchimp_sync') {
            $is_mailchimp_sync = get_post_meta($post->ID, 'is_mailchimp_sync', true);

            if ($is_mailchimp_sync == '') {
                $is_mailchimp_sync = __('-', 'wp-event-manager-mailchimp');
            }

            echo $is_mailchimp_sync;
        }
    }

    /**
     * wpem_mailchimp_admin_registration_field_mapping function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wpem_mailchimp_admin_registration_field_mapping() {
        if (!empty($_POST['submit_mailchimp_admin_registration_mapping']) && wp_verify_nonce($_POST['_wpnonce'], 'wpem_mailchimp_admin_registration_field_mapping')) {
            $registration_field = !empty($_POST['registration_field']) ? array_filter($_POST['registration_field']) : '';
            $registration_mailchimp_field = !empty($_POST['registration_mailchimp_field']) ? array_filter($_POST['registration_mailchimp_field']) : '';
            $enable_mailchimp_registration = !empty($_POST['enable_mailchimp_registration']) ? $_POST['enable_mailchimp_registration'] : 0;


            update_option('registration_field', $registration_field);

            $new_registration_mailchimp_field = [];

            if (!empty($registration_mailchimp_field) > 0) {
                foreach ($registration_mailchimp_field as $key => $value) {
                    $new_registration_mailchimp_field[$value] = $registration_field[$key];
                }
            }
            update_option('registration_mailchimp_field', $new_registration_mailchimp_field);
            update_option('enable_mailchimp_registration', $enable_mailchimp_registration);
        }

        $enable_mailchimp_registration = get_option('enable_mailchimp_registration', true);

        $mailchimp_settings = get_mailchimp_settings_by_user();

        $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
        $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : '';
        $check_mailchimp_key = check_mailchimp_key($mailchimp_api_key);

        $registration_field = get_option('registration_field');
        $registration_mailchimp_field = get_option('registration_mailchimp_field');

        if (empty($registration_mailchimp_field)) {
            $registration_mailchimp_field = get_default_mailchimp_registration_matches_attribute();
        }

        if (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] == 401)
            return;

        if ($mailchimp_api_key != '' && is_array($check_mailchimp_key)) :
            include('templates/registration-field-mapping.php');
        endif;
    }

    /**
     * event_registration_columns function.
     *
     * @access public
     * @param mixed $columns
     * @return void
     * @since 1.0.0
     */
    public function event_registration_columns($columns) {
        foreach ($columns as $key => $column) {
            $new_columns[$key] = $column;

            if ('event_registration_posted' === $key) {
                $new_columns['is_mailchimp_sync'] = '<span class="tips dashicons dashicons-email" data-tip="' . __("Mailchimp", 'wp-event-manager-mailchimp') . '">' . __("Mailchimp", 'wp-event-manager') . '</span>';
            }
        }

        return $new_columns;
    }

    /**
     * event_registration_content function.
     *
     * @access public
     * @param mixed $column_name
     * @return void
     * @since 1.0.0
     */
    public function event_registration_content($column_name) {
        global $post;

        if ($column_name == 'is_mailchimp_sync') {
            $is_mailchimp_sync = get_post_meta($post->ID, 'is_mailchimp_sync', true);

            if ($is_mailchimp_sync == '') {
                $is_mailchimp_sync = __('-', 'wp-event-manager-mailchimp');
            }

            echo $is_mailchimp_sync;
        }
    }

    /**
     * register_my_bulk_actions function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function register_registration_bulk_actions($bulk_actions) {
        $enable_registration = get_option('enable_mailchimp_registration', true);
        $mailchimp_settings = get_mailchimp_settings_by_user();

        $sync_type = isset($mailchimp_settings['mailchimp_sync_type']) ? $mailchimp_settings['mailchimp_sync_type'] : 'auto';

        if ($sync_type == 'manual' && $enable_registration == true)
            $bulk_actions['attendee_sync_mailchimp'] = __('Sync with mailchimp', 'wp-event-manager-mailchimp');

        return $bulk_actions;
    }

    /**
     * wpem_sync_attendee_bulk_handler function.
     *
     * @access public
     * @return String 
     * @since 1.0.0
     */
    public function wpem_sync_attendee_bulk_handler($redirect_to, $doaction, $post_ids) {
        if ($doaction !== 'attendee_sync_mailchimp')
            return $redirect_to;

        $response = $this->add_admin_data_in_mailchimp_list('event_registration', $post_ids);

        $redirect_to = add_query_arg('bulk_attendee_sync', count($post_ids), $redirect_to);
        return $redirect_to;
    }

    /**
     * registration_sync_bulk_action_admin_notice function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function registration_sync_bulk_action_admin_notice() {
        if (!empty($_REQUEST['bulk_attendee_sync'])) {
            $attendee_count = intval($_REQUEST['bulk_attendee_sync']);
            printf('<div class="updated"><p id="message" class="updated fade">' .
                    _n('%s Attendee syncronized to Mailchimp.',
                            '%s Attendee syncronized to Mailchimp.',
                            $attendee_count,
                            'wp-event-manager-mailchimp'
                    ) . '</p></div>', $attendee_count);
        }
    }

    /**
     * register_guest_list_bulk_actions function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function register_guest_list_bulk_actions($bulk_actions) {
        $enable_guest_list = get_option('enable_mailchimp_registration', true);
        $mailchimp_settings = get_mailchimp_settings_by_user();

        $sync_type = isset($mailchimp_settings['mailchimp_sync_type']) ? $mailchimp_settings['mailchimp_sync_type'] : 'auto';

        if ($sync_type == 'manual' && $enable_guest_list == true)
            $bulk_actions['guest_sync_mailchimp'] = __('Sync with mailchimp', 'wp-event-manager-mailchimp');

        return $bulk_actions;
    }

    /**
     * wpem_sync_attendee_bulk_handler function.
     *
     * @access public
     * @return String 
     * @since 1.0.0
     */
    public function wpem_sync_guest_bulk_handler($redirect_to, $doaction, $post_ids) {
        if ($doaction !== 'guest_sync_mailchimp')
            return $redirect_to;

        $response = $this->add_admin_data_in_mailchimp_list('event_guest_list', $post_ids);

        $redirect_to = add_query_arg('bulk_guest_sync', count($post_ids), $redirect_to);
        return $redirect_to;
    }

    /**
     * registration_sync_bulk_action_admin_notice function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function guest_sync_bulk_action_admin_notice() {
        if (!empty($_REQUEST['bulk_guest_sync'])) {
            $guest_count = intval($_REQUEST['bulk_guest_sync']);
            printf('<div class="updated"><p id="message" class="updated fade">' .
                    _n('Guest %s syncronized to Mailchimp.',
                            'Guests %s syncronized to Mailchimp.',
                            $guest_count,
                            'wp-event-manager-mailchimp'
                    ) . '</p></div>', $guest_count);
        }
    }

    /**
     * wpem_mailchimp_guest_lists_field_mapping function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wpem_mailchimp_guest_lists_field_mapping() {
        if (!empty($_POST['submit_mailchimp_admin_guest_list_field_mapping']) && wp_verify_nonce($_POST['_wpnonce'], 'wpem_admin_mailchimp_guest_list_field_mapping')) {
            $guest_list_field = !empty($_POST['guest_list_field']) ? array_filter($_POST['guest_list_field']) : '';
            $guest_list_mailchimp_field = !empty($_POST['guest_list_mailchimp_field']) ? array_filter($_POST['guest_list_mailchimp_field']) : '';
            $enable_mailchimp_guest_list = isset($_POST['enable_mailchimp_guest_list']) ? $_POST['enable_mailchimp_guest_list'] : 0;

            update_option('guest_list_field', $guest_list_field);

            $new_registration_mailchimp_field = [];

            if (!empty($guest_list_mailchimp_field) > 0) {
                foreach ($guest_list_mailchimp_field as $key => $value) {
                    $new_registration_mailchimp_field[$value] = $guest_list_field[$key];
                }
            }
            update_option('guest_list_mailchimp_field', $new_registration_mailchimp_field);
            update_option('enable_mailchimp_guest_list', $enable_mailchimp_guest_list);
        }
        $enable_mailchimp_guest_list = get_option('enable_mailchimp_guest_list', true);
        $mailchimp_settings = get_mailchimp_settings_by_user();

        $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
        $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : '';
        $check_mailchimp_key = check_mailchimp_key($mailchimp_api_key);

        $guest_list_field = get_option('guest_list_field');
        $guest_list_mailchimp_field = get_option('guest_list_mailchimp_field');

        if (empty($guest_list_mailchimp_field)) {
            $guest_list_mailchimp_field = get_default_mailchimp_guest_list_matches_attribute();
        }

        if (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] == 401)
            return;

        if ($mailchimp_api_key != '' && is_array($check_mailchimp_key)) :
            include('templates/guestlist-field-mapping.php');
        endif;
    }

    /**
     * event_guest_list_columns function.
     *
     * @access public
     * @param mixed $columns
     * @return void
     * @since 1.0.0
     */
    public function event_guest_list_columns($columns) {
        foreach ($columns as $key => $column) {
            $new_columns[$key] = $column;

            if ('group_name' === $key) {
                $new_columns['is_mailchimp_sync'] = '<span class="tips dashicons dashicons-email" data-tip="' . __("Mailchimp", 'wp-event-manager-mailchimp') . '">' . __("Mailchimp", 'wp-event-manager') . '</span>';
            }
        }

        return $new_columns;
    }

    /**
     * event_guest_list_content function.
     *
     * @access public
     * @param mixed $column_name
     * @return void
     * @since 1.0.0
     */
    public function event_guest_list_content($column_name) {
        global $post;

        if ($column_name == 'is_mailchimp_sync') {
            $is_mailchimp_sync = get_post_meta($post->ID, 'is_mailchimp_sync', true);

            if ($is_mailchimp_sync == '') {
                $is_mailchimp_sync = __('-', 'wp-event-manager-mailchimp');
            }

            echo $is_mailchimp_sync;
        }
    }

    /**
     * get_mailchip_list function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function get_mailchip_list() {
        $mailchimp_settings = get_mailchimp_settings_by_user();

        $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';

        $lists = [];

        if ($mailchimp_api_key != '') {
            $lists = get_mailchimp_lists($mailchimp_api_key);
        }

        return $lists;
    }

    /**
     * mailchimp_sync_via_add_new_create function.
     *
     * @access public
     * @param mixed $post_id, $post, $update
     * @return void
     * @since 1.0.0
     */
    public function mailchimp_sync_via_add_new_create($post_id, $post, $update) {
        $mailchimp_settings = get_mailchimp_settings_by_user();

        $mailchimp_sync_type = isset($mailchimp_settings['mailchimp_sync_type']) ? $mailchimp_settings['mailchimp_sync_type'] : '';
        $mailchimp_sync_via = isset($mailchimp_settings['mailchimp_sync_via']) ? $mailchimp_settings['mailchimp_sync_via'] : '';

        if ($mailchimp_sync_type == 'auto' && $mailchimp_sync_via == 'when_created') {
            if (!in_array($post->post_status, ['auto-draft']) && in_array($post->post_type, ['event_organizer', 'event_registration', 'event_guest_list'])) {
                $arr_post_id = [$post_id];
                $post_type = $post->post_type;

                if (count($arr_post_id) > 0) {
                    $response = $this->add_admin_data_in_mailchimp_list($post_type, $arr_post_id);
                }
            }
        }
    }

    /**
     * add_admin_data_in_mailchimp_list function.
     *
     * @access public
     * @param mixed $post_type, $arr_post_id
     * @return void
     * @since 1.0.0
     */
    public function add_admin_data_in_mailchimp_list($post_type = '', $arr_post_id = []) {
        $response = [];

        if (in_array($post_type, ['event_organizer', 'event_registration', 'event_guest_list']) != '' && !empty($arr_post_id)) {
            $mailchimp_settings = get_mailchimp_settings_by_user();

            $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
            $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : '';

            $organizer_mailchimp_field = get_option('organizer_mailchimp_field');
            $registration_mailchimp_field = get_option('registration_mailchimp_field');
            $guest_list_mailchimp_field = get_option('guest_list_mailchimp_field');

            if ($post_type == 'event_organizer') {
                $mailchimp_sync_field = $organizer_mailchimp_field;

                if (empty($mailchimp_sync_field)) {
                    $mailchimp_sync_field = get_default_mailchimp_organizer_matches_attribute();
                }

                $new_mailchimp_sync_field = [];

                foreach ($mailchimp_sync_field as $key => $value) {
                    $new_mailchimp_sync_field[$key] = '_' . $value;
                }

                $mailchimp_sync_field = $new_mailchimp_sync_field;
            } else if ($post_type == 'event_registration') {
                $mailchimp_sync_field = $registration_mailchimp_field;

                if (empty($mailchimp_sync_field)) {
                    $mailchimp_sync_field = get_default_mailchimp_registration_matches_attribute();
                }
            } else if ($post_type == 'event_guest_list') {
                $mailchimp_sync_field = $guest_list_mailchimp_field;

                if (empty($mailchimp_sync_field)) {
                    $mailchimp_sync_field = get_default_mailchimp_guest_list_matches_attribute();
                }
            }

            foreach ($arr_post_id as $post_id) {

                $post = get_post($post_id);
                if (isset($mailchimp_settings['mailchimp_list']) && $mailchimp_settings['mailchimp_list'] == false) {
                    $event_id = $post->post_parent;
                    $event_mailchimp_list = get_post_meta($event_id, 'mailchimp_list', true);
                    if ($event_mailchimp_list == false) {
                        $response['message'] = __('Synchronization disabled for this event.', 'wp-event-manager-mailchimp');
                        continue;
                    }

                    if (!empty($event_mailchimp_list)) {
                        $mailchimp_list = $event_mailchimp_list;
                    }
                }

                $is_mailchimp_sync = get_post_meta($post_id, 'is_mailchimp_sync', true);

                if ($is_mailchimp_sync != 'subscribed') {
                    $result = sync_data_in_mailchimp_list($mailchimp_api_key, $mailchimp_list, $mailchimp_sync_field, $post_id);

                    if ($result['status'] == 400) {

                        if ($result['title'] == 'Member Exists') {
                            update_post_meta($post_id, 'is_mailchimp_sync', 'subscribed');
                        }

                        $response['code'] = 400;
                        $response['message'] = __($result['title'], 'wp-event-manager-mailchimp');
                    } else {
                        if ($result['id'] != '') {
                            update_post_meta($post_id, 'is_mailchimp_sync', 'subscribed');
                        }

                        $response['code'] = 200;
                        $response['message'] = __('Subscribed', 'wp-event-manager-mailchimp');
                    }
                }
            }
        }

        return $response;
    }

    /**
     * event_manager_mailchimp_sync_admin function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function event_manager_mailchimp_sync_admin() {
        check_ajax_referer('_nonce_wpem_mailchimp_admin_security', 'security');

        $params = $_POST['form_data'];

        $response = [];

        $arr_post_id = $params['post_id'];
        $post_type = $params['post_type'];

        if (count($arr_post_id) > 0) {
            $response = $this->add_admin_data_in_mailchimp_list($post_type, $arr_post_id);
        }

        print_r(json_encode($response));
        wp_die();
    }

}

new WPEM_Mailchimp_Admin();
