<?php
/*
* This file use for setings at admin site for event mailchimp integration settings.
*/
if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * WPEM_Mailchimp_Integration_Settings class.
 */
class WPEM_Mailchimp_Settings
{

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 * @since 1.0.0
	 */
	public function __construct()
	{
	}

	/**
	 * wp_event_mailchimp_settings function.
	 *
	 * @access public
	 * @return void
	 * @since 1.0.0
	 */
	public function wp_event_mailchimp_settings()
	{
		$user_id = get_current_user_id();

		if (!empty($_POST['wp_event_mailchimp_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'event_mailchimp_disconnect_settings')) {
			$arr_mailchimp_lists = get_sync_fields_by_user($user_id, 'mailchimp_lists');

			if (!empty($arr_mailchimp_lists)) {
				foreach ($arr_mailchimp_lists as $mailchimp_list => $mailchimp_name) {
					delete_mailchimp_settings_by_user('mailchimp_list_dynamic_field_' . $mailchimp_list);
				}
			}
			delete_mailchimp_settings_by_user('mailchimp_lists');
			delete_mailchimp_settings_by_user('mailchimp_settings');

			$arr_post_type = ['event_organizer', 'event_registration', 'event_guest_list'];
			wp_clear_scheduled_hook('event_manager_auto_mailchimp_sync_admin', array($arr_post_type));
		}

		if (!empty($_POST['wp_event_mailchimp_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'event_mailchimp_settings')) {
			$mailchimp_api_key  = !empty($_POST['mailchimp_api_key']) ? sanitize_text_field($_POST['mailchimp_api_key']) : '';
			$mailchimp_list  = !empty($_POST['mailchimp_list']) ? sanitize_text_field($_POST['mailchimp_list']) : '';
			$mailchimp_sync_type  = !empty($_POST['mailchimp_sync_type']) ? sanitize_text_field($_POST['mailchimp_sync_type']) : '';
			$mailchimp_sync_via  = !empty($_POST['mailchimp_sync_via']) ? sanitize_text_field($_POST['mailchimp_sync_via']) : '';
			$mailchimp_sync_schedule  = !empty($_POST['mailchimp_sync_schedule']) ? sanitize_text_field($_POST['mailchimp_sync_schedule']) : 'weekly';

			$mailchimp_settings = [
				'mailchimp_api_key' => $mailchimp_api_key,
				'mailchimp_list' => $mailchimp_list,
				'mailchimp_sync_type' => $mailchimp_sync_type,
				'mailchimp_sync_schedule' => $mailchimp_sync_schedule,
				'mailchimp_sync_via' => $mailchimp_sync_via,
			];

			update_mailchimp_settings_by_user('mailchimp_settings', $mailchimp_settings);

			$arr_post_type = ['event_organizer', 'event_registration', 'event_guest_list'];
			wp_clear_scheduled_hook('event_manager_auto_mailchimp_sync_admin', array($arr_post_type));

			if ($mailchimp_sync_type == 'auto' && $mailchimp_sync_via == 'cron_job') {
				switch ($mailchimp_sync_schedule) {
					case '5min':
						$next = strtotime('+5 minutes');
						break;
					case 'daily':
						$next = strtotime('+1 day');
						break;
					case 'weekly':
						$next = strtotime('+1 week');
						break;
					case 'monthly':
						$next = strtotime('+1 month');
						break;
					case 'yearly':
						$next = strtotime('+1 year');
						break;
					default:
						$next = strtotime('+1 week');
						break;
				}

				// Create cron
				wp_schedule_event($next, $mailchimp_sync_schedule, 'event_manager_auto_mailchimp_sync_admin', array($arr_post_type));
			}
		}

		$mailchimp_settings = get_mailchimp_settings_by_user();

		$mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
		$mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : '';
		$mailchimp_sync_type = isset($mailchimp_settings['mailchimp_sync_type']) && !empty($mailchimp_settings['mailchimp_sync_type']) ? $mailchimp_settings['mailchimp_sync_type'] : 'auto';
		$mailchimp_sync_via = isset($mailchimp_settings['mailchimp_sync_via']) && !empty($mailchimp_settings['mailchimp_sync_via']) ? $mailchimp_settings['mailchimp_sync_via'] : 'cron_job';
		$mailchimp_sync_schedule = isset($mailchimp_settings['mailchimp_sync_schedule']) ? $mailchimp_settings['mailchimp_sync_schedule'] : '';

		$check_mailchimp_key = check_mailchimp_key($mailchimp_api_key);

		include('templates/mailchimp-settings.php');
	}
}
