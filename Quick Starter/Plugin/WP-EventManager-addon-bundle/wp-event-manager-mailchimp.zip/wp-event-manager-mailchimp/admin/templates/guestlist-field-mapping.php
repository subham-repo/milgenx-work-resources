<div class="white-background">
    <?php
    
    if (array_key_exists('addr1', $guest_list_mailchimp_field)) {
        if (!array_key_exists('city', $guest_list_mailchimp_field) || !array_key_exists('state', $guest_list_mailchimp_field) || !array_key_exists('country', $guest_list_mailchimp_field) || !array_key_exists('zip', $guest_list_mailchimp_field)) {
            ?>
            <div class="notice inline notice-alt notice-warning">
                <p>
                    <?php echo __('City, State, Zip code & Country are mandatory with Address field.', 'wp-event-manager-sendinblue'); ?>
                </p>
            </div>
            <?php
        }
    }
    ?>
    <form method="post" class="wpem-mailchimp-guest-list-matches-attribute">
        <div class="wpem-mailchimp-settings-guest-list">
            <label><strong><?php _e('Sync Guest Lists', 'wp-event-manager-mailchimp'); ?></strong> <input id="setting-enable_mailchimp_guest_list" name="enable_mailchimp_guest_list" type="checkbox" <?php checked($enable_mailchimp_guest_list, true); ?> value="1"> <?php _e('Enable guest list sync with mailchimp.', 'wp-event-manager-mailchimp'); ?></label>
        </div>
        <h3><?php _e('Guest Field Mapping with Mailchimp', 'wp-event-manager-mailchimp'); ?></h3>
        <table class="widefat wpem-mailchimp-field-maping-table">
            <thead>
                <tr>
                    <th><?php _e('Guest List Field', 'wp-event-manager-mailchimp'); ?></th>
                    <th><?php _e('Mailchimp Field', 'wp-event-manager-mailchimp'); ?></th>
                    <th class="wpem-mailchimp-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>

            <tbody>
                <?php if (!empty($guest_list_mailchimp_field)) : ?>
                    <?php foreach ($guest_list_mailchimp_field as $sync_field => $form_field) : ?>
                        <tr>
                            <td>
                                <select name="guest_list_field[]" class="guest-list-field">
                                    <option value=""><?php _e('Select Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                    <?php foreach (get_event_guest_lists_form_fields() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="guest_list_mailchimp_field[]" class="mailchimp-guest-list-field">
                                    <option value=""><?php _e('Select Mailchimp Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                    <?php foreach (get_mailchimp_list_dynamic_field($mailchimp_api_key, $mailchimp_list) as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-mailchimp'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="guest_list_field[]" class="guest-list-field">
                                <option value=""><?php _e('Select Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                <?php foreach (get_event_guest_lists_form_fields() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="guest_list_mailchimp_field[]" class="mailchimp-guest-list-field">
                                <option value=""><?php _e('Select Mailchimp Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                <?php foreach (get_mailchimp_list_dynamic_field($mailchimp_api_key, $mailchimp_list) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">
                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-mailchimp'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td>
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wp-event-manager-mailchimp'); ?></a>
                    </td>
                    <td colspan="2">
                        <?php wp_nonce_field('wpem_admin_mailchimp_guest_list_field_mapping'); ?>
                        <input type="submit" class="button-primary wpem-field-maping-save" name="submit_mailchimp_admin_guest_list_field_mapping" value="<?php esc_attr_e('Save', 'wp-event-manager-mailchimp'); ?>" />
                    </td>

                </tr>
            </tfoot>

        </table>
    </form>
</div>		
