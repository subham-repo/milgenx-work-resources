<div class="wrap wp_event_manager wpem-mailchimp-admin-wrap">
    <h2><?php _e('WP Event Manager Mailchimp Settings', 'wp-event-manager-mailchimp'); ?></h2>

    <?php do_action('wp_event_mailchimp_settings_before'); ?>

    <div class="wpem-mailchimp-setting-wrapper">

        <div class="wpem-mailchimp-setting">
            <div class="wpem-mailchimp-image">
                <img src="<?php echo WPEM_MAILCHIMP_PLUGIN_URL ?>/assets/images/mailchimp_logo_small.png" alt="mailchimp">
            </div>
            <div class="wpem-mailchimp-settings-container">
                <?php $check_mailchimp_key = check_mailchimp_key($mailchimp_api_key); ?>
                <?php if (!empty($mailchimp_api_key) && !is_array($check_mailchimp_key)) { ?>

                    <div class="error">
                        <p>
                            <?php echo __('The API key entered is invalid.', 'wp-event-manager-sendinblue'); ?>
                        </p>
                    </div>

                <?php } elseif (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] == 401) { ?>

                    <div class="error">
                        <p>
                            <?php echo __('The API key entered is invalid.', 'wp-event-manager-sendinblue'); ?>
                        </p>
                    </div>

                <?php } ?>
                <div class="wpem-mailchimp-info">
                    <h1><?php _e('Mailchimp Settings', 'wp-event-manager-mailchimp'); ?></h1>
                    <?php if (isset($check_mailchimp_key['total_items']) && $check_mailchimp_key['total_items'] > 0) : ?>

                        <form method="post" class="wp-event-mailchimp-disconnect-settings">
                            <input type="submit" class="wpem-theme-button wpem-theme-button-disconnect" name="wp_event_mailchimp_settings" value="<?php esc_attr_e('Disconnect', 'wp-event-manager-mailchimp'); ?>">

                            <?php wp_nonce_field('event_mailchimp_disconnect_settings'); ?>
                        </form>


                    <?php endif; ?>
                    <p><?php _e('Integrate MailChimp with WP Event Manager', 'wp-event-manager-mailchimp'); ?></p>
                </div>
                <form method="post" class="wpem-mailchimp-form">
                    <div class="wpem-mailchimp-form-container">
                        <input type="text" class="mailchimp-api-key" name="mailchimp_api_key" placeholder="<?php _e('Mailchimp API Key', 'wp-event-manager-mailchimp'); ?>" value="<?php echo $mailchimp_api_key; ?>">

                        <?php if (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] == 401) : ?>

                        <?php else : ?>
                            <?php if ($mailchimp_api_key != '' && is_array($check_mailchimp_key)) : ?>
                                <select name="mailchimp_list" class="mailchimp-list">
                                    <?php foreach (get_mailchimp_lists($mailchimp_api_key) as $id => $label) : ?>
                                        <option value="<?php echo esc_attr($id); ?>" <?php selected($mailchimp_list, $id); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>

                            <?php if ($mailchimp_api_key != '' && is_array($check_mailchimp_key)) : ?>
                                <select name="mailchimp_sync_type" class="mailchimp-sync-type" id="mailchimp-sync-type">
                                    <option value=""><?php _e('Select Mailchimp Sync Type', 'wp-event-manager-mailchimp'); ?></option>
                                    <?php foreach (get_mailchimp_sync_type() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($mailchimp_sync_type, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <?php
                                $style = '';
                                if ($mailchimp_sync_type == 'manual') {
                                    $style = 'style="display: none;"';
                                }
                                ?>
                                <select id="mailchimp-sync-via" <?php echo $style; ?> name="mailchimp_sync_via" class="mailchimp-sync-via">
                                    <option value=""><?php _e('Select Mailchimp Sync Via', 'wp-event-manager-mailchimp'); ?></option>
                                    <?php foreach (get_mailchimp_sync_via() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($mailchimp_sync_via, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <?php
                                $style = '';
                                if ($mailchimp_sync_type == 'manual' || $mailchimp_sync_via == 'when_created') {
                                    $style = 'style="display: none;"';
                                }
                                ?>
                                <select id="mailchimp_sync_schedule" <?php echo $style; ?> name="mailchimp_sync_schedule" class="mailchimp-sync-schedule">
                                    <?php foreach (get_mailchimp_sync_schedule() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($mailchimp_sync_schedule, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>

                        <?php endif; ?>

                        <input type="submit" class="wpem-theme-button" name="wp_event_mailchimp_settings" value="<?php esc_attr_e('Save Setting', 'wp-event-manager-mailchimp'); ?>" />

                        <?php wp_nonce_field('event_mailchimp_settings'); ?>

                    </div>
                </form>

            </div>
        </div>
    </div>

    <?php do_action('wp_event_mailchimp_settings_after'); ?>

</div>
