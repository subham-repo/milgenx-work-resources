<div class="white-background">
    <?php
    if (array_key_exists('addr1', $registration_mailchimp_field)) {
        if (!array_key_exists('city', $registration_mailchimp_field) || !array_key_exists('state', $registration_mailchimp_field) || !array_key_exists('country', $registration_mailchimp_field) || !array_key_exists('zip', $registration_mailchimp_field)) {
            ?>
            <div class="notice inline notice-alt notice-warning">
                <p>
                    <?php echo __('City, State, Zip code & Country are mandatory with Address field.', 'wp-event-manager-sendinblue'); ?>
                </p>
            </div>
            <?php
        }
    }
    ?>
    <form method="post" class="wpem-mailchimp-registration-matches-attribute">
        <div class="wpem-mailchimp-settings-organizer">
            <label><strong>Sync Registrations</strong> <input id="setting-enable_mailchimp_registration" name="enable_mailchimp_registration" type="checkbox" <?php checked($enable_mailchimp_registration, true); ?> value="1"> <?php _e('Enable registration sync with mailchimp.', 'wp-event-manager-mailchimp'); ?></label>
        </div>
        <h3><?php _e('Registration Field Mapping with Mailchimp', 'wp-event-manager-mailchimp'); ?></h3>

        <table class="widefat wpem-mailchimp-field-maping-table">
            <thead>
                <tr>
                    <th ><?php _e('Registration Field', 'wp-event-manager-mailchimp'); ?></th>
                    <th ><?php _e('Mailchimp Field', 'wp-event-manager-mailchimp'); ?></th>
                    <th class="wpem-mailchimp-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($registration_mailchimp_field)) : ?>
                    <?php foreach ($registration_mailchimp_field as $sync_field => $form_field) : ?>

                        <tr>
                            <td>
                                <select name="registration_field[]" class="registration-field">
                                    <option value=""><?php _e('Select registration Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                    <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="registration_mailchimp_field[]" class="mailchimp-registration-field">
                                    <option value=""><?php _e('Select Mailchimp Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                    <?php foreach (get_mailchimp_list_dynamic_field($mailchimp_api_key, $mailchimp_list) as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-mailchimp'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="registration_field[]" class="registration-field">
                                <option value=""><?php _e('Select registration Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="registration_mailchimp_field[]" class="mailchimp-registration-field">
                                <option value=""><?php _e('Select Mailchimp Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                <?php foreach (get_mailchimp_list_dynamic_field($mailchimp_api_key, $mailchimp_list) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">
                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-mailchimp'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td >
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wp-event-manager-mailchimp'); ?></a>
                    </td>
                    <td colspan="2">
                        <?php wp_nonce_field('wpem_mailchimp_admin_registration_field_mapping'); ?>
                        <input type="submit" class="button-primary wpem-field-maping-save" name="submit_mailchimp_admin_registration_mapping" value="<?php esc_attr_e('Save', 'wp-event-manager-mailchimp'); ?>" />
                    </td>
                </tr>
            </tfoot>
        </table>
    </form>	
</div>

