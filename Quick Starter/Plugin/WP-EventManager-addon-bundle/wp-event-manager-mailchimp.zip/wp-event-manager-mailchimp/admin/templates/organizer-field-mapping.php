<div class="white-background">
    <?php
    if (array_key_exists('addr1', $organizer_mailchimp_field)) {
        if (!array_key_exists('city', $organizer_mailchimp_field) || !array_key_exists('state', $organizer_mailchimp_field) || !array_key_exists('country', $organizer_mailchimp_field) || !array_key_exists('zip', $organizer_mailchimp_field)) {
            ?>
            <div class="notice inline notice-alt notice-warning">
                <p>
                    <?php echo __('City, State, Zip code & Country are mandatory with Address field.', 'wp-event-manager-sendinblue'); ?>
                </p>
            </div>
            <?php
        }
    }
    ?>
    <form method="post" class="wpem-mailchimp-organizer-matches-attribute">
        <div class="wpem-mailchimp-settings-organizer">
            <label><input id="setting-enable_mailchimp_organizer" name="enable_mailchimp_organizer" type="checkbox" <?php checked($enable_mailchimp_organizer, true); ?> value="1" > <?php _e('Enable organizer sync with mailchimp.', 'wp-event-manager-mailchimp'); ?></label>
        </div>
        <h3><?php _e('Organizer Field Mapping with Mailchimp', 'wp-event-manager-mailchimp'); ?></h3>
        <table class="widefat wpem-mailchimp-field-maping-table">
            <thead>
                <tr>
                    <th ><?php _e('Organizer Field', 'wp-event-manager-mailchimp'); ?></th>
                    <th ><?php _e('Mailchimp Field', 'wp-event-manager-mailchimp'); ?></th>
                    <th class="wpem-mailchimp-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>

            <tbody>
                <?php if (!empty($organizer_mailchimp_field)) : ?>
                    <?php foreach ($organizer_mailchimp_field as $sync_field => $form_field) : ?>
                        <tr>
                            <td>
                                <select name="organizer_field[]" class="organization-field">
                                    <option value=""><?php _e('Select Organizer Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                    <?php foreach (get_event_organization_form_field_lists() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="organizer_mailchimp_field[]" class="mailchimp-organization-field">
                                    <option value=""><?php _e('Select Mailchimp Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                    <?php foreach (get_mailchimp_list_dynamic_field($mailchimp_api_key, $mailchimp_list) as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-mailchimp'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="organizer_field[]" class="organization-field">
                                <option value=""><?php _e('Select Organizer Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                <?php foreach (get_event_organization_form_field_lists() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="organizer_mailchimp_field[]" class="mailchimp-organization-field">
                                <option value=""><?php _e('Select Mailchimp Field', 'wp-event-manager-mailchimp'); ?>...</option>
                                <?php foreach (get_mailchimp_list_dynamic_field($mailchimp_api_key, $mailchimp_list) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">

                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wp-event-manager-mailchimp'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td >
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wp-event-manager-mailchimp'); ?></a>
                    </td>	                    	
                    <td colspan="2">
                        <input type="submit" class="button-primary wpem-field-maping-save" name="wp_event_mailchimp_organizer_matches_attribute" value="<?php esc_attr_e('Save', 'wp-event-manager-mailchimp'); ?>" />

                        <?php wp_nonce_field('event_mailchimp_organizer_matches_attribute'); ?>
                    </td>
                </tr>
            </tfoot>

        </table>
    </form>		
</div>