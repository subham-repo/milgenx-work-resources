<?php

if (!function_exists('get_mailchimp_sync_type')) {

    /**
     * Event Mailchimp Sync Type
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_sync_type() {
        return apply_filters('mailchimp_sync_type', array(
            'auto' => __('Auto', 'wp-event-manager-mailchimp'),
            'manual' => __('Manual', 'wp-event-manager-mailchimp'),
        ));
    }

}

if (!function_exists('get_mailchimp_sync_schedule')) {

    /**
     * Event Mailchimp Sync Schedule
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_sync_schedule() {
        return apply_filters('mailchimp_sync_schedule', array(
            '5min' => __('5 Min', 'wp-event-manager-mailchimp'),
            'daily' => __('Daily', 'wp-event-manager-mailchimp'),
            'weekly' => __('Weekly', 'wp-event-manager-mailchimp'),
            'monthly' => __('Monthly', 'wp-event-manager-mailchimp'),
            'yearly' => __('Yearly', 'wp-event-manager-mailchimp'),
        ));
    }

}

if (!function_exists('get_mailchimp_sync_via')) {

    /**
     * Event Mailchimp Sync Type
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_sync_via() {
        return apply_filters('mailchimp_sync_via', array(
            'when_created' => __('When new created', 'wp-event-manager-mailchimp'),
            'cron_job' => __('Cron Job', 'wp-event-manager-mailchimp'),
        ));
    }

}

if (!function_exists('get_mailchimp_settings_by_user')) {

    /**
     * Get Mailchimp Settings
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_settings_by_user() {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        $mailchimp_settings = [];

        if (current_user_can('manage_options')) {
            $mailchimp_settings = get_option('mailchimp_settings');
        } else {
            $mailchimp_settings = get_user_meta($user_id, 'mailchimp_settings', true);
        }

        return $mailchimp_settings;
    }

}

if (!function_exists('get_mailchimp_settings_by_user_id')) {

    /**
     * Get Mailchimp Settings
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_settings_by_user_id($user_id = '') {

        $user_meta = get_userdata($user_id);

        $mailchimp_settings = [];

        if (isset($user_meta->roles) && in_array('administrator', $user_meta->roles)) {
            $mailchimp_settings = get_option('mailchimp_settings');
        } elseif (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $mailchimp_settings = get_option('mailchimp_settings');
        } else {
            $mailchimp_settings = get_user_meta($user_id, 'mailchimp_settings', true);
        }

        return $mailchimp_settings;
    }

}

if (!function_exists('update_mailchimp_settings_by_user')) {

    /**
     * update Mailchimp Settings
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function update_mailchimp_settings_by_user($field_key = '', $field_value = '') {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        if (current_user_can('manage_options')) {
            update_option($field_key, $field_value);
        } else {
            update_user_meta($user_id, $field_key, $field_value);
        }
    }

}

if (!function_exists('delete_mailchimp_settings_by_user')) {

    /**
     * update Mailchimp Settings
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function delete_mailchimp_settings_by_user($field_key = '') {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        if (current_user_can('manage_options')) {
            delete_option($field_key);
        } else {
            delete_user_meta($user_id, $field_key);
        }
    }

}

if (!function_exists('get_sync_fields_by_user')) {

    /**
     * Get Mailchimp Settings
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_sync_fields_by_user($user_id = '', $fields_key = '') {
        $sync_fields = [];

        $user_meta = get_userdata($user_id);

        if (( isset($user_meta->roles) && in_array('administrator', $user_meta->roles) ) || current_user_can('manage_options')) {
            $sync_fields = get_option($fields_key);
        } else if (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $sync_fields = get_option($fields_key);
        } else {
            $sync_fields = get_user_meta($user_id, $fields_key, true);
        }

        return $sync_fields;
    }

}

if (!function_exists('get_mailchimp_sync_fields_by_user')) {

    /**
     * Get Mailchimp Settings
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_sync_fields_by_user($user_id = '', $fields_key = '') {
        $mailchimp_sync_fields = [];

        $user_meta = get_userdata($user_id);

        if (( isset($user_meta->roles) && in_array('administrator', $user_meta->roles) ) || current_user_can('manage_options')) {
            $mailchimp_sync_fields = get_option($fields_key);
        } else if (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $mailchimp_sync_fields = get_option($fields_key);
        } else {
            $mailchimp_sync_fields = get_user_meta($user_id, $fields_key, true);
        }

        return $mailchimp_sync_fields;
    }

}

if (!function_exists('mailchimp_request')) {

    /**
     * Mailchimp request
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function mailchimp_request($mailchimp_api_key = '', $end_point = '', $args = []) {

        $response_body = '';

        if ($mailchimp_api_key != '' && $end_point != '') {
            $url = 'https://' . substr($mailchimp_api_key, strpos($mailchimp_api_key, '-') + 1) . '.api.mailchimp.com/3.0/' . $end_point;

            $response = wp_remote_post($url, $args);

            if (is_wp_error($response)) {
                $result = $response->get_error_message();
            } else {
                $result = json_decode(wp_remote_retrieve_body($response), true);
            }
        }

        return $result;
    }

}

if (!function_exists('check_mailchimp_key')) {

    /**
     * Check mailchimp key
     *
     * @access public
     * @param 
     * @return bool
     * @since 1.0.0
     */
    function check_mailchimp_key($mailchimp_api_key = '') {

        $response_body = [];

        if ($mailchimp_api_key != '') {
            $args = [
                'method' => 'GET',
                'count' => '1',
                'headers' => [
                    'authorization' => 'Basic ' . base64_encode('user:' . $mailchimp_api_key)
                ]
            ];

            $end_point = 'lists/';

            $response_body = mailchimp_request($mailchimp_api_key, $end_point, $args);
        }

        return $response_body;
    }

}

if (!function_exists('get_mailchimp_lists')) {

    /**
     * Get mailchimp list
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_lists($mailchimp_api_key = '') {

        $user_id = get_current_user_id();

        $arr_mailchimp_lists = get_sync_fields_by_user($user_id, 'mailchimp_lists');

        if (empty($arr_mailchimp_lists)) {
            $arr_mailchimp_lists = [];

            if ($mailchimp_api_key != '') {
                $args = [
                    'method' => 'GET',
                    'count' => '20',
                    'headers' => [
                        'authorization' => 'Basic ' . base64_encode('user:' . $mailchimp_api_key)
                    ]
                ];

                $end_point = 'lists/';

                $response_body = mailchimp_request($mailchimp_api_key, $end_point, $args);

                if (!empty($response_body['lists'])) {
                    $arr_mailchimp_lists[] = __('Event based selection', 'wp-event-manager-mailchimp');

                    foreach ($response_body['lists'] as $mailchimp_list) {
                        $arr_mailchimp_lists[$mailchimp_list['id']] = $mailchimp_list['name'];
                    }
                }
            }

            update_mailchimp_settings_by_user('mailchimp_lists', $arr_mailchimp_lists);
        }



        return $arr_mailchimp_lists;
    }

}

if (!function_exists('get_event_organization_form_field_lists')) {

    /**
     * Get event registration form fields
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_event_organization_form_field_lists() {

        // organizer fields
        $GLOBALS['event_manager']->forms->get_form('submit-organizer', array());
        $form_submit_organizer_instance = call_user_func(array('WP_Event_Manager_Form_Submit_Organizer', 'instance'));
        $organizer_form_fields = $form_submit_organizer_instance->merge_with_custom_fields('frontend');


        $organizer_fields = $organizer_form_fields['organizer'];

        return $organizer_fields;
    }

}

if (!function_exists('get_mailchimp_list_static_field')) {

    /**
     * Event Mailchimp List Static Field
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_list_static_field() {

        $fields = array(
            'email_address' => __('Email', 'wp-event-manager-mailchimp'),
            'FNAME' => __('First Name', 'wp-event-manager-mailchimp'),
            'LNAME' => __('Last Name', 'wp-event-manager-mailchimp'),
            'PHONE' => __('Phone', 'wp-event-manager-mailchimp'),
            'addr1' => __('Address 1', 'wp-event-manager-mailchimp'),
            'addr2' => __('Address 2', 'wp-event-manager-mailchimp'),
            'city' => __('City', 'wp-event-manager-mailchimp'),
            'state' => __('State', 'wp-event-manager-mailchimp'),
            'country' => __('Country', 'wp-event-manager-mailchimp'),
            'zip' => __('Zipcode', 'wp-event-manager-mailchimp'),
        );

        $fields = apply_filters('mailchimp_list_static_field', $fields);

        return $fields;
    }

}

if (!function_exists('get_mailchimp_list_dynamic_field')) {

    /**
     * Event Mailchimp List dynamin Field
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_list_dynamic_field($mailchimp_api_key = '', $mailchimp_list = '') {
        $user_id = get_current_user_id();

        if ($mailchimp_api_key != '' && $mailchimp_list != '') {
            $fields = get_sync_fields_by_user($user_id, 'mailchimp_list_dynamic_field_' . $mailchimp_list);

            if (empty($fields)) {
                $args = [
                    'method' => 'GET',
                    'headers' => [
                        'authorization' => 'Basic ' . base64_encode('user:' . $mailchimp_api_key)
                    ]
                ];

                $end_point = '/lists/' . $mailchimp_list . '/merge-fields/';

                $response_body = mailchimp_request($mailchimp_api_key, $end_point, $args);


                $fields = [
                    'email_address' => __('Email', 'wp-event-manager-mailchimp'),
                    'FNAME' => __('First Name', 'wp-event-manager-mailchimp'),
                    'LNAME' => __('Last Name', 'wp-event-manager-mailchimp'),
                    'PHONE' => __('Phone', 'wp-event-manager-mailchimp'),
                ];
                if (!empty($response_body['merge_fields'])) {
                    foreach ($response_body['merge_fields'] as $field) {
                        if (!in_array($field['tag'], ['ADDRESS'])) {
                            $fields[$field['tag']] = sprintf(__('%s', 'wp-event-manager-mailchimp'), $field['name']);
                        }
                    }
                }

                $fields['addr1'] = __('Address 1', 'wp-event-manager-mailchimp');
                $fields['addr2'] = __('Address 2', 'wp-event-manager-mailchimp');
                $fields['city'] = __('City', 'wp-event-manager-mailchimp');
                $fields['state'] = __('State', 'wp-event-manager-mailchimp');
                $fields['country'] = __('Country', 'wp-event-manager-mailchimp');
                $fields['zip'] = __('Zipcode', 'wp-event-manager-mailchimp');

                update_mailchimp_settings_by_user('mailchimp_list_dynamic_field_' . $mailchimp_list, $fields);
            }
        } else {
            $fields = get_mailchimp_list_static_field();
        }

        if (isset($fields['BIRTHDAY']))
            unset($fields['BIRTHDAY']);

        $fields = apply_filters('mailchimp_list_dynamic_field', $fields);

        return $fields;
    }

}

if (!function_exists('get_mailchimp_field_static_format')) {

    /**
     * Mailchimp List static Field format
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_field_static_format() {
        return apply_filters('mailchimp_field_static_format', array(
            'email_address' => __('Email', 'wp-event-manager-mailchimp'),
            'status' => __('Status', 'wp-event-manager-mailchimp'),
            'merge_fields' => array(
                'FNAME' => __('First Name', 'wp-event-manager-mailchimp'),
                'LNAME' => __('Last Name', 'wp-event-manager-mailchimp'),
                'PHONE' => __('Phone', 'wp-event-manager-mailchimp'),
                'BIRTHDAY' => __('Birthday', 'wp-event-manager-mailchimp'),
                'ADDRESS' => array(
                    'addr1' => __('Address 1', 'wp-event-manager-mailchimp'),
                    'addr2' => __('Address 2', 'wp-event-manager-mailchimp'),
                    'city' => __('City', 'wp-event-manager-mailchimp'),
                    'state' => __('State', 'wp-event-manager-mailchimp'),
                    'country' => __('Country', 'wp-event-manager-mailchimp'),
                    'zip' => __('Zipcode', 'wp-event-manager-mailchimp'),
                ),
            ),
        ));
    }

}

if (!function_exists('get_mailchimp_field_dynamic_format')) {

    /**
     * Event Mailchimp List Field
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_mailchimp_field_dynamic_format($mailchimp_api_key = '', $mailchimp_list = '') {
        if ($mailchimp_api_key != '' && $mailchimp_list != '') {
            $args = [
                'method' => 'GET',
                'headers' => [
                    'authorization' => 'Basic ' . base64_encode('user:' . $mailchimp_api_key)
                ]
            ];

            $end_point = '/lists/' . $mailchimp_list . '/merge-fields/';

            $response_body = mailchimp_request($mailchimp_api_key, $end_point, $args);

            $fields = [
                'email_address' => __('Email', 'wp-event-manager-mailchimp'),
                'status' => __('Status', 'wp-event-manager-mailchimp'),
                'merge_fields' => array(
                    'FNAME' => __('First Name', 'wp-event-manager-mailchimp'),
                    'LNAME' => __('Last Name', 'wp-event-manager-mailchimp'),
                    'PHONE' => __('Phone', 'wp-event-manager-mailchimp'),
                    'ADDRESS' => array(
                        'addr1' => __('Address 1', 'wp-event-manager-mailchimp'),
                        'addr2' => __('Address 2', 'wp-event-manager-mailchimp'),
                        'city' => __('City', 'wp-event-manager-mailchimp'),
                        'state' => __('State', 'wp-event-manager-mailchimp'),
                        'country' => __('Country', 'wp-event-manager-mailchimp'),
                        'zip' => __('Zipcode', 'wp-event-manager-mailchimp'),
                    ),
                ),
            ];

            if (!empty($response_body['merge_fields'])) {
                foreach ($response_body['merge_fields'] as $field) {
                    if (!in_array($field['tag'], ['ADDRESS'])) {
                        $fields['merge_fields'][$field['tag']] = __($field['name'], 'wp-event-manager-mailchimp');
                    }
                }
            }
        } else {
            $fields = get_mailchimp_field_static_format();
        }

        return $fields;
    }

}

if (!function_exists('get_default_mailchimp_registration_matches_attribute')) {

    /**
     * Default Mailchimp Registration Matches Attribute
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_default_mailchimp_registration_matches_attribute() {
        $registration_mailchimp_field = [];

        $registration_form_field = get_event_registration_form_fields();

        foreach ($registration_form_field as $key => $field) {
            if (in_array('from_email', $field['rules'])) {
                $registration_mailchimp_field['email_address'] = $key;
            } else if (in_array('from_name', $field['rules'])) {
                $registration_mailchimp_field['FNAME'] = $key;
            }
        }

        return $registration_mailchimp_field;
    }

}

if (!function_exists('get_default_mailchimp_organizer_matches_attribute')) {

    /**
     * Default Mailchimp Organizer Matches Attribute
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_default_mailchimp_organizer_matches_attribute() {
        $organizer_mailchimp_field = [];

        $organizer_mailchimp_field['email_address'] = 'organizer_email';
        $organizer_mailchimp_field['FNAME'] = 'organizer_name';

        return $organizer_mailchimp_field;
    }

}

if (!function_exists('get_event_by_user_id')) {

    /**
     * Get event by user id
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_event_by_user_id($user_id = '') {
        return get_posts(array(
            'posts_per_page' => -1,
            'post_type' => 'event_listing',
            'post_status' => 'publish',
            'suppress_filters' => 'false',
            'author' => $user_id,
            'fields' => 'ids',
        ));
    }

}

if (!function_exists('get_registration_attendee_list')) {

    /**
     * Get event registration attendee list
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_registration_attendee_list($atts = [], $filters = []) {
        $user_id = get_current_user_id();

        extract($atts = shortcode_atts(array(
            'event_id' => '',
            'posts_per_page' => 20,
            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                ), $atts));

        $registration_mailchimp_field = get_mailchimp_sync_fields_by_user($user_id, 'registration_mailchimp_field');
        if (empty($registration_mailchimp_field)) {
            $registration_mailchimp_field = get_default_mailchimp_registration_matches_attribute();
        }

        $args = array(
            'post_type' => 'event_registration',
            //'post_status'     => array( 'publish' ),
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'post_parent' => $event_id,
            'author' => $user_id,
            'meta_query' => [
                'relation' => 'AND',
            ]
        );

        if (isset($registration_mailchimp_field['email_address']) && !empty($registration_mailchimp_field['email_address'])) {
            $args['meta_query'][] = [
                'key' => $registration_mailchimp_field['email_address'],
                'value' => '',
                'compare' => '!='
            ];
        }

        if (!empty($filters)) {
            foreach ($filters as $key => $value) {
                if ($key != '' && $value != '') {
                    $args['meta_query'][] = [
                        'key' => $key,
                        'value' => $value,
                        'compare' => 'LIKE',
                    ];
                }
            }
        }

        $registrations = new WP_Query($args);

        return $registrations;
    }

}

if (!function_exists('get_guest_lists_guest_list')) {

    /**
     * Get event registration attendee list
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_guest_lists_guest_list($atts = [], $filters = []) {
        $user_id = get_current_user_id();

        extract($atts = shortcode_atts(array(
            'event_id' => '',
            'posts_per_page' => 20,
            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                ), $atts));

        $guest_list_mailchimp_field = get_mailchimp_sync_fields_by_user($user_id, 'guest_list_mailchimp_field');
        if (empty($guest_list_mailchimp_field)) {
            $guest_list_mailchimp_field = get_default_mailchimp_guest_list_matches_attribute();
        }

        $args = array(
            'post_type' => 'event_guest_list',
            //'post_status'     => array( 'publish' ),
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'post_parent' => $event_id,
            'author' => $user_id,
            'meta_query' => [
                'relation' => 'AND',
            ]
        );

        if (isset($guest_list_mailchimp_field['email_address']) && !empty($guest_list_mailchimp_field['email_address'])) {
            $args['meta_query'][] = [
                'key' => $guest_list_mailchimp_field['email_address'],
                'value' => '',
                'compare' => '!='
            ];
        }

        if (!empty($filters)) {
            foreach ($filters as $key => $value) {
                if ($key != '' && $value != '') {
                    $args['meta_query'][] = [
                        'key' => $key,
                        'value' => $value,
                        'compare' => 'LIKE',
                    ];
                }
            }
        }

        $guests = new WP_Query($args);

        return $guests;
    }

}

if (!function_exists('add_attendees_in_mailchimp_list')) {

    /**
     * Add attendees in mailchimp
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function add_attendees_in_mailchimp_list($user_id = '', $arr_attendees_id = []) {
        $response = [];

        if ($user_id != '' && !empty($arr_attendees_id)) {
            $mailchimp_settings = get_mailchimp_settings_by_user_id($user_id);

            $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
            $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : 0;

            $registration_field = get_sync_fields_by_user($user_id, 'registration_field');

            $registration_mailchimp_field = get_mailchimp_sync_fields_by_user($user_id, 'registration_mailchimp_field');

            if (empty($registration_mailchimp_field)) {
                $registration_mailchimp_field = get_default_mailchimp_registration_matches_attribute();
            }

            foreach ($arr_attendees_id as $attendees_id) {
                $is_mailchimp_sync = get_post_meta($attendees_id, 'is_mailchimp_sync', true);

                $attendees = get_post($attendees_id);
                if (!empty($attendees)) {
                    if ($mailchimp_list == false) {
                        $event_id = $attendees->post_parent;
                        $event_mailchimp_list = get_post_meta($event_id, 'mailchimp_list', true);

                        // When Event based mailchimp list is disabled
                        if ($event_mailchimp_list == false) {
                            $response['message'] = __('Synchronization disabled for this event.', 'wp-event-manager-mailchimp');
                            continue;
                        }

                        if (!empty($event_mailchimp_list)) {
                            $mailchimp_list = $event_mailchimp_list;
                        }
                    }
                }

               // if ($is_mailchimp_sync != 'subscribed') 
                {
                    $result = sync_data_in_mailchimp_list($mailchimp_api_key, $mailchimp_list, $registration_mailchimp_field, $attendees_id);

                    if (isset($result['id']) && $result['id'] != '') {
                        update_post_meta($attendees_id, 'is_mailchimp_sync', 'subscribed');
                    }

                    if ($result['status'] == 400) {
                        if ($result['title'] == 'Member Exists') {
                            update_post_meta($attendees_id, 'is_mailchimp_sync', 'subscribed');
                        }
                        $response['code'] = 400;
                        $message = $result['title'];
                        $message .= isset($result['detail']) ? ' ' . $result['detail'] : '';
                        $response['message'] = sprintf(__('%s', 'wp-event-manager-mailchimp'), $message);
                    } else {
                        $response['code'] = 200;
                        $response['message'] = __('Subscribed', 'wp-event-manager-mailchimp');
                    }
                }
            }
        }

        return $response;
    }

}

if (!function_exists('add_guests_in_mailchimp_list')) {

    /**
     * Add guests in mailchimp
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function add_guests_in_mailchimp_list($user_id = '', $arr_guests_id = []) {
        $response = [];

        if ($user_id != '' && !empty($arr_guests_id)) {
            $mailchimp_settings = get_mailchimp_settings_by_user_id($user_id);

            $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
            $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : 0;

            $guest_list_field = get_sync_fields_by_user($user_id, 'guest_list_field');
            $guest_list_mailchimp_field = get_mailchimp_sync_fields_by_user($user_id, 'guest_list_mailchimp_field');

            if (empty($guest_list_mailchimp_field)) {
                $guest_list_mailchimp_field = get_default_mailchimp_guest_list_matches_attribute();
            }

            foreach ($arr_guests_id as $guest_id) {
                $is_mailchimp_sync = get_post_meta($guest_id, 'is_mailchimp_sync', true);

                $guest = get_post($guest_id);
                if (!empty($guest)) {

                    if ($mailchimp_list == false) {
                        $event_id = $guest->post_parent;
                        $event_mailchimp_list = get_post_meta($event_id, 'mailchimp_list', true);
                        if ($event_mailchimp_list == false) {
                            $response['message'] = __('Synchronization disabled for this event.', 'wp-event-manager-mailchimp');
                            continue;
                        }
                        if (!empty($event_mailchimp_list)) {
                            $mailchimp_list = $event_mailchimp_list;
                        }
                    }
                }

               // if ($is_mailchimp_sync != 'subscribed') 
                {
                    $result = sync_data_in_mailchimp_list($mailchimp_api_key, $mailchimp_list, $guest_list_mailchimp_field, $guest_id);

                    if (isset($result['id']) && $result['id'] != '') {
                        update_post_meta($guest_id, 'is_mailchimp_sync', 'subscribed');
                    }

                    if ($result['status'] == 400) {
                        if ($result['title'] == 'Member Exists') {
                            update_post_meta($guest_id, 'is_mailchimp_sync', 'subscribed');
                        }

                        $response['code'] = 400;
                        $message = $result['title'];
                        $message .= isset($result['detail']) ? ' ' . $result['detail'] : '';
                        $response['message'] = sprintf(__('%s', 'wp-event-manager-mailchimp'), $message);
                    } else {
                        $response['code'] = 200;
                        $response['message'] = __('Subscribed', 'wp-event-manager-mailchimp');
                    }
                }
            }
        }

        return $response;
    }

}

if (!function_exists('sync_data_in_mailchimp_list')) {

    /**
     * Sync attendees in mailchimp
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function sync_data_in_mailchimp_list($mailchimp_api_key = '', $mailchimp_list = '', $registration_mailchimp_field = [], $post_id = '') {
        $response_body = [];

        if ($mailchimp_api_key != '' && $mailchimp_list != '' && !empty($registration_mailchimp_field) && $post_id != '') {
            $params = [];
            $field_mailchimp = get_mailchimp_field_dynamic_format($mailchimp_api_key, $mailchimp_list);

            foreach ($field_mailchimp as $field_name => $field_value) {
                if (is_array($field_value)) {
                    foreach ($field_value as $field_name2 => $field_value2) {
                        if (is_array($field_value2)) {
                            foreach ($field_value2 as $field_name3 => $field_value3) {
                                if (array_key_exists($field_name3, $registration_mailchimp_field)) {
                                    $params[$field_name][$field_name2][$field_name3] = get_post_meta($post_id, $registration_mailchimp_field[$field_name3], true);
                                }
                            }
                        } else {
                            if (array_key_exists($field_name2, $registration_mailchimp_field)) {
                                $params[$field_name][$field_name2] = get_post_meta($post_id, $registration_mailchimp_field[$field_name2], true);
                            }
                        }
                    }
                } else {
                    if (array_key_exists($field_name, $registration_mailchimp_field)) {
                        $params[$field_name] = get_post_meta($post_id, $registration_mailchimp_field[$field_name], true);
                    }
                }
            }

            $params['status'] = 'subscribed';

            $args = [
                'method' => 'POST',
                'headers' => [
                    'authorization' => 'Basic ' . base64_encode('user:' . $mailchimp_api_key)
                ],
                'body' => json_encode($params)
            ];
            $end_point = 'lists/' . $mailchimp_list . '/members/';

            $response_body = mailchimp_request($mailchimp_api_key, $end_point, $args);
        }

        return $response_body;
    }

}

if (!function_exists('sync_data_in_mailchimp_list_2')) {

    /**
     * Sync attendees in mailchimp
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function sync_data_in_mailchimp_list_2($mailchimp_api_key = '', $mailchimp_list = '', $registration_mailchimp_field = [], $data = []) {
        $response_body = [];

        if ($mailchimp_api_key != '' && $mailchimp_list != '' && !empty($registration_mailchimp_field) && $data != '') {
            $params = [];
            $field_mailchimp = get_mailchimp_field_dynamic_format($mailchimp_api_key, $mailchimp_list);

            foreach ($field_mailchimp as $field_name => $field_value) {
                if (is_array($field_value)) {
                    foreach ($field_value as $field_name2 => $field_value2) {
                        if (is_array($field_value2)) {
                            foreach ($field_value2 as $field_name3 => $field_value3) {
                                if (array_key_exists($field_name3, $registration_mailchimp_field)) {
                                    $params[$field_name][$field_name2][$field_name3] = $data[$registration_mailchimp_field[$field_name3]];
                                }
                            }
                        } else {
                            if (array_key_exists($field_name2, $registration_mailchimp_field)) {
                                $params[$field_name][$field_name2] = $data[$registration_mailchimp_field[$field_name2]];
                            }
                        }
                    }
                } else {
                    if (array_key_exists($field_name, $registration_mailchimp_field)) {
                        $params[$field_name] = $data[$registration_mailchimp_field[$field_name]];
                    }
                }
            }

            $params['status'] = 'subscribed';

            $args = [
                'method' => 'POST',
                'headers' => [
                    'authorization' => 'Basic ' . base64_encode('user:' . $mailchimp_api_key)
                ],
                'body' => json_encode($params)
            ];

            $end_point = 'lists/' . $mailchimp_list . '/members/';

            $response_body = mailchimp_request($mailchimp_api_key, $end_point, $args);
        }

        return $response_body;
    }

}

/**
 * add mailchimp cron schedules
 *
 * @access public
 * @param 
 * @return array
 * @since 1.0.0
 */
add_filter('cron_schedules', 'mailchimp_cron_schedules');

function mailchimp_cron_schedules($schedules) {
    if (!isset($schedules["5min"])) {
        $schedules["5min"] = array(
            'interval' => 5 * 60,
            'display' => __('5 Min', 'wp-event-manager-mailchimp'));
    }
    if (!isset($schedules["weekly"])) {
        $schedules["weekly"] = array(
            'interval' => 60 * 60 * 24 * 7,
            'display' => __('Once Weekly', 'wp-event-manager-mailchimp'));
    }
    if (!isset($schedules["monthly"])) {
        $schedules["monthly"] = array(
            'interval' => 60 * 60 * 24 * 30,
            'display' => __('Once Monthly', 'wp-event-manager-mailchimp'));
    }
    if (!isset($schedules["yearly"])) {
        $schedules["yearly"] = array(
            'interval' => 60 * 60 * 24 * 365,
            'display' => __('Once Yearly', 'wp-event-manager-mailchimp'));
    }
    return $schedules;
}

if (!function_exists('get_default_mailchimp_guest_list_matches_attribute')) {

    /**
     * Default Mailchimp guest_list Matches Attribute
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_default_mailchimp_guest_list_matches_attribute() {
        $guest_list_mailchimp_field = [];

        $guest_list_form_field = get_event_guest_lists_form_fields();

        foreach ($guest_list_form_field as $key => $field) {
            if (in_array('from_email', $field['rules'])) {
                $guest_list_mailchimp_field['email_address'] = $key;
            } else if (in_array('from_name', $field['rules'])) {
                $guest_list_mailchimp_field['FNAME'] = $key;
            }
        }

        return $guest_list_mailchimp_field;
    }

}

if (!function_exists('get_default_mailchimp_contact_organizer_matches_attribute')) {

    /**
     * Default Mailchimp contact_organizer Matches Attribute
     *
     * @access public
     * @param 
     * @return array
     * @since 1.0.0
     */
    function get_default_mailchimp_contact_organizer_matches_attribute() {
        $guest_list_mailchimp_field = [];

        $guest_list_form_field = get_contact_organizer_form_fields();

        foreach ($guest_list_form_field as $key => $field) {
            if (isset($field['rules']) && in_array('from_email', $field['rules'])) {
                $guest_list_mailchimp_field['email_address'] = $key;
            } else if (isset($field['rules']) && in_array('from_name', $field['rules'])) {
                $guest_list_mailchimp_field['FNAME'] = $key;
            }
        }

        return $guest_list_mailchimp_field;
    }

}

/**
 * event_manager_auto_mailchimp_sync_admin_callback function.
 *
 * @access public
 * @param mixed $arr_post_type
 * @return void
 * @since 1.0.0
 */
function event_manager_auto_mailchimp_sync_admin_callback($arr_post_type = []) {
    $args = array(
        'post_type' => $arr_post_type,
        'posts_per_page' => -1,
    );

    $result = new WP_Query($args);

    if ($result->found_posts > 0) {
        $mailchimp_api_key = get_option('mailchimp_settings')['mailchimp_api_key'];
        $mailchimp_list = get_option('mailchimp_settings')['mailchimp_list'];
        $mailchimp_sync_type = get_option('mailchimp_settings')['mailchimp_sync_type'];

        $organizer_mailchimp_field = get_option('organizer_mailchimp_field');
        $registration_mailchimp_field = get_option('registration_mailchimp_field');
        $guest_list_mailchimp_field = get_option('guest_list_mailchimp_field');

        foreach ($result->posts as $result) {

            if ($mailchimp_list == false) {
                $event_id = $result->post_parent;
                $event_mailchimp_list = get_post_meta($event_id, 'mailchimp_list', true);
                if ($event_mailchimp_list == false) {
                    $response['message'] = __('Synchronization disabled for this event.', 'wp-event-manager-mailchimp');
                    continue;
                }

                if (!empty($event_mailchimp_list)) {
                    $mailchimp_list = $event_mailchimp_list;
                }
            }
            if ($result->post_type == 'event_organizer') {
                $mailchimp_sync_field = $organizer_mailchimp_field;

                if (empty($mailchimp_sync_field)) {
                    $mailchimp_sync_field = get_default_mailchimp_organizer_matches_attribute();
                }

                $new_mailchimp_sync_field = [];

                foreach ($mailchimp_sync_field as $key => $value) {
                    $new_mailchimp_sync_field[$key] = '_' . $value;
                }

                $mailchimp_sync_field = $new_mailchimp_sync_field;
            } else if ($result->post_type == 'event_registration') {
                $mailchimp_sync_field = $registration_mailchimp_field;

                if (empty($mailchimp_sync_field)) {
                    $mailchimp_sync_field = get_default_mailchimp_registration_matches_attribute();
                }
            } else if ($result->post_type == 'event_guest_list') {
                $mailchimp_sync_field = $guest_list_mailchimp_field;

                if (empty($mailchimp_sync_field)) {
                    $mailchimp_sync_field = get_default_mailchimp_guest_list_matches_attribute();
                }
            }

            sync_data_in_mailchimp_list($mailchimp_api_key, $mailchimp_list, $mailchimp_sync_field, $result->ID);
        }
    }
}
