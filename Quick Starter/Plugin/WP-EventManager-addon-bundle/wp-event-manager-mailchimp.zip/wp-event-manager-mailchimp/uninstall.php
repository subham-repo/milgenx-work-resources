<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

$options = array(
		'wpem_mailchimp_version',
		'organizer_field',
		'organizer_mailchimp_field',
		'registration_field',
		'registration_mailchimp_field',
		'mailchimp_list',
		'mailchimp_sync_type',
		'mailchimp_sync_via',
		'mailchimp_sync_schedule',
);

foreach ( $options as $option ) {
	delete_option( $option );
}
