<div id="wpem_mailchimp" class="wpem-mailchimp">

    <?php do_action('wpem_mailchimp_dashboard_before'); ?>

    <?php $check_mailchimp_key = check_mailchimp_key($mailchimp_api_key); ?>
    <?php if (!empty($mailchimp_api_key) && !is_array($check_mailchimp_key)) { ?>

        <p class="event-manager-message wpem-alert wpem-alert-danger">
            <?php echo __('The API key entered is invalid.', 'wp-event-manager-sendinblue'); ?>
        </p>

    <?php } elseif (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] == 401) { ?>

        <p class="event-manager-message wpem-alert wpem-alert-danger">
            <?php echo __('The API key entered is invalid.', 'wp-event-manager-sendinblue'); ?>
        </p>

    <?php } ?>

    <div class="wpem-main wpem-mailchimp-wrapper event-mailchimp">
        <div class="wpem-mailchimp-matches-attribute-header wpem-form-wrapper">
            <h3 class="wpem-form-title wpem-heading-text"><?php _e('Mailchimp Settings', 'wp-event-manager-mailchimp'); ?></h3>
            <?php
            if (isset($check_mailchimp_key['total_items']) && $check_mailchimp_key['total_items'] > 0) :
                ?>
                <form class="wpem-mailchimp-disconnect wpem-form-wrapper" method="POST">

                    <input type="hidden" name="action" value="show_mailchimp" />
                    <?php if (!empty($_GET['page_id'])) : ?>
                        <input type="hidden" name="page_id" value="<?php echo absint($_GET['page_id']); ?>" />
                    <?php endif; ?>

                    <button type="submit" name="wp_event_manager_mailchimp_disconnect" class="wpem-theme-button wpem-theme-button-disconnect" value="<?php esc_attr_e('Disconnect', 'wp-event-manager-mailchimp'); ?>"><?php esc_attr_e('Disconnect', 'wp-event-manager-mailchimp'); ?></button>

                    <?php wp_nonce_field('event_manager_mailchimp_disconnect'); ?>

                </form>
            <?php endif; ?>
        </div>
        <div class="wpem-mailchimp-body">
            <form class="wpem-mailchimp wpem-form-wrapper" method="POST">
                <div class="wpem-mailchimp-field">
                    <div class="wpem-row">
                        <?php
                        $style = '';
                        if ($mailchimp_api_key != '' && is_array($check_mailchimp_key)) {
                            if (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] == 401) {
                                $style = 'style="display: block;"';
                            } else {
                                $style = 'style="display: none;"';
                            }
                        }
                        ?>
                        <div class="wpem-col-md-6" <?php echo $style; ?>>
                            <div class="wpem-form-group">
                                <?php
                                $readonly = '';
                                if ($mailchimp_api_key != '' && is_array($check_mailchimp_key)) {
                                    if (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] != 401) {
                                        $readonly = 'readonly';
                                    }
                                }
                                ?>
                                <input type="text" name="mailchimp_api_key" id="mailchimp-api-key" class="mailchimp-api-key" placeholder="<?php _e('Enter Mailchimp API Key', 'wp-event-manager-mailchimp'); ?>" value="<?php echo $mailchimp_api_key; ?>" <?php echo $readonly; ?> />
                            </div>
                        </div>

                        <?php if (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] == 401) : ?>
                        <?php else : ?>
                            <?php if (!empty($mailchimp_api_key) && is_array($check_mailchimp_key)) : ?>
                                <div class="wpem-col-md-6">
                                    <div class="wpem-form-group">
                                        <select name="mailchimp_list" class="mailchimp-list" >
                                            <?php foreach (get_mailchimp_lists($mailchimp_api_key) as $id => $label) : ?>
                                                <option value="<?php echo esc_attr($id); ?>" <?php selected($mailchimp_list, $id); ?>><?php echo esc_html($label); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <?php if (!empty($mailchimp_api_key)) : ?>

                                    <div class="wpem-col-md-6">
                                        <div class="wpem-form-group">
                                            <select required name="mailchimp_sync_type" class="mailchimp-sync-type" id="mailchimp-sync-type">
                                                <option value=""><?php _e('Select Mailchimp Sync Type', 'wp-event-manager-mailchimp'); ?>...</option>
                                                <?php foreach (get_mailchimp_sync_type() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($mailchimp_sync_type, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <?php
                                    $style = '';
                                    if ($mailchimp_sync_type == 'manual') {
                                        $style = 'style="display: none;"';
                                    }
                                    ?>
                                    <div class="wpem-col-md-6" id="mailchimp_sync_via" <?php echo $style; ?>>
                                        <div class="wpem-form-group">
                                            <select name="mailchimp_sync_via" class="mailchimp-sync-via" id="mailchimp-sync-via">
                                                <option value=""><?php _e('Select Mailchimp Sync Via', 'wp-event-manager-mailchimp'); ?>...</option>
                                                <?php foreach (get_mailchimp_sync_via() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($mailchimp_sync_via, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <?php
                                    $style = '';
                                    if ($mailchimp_sync_type == 'manual' || $mailchimp_sync_via == 'when_created') {
                                        $style = 'style="display: none;"';
                                    }
                                    ?>
                                    <div class="wpem-col-md-6" id="mailchimp_sync_schedule" <?php echo $style; ?>>
                                        <div class="wpem-form-group">
                                            <select name="mailchimp_sync_schedule" class="mailchimp-sync-schedule" id="mailchimp-sync-schedule">
                                                <option value=""><?php _e('Select Mailchimp Sync Schedule', 'wp-event-manager-mailchimp'); ?>...</option>
                                                <?php foreach (get_mailchimp_sync_schedule() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($mailchimp_sync_schedule, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                <?php endif; ?>
                            <?php endif; ?>

                        <?php endif; ?>

                        <div class="wpem-col-12">
                            <div class="wpem-form-group">
                                <input type="hidden" name="action" value="show_mailchimp" />
                                <button type="submit" name="wp_event_manager_mailchimp" class="wpem-theme-button" value="<?php esc_attr_e('Save Setting', 'wp-event-manager-mailchimp'); ?>"><?php esc_attr_e('Save Setting', 'wp-event-manager-mailchimp'); ?></button>

                                <?php wp_nonce_field('event_manager_mailchimp'); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>

    <?php do_action('wpem_mailchimp_dashboard_after'); ?>

</div>
