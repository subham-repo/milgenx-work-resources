<div class="wpem-main wpem-mailchimp-matches-attribute event-mailchimp-matches-attribute">
    <?php
    if (array_key_exists('addr1', $contact_organizer_mailchimp_field)) {
        if (!array_key_exists('city', $contact_organizer_mailchimp_field) || !array_key_exists('state', $contact_organizer_mailchimp_field) || !array_key_exists('country', $contact_organizer_mailchimp_field) || !array_key_exists('zip', $contact_organizer_mailchimp_field)) {
            ?>
            <p class="event-manager-message wpem-alert wpem-alert-warning">
                <?php echo __('City, State, Zip code & Country are mandatory with Address field.', 'wp-event-manager-sendinblue'); ?>
            </p>

            <?php
        }
    }
    ?>
    <div class="wpem-mailchimp-matches-attribute-header wpem-form-wrapper">
        <h3 class="wpem-form-title wpem-heading-text"><?php _e('Contact Organizer Matches Attribute', 'wp-event-manager-mailchimp'); ?></h3>
    </div>

    <div class="wpem-mailchimp-matches-attribute-body">

        <?php if ($field_not_mapping_message != '') : ?>
            <p class="event-manager-message wpem-alert wpem-alert-warning"><?php _e($field_not_mapping_message); ?></p>
        <?php endif; ?>

        <form class="wpem-form-wrapper" method="POST">
            <div class="wpem-mc-block-editor-wrapper">
                <table class="wpem-main wpem-mc-block-editor-table">
                    <thead>
                        <tr>
                            <th class="wpem-mc-col-name"> <?php _e('Contact Organizer Field', 'wp-event-manager-mailchimp'); ?>
                            </th>
                            <th class="wpem-mc-col-name"> <?php _e('Mailchimp Field', 'wp-event-manager-mailchimp'); ?>
                            </th>
                            <th class="wpem-mc-block-editor-act">&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody class="wpem-mc-block-editor-table-body">
                        <?php if (!empty($contact_organizer_mailchimp_field)) : ?>
                            <?php foreach ($contact_organizer_mailchimp_field as $sync_field => $form_field) : ?>
                                <tr>
                                    <td>
                                        <div class="wpem-form-group">
                                            <select name="contact_organizer_field[]" class="contact-organizer-field">
                                                <option value=""><?php _e('Select field', 'wp-event-manager-mailchimp'); ?>...</option>
                                                <?php foreach (get_contact_organizer_form_fields() as $name => $field) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="wpem-form-group">
                                            <select name="contact_organizer_mailchimp_field[]" class="mailchimp-field">
                                                <option value=""><?php _e('Select field', 'wp-event-manager-mailchimp'); ?>...</option>
                                                <?php foreach (get_mailchimp_list_dynamic_field($mailchimp_api_key, $mailchimp_list) as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </td>
                                    <td class="wpem-dboard-event-act-btn">
                                        <div class="wpem-form-group">
                                            <a href="javascript:void(0)" class="delete-field"></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>

                    </tbody>
                    <tfoot>
                        <tr>
                            <td class="wpem-form-group" colspan="3">

                                <button type="button" class="wpem-theme-button add-field" value="<?php esc_attr_e('Add Field', 'wp-event-manager-mailchimp'); ?>"><?php esc_attr_e('Add Field', 'wp-event-manager-mailchimp'); ?></button>

                                <button type="submit" name="wp_event_manager_mailchimp_contact_organizer_matches_attribute" class="wpem-theme-button wpem-fr" value="<?php esc_attr_e('Save', 'wp-event-manager-mailchimp'); ?>"><?php esc_attr_e('Save', 'wp-event-manager-mailchimp'); ?></button>

                                <?php wp_nonce_field('event_manager_mailchimp_contact_organizer_matches_attribute'); ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </form>


    </div>

</div>
