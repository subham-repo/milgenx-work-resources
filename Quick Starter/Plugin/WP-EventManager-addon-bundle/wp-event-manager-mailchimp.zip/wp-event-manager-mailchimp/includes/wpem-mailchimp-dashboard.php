<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Mailchimp_Integration_Dashboard class.
 */
class WPEM_Mailchimp_Dashboard {

    /**
     * __construct function.
     */
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'frontend_scripts'));
        add_action('wp_loaded', array($this, 'edit_handler'));

        //wpem dashboard column and content
        add_filter('wpem_dashboard_menu', array($this, 'wpem_dashboard_menu_add'));
        add_action('event_manager_event_dashboard_content_wpem_mailchimp_settings', array($this, 'wpem_mailchimp_settings'));



        add_filter('event_manager_event_dashboard_columns', array($this, 'add_mailchimp_columns'));
        add_action('event_manager_event_dashboard_column_mailchimp', array($this, 'mailchimp_column'));

        // Ajax on event dashboard for perticular event mailchimp list selection
        add_action('wp_ajax_event_manager_mailchimp_save_list_event', array($this, 'event_manager_mailchimp_save_list_event'));

        // cron
        add_action('event_manager_auto_mailchimp_sync_attendees', array($this, 'event_manager_auto_mailchimp_sync_attendees_callback'));
    }

    /**
     * frontend_scripts function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function frontend_scripts() {
        wp_register_script('wpem-mailchimp-dashboard', WPEM_MAILCHIMP_PLUGIN_URL . '/assets/js/mailchimp-dashboard.js', array('jquery'), WPEM_MAILCHIMP_VERSION, true);

        wp_localize_script('wpem-mailchimp-dashboard', 'wpem_mailchimp', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'wpem_mailchimp_dashboard_security' => wp_create_nonce("_nonce_wpem_mailchimp_dashboard_security"),
            'in_queue_icon' => EVENT_MANAGER_PLUGIN_URL . '/assets/images/ajax-loader.gif',
        ));

        wp_enqueue_style('wpem-mailchimp-frontend', WPEM_MAILCHIMP_PLUGIN_URL . '/assets/css/frontend.css');
    }

    /**
     * add dashboard menu function.
     *
     * @access public
     * @return void
     */
    public function wpem_dashboard_menu_add($menus) {
        $menus['wpem_mailchimp'] = array(
            'title' => __('Mailchimp', 'wp-event-manager-mailchimp'),
            'icon' => 'wpem-icon-mail3',
            'submenu' => array('wpem_mailchimp_settings' => array(
                    'title' => __('Settings', 'wp-event-manager'),
                    'query_arg' => ['action' => 'wpem_mailchimp_settings'],
                ))
        );

        $enable_mailchimp_registration = get_option('enable_mailchimp_registration', true);
        $enable_mailchimp_guest_list = get_option('enable_mailchimp_guest_list', true);
        $mailchimp_settings = get_mailchimp_settings_by_user();

        $sync_type = isset($mailchimp_settings['mailchimp_sync_type']) ? $mailchimp_settings['mailchimp_sync_type'] : 'auto';

        if (is_plugin_active('wp-event-manager-registrations/wp-event-manager-registrations.php') && $enable_mailchimp_registration == true && $sync_type == 'manual') {
            $menus['wpem_mailchimp']['submenu']['sync_registrations'] = array(
                'title' => __('Sync Registrations', 'wp-event-manager'),
                'query_arg' => ['action' => 'sync_registrations'],
            );
        }

        if (is_plugin_active('wp-event-manager-guest-lists/wp-event-manager-guest-lists.php') && $enable_mailchimp_guest_list == true && $sync_type == 'manual') {
            $menus['wpem_mailchimp']['submenu']['sync_guest_list'] = array(
                'title' => __('Sync Guests', 'wp-event-manager'),
                'query_arg' => ['action' => 'sync_guest_list'],
            );
        }
        return $menus;
    }

    /**
     * Export Event and Other Data
     */
    public function wpem_mailchimp_settings() {

        $user_id = get_current_user_id();

        wp_enqueue_script('wpem-mailchimp-dashboard');

        $mailchimp_settings = get_mailchimp_settings_by_user();

        get_event_manager_template(
                'wpem-mailchimp-settings.php',
                array(
                    'user_id' => $user_id,
                    'mailchimp_api_key' => isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '',
                    'mailchimp_list' => isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : '',
                    'mailchimp_sync_type' => isset($mailchimp_settings['mailchimp_sync_type']) ? $mailchimp_settings['mailchimp_sync_type'] : 'auto',
                    'mailchimp_sync_via' => isset($mailchimp_settings['mailchimp_sync_via']) ? $mailchimp_settings['mailchimp_sync_via'] : 'cron_job',
                    'mailchimp_sync_schedule' => isset($mailchimp_settings['mailchimp_sync_schedule']) ? $mailchimp_settings['mailchimp_sync_schedule'] : 'weekly',
                ),
                'wp-event-manager-mailchimp',
                WPEM_MAILCHIMP_PLUGIN_DIR . '/templates/'
        );
    }

    /**
     * edit_handler function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function edit_handler() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wp_event_manager_mailchimp']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_mailchimp')) {
            $mailchimp_api_key = !empty($_POST['mailchimp_api_key']) ? sanitize_text_field($_POST['mailchimp_api_key']) : '';
            $mailchimp_list = !empty($_POST['mailchimp_list']) ? sanitize_text_field($_POST['mailchimp_list']) : '';
            $mailchimp_sync_type = !empty($_POST['mailchimp_sync_type']) ? sanitize_text_field($_POST['mailchimp_sync_type']) : 'auto';
            $mailchimp_sync_via = !empty($_POST['mailchimp_sync_via']) ? sanitize_text_field($_POST['mailchimp_sync_via']) : 'cron_job';
            $mailchimp_sync_schedule = !empty($_POST['mailchimp_sync_schedule']) ? sanitize_text_field($_POST['mailchimp_sync_schedule']) : 'weekly';

            $mailchimp_settings = [
                'mailchimp_api_key' => $mailchimp_api_key,
                'mailchimp_list' => $mailchimp_list,
                'mailchimp_sync_type' => $mailchimp_sync_type,
                'mailchimp_sync_schedule' => $mailchimp_sync_schedule,
                'mailchimp_sync_via' => $mailchimp_sync_via,
            ];

            update_mailchimp_settings_by_user('mailchimp_settings', $mailchimp_settings);

            wp_clear_scheduled_hook('event_manager_auto_mailchimp_sync_attendees', array($user_id));
            if ($mailchimp_sync_type == 'auto' && $mailchimp_sync_via == 'cron_job') {
                switch ($mailchimp_sync_schedule) {
                    case '5min' :
                        $next = strtotime('+5 minutes');
                        break;
                    case 'daily' :
                        $next = strtotime('+1 day');
                        break;
                    case 'weekly' :
                        $next = strtotime('+1 week');
                        break;
                    case 'monthly' :
                        $next = strtotime('+1 month');
                        break;
                    case 'yearly' :
                        $next = strtotime('+1 year');
                        break;
                    default :
                        $next = strtotime('+1 week');
                        break;
                }

                // Create cron
                wp_schedule_event($next, $mailchimp_sync_schedule, 'event_manager_auto_mailchimp_sync_attendees', array($user_id));
            }
        }

        if (!empty($_POST['wp_event_manager_mailchimp_disconnect']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_mailchimp_disconnect')) {
            $arr_mailchimp_lists = get_sync_fields_by_user($user_id, 'mailchimp_lists');

            if (!empty($arr_mailchimp_lists)) {
                foreach ($arr_mailchimp_lists as $mailchimp_list => $mailchimp_name) {
                    delete_mailchimp_settings_by_user('mailchimp_list_dynamic_field_' . $mailchimp_list);
                }
            }

            wp_clear_scheduled_hook('event_manager_auto_mailchimp_sync_attendees', array($user_id));

            delete_mailchimp_settings_by_user('mailchimp_lists');
            delete_mailchimp_settings_by_user('mailchimp_settings');
        }
    }

    /**
     * add_mailchimp_columns function.
     *
     * @access public
     * @param $columns
     * @return void
     * @since 1.0.0
     */
    public function add_mailchimp_columns($columns) {
        $mailchimp_settings = get_mailchimp_settings_by_user();
        $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : 0;
        //if user not set event based settings then do not add column
        if ($mailchimp_list != false)
            return $columns;


        $columns['mailchimp'] = __('Mailchimp', 'wp-event-manager-mailchimp');
        return $columns;
    }

    /**
     * mailchimp_column function.
     *
     * @access public
     * @param $event
     * @return void
     * @since 1.0.0
     */
    public function mailchimp_column($event) {
        $user_id = get_current_user_id();
        $event_id = $event->ID;

        $event_mailchimp_list = get_post_meta($event_id, 'mailchimp_list', true);

        $mailchimp_settings = get_mailchimp_settings_by_user();

        $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
        $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : 0;

        if ($mailchimp_list != false)
            return;

        wp_enqueue_script('wpem-mailchimp-dashboard');

        $mailchimp_lists = get_mailchimp_lists($mailchimp_api_key);

        if (count($mailchimp_lists) > 0) {
            if (isset($mailchimp_lists[0]))
                $mailchimp_lists[0] = __('Disable for this event', 'wp-event-manager-mailchimp');
            ?>
            <div class="wpem-form-wrapper wpem-mailchimp">
                <div class="wpem-form-group">
                    <select name="mailchimp_list" class="mailchimp-list" data-event-id="<?php echo $event->ID; ?>">
                        <?php foreach ($mailchimp_lists as $id => $label) : ?>
                            <option value="<?php echo esc_attr($id); ?>" <?php selected($event_mailchimp_list, $id); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <?php
        } else {
            echo __('Please connect with Mailchimp.', 'wp-event-manager-mailchimp');
        }
    }

    public function event_manager_mailchimp_save_list_event() {
        check_ajax_referer('_nonce_wpem_mailchimp_dashboard_security', 'security');

        $event_id = isset($_REQUEST['event_id']) ? absint($_REQUEST['event_id']) : '';
        $mailchimp_list = isset($_REQUEST['mailchimp_list']) ? $_REQUEST['mailchimp_list'] : 0;

        if (!empty($event_id)) {
            update_post_meta($event_id, 'mailchimp_list', $mailchimp_list);
            return wp_send_json(array(
                'message' => __('Updated sucessfully.', 'wp-event-manager-mailchimp')));
        }



        wp_die();
    }

    /**
     * event_manager_auto_mailchimp_sync_attendees_callback function.
     *
     * @access public
     * @param $event_id
     * @return void
     * @since 1.0.0
     */
    public function event_manager_auto_mailchimp_sync_attendees_callback($user_id) {
        $event_ids = get_event_by_user_id($user_id);

        if (!empty($event_ids)) {
            foreach ($event_ids as $event_id) {
                $registrations = get_registration_attendee_list(['event_id' => $event_id, 'posts_per_page' => -1]);

                $arr_attendees_id = [];

                if ($registrations->found_posts > 0) {
                    foreach ($registrations->posts as $registration) {
                        $arr_attendees_id[] = $registration->ID;
                    }

                    add_attendees_in_mailchimp_list($user_id, $arr_attendees_id);
                }

                $guests = get_guest_lists_guest_list(['event_id' => $event_id, 'posts_per_page' => -1]);

                $arr_guest_id = [];

                if ($guests->found_posts > 0) {
                    foreach ($guests->posts as $guest) {
                        $arr_guest_id[] = $guest->ID;
                    }

                    add_guests_in_mailchimp_list($user_id, $arr_guest_id);
                }
            }
        }
    }

}

new WPEM_Mailchimp_Dashboard();
