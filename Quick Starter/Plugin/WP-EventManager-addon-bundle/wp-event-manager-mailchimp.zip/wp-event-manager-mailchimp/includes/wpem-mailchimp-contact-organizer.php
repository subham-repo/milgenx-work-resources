<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Mailchimp_Contact_Organizer class.
 */
class WPEM_Mailchimp_Contact_Organizer {

    /**
     * __construct function.
     */
    public function __construct() {
        add_action('wpem_mailchimp_dashboard_after', array($this, 'contact_organizer_fields_matches_attribute'), 10);

        add_action('wp_loaded', array($this, 'edit_handler'));

        add_action('event_manager_contact_organizer_send_mail_after', array($this, 'mailchimp_sync_via_add_new_contact_organizer'), 10, 3);
    }

    /**
     * fields_matches function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function contact_organizer_fields_matches_attribute() {
        $user_id = get_current_user_id();

        $mailchimp_settings = get_mailchimp_settings_by_user();

        $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
        $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : '';
        $check_mailchimp_key = check_mailchimp_key($mailchimp_api_key);

        if (isset($check_mailchimp_key['status']) && $check_mailchimp_key['status'] == 401)
            return;

        if (!empty($mailchimp_api_key) && is_array($check_mailchimp_key)) {
            $contact_organizer_field = get_sync_fields_by_user($user_id, 'contact_organizer_field');
            $contact_organizer_mailchimp_field = get_mailchimp_sync_fields_by_user($user_id, 'contact_organizer_mailchimp_field');

            $field_not_mapping_message = '';
            if (empty($contact_organizer_mailchimp_field)) {
                $contact_organizer_mailchimp_field = get_default_mailchimp_contact_organizer_matches_attribute();

                $field_not_mapping_message = __('Name and Email are compulsory fields for Mailchimp synchronization.', 'wp-event-manager-mailchimp');
            }

            get_event_manager_template(
                    'wpem-mailchimp-contact-organizer-field-mapping.php',
                    array(
                        'user_id' => $user_id,
                        'mailchimp_api_key' => $mailchimp_api_key,
                        'mailchimp_list' => $mailchimp_list,
                        'contact_organizer_mailchimp_field' => $contact_organizer_mailchimp_field,
                        'field_not_mapping_message' => $field_not_mapping_message,
                    ),
                    'wp-event-manager-mailchimp',
                    WPEM_MAILCHIMP_PLUGIN_DIR . '/templates/'
            );
        }
    }

    /**
     * edit_handler function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function edit_handler() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wp_event_manager_mailchimp_contact_organizer_matches_attribute']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_mailchimp_contact_organizer_matches_attribute')) {
            $contact_organizer_field = !empty($_POST['contact_organizer_field']) ? array_filter($_POST['contact_organizer_field']) : '';
            $contact_organizer_mailchimp_field = !empty($_POST['contact_organizer_mailchimp_field']) ? array_filter($_POST['contact_organizer_mailchimp_field']) : '';

            update_mailchimp_settings_by_user('contact_organizer_field', $contact_organizer_field);

            $new_mailchimp_field = [];

            if (!empty($contact_organizer_mailchimp_field)) {
                foreach ($contact_organizer_mailchimp_field as $key => $value) {
                    $new_mailchimp_field[$value] = $contact_organizer_field[$key];
                }
            }

            update_mailchimp_settings_by_user('contact_organizer_mailchimp_field', $new_mailchimp_field);
        }
    }

    /**
     * mailchimp_sync_via_add_new_registration function.
     *
     * @access public
     * @param $data
     * @return void
     * @since 1.0.0
     */
    public function mailchimp_sync_via_add_new_contact_organizer($data, $event_id, $organizer_id) {
        $event = get_post($event_id);
        $user_id = $event->post_author;

        $mailchimp_settings = get_mailchimp_settings_by_user_id($user_id);

        $mailchimp_api_key = isset($mailchimp_settings['mailchimp_api_key']) ? $mailchimp_settings['mailchimp_api_key'] : '';
        $mailchimp_list = isset($mailchimp_settings['mailchimp_list']) ? $mailchimp_settings['mailchimp_list'] : '';

        if ($mailchimp_api_key != '') {
            if ($mailchimp_list == '') {
                $event_mailchimp_list = get_post_meta($event_id, 'mailchimp_list', true);
                if (!empty($event_mailchimp_list)) {
                    $mailchimp_list = $event_mailchimp_list;
                }
            }

            $contact_organizer_field = get_sync_fields_by_user($user_id, 'contact_organizer_field');
            $contact_organizer_mailchimp_field = get_mailchimp_sync_fields_by_user($user_id, 'contact_organizer_mailchimp_field');

            if (empty($contact_organizer_mailchimp_field)) {
                $contact_organizer_mailchimp_field = get_default_mailchimp_contact_organizer_matches_attribute();
            }

            $result = sync_data_in_mailchimp_list_2($mailchimp_api_key, $mailchimp_list, $contact_organizer_mailchimp_field, $data);
        }
    }

}

new WPEM_Mailchimp_Contact_Organizer();
