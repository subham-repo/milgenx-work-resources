<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPEM_Mailchimp_Install class.
 */
class WPEM_Mailchimp_Install {

	/**
     * install function.
     *
     * @access public static
     * @param 
     * @return 
     * @since 1.0
     */
	public static function install() 
	{
		update_option( 'wpem_mailchimp_version', WPEM_MAILCHIMP_VERSION );
	}
}
