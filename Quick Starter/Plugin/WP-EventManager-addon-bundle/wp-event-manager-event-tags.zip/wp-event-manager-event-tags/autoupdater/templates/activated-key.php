<div class="updated">
	<p><?php printf( 'Your licence for <strong>%s</strong> has been activated. Thanks!', esc_html( $this->plugin_data['Name'] ) ); ?></p>
</div>