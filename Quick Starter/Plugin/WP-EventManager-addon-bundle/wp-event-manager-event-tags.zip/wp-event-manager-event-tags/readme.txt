=== WP Event Manager - Event Tags ===

Contributors: WP Event Manager
Requires at least: 4.1
Tested up to: 5.2.2
Stable tag: 1.4.2
License: GNU General Public License v3.0

Using the Event Tags plugin you can add a new ‘event tags’ field to the submit process, show events filtered by tag via shortcodes, and add tag filtering to the standard events shortcode.

= Support Policy =

I will happily patch any confirmed bugs with this plugin, however, I will not offer support for:

1. Customisations of this plugin or any plugins it relies upon
2. Conflicts with "premium" themes from ThemeForest and similar marketplaces (due to bad practice and not being readily available to test)
3. CSS Styling (this is customisation work)

If you need help with customisation you will need to find and hire a developer capable of making the changes.

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Changelog ==

= 1.4.2 =

* Added - Gutenburge compatiblity.
* Fixed - Some js and css tweaks.

= 1.4.1 =

* Added - New design responsive structure
* Added - Layout type attribute in events shortcode
* Added - CSS Improved
* Added - All Templates Improved
* Fixed - Minor Bugs

= 1.4 =

* Fixed : field editor compatibility
* Added : Elementor custom widget for shortcode added

= 1.3 =

* FIXED : some css tweaks and update restriction.

= 1.2 =

* FIXED : some css tweaks and unistall.

= 1.1 =

* FIXED : Text domain spell correction.

= 1.0 =
* First release.