<?php
/**
 * get_event_location function.
 *
 * @access public
 * @param mixed $post (default: null)
 * @return void
 */

function get_event_tags( $post = null ) {
	global $post;
	$terms = get_the_term_list( $post->ID, 'event_listing_tag', '<span>', '</span><span>', '</span>' );
	
	if ( ! apply_filters( 'enable_event_tag_archives', get_option( 'event_manager_enable_tag_archive' ) ) )
		$terms =  $terms ;
		
		return $terms;
}

/**
 * display_event_location function.
 * @param  boolean $map_link whether or not to link to the map on google maps
 * @return [type]
 */
function display_event_tags( $post = null ) {
	global $post;
	if ( $terms = get_event_tags($post) ) {
		echo $terms ;
	}
}
//show tags at single event page sidebar
function show_event_tags_sidebar(){
	
	if(get_event_tags() ){
		echo '<h3 class="wpem-heading-text">'. __('Event Tags','wp-event-manager').'</h3>
	<div class="wpem-event-tags">';
		display_event_tags();
		echo '</div>';
	}
	
}
add_action('single_event_sidebar_end','show_event_tags_sidebar');