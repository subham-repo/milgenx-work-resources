<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

$options = array(
	'event_manager_enable_tag_archive',
    'event_manager_tags_filter_type',
	'event_manager_max_tags',
	'event_manager_tag_input'
);

foreach ( $options as $option ) {
	delete_option( $option );
}


$all_fields = get_option( 'event_manager_form_fields', true );
if(is_array($all_fields)){
	$event_tags_fields = array('event_tags');
	foreach ($event_tags_fields as $key => $value) {
		if(isset($all_fields['event'][$value]))
			unset($all_fields['event'][$value]);
	}
}
update_option('event_manager_form_fields', $all_fields);