<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

$options = array(
		'wpem_constant_contact_version',
		'organizer_field',
		'organizer_constant_contact_field',
		'registration_field',
		'registration_constant_contact_field',
		'constant_contact_list',
		'constant_contact_sync_type',
		'constant_contact_sync_via',
		'constant_contact_sync_constant_contact',
		'wpem_constant_contact_code',
		'wpem_constant_contact_temp_redirect_url',
		'enable_constant_contact_organizer',
		'enable_constant_contact_registration',
		'guest_list_field',
		'guest_list_constant_contact_field',
		'enable_constant_contact_guest_list',
);

foreach ( $options as $option ) {
	delete_option( $option );
}
