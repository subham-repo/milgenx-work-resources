<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Constant_Contact_Contact_Organizer class.
 */
class WPEM_Constant_Contact_Contact_Organizer { 

    /**
     * __construct function.
     */
    public function __construct() { 
        add_action('wpem_constant_contact_dashboard_after', array($this, 'contact_organizer_fields_matches_attribute'), 10);

        add_action('wp_loaded', array($this, 'edit_handler'));

        add_action('event_manager_contact_organizer_send_mail_after', [$this, 'wpem_constant_contact_sync_via_add_new_contact_organizer'], 10, 3);

    }

    /**
     * fields_matches function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function contact_organizer_fields_matches_attribute() {
        $user_id = get_current_user_id();

        $constant_contact_settings = get_wpem_constant_contact_settings_by_user();

        $constant_contact_api_key = isset($constant_contact_settings['constant_contact_api_key']) ? $constant_contact_settings['constant_contact_api_key'] : '';
         $constant_contact_access_token = isset($constant_contact_settings['constant_contact_access_token']) ? $constant_contact_settings['constant_contact_access_token'] : '';
        //$constant_contact_list = isset($constant_contact_settings['constant_contact_list']) ? $constant_contact_settings['constant_contact_list'] : '';
        $constant_contact_list = get_wpem_constant_contact_lists($constant_contact_api_key,$constant_contact_access_token);
        
        $check_wpem_constant_contact_key = check_wpem_constant_contact_key($constant_contact_api_key);

        if (empty($constant_contact_list))
            return;

        if (!empty($constant_contact_api_key)) {

            $contact_organizer_field = get_sync_fields_by_user($user_id, 'contact_organizer_field');
            $contact_organizer_constant_contact_field = get_wpem_constant_contact_sync_fields_by_user($user_id, 'contact_organizer_constant_contact_field');

            $field_not_mapping_message = '';
            if (empty($contact_organizer_constant_contact_field)) {
                $contact_organizer_constant_contact_field = get_default_wpem_constant_contact_contact_organizer_matches_attribute();

                $field_not_mapping_message = __('Name and Email are compulsory fields for Constant Contact synchronization.', 'wpem-constant-contact');
            }

            get_event_manager_template(
                    'wpem-constant-contact-contact-organizer-field-mapping.php',
                    array(
                        'user_id' => $user_id,
                        'constant_contact_api_key' => $constant_contact_api_key,
                        'constant_contact_list' => $constant_contact_list,
                        'contact_organizer_constant_contact_field' => $contact_organizer_constant_contact_field,
                        'field_not_mapping_message' => $field_not_mapping_message,
                    ),
                    'wpem-constant-contact',
                    WPEM_CONSTANT_CONTACT_PLUGIN_DIR . '/templates/'
            );
        }
    }

    /**
     * edit_handler function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function edit_handler() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wp_event_manager_constant_contact_contact_organizer_matches_attribute']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_constant_contact_contact_organizer_matches_attribute')) {
            $contact_organizer_field = !empty($_POST['contact_organizer_field']) ? array_filter($_POST['contact_organizer_field']) : '';
            $contact_organizer_constant_contact_field = !empty($_POST['contact_organizer_constant_contact_field']) ? array_filter($_POST['contact_organizer_constant_contact_field']) : '';

            update_wpem_constant_contact_settings_by_user('contact_organizer_field', $contact_organizer_field);

            $new_constant_contact_field = [];

            if (!empty($contact_organizer_constant_contact_field)) {
                foreach ($contact_organizer_constant_contact_field as $key => $value) {
                    $new_constant_contact_field[$value] = $contact_organizer_field[$key];
                }
            }

            update_wpem_constant_contact_settings_by_user('contact_organizer_constant_contact_field', $new_constant_contact_field);
        }
    }

    /**
     * wpem_constant_contact_sync_via_add_new_registration function.
     *
     * @access public
     * @param $data
     * @return void
     * @since 1.0.0
     */
    public function wpem_constant_contact_sync_via_add_new_contact_organizer($data, $event_id, $organizer_id) { 
       
        $event = get_post($event_id);
        $user_id = $event->post_author;

        $constant_contact_settings = get_wpem_constant_contact_settings_by_user_id($user_id);

        $constant_contact_api_key = isset($constant_contact_settings['constant_contact_api_key']) ? $constant_contact_settings['constant_contact_api_key'] : '';
        $constant_contact_access_token = isset($constant_contact_settings['constant_contact_access_token']) ? $constant_contact_settings['constant_contact_access_token'] : '';
        $constant_contact_list = isset($constant_contact_settings['constant_contact_list']) ? $constant_contact_settings['constant_contact_list'] : '';

        if ($constant_contact_api_key != '') {
            if ($constant_contact_list == '') {
                $event_constant_contact_list = get_post_meta($event_id, 'constant_contact_list', true);
                if (!empty($event_constant_contact_list)) {
                    $constant_contact_list = $event_constant_contact_list;
                }
            }

            $contact_organizer_field = get_sync_fields_by_user($user_id, 'contact_organizer_field');
            $contact_organizer_constant_contact_field = get_wpem_constant_contact_sync_fields_by_user($user_id, 'contact_organizer_constant_contact_field');

            if (empty($contact_organizer_constant_contact_field)) {
                $contact_organizer_constant_contact_field = get_default_wpem_constant_contact_contact_organizer_matches_attribute();
            }
            $result = sync_data_in_wpem_constant_contact_list_2($constant_contact_api_key, $constant_contact_list, $contact_organizer_constant_contact_field, $data,$constant_contact_access_token);
        }
    }
}
new WPEM_Constant_Contact_Contact_Organizer();