<?php 
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Constant_Contact_Integration_Dashboard class.
 */
class WPEM_Constant_Contact_Dashboard { 

    /**
     * __construct function.
     */
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'frontend_scripts'));
        add_action('wp_loaded', array($this, 'edit_handler'));

        //wpem dashboard column and content
        add_filter('wpem_dashboard_menu', array($this, 'wpem_dashboard_menu_add'));
        add_action('event_manager_event_dashboard_content_wpem_constant_contact_settings', array($this, 'wpem_constant_contact_settings'));



        add_filter('event_manager_event_dashboard_columns', array($this, 'add_wpem_wpem_constant_contact_columns'));
        add_action('event_manager_event_dashboard_column_constant-contact', array($this, 'wpem_constant_contact_column'));
        

        // Ajax on event dashboard for perticular event constant contact list selection
        add_action('wp_ajax_wpem_constant_contact_save_list_event', array($this, 'wpem_constant_contact_save_list_event'));

        // cron
        add_action('event_manager_auto_constant_contact_sync_attendees', array($this, 'event_manager_auto_wpem_constant_contact_sync_attendees_callback'));
    }

    /**
     * frontend_scripts function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function frontend_scripts() {
        wp_register_script('wpem-constant-contact-dashboard', WPEM_CONSTANT_CONTACT_PLUGIN_URL . '/assets/js/constant-contact-dashboard.js', array('jquery'), WPEM_CONSTANT_CONTACT_VERSION, true);

        wp_localize_script('wpem-constant-contact-dashboard', 'wpem_constant_contact', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'wpem_constant_contact_dashboard_security' => wp_create_nonce("_nonce_wpem_constant_contact_dashboard_security"),
            'in_queue_icon' => EVENT_MANAGER_PLUGIN_URL . '/assets/images/ajax-loader.gif',
        ));

        wp_enqueue_style('wpem-constant-contact-frontend', WPEM_CONSTANT_CONTACT_PLUGIN_URL . '/assets/css/frontend.css');
    }

    /**
     * add dashboard menu function.
     *
     * @access public
     * @return void
     */
    public function wpem_dashboard_menu_add($menus) {
        $menus['wpem_constant_contact'] = array(
            'title' => __('Constant Contact', 'wpem-constant-contact'),
            'icon' => 'wpem-icon-mail3',
            'submenu' => array('wpem_constant_contact_settings' => array(
                    'title' => __('Settings', 'wpem'),
                    'query_arg' => ['action' => 'wpem_constant_contact_settings'],
                ))
        );

        $enable_constant_contact_registration = get_option('enable_constant_contact_registration', true);
        $enable_constant_contact_guest_list = get_option('enable_constant_contact_guest_list', true);
        $enable_constant_contact_organizer = get_option('enable_constant_contact_organizer', true);
        $constant_contact_settings = get_wpem_constant_contact_settings_by_user();

        $sync_type = isset($constant_contact_settings['constant_contact_sync_type']) ? $constant_contact_settings['constant_contact_sync_type'] : 'auto';

        if (is_plugin_active('wp-event-manager-registrations/wp-event-manager-registrations.php') && $enable_constant_contact_registration == true && $sync_type == 'manual') {
            $menus['wpem_constant_contact']['submenu']['wpem_constant_contact_sync_registrations'] = array(
                'title' => __('Sync Registrations', 'wp-event-manager'),
                'query_arg' => ['action' => 'wpem_constant_contact_sync_registrations'],
            );
        }

        if (is_plugin_active('wpem-guests/wpem-guests.php') && $enable_constant_contact_guest_list == true && $sync_type == 'manual') {
            $menus['wpem_constant_contact']['submenu']['wpem_constant_contact_sync_guest_list'] = array(
                'title' => __('Sync Guests', 'wp-event-manager'),
                'query_arg' => ['action' => 'wpem_constant_contact_sync_guest_list'],
            );
        }
        
        return $menus;
    }

    /**
     * Export Event and Other Data
     */
    public function wpem_constant_contact_settings() {

        $user_id = get_current_user_id();

        wp_enqueue_script('wpem-constant-contact-dashboard');

        $constant_contact_settings = get_wpem_constant_contact_settings_by_user();

        get_event_manager_template(
                'wpem-constant-contact-settings.php',
                array(
                    'user_id' => $user_id,
                    'constant_contact_api_key' => isset($constant_contact_settings['constant_contact_api_key']) ? $constant_contact_settings['constant_contact_api_key'] : '',
                    'constant_contact_secret_key' => isset($constant_contact_settings['constant_contact_secret_key']) ? $constant_contact_settings['constant_contact_secret_key'] : '',
                    'constant_contact_access_token' => isset($constant_contact_settings['constant_contact_access_token']) ? $constant_contact_settings['constant_contact_access_token'] : '',
                    'constant_contact_list' => isset($constant_contact_settings['constant_contact_list']) ? $constant_contact_settings['constant_contact_list'] : '',
                    'constant_contact_sync_type' => isset($constant_contact_settings['constant_contact_sync_type']) ? $constant_contact_settings['constant_contact_sync_type'] : 'auto',
                    'constant_contact_sync_via' => isset($constant_contact_settings['constant_contact_sync_via']) ? $constant_contact_settings['constant_contact_sync_via'] : 'cron_job',
                    'constant_contact_sync_schedule' => isset($constant_contact_settings['constant_contact_sync_schedule']) ? $constant_contact_settings['constant_contact_sync_schedule'] : 'weekly',
                ),
                'wpem-constant-contact',
                WPEM_CONSTANT_CONTACT_PLUGIN_DIR . '/templates/'
        );
    }

    /**
     * edit_handler function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function edit_handler() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wp_event_manager_constant_contact']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_constant_contact')) {

            $constant_contact_api_key = !empty($_POST['constant_contact_api_key']) ? sanitize_text_field($_POST['constant_contact_api_key']) : '';
            $constant_contact_secret_key = !empty($_POST['constant_contact_secret_key']) ? sanitize_text_field($_POST['constant_contact_secret_key']) : '';
            $constant_contact_access_token = "";
            $constant_contact_referesh_token = "";
            $constant_contact_list = !empty($_POST['constant_contact_list']) ? sanitize_text_field($_POST['constant_contact_list']) : '';
            $constant_contact_sync_type = !empty($_POST['constant_contact_sync_type']) ? sanitize_text_field($_POST['constant_contact_sync_type']) : 'auto';
            $constant_contact_sync_via = !empty($_POST['constant_contact_sync_via']) ? sanitize_text_field($_POST['constant_contact_sync_via']) : 'cron_job';
            $constant_contact_sync_schedule = !empty($_POST['constant_contact_sync_schedule']) ? sanitize_text_field($_POST['constant_contact_sync_schedule']) : 'weekly';



            $constant_contact_settings = [
                'constant_contact_api_key' => $constant_contact_api_key,
                'constant_contact_secret_key' => $constant_contact_secret_key,
                'constant_contact_access_token' => $constant_contact_access_token,
                'constant_contact_referesh_token' => $constant_contact_referesh_token,
                'constant_contact_list' => $constant_contact_list,
                'constant_contact_sync_type' => $constant_contact_sync_type,
                'constant_contact_sync_schedule' => $constant_contact_sync_schedule,
                'constant_contact_sync_via' => $constant_contact_sync_via,
            ];
            
            update_wpem_constant_contact_settings_by_user('constant_contact_settings', $constant_contact_settings);

            //check current url
            $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
 
            $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            
            update_option('wpem_constant_contact_temp_redirect_url', $url);
            update_option('wpem_constant_contact_code', 'yes');
            if($constant_contact_api_key == '' && $constant_contact_secret_key == ''){
                
                wp_safe_redirect($url);
                exit();
            }

            wp_clear_scheduled_hook('event_manager_auto_constant_contact_sync_attendees', array($user_id));
            if ($constant_contact_sync_type == 'auto' && $constant_contact_sync_via == 'cron_job') {
                switch ($constant_contact_sync_schedule) {
                    case '5min' :
                        $next = strtotime('+5 minutes');
                        break;
                    case 'daily' :
                        $next = strtotime('+1 day');
                        break;
                    case 'weekly' :
                        $next = strtotime('+1 week');
                        break;
                    case 'monthly' :
                        $next = strtotime('+1 month');
                        break;
                    case 'yearly' :
                        $next = strtotime('+1 year');
                        break;
                    default :
                        $next = strtotime('+1 week');
                        break;
                }

                // Create cron
                wp_schedule_event($next, $constant_contact_sync_schedule, 'event_manager_auto_constant_contact_sync_attendees', array($user_id));
            }
            
             $result = check_wpem_constant_contact_key($constant_contact_api_key);
             

            wp_redirect($result);
            exit();
        }

        if (!empty($_POST['wp_event_manager_constant_contact_disconnect']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_constant_contact_disconnect')) {
            $arr_constant_contact_lists = get_sync_fields_by_user($user_id, 'constant_contact_lists');

            if (!empty($arr_constant_contact_lists)) {
                foreach ($arr_constant_contact_lists as $constant_contact_list => $constant_contact_name) {
                    delete_wpem_constant_contact_settings_by_user('constant_contact_list_dynamic_field_' . $constant_contact_list);
                }
            }

            wp_clear_scheduled_hook('event_manager_auto_constant_contact_sync_attendees', array($user_id));

            delete_wpem_constant_contact_settings_by_user('constant_contact_lists');
            delete_wpem_constant_contact_settings_by_user('constant_contact_settings');
        }
       
    }

    /**
     * add_wpem_wpem_constant_contact_columns function.
     *
     * @access public
     * @param $columns
     * @return void
     * @since 1.0.0
     */
    public function add_wpem_wpem_constant_contact_columns($columns) { 
        $constant_contact_settings = get_wpem_constant_contact_settings_by_user();
        $constant_contact_list = isset($constant_contact_settings['constant_contact_list']) ? $constant_contact_settings['constant_contact_list'] : 0;
        //if user not set event based settings then do not add column

        if ($constant_contact_list != false)
            return $columns;
        


        $columns['constant-contact'] = __('Constant Contact', 'wpem-constant-contact');
        return $columns;
    }

    /**
     * wpem_constant_contact_column function.
     *
     * @access public
     * @param $event
     * @return void
     * @since 1.0.0
     */
    public function wpem_constant_contact_column($event) { 
        $user_id = get_current_user_id();
        $event_id = $event->ID;

        $event_constant_contact_list = get_post_meta($event_id, 'constant_contact_list', true);

        $constant_contact_settings = get_wpem_constant_contact_settings_by_user();

        $constant_contact_api_key = isset($constant_contact_settings['constant_contact_api_key']) ? $constant_contact_settings['constant_contact_api_key'] : '';
        $constant_contact_access_token = isset($constant_contact_settings['constant_contact_access_token']) ? $constant_contact_settings['constant_contact_access_token'] : '';
        $constant_contact_list = isset($constant_contact_settings['constant_contact_list']) ? $constant_contact_settings['constant_contact_list'] : 0;

        if ($constant_contact_list != false)
            return;

        wp_enqueue_script('wpem-constant-contact-dashboard');

        $constant_contact_lists = get_wpem_constant_contact_lists($constant_contact_api_key,$constant_contact_access_token);
        
        if (count($constant_contact_lists) > 0) { 
            if (isset($constant_contact_lists[0]))
                $constant_contact_lists[0] = __('Disable for this event', 'wpem-constant-contact');
            ?>
            <div class="wpem-form-wrapper wpem-constant-contact">
                <div class="wpem-form-group">
                    <select name="constant_contact_list" class="constant-contact-list" data-event-id="<?php echo $event->ID; ?>">
            <?php foreach ($constant_contact_lists as $id => $label) : ?>
                            <option value="<?php echo esc_attr($id); ?>" <?php selected($event_constant_contact_list, $id); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <?php
        } else {
            echo __('Please connect with Constant Contact.', 'wpem-constant-contact');
        }
    }

    public function wpem_constant_contact_save_list_event() {
        check_ajax_referer('_nonce_wpem_constant_contact_dashboard_security', 'security');

        $event_id = isset($_REQUEST['event_id']) ? absint($_REQUEST['event_id']) : '';
        $constant_contact_list = isset($_REQUEST['constant_contact_list']) ? $_REQUEST['constant_contact_list'] : 0;

        if (!empty($event_id)) {
            update_post_meta($event_id, 'constant_contact_list', $constant_contact_list);
            return wp_send_json(array(
                'message' => __('Updated sucessfully.', 'wpem-constant-contact')));
        }

        wp_die();
    }

    /**
     * event_manager_auto_wpem_constant_contact_sync_attendees_callback function.
     *
     * @access public
     * @param $event_id
     * @return void
     * @since 1.0.0
     */
    public function event_manager_auto_wpem_constant_contact_sync_attendees_callback($user_id) {
        $event_ids = get_event_by_user_id($user_id);

        if (!empty($event_ids)) {
            foreach ($event_ids as $event_id) {
                $registrations = get_registration_attendee_list(['event_id' => $event_id, 'posts_per_page' => -1]);

                $arr_attendees_id = [];

                if ($registrations->found_posts > 0) {
                    foreach ($registrations->posts as $registration) {
                        $arr_attendees_id[] = $registration->ID;
                    }

                    add_attendees_in_wpem_constant_contact_list($user_id, $arr_attendees_id);
                }

                $guests = get_guest_lists_guest_list(['event_id' => $event_id, 'posts_per_page' => -1]);

                $arr_guest_id = [];

                if ($guests->found_posts > 0) {
                    foreach ($guests->posts as $guest) {
                        $arr_guest_id[] = $guest->ID;
                    }

                    add_guests_in_wpem_constant_contact_list($user_id, $arr_guest_id);
                }
            }
        }
    }
}
new WPEM_Constant_Contact_Dashboard();
