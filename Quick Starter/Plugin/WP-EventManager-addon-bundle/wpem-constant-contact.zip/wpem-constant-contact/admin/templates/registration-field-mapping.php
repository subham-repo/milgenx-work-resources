<div class="white-background">
    <form method="post" class="wpem-constant-contact-registration-matches-attribute">
        <div class="wpem-constant-contact-settings-organizer">
            <label><strong>Sync Registrations</strong> <input id="setting-enable_constant_contact_registration" name="enable_constant_contact_registration" type="checkbox" <?php checked($enable_constant_contact_registration, true); ?> value="1"> <?php _e('Enable registration sync with constant contact.', 'wpem-constant-contact'); ?></label>
        </div>
        <h3><?php _e('Registration Field Mapping with Constant Contact', 'wpem-constant-contact'); ?></h3>
        <table class="widefat wpem-constant-contact-field-maping-table">
            <thead>
                <tr>
                    <th ><?php _e('Registration Field', 'wpem-constant-contact'); ?></th>
                    <th ><?php _e('Constant Contact Field', 'wpem-constant-contact'); ?></th>
                    <th class="wpem-constant-contact-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($registration_constant_contact_field)) : ?>
                    <?php foreach ($registration_constant_contact_field as $sync_field => $form_field) : ?>
                        <tr>
                            <td>
                                <select name="registration_field[]" class="registration-field">
                                    <option value=""><?php _e('Select registration Field', 'wpem-constant-contact'); ?>...</option>
                                    <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="registration_constant_contact_field[]" class="constant-contact-registration-field">
                                    <option value=""><?php _e('Select Constant Contact Field', 'wpem-constant-contact'); ?>...</option>
                                    <?php
                                    $a = get_wpem_constant_contact_list_dynamic_field($constant_contact_api_key, $constant_contact_list);
                                     foreach (get_wpem_constant_contact_list_dynamic_field($constant_contact_api_key, $constant_contact_list,$constant_contact_access_token) as $name => $label) :
                                        
                                        if($name == 'email_address'){
                                            foreach($label as $key => $value) {
                                                  $name = $key;
                                                  $label = $value;
                                                }
                                        }

                                        ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wpem-constant-contact'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="registration_field[]" class="registration-field">
                                <option value=""><?php _e('Select registration Field', 'wpem-constant-contact'); ?>...</option>
                                <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="registration_constant_contact_field[]" class="constant-contact-registration-field">
                                <option value=""><?php _e('Select Constant Contact Field', 'wpem-constant-contact'); ?>...</option>
                                <?php foreach (get_wpem_constant_contact_list_dynamic_field($constant_contact_api_key, $constant_contact_list,$constant_contact_access_token) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">
                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wpem-constant-contact'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td >
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wpem-constant-contact'); ?></a>
                    </td>
                    <td colspan="2">
                        <?php wp_nonce_field('wpem_constant_contact_admin_registration_field_mapping'); ?>
                        <input type="submit" class="button-primary wpem-field-maping-save" name="submit_constant_contact_admin_registration_mapping" value="<?php esc_attr_e('Save', 'wpem-constant-contact'); ?>" />
                    </td>
                </tr>
            </tfoot>
        </table>
    </form>	
</div>