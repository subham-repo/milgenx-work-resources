$constant_contact_access_token<div class="white-background">
    <form method="post" class="wpem-constant-contact-guest-list-matches-attribute">
        <div class="wpem-constant-contact-settings-guest-list">

            <label><strong><?php _e('Sync Guest Lists', 'wpem-constant-contact'); ?></strong> <input id="setting-enable_constant_contact_guest_list" name="enable_constant_contact_guest_list" type="checkbox" <?php checked($enable_constant_contact_guest_list, true); ?> value="1"> <?php _e('Enable guest list sync with constant contact.', 'wpem-constant-contact'); ?></label>
        </div>
        <h3><?php _e('Guest Field Mapping with Constant Contact', 'wpem-constant-contact'); ?></h3>
        <table class="widefat wpem-constant-contact-field-maping-table">
            <thead>
                <tr>
                    <th><?php _e('Guest List Field', 'wpem-constant-contact'); ?></th>
                    <th><?php _e('Constant Contact Field', 'wpem-constant-contact'); ?></th>
                    <th class="wpem-constant-contact-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>

            <tbody>
                <?php if (!empty($guest_list_constant_contact_field)) : ?>
                    <?php foreach ($guest_list_constant_contact_field as $sync_field => $form_field) : ?>
                        <tr>
                            <td>
                                <select name="guest_list_field[]" class="guest-list-field">
                                    <option value=""><?php _e('Select Field', 'wpem-constant-contact'); ?>...</option>
                                    <?php foreach (get_event_guests_form_fields() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="guest_list_constant_contact_field[]" class="constant-contact-guest-list-field">
                                    <option value=""><?php _e('Select Constant Contact Field', 'wpem-constant-contact'); ?>...</option>
                                    <?php foreach (get_wpem_constant_contact_list_dynamic_field($constant_contact_api_key, $constant_contact_list,$constant_contact_access_token) as $name => $label) :
                                         if( $name === 'email_address' ){
                                            foreach($label as $key => $value) {
                                                  $name = $key;
                                                  $label = $value;
                                                }
                                        }
                                        ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wpem-constant-contact'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="guest_list_field[]" class="guest-list-field">
                                <option value=""><?php _e('Select Field', 'wpem-constant-contact'); ?>...</option>
                                <?php foreach (get_event_guest_lists_form_fields() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="guest_list_constant_contact_field[]" class="constant-contact-guest-list-field">
                                <option value=""><?php _e('Select Constant Contact Field', 'wpem-constant-contact'); ?>...</option>
                                <?php foreach (get_wpem_constant_contact_list_dynamic_field($constant_contact_api_key, $constant_contact_list,$constant_contact_access_token) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">
                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wpem-constant-contact'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td>
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wpem-constant-contact'); ?></a>
                    </td>
                    <td colspan="2">
                        <?php wp_nonce_field('wpem_admin_constant_contact_guest_list_field_mapping'); ?>
                        <input type="submit" class="button-primary wpem-field-maping-save" name="submit_constant_contact_admin_guest_list_field_mapping" value="<?php esc_attr_e('Save', 'wpem-constant-contact'); ?>" />
                    </td>

                </tr>
            </tfoot>

        </table>
    </form>
</div>      
