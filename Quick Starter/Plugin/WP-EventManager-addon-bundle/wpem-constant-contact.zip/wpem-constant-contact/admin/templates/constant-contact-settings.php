<div class="wrap wp_event_manager wpem-constant-contact-admin-wrap">
    <h2><?php _e('WP Event Manager Constant Contact Settings', 'wpem-constant-contact'); ?></h2>

    <?php do_action('wpem_constant_contact_settings_before'); ?>

    <div class="wpem-constant-contact-setting-wrapper">
        <div class="wpem-constant-contact-setting">
            <div class="wpem-constant-contact-image">
                <img src="<?php echo WPEM_CONSTANT_CONTACT_PLUGIN_URL ?>/assets/images/constant_contact_logo_small.png" alt="constant-contact">
            </div>
            <div class="wpem-constant-contact-settings-container">
                <?php
                if($constant_contact_api_key){
                $lists = get_wpem_constant_contact_lists($constant_contact_api_key,$constant_contact_access_token);
                $constant_contact_api_key = get_option('constant_contact_settings')['constant_contact_api_key'];
               
                 $check_wpem_constant_contact_key = check_wpem_constant_contact_key($constant_contact_api_key);
                 
                 if (empty($lists) ) { ?>

                    <div class="error">
                        <p>
                            <?php echo __('The API key entered is invalid.', 'wpem-constant-contact'); ?>
                        </p>
                    </div>

                <?php }} ?>
                <div class="wpem-constant-contact-info">
                    <h1><?php _e('Constant Contact Settings', 'wpem-constant-contact'); ?></h1>
                    <?php 
                     if (isset($lists) && !empty($lists) ) : ?>

                        <form method="post" class="wp-event-constant-contact-disconnect-settings">
                            <input type="submit" class="wpem-theme-button wpem-theme-button-disconnect" name="wpem_constant_contact_settings" value="<?php esc_attr_e('Disconnect', 'wpem-constant-contact'); ?>">

                            <?php wp_nonce_field('event_constant_contact_disconnect_settings'); ?>
                        </form>

                    <?php endif; ?>
                    <p><?php _e('Integrate Constant Contact with WP Event Manager', 'wpem-constant-contact'); ?></p>
                </div>
                <form method="post" class="wpem-constant-contact-form">
                    <div class="wpem-constant-contact-form-container">
                        <input type="text" class="constant-contact-api-key" name="constant_contact_api_key" placeholder="<?php _e('Constant Contact API Key', 'wpem-constant-contact'); ?>" value="<?php echo $constant_contact_api_key; ?>">
                        <input type="text" class="constant-contact-secret-key" name="constant_contact_secret_key" placeholder="<?php _e('Constant Contact Secret Key', 'wpem-constant-contact'); ?>" value="<?php echo $constant_contact_secret_key; ?>">

                        <?php if (isset($lists) && empty($lists)) : ?>

                        <?php  else : ?>
                            <?php if ($constant_contact_api_key != '') : ?>
                                
                                <select name="constant_contact_list" class="constant-contact-list">
                                    <?php 
                                     foreach (get_wpem_constant_contact_lists($constant_contact_api_key,$constant_contact_access_token) as $id => $label) : ?>
                                        <option value="<?php echo esc_attr($id); ?>" <?php selected($constant_contact_list, $id); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>

                            <?php if ($constant_contact_api_key != '') : ?>
                                <select name="constant_contact_sync_type" class="constant-contact-sync-type" id="constant-contact-sync-type">
                                    <option value=""><?php _e('Select Constant Contact Sync Type', 'wpem-constant-contact'); ?></option>
                                    <?php foreach (get_wpem_constant_contact_sync_type() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($constant_contact_sync_type, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <?php
                                $style = '';
                                if ($constant_contact_sync_type == 'manual') {
                                    $style = 'style="display: none;"';
                                }
                                ?>
                                <select id="constant-contact-sync-via" <?php echo $style; ?> name="constant_contact_sync_via" class="constant-contact-sync-via">
                                    <option value=""><?php _e('Select Constant Contact Sync Via', 'wpem-constant-contact'); ?></option>
                                    <?php foreach (get_wpem_constant_contact_sync_via() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($constant_contact_sync_via, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <?php
                                $style = '';
                                if ($constant_contact_sync_type == 'manual' || $constant_contact_sync_via == 'when_created') {
                                    $style = 'style="display: none;"';
                                }
                                ?>
                                <select id="constant_contact_sync_schedule" <?php echo $style; ?> name="constant_contact_sync_schedule" class="constant-contact-sync-schedule">
                                    <?php foreach (get_wpem_constant_contact_sync_schedule() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($constant_contact_sync_schedule, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>

                        <?php endif; ?>

                        <input type="submit" class="wpem-theme-button" name="wpem_constant_contact_settings" value="<?php esc_attr_e('Save Setting', 'wpem-constant-contact'); ?>" />

                        <?php wp_nonce_field('event_constant_contact_settings'); ?>

                    </div>
                </form>

            </div>
        </div>
    </div>

    <?php do_action('wpem_constant_contact_settings_after'); ?>

</div>
