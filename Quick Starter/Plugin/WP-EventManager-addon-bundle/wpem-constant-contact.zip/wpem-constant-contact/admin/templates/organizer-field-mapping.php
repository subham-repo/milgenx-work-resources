<div class="white-background">
    <form method="post" class="wpem-constant-contact-organizer-matches-attribute">
        <div class="wpem-constant-contact-settings-organizer">
            <label><input id="setting-enable_constant_contact_organizer" name="enable_constant_contact_organizer" type="checkbox" <?php checked($enable_constant_contact_organizer, true); ?> value="1" > <?php _e('Enable organizer sync with constant contact.', 'wpem-constant-contact'); ?></label>
        </div>
        <h3><?php _e('Organizer Field Mapping with Constant Contact', 'wpem-constant-contact'); ?></h3>
        <table class="widefat wpem-constant-contact-field-maping-table">
            <thead>
                <tr>
                    <th ><?php _e('Organizer Field', 'wpem-constant-contact'); ?></th>
                    <th ><?php _e('Constant Contact Field', 'wpem-constant-contact'); ?></th>
                    <th class="wpem-constant-contact-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>

            <tbody>
                <?php if (!empty($organizer_constant_contact_field)) : ?>
                    <?php foreach ($organizer_constant_contact_field as $sync_field => $form_field) : ?>
                        <tr>
                            <td>
                                <select name="organizer_field[]" class="organization-field">
                                    <option value=""><?php _e('Select Organizer Field', 'wpem-constant-contact'); ?>...</option>
                                    <?php foreach (get_event_organization_form_field_lists() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="organizer_constant_contact_field[]" class="constant-contact-organization-field">
                                    <option value=""><?php _e('Select Constant Contact Field', 'wpem-constant-contact'); ?>...</option>
                                    <?php foreach (get_wpem_constant_contact_list_dynamic_field($constant_contact_api_key, $constant_contact_list,$constant_contact_access_token) as $name => $label) :
                                        if($name === 'email_address'){
                                            foreach($label as $key => $value) {
                                                  $name = $key;
                                                  $label = $value;
                                                }
                                        }
                                     ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wpem-constant-contact'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="organizer_field[]" class="organization-field">
                                <option value=""><?php _e('Select Organizer Field', 'wpem-constant-contact'); ?>...</option>
                                <?php foreach (get_event_organization_form_field_lists() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="organizer_constant_contact_field[]" class="constant-contact-organization-field">
                                <option value=""><?php _e('Select Constant Contact Field', 'wpem-constant-contact'); ?>...</option>
                                <?php foreach (get_wpem_constant_contact_list_dynamic_field($constant_contact_api_key, $constant_contact_list,$constant_contact_access_token) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">

                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wpem-constant-contact'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td >
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wpem-constant-contact'); ?></a>
                    </td>	                    	
                    <td colspan="2">
                        <input type="submit" class="button-primary wpem-field-maping-save" name="wp_event_constant_contact_organizer_matches_attribute" value="<?php esc_attr_e('Save', 'wpem-constant-contact'); ?>" />

                        <?php wp_nonce_field('event_constant_contact_organizer_matches_attribute'); ?>
                    </td>
                </tr>
            </tfoot>

        </table>
    </form>		
</div>