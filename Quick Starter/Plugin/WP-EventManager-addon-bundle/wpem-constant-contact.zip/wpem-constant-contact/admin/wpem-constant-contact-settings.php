<?php
/*
 * This file use for setings at admin site for event constant contact integration settings.
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * WPEM_CONSTANT_CONTACT_Integration_Settings class.
 */
class WPEM_CONSTANT_CONTACT_Settings {

    /**
     * __construct function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function __construct() {
        
    }

    /**
     * wpem_constant_contact_settings function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wpem_constant_contact_settings() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wpem_constant_contact_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'event_constant_contact_disconnect_settings')) { 
            $arr_constant_contact_lists = get_sync_fields_by_user($user_id, 'constant_contact_lists');

            if (!empty($arr_constant_contact_lists)) {
                foreach ($arr_constant_contact_lists as $constant_contact_list => $constant_contact_name) {
                    delete_wpem_constant_contact_settings_by_user('constant_contact_list_dynamic_field_' . $constant_contact_list);
                }
            }
            delete_wpem_constant_contact_settings_by_user('constant_contact_lists');
            delete_wpem_constant_contact_settings_by_user('constant_contact_settings');

            $arr_post_type = ['event_organizer', 'event_registration', 'event_guest_list'];
            wp_clear_scheduled_hook('auto_wpem_constant_contact_sync', array($arr_post_type));
        }

        if (!empty($_POST['wpem_constant_contact_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'event_constant_contact_settings')) {

            $constant_contact_api_key = !empty($_POST['constant_contact_api_key']) ? sanitize_text_field($_POST['constant_contact_api_key']) : '';
            $constant_contact_secret_key = !empty($_POST['constant_contact_secret_key']) ? sanitize_text_field($_POST['constant_contact_secret_key']) : '';
            $constant_contact_access_token = "";
            $constant_contact_referesh_token = "";
            $constant_contact_list = !empty($_POST['constant_contact_list']) ? sanitize_text_field($_POST['constant_contact_list']) : '';
            $constant_contact_sync_type = !empty($_POST['constant_contact_sync_type']) ? sanitize_text_field($_POST['constant_contact_sync_type']) : 'auto';
            $constant_contact_sync_via = !empty($_POST['constant_contact_sync_via']) ? sanitize_text_field($_POST['constant_contact_sync_via']) : 'cron_job';
            $constant_contact_sync_schedule = !empty($_POST['constant_contact_sync_schedule']) ? sanitize_text_field($_POST['constant_contact_sync_schedule']) : 'weekly';

            $constant_contact_settings = [
                'constant_contact_api_key' => $constant_contact_api_key,
                'constant_contact_secret_key' => $constant_contact_secret_key,
                'constant_contact_access_token' => $constant_contact_access_token,
                'constant_contact_referesh_token' => $constant_contact_referesh_token,
                'constant_contact_list' => $constant_contact_list,
                'constant_contact_sync_type' => $constant_contact_sync_type,
                'constant_contact_sync_schedule' => $constant_contact_sync_schedule,
                'constant_contact_sync_via' => $constant_contact_sync_via,
            ];

           
            update_wpem_constant_contact_settings_by_user('constant_contact_settings', $constant_contact_settings);
            
            $arr_post_type = ['event_organizer', 'event_registration', 'event_guest_list'];
            wp_clear_scheduled_hook('auto_wpem_constant_contact_sync', array($arr_post_type));

            if ($constant_contact_sync_type == 'auto' && $constant_contact_sync_via == 'cron_job') {
                switch ($constant_contact_sync_schedule) {
                    case '5min':
                        $next = strtotime('+5 minutes');
                        break;
                    case 'daily':
                        $next = strtotime('+1 day');
                        break;
                    case 'weekly':
                        $next = strtotime('+1 week');
                        break;
                    case 'monthly':
                        $next = strtotime('+1 month');
                        break;
                    case 'yearly':
                        $next = strtotime('+1 year');
                        break;
                    default:
                        $next = strtotime('+1 week');
                        break;
                }

                // Create cron
                wp_schedule_event($next, $constant_contact_sync_schedule, 'auto_wpem_constant_contact_sync', array($arr_post_type));
            }
            $result = check_wpem_constant_contact_key($constant_contact_api_key);
           $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
 
            $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            update_option('wpem_constant_contact_temp_redirect_url', $url);
            update_option('wpem_constant_contact_code', 'yes');

            wp_redirect($result);
        }

        $constant_contact_settings = get_wpem_constant_contact_settings_by_user();

        $constant_contact_api_key = isset($constant_contact_settings['constant_contact_api_key']) ? $constant_contact_settings['constant_contact_api_key'] : '';
        $constant_contact_secret_key = isset($constant_contact_settings['constant_contact_secret_key']) ? $constant_contact_settings['constant_contact_secret_key'] : '';
        $constant_contact_access_token = isset($constant_contact_settings['constant_contact_access_token']) ? $constant_contact_settings['constant_contact_access_token'] : '';
        $constant_contact_referesh_token = isset($constant_contact_settings['constant_contact_referesh_token']) ? $constant_contact_settings['constant_contact_referesh_token'] : '';
        $constant_contact_list = isset($constant_contact_settings['constant_contact_list']) ? $constant_contact_settings['constant_contact_list'] : '';
        $constant_contact_sync_type = isset($constant_contact_settings['constant_contact_sync_type']) && !empty($constant_contact_settings['constant_contact_sync_type']) ? $constant_contact_settings['constant_contact_sync_type'] : 'auto';
        $constant_contact_sync_via = isset($constant_contact_settings['constant_contact_sync_via']) && !empty($constant_contact_settings['constant_contact_sync_via']) ? $constant_contact_settings['constant_contact_sync_via'] : 'cron_job';
        $constant_contact_sync_schedule = isset($constant_contact_settings['constant_contact_sync_schedule']) ? $constant_contact_settings['constant_contact_sync_schedule'] : '';

        $check_wpem_constant_contact_key = check_wpem_constant_contact_key($constant_contact_api_key);

        include('templates/constant-contact-settings.php');
    }
}