var AdminConstantContactIntegration = function () {

    return {

        init: function ()
        {
            jQuery('select#constant-contact-sync-type').on('change', AdminConstantContactIntegration.actions.syncType);
            jQuery('select#constant-contact-sync-via').on('change', AdminConstantContactIntegration.actions.syncVia);

            jQuery('body').on('click', '.wpem-constant-contact-organizer-matches-attribute .add-field', AdminConstantContactIntegration.actions.addFieldOrganization);
            jQuery('body').on('click', '.wpem-constant-contact-organizer-matches-attribute .delete-field', AdminConstantContactIntegration.actions.deleteFieldOrganization);

            jQuery('body').on('click', '.wpem-constant-contact-registration-matches-attribute .add-field', AdminConstantContactIntegration.actions.addFieldRegistration);
            jQuery('body').on('click', '.wpem-constant-contact-registration-matches-attribute .delete-field', AdminConstantContactIntegration.actions.deleteFieldRegistration);

            jQuery('body').on('click', '.wpem-constant-contact-guest-list-matches-attribute .add-field', AdminConstantContactIntegration.actions.addFieldGuest);
            jQuery('body').on('click', '.wpem-constant-contact-guest-list-matches-attribute .delete-field', AdminConstantContactIntegration.actions.deleteFieldGuest);

        },

        actions:
                {

                    /**
                     * syncType function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    syncType: function (e)
                    {

                        var constant_contact_sync_type = jQuery(e.target).val();
                        if (constant_contact_sync_type === 'auto')
                        {
                            jQuery('#constant-contact-sync-via').show();

                            var constant_contact_sync_via = jQuery('#constant-contact-sync-via').val();
                            if (constant_contact_sync_via == 'when_created')
                            {
                                jQuery('#constant_contact_sync_schedule').hide();
                            } else
                            {
                                jQuery('#constant_contact_sync_schedule').show();
                            }
                        } else
                        {
                            jQuery('#constant-contact-sync-via').hide();
                            jQuery('#constant_contact_sync_schedule').hide();
                        }
                    },

                    /**
                     * syncVia function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    syncVia: function (e)
                    {
                        var constant_contact_sync_via = jQuery(e.target).val();
                        if (constant_contact_sync_via == 'cron_job')
                        {
                            jQuery('#constant_contact_sync_schedule').show();
                        } else
                        {
                            jQuery('#constant_contact_sync_schedule').hide();
                        }
                    },

                    /**
                     * addFieldOrganization function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    addFieldOrganization: function (e)
                    {
                        //var html = jQuery(e.target).closest('tr').html();
                        var html = jQuery('.wpem-constant-contact-organizer-matches-attribute tbody tr').last().html();
                        html = html.replace('selected="selected"', '');
                        html = html.replace('selected="selected"', '');
                        jQuery('.wpem-constant-contact-organizer-matches-attribute tbody').append('<tr>' + html + '</tr>');
                    },

                    /**
                     * deleteFieldOrganization function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    deleteFieldOrganization: function (e)
                    {
                        jQuery(e.target).closest('tr').remove();
                    },

                    /**
                     * addFieldRegistration function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    addFieldRegistration: function (e)
                    {
                        //var html = jQuery(e.target).closest('tr').html();
                        var html = jQuery('.wpem-constant-contact-registration-matches-attribute tbody tr').last().html();
                        html = html.replace('selected="selected"', '');
                        html = html.replace('selected="selected"', '');
                        jQuery('.wpem-constant-contact-registration-matches-attribute tbody').append('<tr>' + html + '</tr>');
                    },

                    /**
                     * deleteFieldRegistration function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    deleteFieldRegistration: function (e)
                    {
                        jQuery(e.target).closest('tr').remove();
                    },

                    /**
                     * addFieldGuest function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    addFieldGuest: function (e)
                    {
                        //var html = jQuery(e.target).closest('tr').html();
                        var html = jQuery('.wpem-constant-contact-guest-list-matches-attribute tbody tr').last().html();
                        html = html.replace('selected="selected"', '');
                        html = html.replace('selected="selected"', '');
                        jQuery('.wpem-constant-contact-guest-list-matches-attribute tbody').append('<tr>' + html + '</tr>');
                    },

                    /**
                     * deleteFieldGuest function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    deleteFieldGuest: function (e)
                    {
                        jQuery(e.target).closest('tr').remove();
                    },

                } /* end of action */

    }; /* enf of return */

}; /* end of class */

AdminConstantContactIntegration = AdminConstantContactIntegration();

jQuery(document).ready(function ()
{
    AdminConstantContactIntegration.init();
});
