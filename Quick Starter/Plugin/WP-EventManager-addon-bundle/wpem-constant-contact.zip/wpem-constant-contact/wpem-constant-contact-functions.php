<?php
if (!function_exists('get_wpem_constant_contact_sync_type')) {

    /**
     * Event Constant Contact Sync Type
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_sync_type() {
        return apply_filters('constant_contact_sync_type', array(
            'auto' => __('Auto', 'wpem-constant-contact'),
            'manual' => __('Manual', 'wpem-constant-contact'),
        ));
    }

}

if (!function_exists('get_wpem_constant_contact_sync_schedule')) {

    /**
     * Event Constant Contact Sync Schedule
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_sync_schedule() {
        return apply_filters('constant_contact_sync_schedule', array(
            '5min' => __('5 Min', 'wpem-constant-contact'),
            'daily' => __('Daily', 'wpem-constant-contact'),
            'weekly' => __('Weekly', 'wpem-constant-contact'),
            'monthly' => __('Monthly', 'wpem-constant-contact'),
            'yearly' => __('Yearly', 'wpem-constant-contact'),
        ));
    }

}

if (!function_exists('get_wpem_constant_contact_sync_via')) {

    /**
     * Event Constant Contact Sync Type
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_sync_via() {
        return apply_filters('constant_contact_sync_via', array(
            'when_created' => __('When new created', 'wpem-constant-contact'),
            'cron_job' => __('Cron Job', 'wpem-constant-contact'),
        ));
    }

}

if (!function_exists('get_wpem_constant_contact_settings_by_user')) {

    /**
     * Get Constant Contact Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_settings_by_user() {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        $constant_contact_settings = [];

        if (current_user_can('manage_options')) {
            $constant_contact_settings = get_option('constant_contact_settings');
        } else {
            $constant_contact_settings = get_user_meta($user_id, 'constant_contact_settings', true);
        }

        return $constant_contact_settings;
    }

}

if (!function_exists('get_wpem_constant_contact_settings_by_user_id')) {

    /**
     * Get Constant Contact Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_settings_by_user_id($user_id = '') {

        $user_meta = get_userdata($user_id);

        $constant_contact_settings = [];

        if (isset($user_meta->roles) && in_array('administrator', $user_meta->roles)) {
            $constant_contact_settings = get_option('constant_contact_settings');
        } elseif (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $constant_contact_settings = get_option('constant_contact_settings');
        } else {
            $constant_contact_settings = get_user_meta($user_id, 'constant_contact_settings', true);
        }

        return $constant_contact_settings;
    }

}

if (!function_exists('update_wpem_constant_contact_settings_by_user')) {

    /**
     * update Constant Contact Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function update_wpem_constant_contact_settings_by_user($field_key = '', $field_value = '') {

        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        if (current_user_can('manage_options')) { 
            update_option($field_key, $field_value);
        } else { 
            update_user_meta($user_id, $field_key, $field_value);
        }
       
    }

}

if (!function_exists('delete_wpem_constant_contact_settings_by_user')) {

    /**
     * update Constant Contact Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function delete_wpem_constant_contact_settings_by_user($field_key = '') {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        if (current_user_can('manage_options')) {
            delete_option($field_key);
        } else {
            delete_user_meta($user_id, $field_key);
        }
    }

}

if (!function_exists('get_sync_fields_by_user')) {

    /**
     * Get Constant Contact Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sync_fields_by_user($user_id = '', $fields_key = '') {
        $sync_fields = [];

        $user_meta = get_userdata($user_id);

        if ((isset($user_meta->roles) && in_array('administrator', $user_meta->roles)) || current_user_can('manage_options')) {
            $sync_fields = get_option($fields_key);
        } else if (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $sync_fields = get_option($fields_key);
        } else {
            $sync_fields = get_user_meta($user_id, $fields_key, true);
        }

        return $sync_fields;
    }

}

if (!function_exists('get_wpem_constant_contact_sync_fields_by_user')) {

    /**
     * Get Constant Contact Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_sync_fields_by_user($user_id = '', $fields_key = '') {
        $constant_contact_sync_fields = [];

        $user_meta = get_userdata($user_id);

        if ((isset($user_meta->roles) && in_array('administrator', $user_meta->roles)) || current_user_can('manage_options')) {
            $constant_contact_sync_fields = get_option($fields_key);
        } else if (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $constant_contact_sync_fields = get_option($fields_key);
        } else {
            $constant_contact_sync_fields = get_user_meta($user_id, $fields_key, true);
        }

        return $constant_contact_sync_fields;
    }

}

if (!function_exists('wpem_constant_contact_request')) {

    /**
     * Constant Contact request
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function wpem_constant_contact_request($constant_contact_api_key = '', $end_point = '', $args = []) {

        $response_body = '';

        if ($constant_contact_api_key != '' && $end_point != '') {
            $url = 'https://api.cc.email/v3/' . $end_point;

            $response = wp_remote_post($url, $args);

            $result = json_decode(wp_remote_retrieve_body($response), true);
        }
        
        return $result;
    }

}

if (!function_exists('check_wpem_constant_contact_key')) {

    /**
     * Check constant contact key
     *
     * @access public
     * @param
     * @return bool
     * @since 1.0.0
     */
    function check_wpem_constant_contact_key($constant_contact_api_key = '') {

        $response_body = [];
        $authURL = '';

        if ($constant_contact_api_key != '') {
             $args = ['method' => 'GET', 'count' => '1', 'headers' => ['content-type' => 'application/json', 'api-key' => $constant_contact_api_key]];

            $redirectURI = home_url();
            $url = urlencode($redirectURI);
            $client_id = $constant_contact_api_key;
            $baseURL = "https://api.cc.email/v3/idfed";
            $authURL = $baseURL . "?client_id=".$client_id."&scope=contact_data&response_type=code" . "&redirect_uri=" . $url;
            $response = wp_remote_get($authURL);
            $result = json_decode(wp_remote_retrieve_body($response), true);

        }

        return $authURL;
    }

}

if (!function_exists('get_wpem_constant_contact_lists')) {

    /**
     * Get constant contact list
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_lists($constant_contact_api_key = '',$constant_contact_access_token = '') {

        $user_id = get_current_user_id();

        $arr_constant_contact_lists = get_sync_fields_by_user($user_id, 'constant_contact_lists');

        $arr_constant_contact_lists = [];

        if ($constant_contact_api_key != '') {
            $args = ['method' => 'GET',
                     'count' => '20',
                     'headers' => 
                        ['content-type' => 'application/json',
                         'api-key' => $constant_contact_api_key,
                         'Accept' => 'application/json',
                          'Content-Type' => 'application/json',
                          'Authorization' => 'Bearer '.$constant_contact_access_token
                        ]
                     ];

            $end_point = 'contact_lists/';

            $response_body = wpem_constant_contact_request($constant_contact_api_key, $end_point, $args);

            if (!empty($response_body['lists'])) {
                $arr_constant_contact_lists[] = __('Event based selection', 'wpem-constant-contact');

                foreach ($response_body['lists'] as $constant_contact_list) {
                    $arr_constant_contact_lists[$constant_contact_list['list_id']] = $constant_contact_list['name'];
                }
            }
        }

        update_wpem_constant_contact_settings_by_user('constant_contact_lists', $arr_constant_contact_lists);

        return $arr_constant_contact_lists;
    }

}

if (!function_exists('get_event_organization_form_field_lists')) {

    /**
     * Get event registration form fields
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_event_organization_form_field_lists() {

        // organizer fields
        $GLOBALS['event_manager']
                ->forms
                ->get_form('submit-organizer', array());
        $form_submit_organizer_instance = call_user_func(array(
            'WP_Event_Manager_Form_Submit_Organizer',
            'instance'
        ));
        $organizer_form_fields = $form_submit_organizer_instance->merge_with_custom_fields('frontend');

        $organizer_fields = $organizer_form_fields['organizer'];

        return $organizer_fields;
    }

}

if (!function_exists('get_wpem_constant_contact_list_static_field')) {

    /**
     * Event Constant Contact List Static Field
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_list_static_field() {
        $fields = array(
            'email_address' => array(
                'address' => __('Email', 'wpem-constant-contact'),
            ),
            'first_name' => __('First Name', 'wpem-constant-contact'),
            'last_name' => __('Last Name', 'wpem-constant-contact'),
        );

        $fields = apply_filters('constant_contact_list_static_field', $fields);

        return $fields;
    }

}

if (!function_exists('get_wpem_constant_contact_list_dynamic_field')) {

    /**
     * Event Constant Contact List dynamin Field
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_list_dynamic_field($constant_contact_api_key = '', $constant_contact_list = '',$constant_contact_access_token='') {
        $user_id = get_current_user_id();

        if ($constant_contact_api_key != '' && $constant_contact_list != '') { 
            $fields = get_sync_fields_by_user($user_id, 'constant_contact_list_dynamic_field_' . $constant_contact_list);
            if (empty($fields)) {
                
                $args = ['method' => 'GET',
                         'count' => '20',
                         'headers' => 
                            ['content-type' => 'application/json',
                             'api-key' => $constant_contact_api_key,
                             'Accept' => 'application/json',
                              'Content-Type' => 'application/json',
                              'Authorization' => 'Bearer '.$constant_contact_access_token
                            ]
                         ];

                $end_point = 'contact_lists/';

                $response_body = wpem_constant_contact_request($constant_contact_api_key, $end_point, $args);

                $fields = [
                    'email_address' => array(
                        'address' => __('Email', 'wpem-constant-contact'),
                    ),
                ];


                if (!empty($response_body['attributes'])) {
                    foreach ($response_body['attributes'] as $field) {

                        $fields[$field['tag']] = sprintf(__('%s', 'wpem-constant-contact'), $field['name']);
                    }
                }

                $fields['first_name'] = __('First Name', 'wpem-constant-contact');
                $fields['last_name'] = __('Last Name', 'wpem-constant-contact');


                update_wpem_constant_contact_settings_by_user('constant_contact_list_dynamic_field_' . $constant_contact_list, $fields);
            }
        } else {
            $fields = get_wpem_constant_contact_list_static_field();
        }

        $fields = apply_filters('constant_contact_list_dynamic_field', $fields);

        return $fields;
    }

}

if (!function_exists('get_wpem_constant_contact_field_static_format')) {

    /**
     * Constant Contact List static Field format
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_field_static_format() {
        return apply_filters('constant_contact_field_static_format', array(
          
            'email_address' => array(
                'address' => __('Email', 'wpem-constant-contact'),
            ),
            'first_name' => __('First Name', 'wpem-constant-contact'),
            'last_name' => __('Last Name', 'wpem-constant-contact'),
            'status' => __('Status', 'wpem-constant-contact'),

        ));
    }

}

if (!function_exists('get_wpem_constant_contact_field_dynamic_format')) {

    /**
     * Event Constant Contact List Field
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_constant_contact_field_dynamic_format($constant_contact_api_key = '', $constant_contact_list = '', $constant_contact_access_token = '') {
        if ($constant_contact_api_key != '' && $constant_contact_list != '') {
            $args = ['method' => 'GET',
                         'count' => '20',
                         'headers' => 
                            ['content-type' => 'application/json',
                            'api-key' => $constant_contact_api_key,
                            'Accept' => 'application/json',
                            'Content-Type' => 'application/json',
                            'Authorization' => 'Bearer '.$constant_contact_access_token
                            ]
                         ];

            $end_point = 'contact_lists/';

            $response_body = wpem_constant_contact_request($constant_contact_api_key, $end_point, $args);

            $fields = [
                'email_address' => array(
                    'address' => __('Email', 'wpem-constant-contact'),
                ),
                'first_name' => __('First Name', 'wpem-constant-contact'),
                'last_name' => __('Last Name', 'wpem-constant-contact'),
                'status' => __('Status', 'wpem-constant-contact'),

            ];

            if (!empty($response_body['attributes'])) {
                foreach ($response_body['attributes'] as $field) {
                    $fields['attributes'][$field['tag']] = __($field['name'], 'wpem-constant-contact');
                }
            }
        } else {
            $fields = get_wpem_constant_contact_field_static_format();
        }

        return $fields;
    }

}

if (!function_exists('get_default_wpem_constant_contact_registration_matches_attribute')) {

    /**
     * Default Constant Contact Registration Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_wpem_constant_contact_registration_matches_attribute() {
        $registration_constant_contact_field = [];

        $registration_form_field = get_event_registration_form_fields();

        foreach ($registration_form_field as $key => $field) {
            if (in_array('from_email', $field['rules'])) {
                $registration_constant_contact_field['address'] = $key;
            } else if (in_array('from_name', $field['rules'])) {
                $registration_constant_contact_field['first_name'] = $key;
            }
        }

        return $registration_constant_contact_field;
    }

}

if (!function_exists('get_default_wpem_constant_contact_organizer_matches_attribute')) {

    /**
     * Default Constant Contact Organizer Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_wpem_constant_contact_organizer_matches_attribute() {
        $organizer_constant_contact_field = [];

        $organizer_constant_contact_field['email_address'] = 'organizer_email';
        $organizer_constant_contact_field['first_name'] = 'organizer_name';

        return $organizer_constant_contact_field;
    }

}

if (!function_exists('get_event_by_user_id')) {

    /**
     * Get event by user id
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_event_by_user_id($user_id = '') {
        return get_posts(array(
            'posts_per_page' => - 1,
            'post_type' => 'event_listing',
            'post_status' => 'publish',
            'suppress_filters' => 'false',
            'author' => $user_id,
            'fields' => 'ids',
        ));
    }

}

if (!function_exists('get_registration_attendee_list')) {

    /**
     * Get event registration attendee list
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_registration_attendee_list($atts = [], $filters = []) {
        $user_id = get_current_user_id();

        extract($atts = shortcode_atts(array(
            'event_id' => '',
            'posts_per_page' => 20,
            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                ), $atts));

        $registration_constant_contact_field = get_wpem_constant_contact_sync_fields_by_user($user_id, 'registration_constant_contact_field');
        if (empty($registration_constant_contact_field)) {
            $registration_constant_contact_field = get_default_wpem_constant_contact_registration_matches_attribute();
        }

        $args = array(
            'post_type' => 'event_registration',
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'post_parent' => $event_id,
            'author' => $user_id,
            'meta_query' => ['relation' => 'AND',
            ]
        );

        if (isset($registration_constant_contact_field['email']) && !empty($registration_constant_contact_field['email'])) {
            $args['meta_query'][] = ['key' => $registration_constant_contact_field['email'], 'value' => '', 'compare' => '!='];
        }

        if (!empty($filters)) {
            foreach ($filters as $key => $value) {
                if ($key != '' && $value != '') {
                    $args['meta_query'][] = ['key' => $key, 'value' => $value, 'compare' => 'LIKE',];
                }
            }
        }

        $registrations = new WP_Query($args);

        return $registrations;
    }

}

if (!function_exists('get_guest_lists_guest_list')) {

    /**
     * Get event registration attendee list
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_guest_lists_guest_list($atts = [], $filters = []) {
        $user_id = get_current_user_id();

        extract($atts = shortcode_atts(array(
            'event_id' => '',
            'posts_per_page' => 20,
            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                ), $atts));

        $guest_list_constant_contact_field = get_wpem_constant_contact_sync_fields_by_user($user_id, 'guest_list_constant_contact_field');
        if (empty($guest_list_constant_contact_field)) {
            $guest_list_constant_contact_field = get_default_wpem_constant_contact_guest_list_matches_attribute();
        }

        $args = array(
            'post_type' => 'event_guests',
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'post_parent' => $event_id,
            'author' => $user_id,
            'meta_query' => [
                'relation' => 'AND',
            ]
        );

        if (isset($guest_list_constant_contact_field['email']) && !empty($guest_list_constant_contact_field['email'])) {
            $args['meta_query'][] = ['key' => $guest_list_constant_contact_field['email'], 'value' => '', 'compare' => '!='];
        }

        if (!empty($filters)) {
            foreach ($filters as $key => $value) {
                if ($key != '' && $value != '') {
                    $args['meta_query'][] = ['key' => $key, 'value' => $value, 'compare' => 'LIKE',];
                }
            }
        }

        $guests = new WP_Query($args);

        return $guests;
    }

}

if (!function_exists('sync_data_in_wpem_constant_contact_list')) {

    /**
     * Sync attendees in constant contact
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function sync_data_in_wpem_constant_contact_list($constant_contact_api_key = '', $constant_contact_list = '', $registration_constant_contact_field = [], $post_id = '',$constant_contact_access_token='') {
        $response_body = [];
        
        if ($constant_contact_api_key != '' && $constant_contact_list != '' && !empty($registration_constant_contact_field) && $post_id != '') {
            $params = [];
            $field_constant_contact = get_wpem_constant_contact_field_dynamic_format($constant_contact_api_key, $constant_contact_list,$constant_contact_access_token);
            foreach ($field_constant_contact as $field_name => $field_value) {
                if (is_array($field_value)) {
                    foreach ($field_value as $field_name2 => $field_value2) {
                        if (is_array($field_value2)) { 
                            foreach ($field_value2 as $field_name3 => $field_value3) {
                                if (array_key_exists($field_name3, $registration_constant_contact_field)) {
                                    $params[$field_name][$field_name2][$field_name3] = get_post_meta($post_id, $registration_constant_contact_field[$field_name3], true);
                                }
                            }
                        } else {
                            if (array_key_exists($field_name2, $registration_constant_contact_field)) {  
                                $params[$field_name][$field_name2] = get_post_meta($post_id, $registration_constant_contact_field[$field_name2], true);
                            }
                        }
                    }
                } else { 
                    if (array_key_exists($field_name, $registration_constant_contact_field)) {
                        $params[$field_name] = get_post_meta($post_id, $registration_constant_contact_field[$field_name], true);
                    }
                }
            }
            
            $params['status'] = 'subscribed';

            $params['create_source'] = 'Contact';

            $params['list_memberships'] = [$constant_contact_list];
            $args = [
                'method' => 'POST',
                'headers' => [
                    'Accept' => 'application/json',
                    'content-type' => 'application/json',
                    'api-key' => $constant_contact_api_key,
                    'Authorization' => 'Bearer '.$constant_contact_access_token
                ],
                'body' => json_encode($params)
            ];
            $end_point = '/contacts/';
            $response_body = wpem_constant_contact_request($constant_contact_api_key, $end_point, $args);
            
        }
        
  //       $previous = "javascript:history.go(-1)";
		// if(isset($_SERVER['HTTP_REFERER'])) {
		//     $previous = $_SERVER['HTTP_REFERER'];
		// }
		// if(isset($response_body[0]['error_key'])){
		// 	wp_redirect($previous);
		// 	exit();
		// }
        return $response_body;
    }

}

if (!function_exists('add_attendees_in_wpem_constant_contact_list')) {

    /**
     * Add attendees in constant contact
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function add_attendees_in_wpem_constant_contact_list($user_id = '', $arr_attendees_id = []) {
    	
        $response = [];

        if ($user_id != '' && !empty($arr_attendees_id)) {
            $constant_contact_settings = get_wpem_constant_contact_settings_by_user_id($user_id);

            $constant_contact_api_key = isset($constant_contact_settings['constant_contact_api_key']) ? $constant_contact_settings['constant_contact_api_key'] : '';
            $constant_contact_access_token = isset($constant_contact_settings['constant_contact_access_token']) ? $constant_contact_settings['constant_contact_access_token'] : '';
            $constant_contact_list = isset($constant_contact_settings['constant_contact_list']) ? $constant_contact_settings['constant_contact_list'] : 0;

            $registration_field = get_sync_fields_by_user($user_id, 'registration_field');

            $registration_constant_contact_field = get_wpem_constant_contact_sync_fields_by_user($user_id, 'registration_constant_contact_field');

            if (empty($registration_constant_contact_field)) {
                $registration_constant_contact_field = get_default_wpem_constant_contact_registration_matches_attribute();
            }

            foreach ($arr_attendees_id as $attendees_id) {
                $_is_constant_contact_sync = get_post_meta($attendees_id, '_is_constant_contact_sync', true);

                $attendees = get_post($attendees_id);
                if (!empty($attendees)) { 
                    if (isset($constant_contact_settings['constant_contact_list']) && $constant_contact_settings['constant_contact_list'] == false) {
                        $event_id = $attendees->post_parent;
                        $event_constant_contact_list = get_post_meta($event_id, 'constant_contact_list', true);
                        if ($event_constant_contact_list == false) {
                            $response['message'] = __('Synchronization disabled for this event.', 'wpem-constant-contact');
                            continue;
                        }

                        if (!empty($event_constant_contact_list)) {
                            $constant_contact_list = $event_constant_contact_list;
                        }
                    }
                }

                if ($_is_constant_contact_sync != 'subscribed') {

                    $result = sync_data_in_wpem_constant_contact_list($constant_contact_api_key, $constant_contact_list, $registration_constant_contact_field, $attendees_id,$constant_contact_access_token);
                    
                    if (isset($result['contact_id']) && $result['contact_id'] != '') {
                        update_post_meta($attendees_id, '_is_constant_contact_sync', 'subscribed');
                    }
                    if (isset($result['0']['error_key']) && ($result['0']['error_key'] == 'contacts.api.conflict')) {
                       
                        $response['code'] = 200;
                        $response['message'] = __('The contact already exists.', 'wpem-constant-contact');
                    }
                    else if (isset($result['code']) && ($result['code'] == 'duplicate_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else if (isset($result['code']) && ($result['code'] == 'invalid_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else {
                        $response['code'] = 200;
                        $response['message'] = __('Subscribed', 'wpem-constant-contact');
                    }
                } else {
                    $response['code'] = 400;
                    $response['message'] = __('The contact already exists.', 'wpem-constant-contact');
                }
            }
        }

        return $response;
    }

}

if (!function_exists('add_guests_in_wpem_constant_contact_list')) {

    /**
     * Add guests in constant contact
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function add_guests_in_wpem_constant_contact_list($user_id = '', $arr_guests_id = []) {
        
        $response = [];
        if ($user_id != '' && !empty($arr_guests_id)) {

            $constant_contact_settings = get_wpem_constant_contact_settings_by_user_id($user_id);

            $constant_contact_api_key = isset($constant_contact_settings['constant_contact_api_key']) ? $constant_contact_settings['constant_contact_api_key'] : '';
            $constant_contact_access_token = isset($constant_contact_settings['constant_contact_access_token']) ? $constant_contact_settings['constant_contact_access_token'] : '';
            $constant_contact_list = isset($constant_contact_settings['constant_contact_list']) ? $constant_contact_settings['constant_contact_list'] : 0;

            $guest_list_field = get_sync_fields_by_user($user_id, 'guest_list_field');
            $guest_list_constant_contact_field = get_wpem_constant_contact_sync_fields_by_user($user_id, 'guest_list_constant_contact_field');

            if (empty($guest_list_constant_contact_field)) { 
                $guest_list_constant_contact_field = get_default_wpem_constant_contact_guest_list_matches_attribute();
            }

            foreach ($arr_guests_id as $guest_id) { 
                $_is_constant_contact_sync = get_post_meta($guest_id, '_is_constant_contact_sync', true);
                $guest = get_post($guest_id);
                if (!empty($guest)) {
                    if (isset($constant_contact_settings['constant_contact_list']) && $constant_contact_settings['constant_contact_list'] == false) {
                        $event_id = $guest->post_parent;
                        $event_constant_contact_list = get_post_meta($event_id, 'constant_contact_list', true);

                        if ($event_constant_contact_list == false) {
                            $response['message'] = __('Synchronization disabled for this event.', 'wpem-constant-contact');
                            continue;
                        }

                        if (!empty($event_constant_contact_list)) {
                            $constant_contact_list = $event_constant_contact_list;
                        }
                    }
                    
                }
                
                if ($_is_constant_contact_sync != 'subscribed') {

                    $result = sync_data_in_wpem_constant_contact_list($constant_contact_api_key, $constant_contact_list, $guest_list_constant_contact_field, $guest_id,$constant_contact_access_token);
                    
                    if (isset($result['contact_id']) && $result['contact_id'] != '') {
                        update_post_meta($guest_id, '_is_constant_contact_sync', 'subscribed');
                    }
                    if (isset($result['0']['error_key']) && ($result['0']['error_key'] == 'contacts.api.conflict')) {
                       
                        $response['code'] = 200;
                        $response['message'] = __('The contact already exists.', 'wpem-constant-contact');
                    }
                    else if (isset($result['code']) && ($result['code'] == 'duplicate_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else if (isset($result['code']) && ($result['code'] == 'invalid_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else {
                        $response['code'] = 200;
                        $response['message'] = __('Subscribed', 'wpem-constant-contact');
                    }
                } else { 
                    $response['code'] = 200;
                    $response['message'] = __('The contact already exists.', 'wpem-constant-contact');
                }
            }
        }
        return $response;
    }

}

if (!function_exists('sync_data_in_wpem_constant_contact_list_2')) {

    /**
     * Sync attendees in constant contact
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function sync_data_in_wpem_constant_contact_list_2($constant_contact_api_key = '', $constant_contact_list = '', $registration_constant_contact_field = [], $data = [],$constant_contact_access_token ='') {
        $response_body = [];

        if ($constant_contact_api_key != '' && $constant_contact_list != '' && !empty($registration_constant_contact_field) && $data != '') {
            $params = [];
            $field_constant_contact = get_wpem_constant_contact_field_dynamic_format($constant_contact_api_key, $constant_contact_list,$constant_contact_access_token);

            foreach ($field_constant_contact as $field_name => $field_value) {
                if (is_array($field_value)) {
                    foreach ($field_value as $field_name2 => $field_value2) {
                        if (is_array($field_value2)) {
                            foreach ($field_value2 as $field_name3 => $field_value3) {
                                if (array_key_exists($field_name3, $registration_constant_contact_field)) {
                                    $params[$field_name][$field_name2][$field_name3] = $data[$registration_constant_contact_field[$field_name3]];
                                }
                            }
                        } else {
                            if (array_key_exists($field_name2, $registration_constant_contact_field)) {
                                $vdata = isset($data[$registration_constant_contact_field[$field_name2]]) ? $data[$registration_constant_contact_field[$field_name2]] : '' ;
                                $params[$field_name][$field_name2] = $vdata;
                            }
                        }
                    }
                } else {
                    if (array_key_exists($field_name, $registration_constant_contact_field)) {
                        $params[$field_name] = $data[$registration_constant_contact_field[$field_name]];
                    }
                }
            }

            $params['status'] = 'subscribed';

            $params['create_source'] = 'Contact';

            $params['list_memberships'] = [$constant_contact_list];

            $args = [
                'method' => 'POST',
                'headers' => [
                    'Accept' => 'application/json',
                    'content-type' => 'application/json',
                    'api-key' => $constant_contact_api_key,
                    'Authorization' => 'Bearer '.$constant_contact_access_token
                ],
                'body' => json_encode($params)
            ];
            $end_point = '/contacts/';
            $response_body = wpem_constant_contact_request($constant_contact_api_key, $end_point, $args);

        }

        return $response_body;
    }

}

/**
 * add constant contact cron schedules
 *
 * @access public
 * @param
 * @return array
 * @since 1.0.0
 */
add_filter('cron_schedules', 'wpem_constant_contact_cron_schedules');

function wpem_constant_contact_cron_schedules($schedules) {
    if (!isset($schedules["5min"])) {
        $schedules["5min"] = array(
            'interval' => 5 * 60,
            'display' => __('5 Min', 'wpem-constant-contact')
        );
    }
    if (!isset($schedules["weekly"])) {
        $schedules["weekly"] = array(
            'interval' => 60 * 60 * 24 * 7,
            'display' => __('Once Weekly', 'wpem-constant-contact')
        );
    }
    if (!isset($schedules["monthly"])) {
        $schedules["monthly"] = array(
            'interval' => 60 * 60 * 24 * 30,
            'display' => __('Once Monthly', 'wpem-constant-contact')
        );
    }
    if (!isset($schedules["yearly"])) {
        $schedules["yearly"] = array(
            'interval' => 60 * 60 * 24 * 365,
            'display' => __('Once Yearly', 'wpem-constant-contact')
        );
    }
    return $schedules;
}

if (!function_exists('get_default_wpem_constant_contact_guest_list_matches_attribute')) {

    /**
     * Default Constant Contact guest_list Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_wpem_constant_contact_guest_list_matches_attribute() {
        $guest_list_constant_contact_field = [];
        $guest_list_form_field = get_event_guests_form_fields();
        foreach ($guest_list_form_field as $key => $field) {
            if (in_array('from_email', $field['rules'])) {
                $guest_list_constant_contact_field['address'] = $key;
            } else if (in_array('from_name', $field['rules'])) {
                $guest_list_constant_contact_field['first_name'] = $key;
            }
        }

        return $guest_list_constant_contact_field;
    }

}

if (!function_exists('get_default_wpem_constant_contact_contact_organizer_matches_attribute')) {

    /**
     * Default Constant Contact contact_organizer Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_wpem_constant_contact_contact_organizer_matches_attribute() {
        $guest_list_constant_contact_field = [];

        $guest_list_form_field = get_contact_organizer_form_fields();

        foreach ($guest_list_form_field as $key => $field) {
            if (isset($field['rules']) && in_array('from_email', $field['rules'])) {
                $guest_list_constant_contact_field['address'] = $key;
            } else if (isset($field['rules']) && in_array('from_name', $field['rules'])) {
                $guest_list_constant_contact_field['first_name'] = $key;
            }
        }

        return $guest_list_constant_contact_field;
    }

}

/**
 * auto_wpem_constant_contact_sync_callback function.
 *
 * @access public
 * @param mixed $arr_post_type
 * @return void
 * @since 1.0.0
 */
function auto_wpem_constant_contact_sync_callback($arr_post_type = []) {
    $args = array(
        'post_type' => $arr_post_type,
        'posts_per_page' => - 1,
    );

    $result = new WP_Query($args);
    $response = [];

    if ($result->found_posts > 0) {
        $constant_contact_api_key = get_option('constant_contact_settings')['constant_contact_api_key'];
        $constant_contact_access_token = get_option('constant_contact_settings')['constant_contact_access_token'];
        $constant_contact_list = get_option('constant_contact_settings')['constant_contact_list'];
        $constant_contact_sync_type = get_option('constant_contact_settings')['constant_contact_sync_type'];

        $organizer_constant_contact_field = get_option('organizer_constant_contact_field');
        $registration_constant_contact_field = get_option('registration_constant_contact_field');
        $guest_list_constant_contact_field = get_option('guest_list_constant_contact_field');


        foreach ($result->posts as $result) {

            if (isset(get_option('constant_contact_settings')['constant_contact_list']) && get_option('constant_contact_settings')['constant_contact_list'] == false) {
                $event_id = $result->post_parent;
                $event_constant_contact_list = get_post_meta($event_id, 'constant_contact_list', true);
                if ($event_constant_contact_list == false) {
                    $response['message'] = __('Synchronization disabled for this event.', 'wpem-constant-contact');
                    continue;
                }

                if (!empty($event_constant_contact_list)) {
                    $constant_contact_list = $event_constant_contact_list;
                }
            }

            if ($result->post_type == 'event_organizer') {
                $constant_contact_sync_field = $organizer_constant_contact_field;

                if (empty($constant_contact_sync_field)) {
                    $constant_contact_sync_field = get_default_wpem_constant_contact_organizer_matches_attribute();
                }

            } else if ($result->post_type == 'event_registration') {

                $constant_contact_sync_field = $registration_constant_contact_field;

                if (empty($constant_contact_sync_field)) {
                    $constant_contact_sync_field = get_default_wpem_constant_contact_registration_matches_attribute();
                }
            } else if ($result->post_type == 'event_guests') {

                $constant_contact_sync_field = $guest_list_constant_contact_field;

                if (empty($constant_contact_sync_field)) {
                    $constant_contact_sync_field = get_default_wpem_constant_contact_guest_list_matches_attribute();
                }
            }

            $results = sync_data_in_wpem_constant_contact_list($constant_contact_api_key, $constant_contact_list, $constant_contact_sync_field, $result->ID,$constant_contact_access_token);
            if (isset($results['contact_id']) && $results['contact_id'] != '') {
                update_post_meta($result->ID, '_is_constant_contact_sync', 'subscribed');
            }
        }
    }
    wp_reset_postdata();
}
function wpem_constant_contact_curl_setup($base,$url,$clientId,$clientSecret){

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);

    // Set authorization header
    // Make string of "API_KEY:SECRET"
    $auth = $clientId . ':' . $clientSecret;
    // Base64 encode it
    $credentials = base64_encode($auth);
    // Create and set the Authorization header to use the encoded credentials
    $authorization = 'Authorization: Basic ' . $credentials;
    curl_setopt($ch, CURLOPT_HTTPHEADER, array($authorization));

    // Set method and to expect response
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Make the call
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
function get_wpem_constant_contact_accessToken($redirectURI, $clientId, $clientSecret, $code) {
    

    // Define base URL
    $base = 'https://idfed.constantcontact.com/as/token.oauth2';

    // Create full request URL
    $url = $base . '?code=' . $code . '&redirect_uri=' . $redirectURI . '&grant_type=authorization_code&scope=contact_data';

    // Use cURL to get access token and refresh token
    
    $result = wpem_constant_contact_curl_setup($base,$url,$clientId,$clientSecret);
    
    $a = json_decode($result, true);
    
    $access_token = isset($a['access_token']) ? $a['access_token'] : '';
    $refresh_token = isset($a['refresh_token']) ? $a['refresh_token'] : '';
    $token_type = isset($a['token_type']) ? $a['token_type'] : '';

    // save into db
    $user_id = get_current_user_id();
    $get_db_data = get_sync_fields_by_user($user_id,'constant_contact_settings');


    $get_db_data['constant_contact_access_token'] = $access_token;
    $get_db_data['constant_contact_referesh_token'] = $refresh_token;


    update_wpem_constant_contact_settings_by_user('constant_contact_settings', $get_db_data);

    wpem_constant_contact_refreshToken($refresh_token,$clientId,$clientSecret);
  
    return $result;

}
function wpem_constant_contact_refreshToken($refreshToken, $clientId, $clientSecret) {
    
    // Define base URL
    $base = 'https://idfed.constantcontact.com/as/token.oauth2';

    // Create full request URL
    $url = $base . '?refresh_token=' . $refreshToken . '&grant_type=refresh_token';

    // Use cURL to get a new access token and refresh token
    $result = wpem_constant_contact_curl_setup($base,$url,$clientId,$clientSecret);
    
    $a = json_decode($result, true);
    $access_token =  isset($a['access_token']) ? $a['access_token'] : '';
    $refresh_token = isset($a['refresh_token']) ? $a['refresh_token'] : '';
    $token_type = isset($a['token_type']) ? $a['token_type'] : '';
   

    $user_id = get_current_user_id();
    $get_db_data = get_sync_fields_by_user($user_id,'constant_contact_settings');

    $get_db_data['constant_contact_access_token'] = $access_token;
    $get_db_data['constant_contact_referesh_token'] = $refresh_token;

    update_wpem_constant_contact_settings_by_user('constant_contact_settings', $get_db_data);
    $constant_contact_api_key = $get_db_data['constant_contact_api_key'];
    
    get_wpem_constant_contact_lists($constant_contact_api_key,$access_token);
    
     $url = get_option('wpem_constant_contact_temp_redirect_url');
     wp_safe_redirect($url);
     exit();
   
}

add_filter( 'cron_schedules', 'schedules_wpem_constant_contact_cron' );
function schedules_wpem_constant_contact_cron( $schedules ) {
    $schedules['every_two'] = array(
            'interval'  => 120*60,
            'display'   => __( 'Every 2 hours', 'textdomain' )
    );
    return $schedules;
}

// Schedule an action if it's not already scheduled
if ( ! wp_next_scheduled( 'schedules_wpem_constant_contact_cron' ) ) {
    wp_schedule_event( time(), 'every_two', 'schedules_wpem_constant_contact_cron' );
}

// Hook into that action that'll fire every one minutes
add_action( 'schedules_wpem_constant_contact_cron', 'wpem_constant_contact_refreshToken_cron' );


function wpem_constant_contact_refreshToken_cron(){
       
    $user_id = '1';

    $arr_constant_contact_lists = get_sync_fields_by_user($user_id, 'constant_contact_settings');

        $constant_contact_api_key = $arr_constant_contact_lists['constant_contact_api_key'];
        $constant_contact_secret_key = $arr_constant_contact_lists['constant_contact_secret_key'];
        $constant_contact_referesh_token = $arr_constant_contact_lists['constant_contact_referesh_token'];

    $refreshToken = $constant_contact_referesh_token ;
    $clientId = $constant_contact_api_key;
    $clientSecret = $constant_contact_secret_key;

    // Define base URL
    $base = 'https://idfed.constantcontact.com/as/token.oauth2';

    // Create full request URL
    $url = $base . '?refresh_token=' . $refreshToken . '&grant_type=refresh_token';

    $result = wpem_constant_contact_curl_setup($base,$url,$clientId,$clientSecret);

    $a = json_decode($result, true);
    $access_token =  isset($a['access_token']) ? $a['access_token'] : '';
    $refresh_token = isset($a['refresh_token']) ? $a['refresh_token'] : '';
    $token_type = isset($a['token_type']) ? $a['token_type'] : '';
   

    $user_id = get_current_user_id();
    $get_db_data = get_sync_fields_by_user($user_id,'constant_contact_settings');


    $get_db_data['constant_contact_access_token'] = $access_token;
    $get_db_data['constant_contact_referesh_token'] = $refresh_token;      

    update_wpem_constant_contact_settings_by_user('constant_contact_settings', $get_db_data);
    
    return $result;
}
