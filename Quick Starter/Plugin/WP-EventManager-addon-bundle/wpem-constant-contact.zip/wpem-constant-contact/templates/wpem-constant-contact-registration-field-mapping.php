<div class="wpem-main wpem-constant-contact-matches-attribute event-constant-contact-matches-attribute">
    <div class="wpem-constant-contact-matches-attribute-header wpem-form-wrapper">
        <h3 class="wpem-form-title wpem-heading-text"><?php _e('Registration Field Mapping with Constant Contact', 'wpem-constant-contact'); ?></h3>
    </div>

    <div class="wpem-constant-contact-matches-attribute-body">

        <?php if ($field_not_mapping_message != '') : ?>
            <p class="event-manager-message wpem-alert wpem-alert-warning"><?php _e($field_not_mapping_message); ?></p>
        <?php endif; ?>

        <form class="wpem-form-wrapper" method="POST">
            <div class="wpem-mc-block-editor-wrapper">
                <table class="wpem-main wpem-mc-block-editor-table">
                    <thead>
                        <tr>
                            <th class="wpem-mc-col-name"> <?php _e('Registration Field', 'wpem-constant-contact'); ?>
                            </th>
                            <th class="wpem-mc-col-name"> <?php _e('Constant Contact Field', 'wpem-constant-contact'); ?>
                            </th>
                            <th class="wpem-mc-block-editor-act">&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody class="wpem-mc-block-editor-table-body">
                        <?php if (!empty($registration_constant_contact_field)) : ?>
                            <?php foreach ($registration_constant_contact_field as $sync_field => $form_field) : ?>
                                <tr>
                                    <td>
                                        <div class="wpem-form-group">
                                            <select name="registration_field[]" class="registration-field">
                                                <option value=""><?php _e('Select field', 'wpem-constant-contact'); ?>...</option>
                                                <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="wpem-form-group">
                                            <select name="registration_constant_contact_field[]" class="constant-contact-field">
                                                <option value=""><?php _e('Select field', 'wpem-constant-contact'); ?>...</option>
                                                <?php foreach (get_wpem_constant_contact_list_dynamic_field($constant_contact_api_key, $constant_contact_list,$constant_contact_access_token) as $name => $label) :
                                                    if($name == 'email_address'){
                                                        foreach($label as $key => $value) {
                                                              $name = $key;
                                                              $label = $value;
                                                            }

                                                    }
                                                 ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </td>
                                    <td class="wpem-dboard-event-act-btn">
                                        <div class="wpem-form-group">
                                            <a href="javascript:void(0)" class="delete-field"></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>

                    </tbody>
                    <tfoot>
                        <tr>
                            <td class="wpem-form-group" colspan="3">

                                <button type="button" class="wpem-theme-button add-field" value="<?php esc_attr_e('Add Field', 'wpem-constant-contact'); ?>"><?php esc_attr_e('Add Field', 'wpem-constant-contact'); ?></button>

                                <button type="submit" name="wp_event_manager_constant_contact_registration_matches_attribute" class="wpem-theme-button wpem-fr" value="<?php esc_attr_e('Save', 'wpem-constant-contact'); ?>"><?php esc_attr_e('Save', 'wpem-constant-contact'); ?></button>

                                <?php wp_nonce_field('event_manager_constant_contact_registration_matches_attribute'); ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </form>
    </div>
</div>