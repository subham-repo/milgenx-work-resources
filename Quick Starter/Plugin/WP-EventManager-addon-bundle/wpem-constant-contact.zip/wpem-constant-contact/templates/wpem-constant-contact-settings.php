<div id="wpem_constant_contact" class="wpem-constant-contact">

    <?php do_action('wpem_constant_contact_dashboard_before'); ?>

    <?php $check_wpem_constant_contact_key = check_wpem_constant_contact_key($constant_contact_api_key); ?>
    <?php $lists = get_wpem_constant_contact_lists($constant_contact_api_key,$constant_contact_access_token); ?>

    <?php if($constant_contact_api_key){
     if (empty($lists) ) { ?>

         <p class="event-manager-message wpem-alert wpem-alert-danger">
            <?php if(isset($check_wpem_zoho_crm_key->message)){
                echo $check_wpem_zoho_crm_key->message;
            }else{
                echo "Invalid crm details";
            }  ?>
        </p>

    <?php } } ?>

    <div class="wpem-main wpem-constant-contact-wrapper event-constant-contact">
        <div class="wpem-constant-contact-matches-attribute-header wpem-form-wrapper">
            <h3 class="wpem-form-title wpem-heading-text"><?php _e('Constant Contact Settings', 'wpem-constant-contact'); ?></h3>

            <?php
            if (isset($lists) && !empty($lists)) : ?>
                <form class="wpem-constant-contact-disconnect wpem-form-wrapper" method="POST">

                    <input type="hidden" name="action" value="show_constant_contact" />
                    <?php if (!empty($_GET['page_id'])) : ?>
                        <input type="hidden" name="page_id" value="<?php echo absint($_GET['page_id']); ?>" />
                    <?php endif; ?>

                    <button type="submit" name="wp_event_manager_constant_contact_disconnect" class="wpem-theme-button wpem-theme-button-disconnect" value="<?php esc_attr_e('Disconnect', 'wpem-constant-contact'); ?>"><?php esc_attr_e('Disconnect', 'wpem-constant-contact'); ?></button>

                    <?php wp_nonce_field('event_manager_constant_contact_disconnect'); ?>

                </form>
            <?php endif; ?>
        </div>
        <div class="wpem-constant-contact-body">
            <form class="wpem-constant-contact wpem-form-wrapper" method="POST">
                <div class="wpem-constant-contact-field">
                    <div class="wpem-row">

                        <?php 
                        $style = '';
                        if ($constant_contact_api_key != '') {
                            if (isset($lists) && empty($lists)) { 
                                $style = 'style="display: block;"';
                            } else {
                                $style = 'style="display: none;"';
                            }
                        }
                        ?>
                        <div class="wpem-col-md-6" <?php echo $style; ?>>
                            <div class="wpem-form-group">
                                <?php
                                $readonly = '';
                                if ($constant_contact_api_key != '') {
                                    if (isset($check_wpem_constant_contact_key['code']) && $check_wpem_constant_contact_key['code'] != "unauthorized") {
                                        $readonly = 'readonly';
                                    }
                                }
                                ?>
                                <input type="text" name="constant_contact_api_key" id="constant-contact-api-key" class="constant-contact-api-key" placeholder="<?php _e('Enter Constant Contact API Key', 'wpem-constant-contact'); ?>" value="<?php echo $constant_contact_api_key; ?>" <?php echo $readonly; ?> />
                                
                            </div>
                        </div>
                        <div class="wpem-col-md-6" <?php echo $style; ?>>
                            <div class="wpem-form-group">
                                <?php
                                $readonly = '';
                                if ($constant_contact_api_key != '') {
                                    if (isset($check_wpem_constant_contact_key['code']) && $check_wpem_constant_contact_key['code'] != "unauthorized") {
                                        $readonly = 'readonly';
                                    }
                                }
                                ?>
                                
                                <input type="text" name="constant_contact_secret_key" id="constant-contact-secret-key" class="constant-contact-secret-key" placeholder="<?php _e('Enter Constant Secret Key', 'wpem-constant-contact'); ?>" value="<?php echo $constant_contact_secret_key; ?>" <?php echo $readonly; ?> />
                            </div>
                        </div>

                        <?php if (isset($lists) && empty($lists) ) : ?>
                        <?php else : ?>
                            <?php if (!empty($constant_contact_api_key)) : ?>
                                <div class="wpem-col-md-6">
                                    <div class="wpem-form-group">
                                        <select name="constant_contact_list" class="constant-contact-list" >
                                            <?php foreach (get_wpem_constant_contact_lists($constant_contact_api_key,$constant_contact_access_token) as $id => $label) : ?>
                                                <option value="<?php echo esc_attr($id); ?>" <?php selected($constant_contact_list, $id); ?>><?php echo esc_html($label); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if (!empty($constant_contact_api_key)) : ?>
                                    <div class="wpem-col-md-6">
                                        <div class="wpem-form-group">
                                            <select required name="constant_contact_sync_type" class="constant-contact-sync-type" id="constant-contact-sync-type">
                                                <option value=""><?php _e('Select Constant Contact Sync Type', 'wpem-constant-contact'); ?>...</option>
                                                <?php foreach (get_wpem_constant_contact_sync_type() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($constant_contact_sync_type, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php
                                    $style = '';
                                    if ($constant_contact_sync_type == 'manual') {
                                        $style = 'style="display: none;"';
                                    }
                                    ?>
                                    <div class="wpem-col-md-6" id="constant_contact_sync_via" <?php echo $style; ?>>
                                        <div class="wpem-form-group">
                                            <select name="constant_contact_sync_via" class="constant-contact-sync-via" id="constant-contact-sync-via">
                                                <option value=""><?php _e('Select Constant Contact Sync Via', 'wpem-constant-contact'); ?>...</option>
                                                <?php foreach (get_wpem_constant_contact_sync_via() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($constant_contact_sync_via, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <?php
                                    $style = '';
                                    if ($constant_contact_sync_type == 'manual' || $constant_contact_sync_via == 'when_created') {
                                        $style = 'style="display: none;"';
                                    }
                                    ?>
                                    <div class="wpem-col-md-6" id="constant_contact_sync_schedule" <?php echo $style; ?>>
                                        <div class="wpem-form-group">
                                            <select name="constant_contact_sync_schedule" class="constant-contact-sync-schedule" id="constant-contact-sync-schedule">
                                                <option value=""><?php _e('Select Constant Contact Sync Schedule', 'wpem-constant-contact'); ?>...</option>
                                                <?php foreach (get_wpem_constant_contact_sync_schedule() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($constant_contact_sync_schedule, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                <?php endif; ?>
                            <?php endif; ?>

                        <?php endif; ?>

                        <div class="wpem-col-12">
                            <div class="wpem-form-group">
                                <input type="hidden" name="action" value="show_constant_contact" />
                                <button type="submit" name="wp_event_manager_constant_contact" class="wpem-theme-button" value="<?php esc_attr_e('Save Setting', 'wpem-constant-contact'); ?>"><?php esc_attr_e('Save Setting', 'wpem-constant-contact'); ?></button>

                                <?php wp_nonce_field('event_manager_constant_contact'); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php do_action('wpem_constant_contact_dashboard_after'); ?>
</div>