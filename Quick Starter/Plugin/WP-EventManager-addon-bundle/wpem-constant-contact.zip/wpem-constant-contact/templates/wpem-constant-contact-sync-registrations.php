<div id="wpem-constant-contact-sync-registrations" class="wpem-constant-contact-sync-registrations">
    
    <p class="event-manager-message wpem-alert wpem-alert-danger" style="display: none;">
        <?php _e('Please Select Attendees to sync.', 'wpem-constant-contact'); ?>
    </p>
    
    <div class="wpem-main wpem-constant-contact-sync-wrapper event-constant-contact-sync">
        <div class="wpem-constant-contact-sync-header wpem-form-wrapper">
            <h3 class="wpem-form-title wpem-heading-text"><?php _e('Sync Attendees', 'wpem-constant-contact'); ?></h3>
        </div>

        <div class="wpem-constant-contact-sync-body wpem-dashboard-main-header">

            <form method="GET" class="wpem-constant-contact-sync-list-filter wpem-form-wrapper">
                <div class="wpem-events-filter">
                    <div class="wpem-events-filter-block">
                        <div class="wpem-form-group">
                            <select name="event_id" id="event_id">
                                <option value=""><?php _e('Select Event', 'wpem'); ?></option>
                                <?php if (!empty($events)) : ?>
                                    <?php foreach ($events as $key => $event) : ?>
                                        <option value="<?php echo esc_html($event->ID); ?>" <?php selected($event_id, $event->ID); ?>><?php echo esc_html($event->post_title); ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="wpem-events-filter-block">
                        <div class="wpem-form-group">
                            <select name="sync_filter_field" class="registration-field">
                                <option value=""><?php _e('Select field', 'wpem-constant-contact'); ?>...</option>
                                <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_filter_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="wpem-events-filter-block">
                        <div class="wpem-form-group">
                            <input type="text" name="sync_filter_value" placeholder="<?php _e('Enter value', 'wpem-constant-contact'); ?>" value="<?php echo $sync_filter_value; ?>" />
                        </div>
                    </div>
                    <div class="wpem-events-filter-block wpem-events-filter-submit">
                        <div class="wpem-form-group">
                            <input type="hidden" name="action" value="wpem_constant_contact_sync_registrations" />

                            <button type="submit" class="wpem-theme-button" name="wpem_constant_contact_filter" value="<?php esc_attr_e('Filter', 'wpem-constant-contact'); ?>"><?php _e('Filter', 'wpem-constant-contact'); ?></button>
                        </div>
                    </div>
                </div>
            </form>

            <form method="post" class="wpem-constant-contact-sync-attendees">
                <div class="wpem-scrollable-table-block">
                    <table class="wpem-main">
                        <thead>
                            <tr>
                                <th class="wpem-heading-text">
                                    <input type="checkbox" id="all_select">
                                    <input type="hidden" name="attendees_ids" id="attendees_ids" value="">
                                </th>
                                <?php
                                $fields = get_wpem_constant_contact_list_dynamic_field($constant_contact_api_key, $constant_contact_list,$constant_contact_access_token);

                                foreach ($registration_constant_contact_field as $sync_field => $form_field) {
                                    if($sync_field == 'address'){
                                    echo '<th>' . $fields['email_address'][$sync_field] . '</th>';
                                    }else{
                                        echo '<th>' . $fields[$sync_field] . '</th>';
                                    }
                                }
                                ?>
                                <th class="wpem-heading-text"><?php _e('Constant Contact Sync', 'wpem-constant-contact'); ?></th>
                            </tr>
                        </thead>

                        <?php
                        if ($total_registrations > 0) {
                            foreach ($registrations as $registration) {
                                echo '<tr class="attendees-id-' . $registration->ID . '">';

                                echo '<td><input type="checkbox" class="attende-id" name="attendees_id[]" value="' . $registration->ID . '" ></td>';
                                foreach ($registration_constant_contact_field as $form_field) {
                                    $field_value = get_post_meta($registration->ID, $form_field, true);
                                    echo '<td data-title="">' . $field_value . '</td>';
                                }

                                $_is_constant_contact_sync = get_post_meta($registration->ID, "_is_constant_contact_sync", true);
                                if ($_is_constant_contact_sync == '') {
                                    $_is_constant_contact_sync = __('-', 'wpem-constant-contact');
                                }
                                echo '<td class="sync-status">' . $_is_constant_contact_sync . '</td>';

                                echo '</tr>';
                            }
                        } else {
                            echo '<tr>';
                            echo '<td colspan="' . count($registration_constant_contact_field) . '">' . __('No records found.', 'wpem-constant-contact') . '</td>';
                            echo '</tr>';
                        }
                        wp_reset_postdata();
                        ?>
                        <tfoot>
                            <?php $count = count($registration_constant_contact_field); ?>
                            <?php $count = $count + 2; ?>
                            <tr>
                                <td colspan="2">
                                    <input type="hidden" name="event_id" id="event_id" value="<?php echo absint($event_id); ?>" />
                                    <button type="button" class="wpem-theme-button sync-attendees-button" id="sync-attendees-button"><?php _e('Sync', 'wpem-constant-contact'); ?></button>
                                    <?php wp_nonce_field('event_manager_constant_contact_sync_attendees'); ?>
                                </td>
                                <td  colspan="<?php echo $count; ?>"></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </form>

            <?php
            get_event_manager_template(
                    'pagination.php',
                    array(
                        'max_num_pages' => $max_num_pages
                    )
            );
            ?>

            <?php wp_reset_postdata(); ?>
        </div>

    </div>

</div>