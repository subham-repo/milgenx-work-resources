<?php
/*
  Plugin Name: WP Event Manager - Constant Contact
  Plugin URI: http://www.wp-eventmanager.com/plugins/

  Description: The WP event manager Constant Contact  plugin helps you grow Constant Contact lists as it automates the Syncing process of the registered attendee data of your WordPress website in your Constant Contact list.
  Author: WP Event Manager
  Author URI: http://www.wp-eventmanager.com

  Text Domain: wpem-constant-contact
  Domain Path: /languages
  Version: 1.0.0
  Since: 1.0.0

  Requires WordPress Version at least: 4.1
  Copyright: 2019 WP Event Manager
  License: GNU General Public License v3.0
  License URI: http://www.gnu.org/licenses/gpl-3.0.html

 */

// Exit if accessed directly
ob_start();
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WPEM_Updater')) {
    include( 'autoupdater/wpem-updater.php' );
}

include_once(ABSPATH . 'wp-admin/includes/plugin.php');

function pre_check_before_installing_constant_contact() {
    /*
     * Check weather WP Event Manager is installed or not
     */
    if (!is_plugin_active('wp-event-manager/wp-event-manager.php')) {
        global $pagenow;
        if ($pagenow == 'plugins.php') {
            echo '<div id="error" class="error notice is-dismissible"><p>';
            echo __('WP Event Manager is require to use WP Event Manager - Constant Contact', 'wpem-constant-contact');
            echo '</p></div>';
        }
        return false;
    }
}

add_action('admin_notices', 'pre_check_before_installing_constant_contact');

/**
 * WPEM_Constant_Contact_Integration class.
 */
class WPEM_Constant_Contact extends WPEM_Updater {

    /**
     * The single instance of the class.
     *
     * @var self
     * @since  1.0
     */
    private static $_instance = null;

    /**
     * Main WP Event Manager Constant Contact Instance.
     *
     * Ensures only one instance of WP Event Manager Constant Contact is loaded or can be loaded.
     *
     * @since  1.0
     * @static
     * @see WPEM_Constant_Contact()
     * @return self Main instance.
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * __construct function.
     */
    public function __construct() {
        //if wp event manager not active return from the plugin
        if (!is_plugin_active('wp-event-manager/wp-event-manager.php'))
            return;

        // Define constants
        define('WPEM_CONSTANT_CONTACT_VERSION', '1.0.0');
        define('WPEM_CONSTANT_CONTACT_FILE', __FILE__);
        define('WPEM_CONSTANT_CONTACT_PLUGIN_DIR', untrailingslashit(plugin_dir_path(__FILE__)));
        define('WPEM_CONSTANT_CONTACT_PLUGIN_URL', untrailingslashit(plugins_url(basename(plugin_dir_path(__FILE__)), basename(__FILE__))));


        include( 'wpem-constant-contact-functions.php' );

        //includes
        
        include( 'includes/wpem-constant-contact-dashboard.php' );
        if (is_plugin_active('wp-event-manager-registrations/wp-event-manager-registrations.php')) {
            include( 'includes/wpem-constant-contact-registrations.php' );
        }
        if (is_plugin_active('wpem-guests/wpem-guests.php')) {
            include( 'includes/wpem-constant-contact-guests.php' );
        }
        if (is_plugin_active('wp-event-manager-contact-organizer/wp-event-manager-contact-organizer.php')) {
            include( 'includes/wpem-constant-contact-contact-organizer.php' );
        }

        if (is_admin()) {
            include( 'admin/wpem-constant-contact-admin.php' );
        }

        // admin cron
        add_action('auto_wpem_constant_contact_sync', 'auto_wpem_constant_contact_sync_callback');

        // Activation - works with symlinks
        register_activation_hook(basename(dirname(__FILE__)) . '/' . basename(__FILE__), array($this, 'activate'));

        // Add actions
        add_action('init', array($this, 'load_plugin_textdomain'), 12);

        add_action('init', array($this, 'get_wpem_constant_contact_token'), 12);
        
    }

    /**
     * activate function.
     *
     * @access public
     * @param 
     * @return 
     * @since 1.0
     */
    
    
    

    public function activate() {

        update_option('wpem_constant_contact_version', WPEM_CONSTANT_CONTACT_VERSION);
    }

    /**
     * Localisation
     * */
    public function load_plugin_textdomain() {
        $domain = 'wpem-constant-contact';
        $locale = apply_filters('plugin_locale', get_locale(), $domain);
        load_textdomain($domain, WP_LANG_DIR . "/wpem-constant-contact/" . $domain . "-" . $locale . ".mo");
        load_plugin_textdomain($domain, false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }

    public function get_wpem_constant_contact_token(){
        $option = get_option('wpem_constant_contact_code');
        
        if(isset($_GET['code']) && $option == 'yes'){ 
            $code = $_GET['code'];
            $redirectURI = home_url();
            $url = urlencode($redirectURI);

            $user_id = get_current_user_id();
            update_option('wpem_constant_contact_code','no');
            $arr_constant_contact_lists = get_sync_fields_by_user($user_id, 'constant_contact_settings');
            $constant_contact_api_key = $arr_constant_contact_lists['constant_contact_api_key'];
            $constant_contact_secret_key = $arr_constant_contact_lists['constant_contact_secret_key'];

            $clientId = $constant_contact_api_key;
            $clientSecret = $constant_contact_secret_key;
           
            $result = get_wpem_constant_contact_accessToken($redirectURI, $clientId, $clientSecret, $code);
            
            
        }
    }

}

/**
 * Main instance of WP Event Manager Constant Contact.
 *
 * Returns the main instance of WP Event Manager Constant Contact to prevent the need to use globals.
 *
 * @since  1.0
 * @return WPEM_Constant_Contact_
 */
function WPEM_Constant_Contact() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName
    return WPEM_Constant_Contact::instance();
}

$GLOBALS['wpem_constant_contact'] = WPEM_Constant_Contact();
