<?php

if(!function_exists( 'wpem_get_attendees_type' ))
{
	/**
	* wpem_get_attendees_type function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_attendees_type()
	{
		return apply_filters( 'wpem_attendees_type', array(
				'all'   => __( 'All Uniques Attendees', 'wpem-name-badges' ),
				'specific'  => __( 'Specific Attendees', 'wpem-name-badges' ),
				'ticket_type'  => __( 'Attendees by Ticket Type', 'wpem-name-badges' ),		
			) );
	}
}

if(!function_exists( 'wpem_get_ticket_type' ))
{
	/**
	* wpem_get_ticket_type function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_ticket_type()
	{
		if ( is_plugin_active( 'wp-event-manager-sell-tickets/wp-event-manager-sell-tickets.php' ) )
		{
			$ticket_type = array(
				'Paid'  	=> __( 'Paid Ticket', 'wpem-name-badges' ),
				'Free'  	=> __( 'Free Ticket', 'wpem-name-badges' ),
				'Donation'  => __( 'Donation Ticket', 'wpem-name-badges' ),		
			);
		}
		else
		{
			$ticket_type = get_event_registration_statuses();
		}
		
		return apply_filters( 'wpem_ticket_type', $ticket_type );
	}
}

if(!function_exists( 'wpem_get_sort_by' ))
{
	/**
	* wpem_get_sort_by function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_sort_by()
	{
		$fields = get_event_registration_form_fields();

		$arrField = [];
		foreach ( get_event_registration_form_fields() as $name => $field ){
			$arrField[$name] = $field['label'];
		}

		return apply_filters( 'wpem_sort_by', $arrField );
	}
}

if(!function_exists( 'wpem_get_badges_style' ))
{
	/**
	* wpem_get_badges_style function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_badges_style()
	{
		return apply_filters( 'wpem_badges_style', array(
				'avery_5361'   => __( 'Avery 5361 - Laminated ID Cards (2 x 3 1/4 inch) - Page Size 8.5"x11"', 'wpem-name-badges' ),
				'avery_5384'   => __( 'Avery 5384 - Clip Style Name Badges (3 x 4 inch) - Page Size 8.5"x11"', 'wpem-name-badges' ),
				'avery_5390'   => __( 'Avery 5390 - Name Badges Insert Refills (2 1/4 x 3 1/2 inch) - Page Size 8.5"x11"', 'wpem-name-badges' ),
				'avery_74459'   => __( 'Avery 74459 - Hanging Name Badges (3 x 4 inch) - Page Size 8.5"x11"', 'wpem-name-badges' ),
				'avery_74536'   => __( 'Avery 74536 - Clip Name Badges (3 x 4 inch) - Page Size 8.5"x11"', 'wpem-name-badges' ),
				'avery_74540'   => __( 'Avery 74540 - Pin Name Badges (3 x 4 inch) - Page Size 8.5"x11"', 'wpem-name-badges' ),
				'avery_74541'   => __( 'Avery 74541 - Clip Name Badges (3 x 4 inch) - Page Size 8.5"x11"', 'wpem-name-badges' ),
				'avery_8395'   => __( 'Avery 8395 - Self Adhesive Name Badges (2 1/3 x 3 3/8 inch) - Page Size 8.5"x11"', 'wpem-name-badges' ),
				'avery_L7418'   => __( 'Avery L7418 - Name Badges (86 x 55 mm) - Page Size A4 ', 'wpem-name-badges' ),
				'avery_5392_5393'   => __( '6 badges per sheet 4in x 3in (Avery 5392/5393 Letter size)', 'wpem-name-badges' ),
				'avery_5163_8163'   => __( '10 badges per sheet 4.025in x 2in (Avery 5163/8163 Letter size)', 'wpem-name-badges' ),
				'microsoft_w233'   => __( '12 badges per sheet 63.5mm x 72mm (Microsoft W233 A4 size)', 'wpem-name-badges' ),
				'microsoft_w121'   => __( '16 badges per sheet 99mm x 33.9mm (Microsoft W121 A4 size)', 'wpem-name-badges' ),
				'microsoft_w110'   => __( '24 badges per sheet 35mm x 70mm (Microsoft W110 A4 size)', 'wpem-name-badges' ),
				'avery_5160_8160'   => __( '30 badges per sheet 2.625in x 1in (Avery 5160/8160 Letter size)', 'wpem-name-badges' ),
				'microsoft_w239'   => __( '39 badges per sheet 66mm x 20.60mm (Microsoft W239 A4 size)', 'wpem-name-badges' ),
				'microsoft_w115'   => __( '45 badges per sheet 38.5mm x 29.9mm (Microsoft W115 A4 size)', 'wpem-name-badges' ),
			) );
	}
}

if(!function_exists( 'wpem_get_on_demand_label' ))
{
	/**
	* wpem_get_on_demand_label function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_on_demand_label()
	{
		return apply_filters( 'wpem_on_demand_label', array(
				'dymo_450'   => __( 'Dymo Label/Writer 450', 'wpem-name-badges' ),
			) );
	}
}

if(!function_exists( 'wpem_get_on_demand_label_size' ))
{
	/**
	* wpem_get_on_demand_label_size function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_on_demand_label_size()
	{
		return apply_filters( 'wpem_on_demand_label_size', array(
				'dymo_450'  => array( 
									'lw_address_labels' =>  __( 'LW Address Labels 1 1/8" x 3 1/2"', 'wpem-name-badges' ),
									'lw_file_folder_labels' =>  __( 'LW File Folder Labels, 1-up 9/16" x 3 7/16"', 'wpem-name-badges' ),
									'lw_multi_purpose_labels' =>  __( 'LW Multi-Purpose Labels, Small 1" x 2 1/8"', 'wpem-name-badges' ),
								),
			) );
	}
}

if(!function_exists( 'wpem_get_registration_form_fields' ))
{
	/**
	* wpem_get_registration_form_fields function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_registration_form_fields()
	{
		$fields = get_event_registration_form_fields();

		$fields['barcode'] = [
			'label' => __( 'Barcode', 'wpem-name-badges' ),
		];

		return apply_filters( 'wpem_registration_form_fields', $fields);
	}
}

if(!function_exists( 'wpem_get_font_size' ))
{
	/**
	* wpem_get_font_size function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_font_size()
	{
		$max_size = apply_filters( 'wpem_font_max_size', 70);
		$size_type = apply_filters( 'wpem_font_size_type', 'pt');

		$arrSize = [];
		for($i=1; $i<= $max_size; $i++)
		{
			$arrSize[$i . $size_type] = $i . $size_type;
		}

		return apply_filters( 'wpem_font_size', $arrSize);
	}

	
}

if(!function_exists( 'wpem_get_font_list' ))
{
	/**
	* wpem_get_font_list function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_font_list()
	{
		$font_dir = WPEM_NAME_BADGES_PLUGIN_DIR . "/assets/fonts/";

		$arrFonts = [];

		if (is_dir($font_dir))
		{
		  	if ($fonts = opendir($font_dir))
		  	{
		    	while (($file = readdir($fonts)) !== false)
		    	{
		      		$extension = pathinfo($file, PATHINFO_EXTENSION);

		      		if(in_array($extension, ['ttf']))
		      		{
		      			$name = explode('.', $file);
		      			$font_name = str_replace(
					      				['-', '_'], 
					      				[' ', ' '], 
					      				$name[0]
					      			);

		      			$arrFonts[$file] = ucwords($font_name);
		      		}
		    	}

		    	closedir($fonts);
		  	}
		}

		return $arrFonts;
	}
	
}

if(!function_exists( 'wpem_get_web_font_list' ))
{
	/**
	* wpem_get_web_font_list function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_web_font_list()
	{
		$font_dir = WPEM_NAME_BADGES_PLUGIN_DIR . "/assets/fonts/";

		$arrFonts = [];

		if (is_dir($font_dir))
		{
		  	if ($fonts = opendir($font_dir))
		  	{
		    	while (($file = readdir($fonts)) !== false)
		    	{
		      		$extension = pathinfo($file, PATHINFO_EXTENSION);

		      		if(in_array($extension, ['woff']))
		      		{
		      			$name = explode('.', $file);
		      			$font_name = str_replace(
					      				['-', '_', 'webfont', 'font'], 
					      				[' ', ' ', '', ''], 
					      				$name[0]
					      			);

		      			$arrFonts[$file] = ucwords($font_name);
		      		}
		    	}

		    	closedir($fonts);
		  	}
		}

		return $arrFonts;
	}
	
}

if(!function_exists( 'wpem_get_text_align' ))
{
	/**
	* wpem_get_text_align function.
	*
	* @access public
	* @param 
	* @return array
	* @since 1.0.0
	*/
	function wpem_get_text_align()
	{
		return apply_filters( 'wpem_text_align', array(
				'left'   => __( 'Left', 'wpem-name-badges' ),
				'center'   => __( 'Center', 'wpem-name-badges' ),
				'right'   => __( 'Right', 'wpem-name-badges' ),
			) );
	}
}

if ( ! function_exists( 'get_name_badges_settings_by_user' ) ) {
	/**
	 * Get Name Badges Settings
	 *
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	function get_name_badges_settings_by_user() {
		if ( ! is_user_logged_in() )
			return;

		$user_id = get_current_user_id();

		$name_badges_settings = [];

		if ( current_user_can( 'manage_options' ) )
		{
			$name_badges_settings = get_option('name_badges_settings');
		}
		else
		{
			$name_badges_settings = get_user_meta($user_id, 'name_badges_settings', true);
		}

		return $name_badges_settings;
	}
}

if ( ! function_exists( 'update_name_badges_settings_by_user' ) ) {
	/**
	 * update Name Badges Settings
	 *
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	function update_name_badges_settings_by_user($field_key = '', $field_value = '') {
		if ( ! is_user_logged_in() )
			return;

		$user_id = get_current_user_id();

		if ( current_user_can( 'manage_options' ) )
		{
			update_option($field_key, $field_value);
		}
		else
		{
			update_user_meta($user_id, $field_key, $field_value);
		}
	}
}