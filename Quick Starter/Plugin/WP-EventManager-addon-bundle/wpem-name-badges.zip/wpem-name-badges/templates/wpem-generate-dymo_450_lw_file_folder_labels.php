<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Event Labels</title>
    <style>

    <?php foreach ( $name_badges_settings['font_name'] as $key => $font ) : ?>
    	<?php $font_name = explode('.', $font); ?>
		@font-face {
		    font-family: '<?php echo $font_name[0]; ?>';
		    src: url('<?php echo WPEM_NAME_BADGES_PLUGIN_URL . '/assets/fonts/' . $font; ?>') format('truetype');
		    font-weight: normal;
		    font-style: normal;
		}
	<?php endforeach; ?>

    <?php foreach ( $name_badges_settings['font_name'] as $key => $font ) : ?>
    	<?php $font_name = explode('.', $font); ?>

    	<?php if($key == 1) : ?>
			<?php $class='second-line'; ?>
		<?php elseif($key == 2) : ?>
			<?php $class='third-line'; ?>
		<?php elseif($key == 3) : ?>
			<?php $class='fourth-line'; ?>
                <?php elseif($key == 4) : ?>
			<?php $class='fifth-line'; ?>
		<?php else : ?>
			<?php $class='first-line'; ?>
		<?php endif ; ?>

		<?php echo '.' . $class; ?>{
			font-family: '<?php echo $font_name[0]; ?>';
			font-size: <?php echo $name_badges_settings['font_size'][$key]; ?>;
			text-align: <?php echo $name_badges_settings['text_align'][$key]; ?>;
                        color: <?php echo $name_badges_settings['text_color'][$key]; ?>;
			margin: 0;
			padding: 0;
			line-height: 1;
		}
		
	<?php endforeach; ?>

	@page {
		size: 247.5pt 40.5pt;
		margin: 0px;
	}
	body { 
		margin: 0px;
	}	
	.label{
		padding: .125in .125in 0;
		margin: 0;
	}
	.label .third-line,
	.label .fourth-line{
		display: none;
		height: 0;
		width: 0;
	}
    </style>

</head>

<body>

<?php
$generator = new Picqer\Barcode\BarcodeGeneratorPNG();
?>

<?php if($total_attendees > 0) : ?>
	<?php foreach ( $attendees_list as $key => $attende ) : ?>

		<div class="label">
			<?php foreach ( $name_badges_settings['registration_field'] as $key => $registration_field ) : ?>

				<?php if(!empty($registration_field)) : ?>

					<?php if($key == 1) : ?>
						<?php $class='second-line'; ?>
					<?php elseif($key == 2) : ?>
						<?php $class='third-line'; ?>
					<?php elseif($key == 3) : ?>
						<?php $class='fourth-line'; ?>
                                        <?php elseif($key == 4) : ?>
                                                <?php $class='fifth-line'; ?>
					<?php else : ?>
						<?php $class='first-line'; ?>
					<?php endif ; ?>

					<div class="<?php echo $class; ?>">
						<?php if($registration_field == 'barcode') : ?>
							<?php echo '<img src="data:image/png;base64,' . base64_encode($generator->getBarcode($attende->ID, $generator::TYPE_CODE_128)) . '">'; ?>
						<?php else : ?>
							<?php echo get_post_meta($attende->ID, $registration_field, true); ?>
						<?php endif ; ?>
					</div>

				<?php endif ; ?>
				
			<?php endforeach; ?>
		</div>

	<?php endforeach; ?>
<?php else : ?>
	<div class="label">
		<?php _e( 'No attendees found', 'wpem-name-badges' ); ?>	
	</div>
<?php endif ; ?>

</body>

</html>
