<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<?php
$event_id = !empty($name_badges_settings['event_id']) ? $name_badges_settings['event_id'] : '';

$enable_on_demand_label = !empty($name_badges_settings['enable_on_demand_label']) ? $name_badges_settings['enable_on_demand_label'] : '';
$on_demand_label = !empty($name_badges_settings['on_demand_label']) ? $name_badges_settings['on_demand_label'] : '';
$on_demand_label_size = !empty($name_badges_settings['on_demand_label_size']) ? $name_badges_settings['on_demand_label_size'] : '';

$attendees_type = !empty($name_badges_settings['attendees_type']) ? $name_badges_settings['attendees_type'] : '';
$ticket_type = !empty($name_badges_settings['ticket_type']) ? $name_badges_settings['ticket_type'] : '';
$selected_attende_ids = !empty($name_badges_settings['selected_attende_ids']) ? $name_badges_settings['selected_attende_ids'] : '';
$sort_by = !empty($name_badges_settings['sort_by']) ? $name_badges_settings['sort_by'] : '';
$badges_style = !empty($name_badges_settings['badges_style']) ? $name_badges_settings['badges_style'] : '';

$registration_field = !empty($name_badges_settings['registration_field']) ? $name_badges_settings['registration_field'] : '';
$font_name = !empty($name_badges_settings['font_name']) ? $name_badges_settings['font_name'] : '';
$font_size = !empty($name_badges_settings['font_size']) ? $name_badges_settings['font_size'] : '';
$text_align = !empty($name_badges_settings['text_align']) ? $name_badges_settings['text_align'] : '';
$color = !empty($name_badges_settings['text_color']) ? $name_badges_settings['text_color'] : '';
?>

<div id="wpem_name_badges_settings" class="wpem-name-badges-settings wpem-main">
    <?php do_action('wpem_name_badges_settings_before'); ?>
    <div class="wpem-name-badges-settings-header wpem-dashboard-main-title wpem-dashboard-main-filter">
        <h3 class="wpem-theme-text"><?php _e('Name Badges', 'wpem-name-badges'); ?></h3>
        <!-- <p><?php _e('Create name badges for attendees that include your logo or a QR code.', 'wpem-name-badges'); ?></p> -->
    </div>
    <div class="wpem-name-badges-body">
            <!-- <h5 class="wpem-heading-text"><?php _e('Name badges for events of any size', 'wpem-name-badges'); ?></h5>
                    <p><?php _e('Add your logo, QR code and onsite printing', 'wpem-name-badges'); ?></p> -->
        <form class="wpem-name-badges-settings-form wpem-form-wrapper" method="POST">
            <div class="wpem-name-badges-settings-field">
                <div class="wpem-row">
                    <div class="wpem-col-md-12">
                        <div class="wpem-form-group">
                            <label for="event_id"><?php _e('Select Event:', 'wpem-name-badges'); ?></label>
                            <select name="event_id" id="event_id">
                                <option value=""><?php _e('Select Event', 'wpem-name-badges'); ?></option>
                                <?php foreach ($events as $event) : ?>
                                    <option value="<?php echo esc_attr($event->ID); ?>" <?php selected($event_id, $event->ID); ?>>
                                        <?php echo esc_html($event->post_title); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="wpem-col-md-12">
                        <div class="wpem-form-group">
                            <label for="enable_on_demand_label">
                                <input type="checkbox" name="enable_on_demand_label" id="enable_on_demand_label" <?php checked($enable_on_demand_label, 1); ?> value="1"> <?php _e('On demand badge', 'wpem-name-badges'); ?>
                            </label>
                        </div>
                    </div>
                    <?php
                    if ($enable_on_demand_label) :
                        $d_none = '';
                    else :
                        $d_none = 'd-none';
                    endif;
                    ?>
                    <div class="wpem-col-md-12 <?php echo $d_none; ?>" id="on_demand_label_div">
                        <div class="wpem-form-group">
                            <label for="on_demand_label"><?php _e('Select on demand label:', 'wpem-name-badges'); ?></label>
                            <select name="on_demand_label" id="on_demand_label">
                                <option value=""><?php _e('Select label', 'wpem-name-badges'); ?>...</option>
                                <?php foreach (wpem_get_on_demand_label() as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($on_demand_label, $name); ?>>
                                        <?php echo esc_html($label); ?>
                                        <?php if ($name == 'all') : ?>
                                            <?php echo '(' . esc_html($total_attendees) . ')'; ?>
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <?php
                    if ($enable_on_demand_label) :
                        $d_none = '';
                    else :
                        $d_none = 'd-none';
                    endif;
                    ?>
                    <div class="wpem-col-md-12 <?php echo $d_none; ?>" id="on_demand_label_size_div">
                        <div class="wpem-form-group">
                            <label for="on_demand_label_size"><?php _e('Select on demand label size:', 'wpem-name-badges'); ?></label>
                            <select name="on_demand_label_size" id="on_demand_label_size" data-label="<?php echo esc_attr($on_demand_label); ?>" data-label-size="<?php echo esc_attr($on_demand_label_size); ?>">
                                <option value=""><?php _e('Select label size', 'wpem-name-badges'); ?>...</option>
                                <?php if (!empty($on_demand_label)) : ?>
                                    <?php
                                    $arr_label_size = wpem_get_on_demand_label_size();
                                    $get_label_sizes = $arr_label_size[$on_demand_label];
                                    ?>
                                    <?php foreach ($get_label_sizes as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($on_demand_label_size, $name); ?>>
                                            <?php echo esc_html($label); ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="wpem-col-md-12">
                        <div class="wpem-form-group">
                            <label for="attendees_type"><?php _e('Select Attendees:', 'wpem-name-badges'); ?></label>
                            <select name="attendees_type" id="attendees_type">
                                <?php foreach (wpem_get_attendees_type() as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($attendees_type, $name); ?>>
                                        <?php echo esc_html($label); ?>
                                        <?php if ($name == 'all') : ?>
                                            <?php echo '(' . esc_html($total_attendees) . ')'; ?>
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <?php
                    if ($attendees_type == 'ticket_type') :
                        $d_none = '';
                    else :
                        $d_none = 'd-none';
                    endif;
                    ?>
                    <div class="wpem-col-md-12 <?php echo $d_none; ?>" id="ticket_type_div">
                        <div class="wpem-form-group">
                            <?php if (is_plugin_active('wp-event-manager-sell-tickets/wp-event-manager-sell-tickets.php')) : ?>
                                <label for="ticket_type"><?php _e('Ticket Type:', 'wpem-name-badges'); ?></label>
                            <?php else : ?>
                                <label for="ticket_type"><?php _e('Status Type:', 'wpem-name-badges'); ?></label>
                            <?php endif; ?>
                            <select name="ticket_type" id="ticket_type">
                                <option value=""><?php _e('Select type', 'wpem-name-badges'); ?>...</option>
                                <?php foreach (wpem_get_ticket_type() as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($ticket_type, $name); ?>>
                                        <?php echo esc_html($label); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                     <div class="wpem-col-md-12">
                        <div class="wpem-form-group">
                            <label for="sort_by"><?php _e('Sort Attendees By:', 'wpem-name-badges'); ?></label>
                            <select name="sort_by" id="sort_by">
                                <?php foreach (wpem_get_sort_by() as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($sort_by, $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="wpem-col-md-12" id="attendees_list">
                    </div>
                   
                    <div class="wpem-col-md-12">
                        <div class="wpem-form-group">
                            <label for="badges_style"><?php _e('Select Badges Style:', 'wpem-name-badges'); ?></label>
                            <select name="badges_style" id="badges_style">
                                <?php foreach (wpem_get_badges_style() as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($badges_style, $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="wpem-col-md-12">
                        <div class="wpem-customization-box">
                            <h5 class="wpem-heading-text"><?php _e('Customize attendees badges layout', 'wpem-name-badges'); ?></h5>
                            <?php if (!empty($registration_field)) : ?>
                                <?php foreach ($registration_field as $key => $field_value) : ?>
                                    <div class="wpem-row wpem-no-gutters">
                                        <div class="wpem-col-xl-2 wpem-col-lg-12 wpem-mb-2 wpem-sm-mb-2 wpem-pr-md-2">
                                            <?php if ($key == 1) : ?>
                                                <?php _e('Second Line:', 'wpem-name-badges'); ?>
                                            <?php elseif ($key == 2) : ?>
                                                <?php _e('Third Line:', 'wpem-name-badges'); ?>
                                            <?php elseif ($key == 3) : ?>
                                                <?php _e('Fourth Line:', 'wpem-name-badges'); ?>
                                            <?php elseif ($key == 4) : ?>
                                                <?php _e('Fifth Line:', 'wpem-name-badges'); ?>
                                            <?php else : ?>
                                                <?php _e('First Line:', 'wpem-name-badges'); ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="wpem-col-xl-3 wpem-col-lg-3">
                                            <div class="wpem-form-group">
                                                <select name="registration_field[]" class="registration-field">
                                                    <option value=""><?php _e('Select field', 'wpem-name-badges'); ?>...</option>
                                                    <?php foreach (wpem_get_registration_form_fields() as $name => $field) : ?>
                                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($field_value, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="wpem-col-xl-2 wpem-col-lg-2">
                                            <div class="wpem-form-group">
                                                <select name="font_name[]" class="font-name">
                                                    <option value=""><?php _e('Select font', 'wpem-name-badges'); ?>...</option>
                                                    <?php foreach (wpem_get_font_list() as $name => $label) : ?>
                                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($font_name[$key], $name); ?>><?php echo esc_html($label); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="wpem-col-xl-2 wpem-col-lg-2">
                                            <div class="wpem-form-group">
                                                <select name="font_size[]" class="font-size">
                                                    <option value=""><?php _e('Select font size', 'wpem-name-badges'); ?>...</option>
                                                    <?php foreach (wpem_get_font_size() as $name => $label) : ?>
                                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($font_size[$key], $name); ?>><?php echo esc_html($label); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="wpem-col-xl-2 wpem-col-lg-3 wpem-col-6 wpem-pl-lg-2">
                                            <div class="wpem-form-group wpem-radio-group ">
                                                <?php foreach (wpem_get_text_align() as $name => $label) : ?>
                                                    <input type="radio" name="text_align[<?php echo $key; ?>]" value="<?php echo esc_attr($name); ?>" id="align_position_<?php echo $name . '_' . $key; ?>" <?php checked($text_align[$key], $name); ?>><label for="align_position_<?php echo $name . '_' . $key; ?>"><i class="wpem-icon-paragraph-<?= $name; ?>"></i></label>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                        <div class="wpem-col-xl-1 wpem-col-lg-2 wpem-col-6 wpem-pl-2">
                                            <div class="wpem-form-group">
                                                <input type="color" name="text_color[<?php echo $key; ?>]" value="<?php echo esc_attr($color[$key]); ?>">
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <?php for ($i = 0; $i <= 4; $i++) : ?>
                                    <div class="wpem-row">
                                        <div class="wpem-col-md-2">
                                            <?php if ($i == 1) : ?>
                                                <?php _e('Second Line:', 'wpem-name-badges'); ?>
                                            <?php elseif ($i == 2) : ?>
                                                <?php _e('Third Line:', 'wpem-name-badges'); ?>
                                            <?php elseif ($i == 3) : ?>
                                                <?php _e('Fourth Line:', 'wpem-name-badges'); ?>
                                            <?php elseif ($i == 4) : ?>
                                                <?php _e('Fifth Line:', 'wpem-name-badges'); ?>
                                            <?php else : ?>
                                                <?php _e('First Line:', 'wpem-name-badges'); ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="wpem-col-md-3">
                                            <div class="wpem-form-group">
                                                <select name="registration_field[]" class="registration-field">
                                                    <option value=""><?php _e('Select field', 'wpem-name-badges'); ?>...</option>
                                                    <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                                        <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="wpem-col-md-3">
                                            <div class="wpem-form-group">
                                                <select name="font_name[]" class="font-name">
                                                    <option value=""><?php _e('Select font', 'wpem-name-badges'); ?>...</option>
                                                    <?php foreach (wpem_get_font_list() as $name => $label) : ?>
                                                        <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="wpem-col-md-2">
                                            <div class="wpem-form-group">
                                                <select name="font_size[]" class="font-size">
                                                    <option value=""><?php _e('Select font size', 'wpem-name-badges'); ?>...</option>
                                                    <?php foreach (wpem_get_font_size() as $name => $label) : ?>
                                                        <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="wpem-col-md-2">
                                            <div class="wpem-form-group">
                                                <?php foreach (wpem_get_text_align() as $name => $label) : ?>
                                                    <input type="radio" name="text_align[<?php echo $i; ?>]" value="<?php echo esc_attr($name); ?>" <?php checked('left', $name); ?>><?php echo esc_html($label); ?>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                        <div class="wpem-col wpem-pl-md-1">
                                            <div class="wpem-form-group">
                                                <input type="color" name="text_color[<?php echo $key; ?>]" value="<?php echo esc_attr($color[$key]); ?>">
                                            </div>
                                        </div>
                                    </div>
                                <?php endfor; ?>
                            <?php endif; ?>
                            <div id="response"></div>
                            <div class="wpem-row">
                                <div class="wpem-col-md-12">
                                    <button type="button" class="wpem-theme-button" name="wpem_name_badges_save_settings" id="wpem_name_badges_save_settings" value="<?php esc_attr_e('Save Settings', 'wpem-name-badges'); ?>"><?php _e('Save Settings', 'wpem-name-badges'); ?></button>
                                    <input type="submit" class="wpem-theme-button" name="wpem_name_badges_generate" id="wpem_name_badges_generate" value="<?php esc_attr_e('Generate Badges', 'wpem-name-badges'); ?>" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <?php do_action('wpem_name_badges_settings_after'); ?>
</div>
