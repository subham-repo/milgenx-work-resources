<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Event Labels</title>
    <style>

    <?php foreach ( $name_badges_settings['font_name'] as $key => $font ) : ?>
    	<?php $font_name = explode('.', $font); ?>
		@font-face {
		    font-family: '<?php echo $font_name[0]; ?>';
		    src: url('<?php echo WPEM_NAME_BADGES_PLUGIN_URL . '/assets/fonts/' . $font; ?>') format('truetype');
		    font-weight: normal;
		    font-style: normal;
		}
	<?php endforeach; ?>

    <?php foreach ( $name_badges_settings['font_name'] as $key => $font ) : ?>
    	<?php $font_name = explode('.', $font); ?>

    	<?php if($key == 1) : ?>
			<?php $class='second-line'; ?>
		<?php elseif($key == 2) : ?>
			<?php $class='third-line'; ?>
		<?php elseif($key == 3) : ?>
			<?php $class='fourth-line'; ?>
                <?php elseif($key == 4) : ?>
			<?php $class='fifth-line'; ?>
		<?php else : ?>
			<?php $class='first-line'; ?>
		<?php endif ; ?>

		<?php echo '.' . $class; ?>{
			font-family: '<?php echo $font_name[0]; ?>';
			font-size: <?php echo $name_badges_settings['font_size'][$key]; ?>;
			text-align: <?php echo $name_badges_settings['text_align'][$key]; ?>;
                        color: <?php echo $name_badges_settings['text_color'][$key]; ?>;
			margin: 0;
			padding: 0;
			line-height: 1;
		}
		
	<?php endforeach; ?>
	@page { 
		margin: 119px 81.5px;
		margin-bottom: 0;
	}
	body { margin: 0px; }
	.label{
     	width: 3.15in;
     	height: 2in;
     	outline: 1px solid #000;
     	padding: .125in .125in 0;
     	float: left;
     	display: block;
     	margin: 0;
    }
	.clearfix{
		clear: both;
		display:block;
	}
	.page-break{
    	clear: left;
    	display:block;
    	page-break-after:always;
    }
    </style>

</head>

<body>

<?php
$generator = new Picqer\Barcode\BarcodeGeneratorPNG();
$per_page = 8;
$per_row = 2;
$new_page = 9;
$i = 1;
?>

<?php if($total_attendees > 0) : ?>
	<?php foreach ( $attendees_list as $key => $attende ) : ?>

		<?php
		if($i % $per_row == 0){ 
	        
	    } 
	    else{ 
	        echo '<div class="clearfix"></div>';
	    }

	    if($i % $new_page == 0){ 
	        echo '<div class="page-break"></div>';
	    } 
	    else{ 
	        
	    }
		?>

		<div class="label">
			<?php foreach ( $name_badges_settings['registration_field'] as $key => $registration_field ) : ?>

				<?php if(!empty($registration_field)) : ?>

					<?php if($key == 1) : ?>
						<?php $class='second-line'; ?>
					<?php elseif($key == 2) : ?>
						<?php $class='third-line'; ?>
					<?php elseif($key == 3) : ?>
						<?php $class='fourth-line'; ?>
                                        <?php elseif($key == 4) : ?>
                                                <?php $class='fifth-line'; ?>
					<?php else : ?>
						<?php $class='first-line'; ?>
					<?php endif ; ?>

					<div class="<?php echo $class; ?>">
						<?php if($registration_field == 'barcode') : ?>							
							<?php echo '<img src="data:image/png;base64,' . base64_encode($generator->getBarcode($attende->ID, $generator::TYPE_CODE_128)) . '">'; ?>
						<?php else : ?>
							<?php echo get_post_meta($attende->ID, $registration_field, true); ?>
						<?php endif ; ?>
					</div>

				<?php endif ; ?>
				
			<?php endforeach; ?>
		</div>

		<?php $i++; ?>

	<?php endforeach; ?>
<?php else : ?>
	<div class="label">
		<?php _e( 'No attendees found', 'wpem-name-badges' ); ?>	
	</div>
<?php endif ; ?>

</body>

</html>
