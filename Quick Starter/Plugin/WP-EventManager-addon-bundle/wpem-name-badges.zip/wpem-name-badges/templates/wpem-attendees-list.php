<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
} ?>
<div class="wpem-customization-box wpem-mb-3">
	<h3 class="wpem-heading-text">Attendee list</h3>
	<div id="wpem_attendees_list" class="wpem-attendees-list">
		<table class="widefat fixed wp-list-table striped wpem-mb-0">
			<thead>
				<tr>
					<th>
						<input type="checkbox" id="all_attende_id">
						<?php _e('ID:', 'wpem-name-badges'); ?>
						<input type="hidden" name="selected_attende_ids" id="selected_attende_ids" value="<?php echo implode(',', $selected_attende_ids); ?>">
					</th>
					<?php foreach ($registration_form_fields as $name => $field) : ?>
						<th><?php echo esc_html($field['label']); ?></th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<tbody>
				<?php if ($total_attendees > 0) : ?>
					<?php foreach ($attendees_list as $key => $attende) : ?>
						<tr>
							<?php if (in_array($attende->ID, $selected_attende_ids)) :
								$checked = 'checked';
							else :
								$checked = '';
							endif; ?>
							<td><input type="checkbox" <?php echo $checked; ?> class="attende-id" value="<?php echo $attende->ID; ?>"></td>
							<?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
								<td><?php echo get_post_meta($attende->ID, $name, true); ?></td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr>
						<td colspan="<?php echo count($registration_form_fields) + 1; ?>"><?php _e('No attendees found', 'wpem-name-badges'); ?></td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
