var NameBadgesDashboard = function () {

    return {

	    init: function() 
        {
            jQuery('body').on('click', '.wpem-name-badges-settings-form .wpem-name-badges-settings-field #enable_on_demand_label', NameBadgesDashboard.actions.enableOnDemandLabel);

            jQuery('body').on('change', '.wpem-name-badges-settings-form .wpem-name-badges-settings-field #on_demand_label', NameBadgesDashboard.actions.changeOnDemandLabel);


            if( jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #attendees_type').length > 0 )
            {
                NameBadgesDashboard.actions.getAttendees();    
            }
            jQuery( '.wpem-name-badges-settings-form .wpem-name-badges-settings-field #attendees_type' ).on('change', NameBadgesDashboard.actions.getAttendees);
            jQuery( '.wpem-name-badges-settings-form .wpem-name-badges-settings-field #sort_by' ).on('change', NameBadgesDashboard.actions.getAttendees);
            jQuery( '.wpem-name-badges-settings-form .wpem-name-badges-settings-field #ticket_type' ).on('change', NameBadgesDashboard.actions.getAttendees);

            //jQuery( '.wpem-name-badges-settings-form .wpem-name-badges-settings-field #all_attende_id' ).on('click', NameBadgesDashboard.actions.allSelectAttendees);

            jQuery('body').on('click', '.wpem-name-badges-settings-form .wpem-name-badges-settings-field #all_attende_id', NameBadgesDashboard.actions.allSelectAttendees);

            jQuery('body').on('click', '.wpem-name-badges-settings-form .wpem-name-badges-settings-field .attende-id', NameBadgesDashboard.actions.selectAttendees);

            jQuery( '.wpem-name-badges-settings-form .wpem-name-badges-settings-field #wpem_name_badges_save_settings' ).on('click', NameBadgesDashboard.actions.saveNameBadgesSettings);

            
            jQuery( '.wpem-actions-wrapper .print  .wpem-name-badges-print' ).on('click', NameBadgesDashboard.actions.printNameBadges);
        },


	    actions:
	    {
            /**
             * enableOnDemandLabel function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            enableOnDemandLabel: function (e) 
            {
                if(jQuery(e.target).prop("checked") == true)
                {
                    jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #on_demand_label_div').show();
                    jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #on_demand_label_size_div').show();
                }
                else
                {
                    jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #on_demand_label_div').hide();
                    jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #on_demand_label_size_div').hide();
                }

                var on_demand_label = jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #on_demand_label_size').attr('data-label');
                var on_demand_label_size = jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #on_demand_label_size').attr('data-label-size');

                if(on_demand_label != '')
                {
                    jQuery.ajax({
                        url: wpem_name_badges_dashboard.ajax_url,
                        type: 'POST',
                        dataType: 'HTML',
                        data: {
                            action: 'get_on_demand_label_size',
                            security: wpem_name_badges_dashboard.wpem_name_badges_dashboard_security,
                            on_demand_label: on_demand_label,
                            on_demand_label_size: on_demand_label_size,
                        },
                        success: function (response)
                        {
                            jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #on_demand_label_size').html(response);
                        }
                    });
                }
            },

            /**
             * changeOnDemandLabel function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            changeOnDemandLabel: function (e) 
            {
                var on_demand_label = jQuery( e.target ).val();
                var on_demand_label_size = '';

                if(on_demand_label != '')
                {
                    jQuery.ajax({
                        url: wpem_name_badges_dashboard.ajax_url,
                        type: 'POST',
                        dataType: 'HTML',
                        data: {
                            action: 'get_on_demand_label_size',
                            security: wpem_name_badges_dashboard.wpem_name_badges_dashboard_security,
                            on_demand_label: on_demand_label,
                            on_demand_label_size: on_demand_label_size,
                        },
                        success: function (response)
                        {
                            jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #on_demand_label_size').html(response);
                        }
                    });
                }
            },

            /**
             * getAttendees function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            getAttendees: function (event) 
            {
                var attendees_type = jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #attendees_type').val();
                var sort_by = jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #sort_by').val();
                var ticket_type = jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #ticket_type').val();
                var event_id = jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #event_id').val();

                jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #attendees_list').html('');

                if(attendees_type == 'ticket_type')
                {
                    jQuery( '.wpem-name-badges-settings-form .wpem-name-badges-settings-field #ticket_type_div' ).removeClass('d-none');
                }
                else
                {                    
                    jQuery( '.wpem-name-badges-settings-form .wpem-name-badges-settings-field #ticket_type_div' ).addClass('d-none');
                }

                if(attendees_type == 'all')
                {
                    return;
                }


                jQuery.ajax({
                    url: wpem_name_badges_dashboard.ajax_url,
                    type: 'POST',
                    dataType: 'HTML',
                    data: {
                        action: 'get_attendees_list',
                        security: wpem_name_badges_dashboard.wpem_name_badges_dashboard_security,
                        attendees_type: attendees_type,
                        sort_by: sort_by,
                        ticket_type: ticket_type,
                        event_id: event_id,
                    },
                    beforeSend: function(){
                        jQuery('#attendees_list').addClass('wpem-loading');
                    },
                    success: function (response)
                    {
                        jQuery('#attendees_list').removeClass('wpem-loading');

                        jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field #attendees_list').html(response);
                    }
                });
            },

            /**
             * allSelectAttendees function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            allSelectAttendees: function (event) 
            {
                if(jQuery(event.target).prop("checked") == true)
                {
                    jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field input[type="checkbox"]').prop('checked', true);
                }
                else
                {
                    jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field input[type="checkbox"]').prop('checked', false);
                }

                var allSelectAttendees = [];

                jQuery.each(jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field input.attende-id:checked'), function(){
                    allSelectAttendees.push(jQuery(this).val());
                });

                jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field input#selected_attende_ids').val(allSelectAttendees.toString());
            },

            /**
             * selectAttendees function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            selectAttendees: function (event) 
            {
                var allSelectAttendees = [];

                jQuery.each(jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field input.attende-id:checked'), function(){
                    allSelectAttendees.push(jQuery(this).val());
                });

                jQuery('.wpem-name-badges-settings-form .wpem-name-badges-settings-field input#selected_attende_ids').val(allSelectAttendees.toString());
            },

            /**
             * saveNameBadgesSettings function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            saveNameBadgesSettings: function (event) 
            {
                jQuery( '#response' ).html('');

                var formData = jQuery('body .wpem-name-badges-settings-form').serialize();

                jQuery.ajax({
                    url: wpem_name_badges_dashboard.ajax_url,
                    type: 'POST',
                    dataType: 'JSON',
                    data: {
                        action: 'save_name_badges_settings',
                        security: wpem_name_badges_dashboard.wpem_name_badges_dashboard_security,
                        form_data: formData,
                    },
                    success: function (response)
                    {   
                        jQuery( '#response' ).html('<div class="'+response.class+'">'+response.message+'<div>');
                    }
                });
            },

            /**
             * printNameBadges function.
             *
             * @access public
             * @param 
             * @return 
             * @since 1.0
             */
            printNameBadges: function (event) 
            {
                var event_id = jQuery(event.target).attr('data-event-id');
                var attende_id = jQuery(event.target).attr('data-attende-id');

                if(event_id == '' || event_id == '')
                {
                    return;
                }

                jQuery.ajax({
                    url: wpem_name_badges_dashboard.ajax_url,
                    type: 'POST',
                    dataType: 'JSON',
                    data: {
                        action: 'print_name_badges',
                        security: wpem_name_badges_dashboard.wpem_name_badges_dashboard_security,
                        event_id: event_id,
                        attende_id: attende_id,
                    },
                    success: function (response)
                    {
                        //console.log(response.url)

                        if(response.url != '')
                        {
                            window.open(response.url, "_blank");    
                        }
                        
                    }
                });
            },

		
		} /* end of action */

    }; /* enf of return */

}; /* end of class */

NameBadgesDashboard = NameBadgesDashboard();

jQuery(document).ready(function($) 
{
   NameBadgesDashboard.init();
});
