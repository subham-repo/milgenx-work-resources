<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPEM_Name_Badges_Ajax class.
 */
class WPEM_Name_Badges_Ajax{

	/**
	 * __construct function.
	 */
	public function __construct() 
	{
		

		add_action( 'wp_ajax_get_on_demand_label_size', array( $this, 'get_on_demand_label_size' ) );
		add_action( 'wp_ajax_get_attendees_list', array( $this, 'get_attendees_list' ) );
		add_action( 'wp_ajax_save_name_badges_settings', array( $this, 'save_name_badges_settings' ) );
				
	}

	/**
	* get_on_demand_label_size function.
	*
	* @access public
	* @param 
	* @return 
	* @since 1.0.0
	*/
	public function get_on_demand_label_size()
	{
		check_ajax_referer( '_nonce_wpem_name_badges_dashboard_security', 'security' );

		$on_demand_label = $_POST['on_demand_label'];
		$on_demand_label_size = $_POST['on_demand_label_size'];

		$arr_label_size = wpem_get_on_demand_label_size();

		$get_label_sizes = $arr_label_size[$on_demand_label];

		$output = '<option value="">' . __( 'Select label size', 'wpem-name-badges' ) . '...</option>';
		if(!empty($get_label_sizes))
		{
			foreach ($get_label_sizes as $name => $label) {
				$output .= '<option value="' . $name . '"  ' . selected( $on_demand_label_size, $name ) . ' >' . $label . '</option>';
			}
		}

		echo $output;

        wp_die();
	}

	/**
	* get_attendees_list function.
	*
	* @access public
	* @param 
	* @return 
	* @since 1.0.0
	*/
	public function get_attendees_list()
	{
		check_ajax_referer( '_nonce_wpem_name_badges_dashboard_security', 'security' );

		$attendees_type	= ! empty( $_POST['attendees_type'] ) ? sanitize_text_field( $_POST['attendees_type'] ) : '';		
		$ticket_type  	= ! empty( $_POST['ticket_type'] ) ? sanitize_text_field( $_POST['ticket_type'] ) : '';
		$sort_by  		= ! empty( $_POST['sort_by'] ) ? sanitize_text_field( $_POST['sort_by'] ) : '';
		$event_id 		= absint( $_POST['event_id'] );
		$selected_attende_ids = [];
		$name_badges_settings = get_option('name_badges_settings');
                if (is_array($name_badges_settings) && isset($name_badges_settings['selected_attende_ids'])) {
                    $selected_attende_ids = explode(',', $name_badges_settings['selected_attende_ids']);
                }

		$post_status = [];
		if($attendees_type == 'ticket_type')
		{
			if ( is_plugin_active( 'wp-event-manager-sell-tickets/wp-event-manager-sell-tickets.php' ) )
			{
				$post_status = array_merge( array_keys( get_event_registration_statuses() ), array( 'publish' ) );
			}
			else
			{
				$post_status = [ $ticket_type ];
			}
		}
		else
		{
			$post_status = array_merge( array_keys( get_event_registration_statuses() ), array( 'publish' ) );
		}

		$args = [
			'post_type' 		=> 'event_registration',
			'post_status' 		=> $post_status,
			'posts_per_page'    => -1,
			'post_parent'       => $event_id,
			'order'				=> 'ASC',
			'orderby'   		=> 'meta_value',
    		'meta_key'  		=> $sort_by,
		];

		if ( is_plugin_active( 'wp-event-manager-sell-tickets/wp-event-manager-sell-tickets.php' ) )
		{
			if($attendees_type == 'ticket_type' && $ticket_type != '')
			{
				$args['meta_query'][] = [
									'key'     => '_ticket_type',
							        'value'   => $ticket_type,
							        'compare' => 'LIKE',
							        ];
			}
		}

		$attendees = new WP_Query( $args );

		ob_start();

		get_event_manager_template( 
			'wpem-attendees-list.php', 
			array( 
				'event_id' 			=> $event_id,
				'selected_attende_ids' 	=> $selected_attende_ids,
				'registration_form_fields' => get_event_registration_form_fields(),
				'attendees_list' 	=> $attendees->posts,
				'total_attendees' 	=> $attendees->found_posts,
			), 
			'wpem-name-badges', 
			WPEM_NAME_BADGES_PLUGIN_DIR . '/templates/'
		);

		$output = ob_get_clean();

		echo $output;

		wp_die();
	}


	/**
	* save_name_badges_settings function.
	*
	* @access public
	* @param 
	* @return 
	* @since 1.0.0
	*/
	public function save_name_badges_settings()
	{
		$user_id= get_current_user_id();

		check_ajax_referer( '_nonce_wpem_name_badges_dashboard_security', 'security' );

		$form_data = $_POST['form_data'];
        parse_str($form_data, $form_data);

        update_name_badges_settings_by_user('name_badges_settings', $form_data);

        if(!empty($user_id))
        {
        	if( isset($form_data['event_id']) && !empty($form_data['event_id']) )
        	{
        		$message = __( 'Successfully saved settings.', 'wpem-name-badges' );
        		$class = 'wpem-alert wpem-alert-success updated published';
        	}
        	else
        	{
        		$message = __( 'Please select event.', 'wpem-name-badges' );
        		$class = 'wpem-alert wpem-alert-danger error';
        	}
        	
        }
        else
        {
        	$message = __( 'Failed to save settings.', 'wpem-name-badges' );
        	$class = 'wpem-alert wpem-alert-danger error';
        }

        $response = [
            'message' 	=>  $message,
            'class' 	=>  $class,
        ];

        wp_send_json( $response );

        wp_die();
	}

	
	

}

new WPEM_Name_Badges_Ajax();
