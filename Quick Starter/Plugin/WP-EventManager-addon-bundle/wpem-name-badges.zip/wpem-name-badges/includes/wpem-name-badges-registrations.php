<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPEM_Name_Badges_Registrations class.
 */
class WPEM_Name_Badges_Registrations{

	/**
	 * __construct function.
	 */
	public function __construct() 
	{
		include_once (WPEM_NAME_BADGES_PLUGIN_DIR . '/includes/wpem-name-badges-generate-badges.php' );
		$this->generate_badges = new WPEM_Name_Badges_Generate_Badges();

		add_action( 'event_registration_footer_action_end', array( $this, 'add_print_lable_icon' ) );

		add_action( 'event_manager_event_registrations_admin_custom_actions', array( $this, 'add_print_lable_icon_admin' ) );

		// Ajax
		add_action( 'wp_ajax_print_name_badges', array( $this, 'print_name_badges' ) );
	}

	/**
	* add_print_lable_icon function.
	*
	* @access public
	* @param 
	* @return 
	* @since 1.0.0
	*/
	public function add_print_lable_icon($registration)
	{
		$user_id= get_current_user_id();

		wp_enqueue_style( 'wpem-name-badges-frontend' );
		wp_enqueue_script( 'wpem-name-badges-dashboard' );

		$name_badges_settings = get_name_badges_settings_by_user(); ?>

		<?php if(!empty($name_badges_settings) && isset($name_badges_settings['enable_on_demand_label']) && $name_badges_settings['enable_on_demand_label'] ) : ?>
			<div class="print action-btn">
				<a href="javascript:void(0)" class="wpem-name-badges-print" title="<?php _e( 'Print', 'wpem-name-badges' ); ?>" data-event-id="<?php echo $registration->post_parent; ?>" data-attende-id="<?php echo $registration->ID; ?>" >
					<?php _e( 'Print', 'wpem-name-badges' ); ?>
				</a>
			</div>
		<?php endif ; ?>

		<?php
	}

	/**
	* add_print_lable_icon function.
	*
	* @access public
	* @param 
	* @return 
	* @since 1.0.0
	*/
	public function add_print_lable_icon_admin($registration)
	{
		$user_id= get_current_user_id();

		wp_enqueue_style( 'wpem-name-badges-admin' );

		wp_enqueue_script( 'wpem-name-badges-admin' );

		$name_badges_settings = get_name_badges_settings_by_user(); ?>

		<?php if(!empty($name_badges_settings) && isset($name_badges_settings['enable_on_demand_label']) && $name_badges_settings['enable_on_demand_label'] ) : ?>			
			<a href="javascript:void(0)" class="icon-print button tips wpem-name-badges-print" data-tip="<?php _e( 'Print', 'wpem-name-badges' ); ?>" data-event-id="<?php echo $registration->post_parent; ?>" data-attende-id="<?php echo $registration->ID; ?>" >
				<?php _e( 'Print', 'wpem-name-badges' ); ?>
			</a>
		<?php endif ; ?>

		<?php
	}

	/**
	* print_name_badges function.
	*
	* @access public
	* @param 
	* @return 
	* @since 1.0.0
	*/
	public function print_name_badges()
	{
		$user_id= get_current_user_id();
		
		check_ajax_referer( '_nonce_wpem_name_badges_dashboard_security', 'security' );

		$event_id = absint( $_POST['event_id'] );
		$attende_id = absint( $_POST['attende_id'] );

		$name_badges_settings = get_name_badges_settings_by_user();

        $args = [
			'post_type'	=> 'event_registration',
			'post__in' 	=> [$attende_id]
		];

		$attendees = new WP_Query( $args );

		$url = '';
		if($attendees->found_posts > 0)
		{
			$html = $this->generate_badges->generate_html($event_id, $name_badges_settings, $attendees, true);

			//$url = $this->generate_pdf_mpdf($event_id, $name_badges_settings, $html);
			$url = $this->generate_badges->generate_pdf_dompdf($event_id, $name_badges_settings, $html, true);
		}

		wp_reset_query();
		wp_reset_postdata();

        echo json_encode([
            'url' => $url,
        ]);

        wp_die();
	}
	

}

new WPEM_Name_Badges_Registrations();