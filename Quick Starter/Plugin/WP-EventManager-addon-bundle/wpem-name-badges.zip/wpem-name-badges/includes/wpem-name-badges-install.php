<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPEM_Name_Badges_Install class.
 */
class WPEM_Name_Badges_Install {

	/**
     * install function.
     *
     * @access public static
     * @param 
     * @return 
     * @since 1.0
     */
	public static function install() 
	{
		update_option( 'wpem_name_badges_version', WPEM_NAME_BADGES_VERSION );
	}

     /**
     * install function.
     *
     * @access public static
     * @param 
     * @return 
     * @since 1.0
     */
     public static function update() 
     {
          update_option( 'wpem_name_badges_version', WPEM_NAME_BADGES_VERSION );
     }
}