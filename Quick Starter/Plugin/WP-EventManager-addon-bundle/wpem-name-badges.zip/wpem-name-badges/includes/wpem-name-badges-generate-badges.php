<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * WPEM_Name_Badges_Generate_Badges class.
 */
class WPEM_Name_Badges_Generate_Badges{

	/**
	 * __construct function.
	 */
	public function __construct() 
	{

		require_once  'lib/vendor/autoload.php';
		
	}

	/**
	* generate_badges function.
	*
	* @access public
	* @param $event_id
	* @return 
	* @since 1.0.0
	*/
	public function generate_badges($event_id = 0)
	{
		if(empty($event_id))
			return;
			
		$user_id= get_current_user_id();

		$name_badges_settings = get_name_badges_settings_by_user();

		$attendees_type	= ! empty( $name_badges_settings['attendees_type'] ) ? sanitize_text_field( $name_badges_settings['attendees_type'] ) : '';
		$ticket_type  	= ! empty( $name_badges_settings['ticket_type'] ) ? sanitize_text_field( $name_badges_settings['ticket_type'] ) : '';
		$selected_attende_ids  	= ! empty( $name_badges_settings['selected_attende_ids'] ) ? sanitize_text_field( $name_badges_settings['selected_attende_ids'] ) : '';
		$sort_by  		= ! empty( $name_badges_settings['sort_by'] ) ? sanitize_text_field( $name_badges_settings['sort_by'] ) : '';

		$post_status = [];
		error_log($attendees_type);
		if($attendees_type == 'ticket_type')
		{
			//$post_status = [ $ticket_type ];
		}
		else
		{
			$post_status = array_merge( array_keys( get_event_registration_statuses() ), array( 'publish' ) );
		}

		$args = [
			'post_type' 		=> 'event_registration',
			'post_status' 		=> $post_status,
			'posts_per_page'    => -1,
			'post_parent'       => $event_id,
			'order'				=> 'ASC',
			'orderby'   		=> 'meta_value',
    		'meta_key'  		=> $sort_by,
		];

		if(in_array($attendees_type, ['specific', 'ticket_type']))
		{
			$arr_attende_ids = explode(',', $selected_attende_ids);
			$args['post__in'] = $arr_attende_ids;
		}

		$attendees = new WP_Query( $args );

		$url = '';
		error_log('before directory'.$attendees->found_posts);
		if($attendees->found_posts > 0)
		{
			//require_once 'lib/vendor/autoload.php';
			$html = $this->generate_html($event_id, $name_badges_settings, $attendees);

			//$url = $this->generate_pdf_mpdf($event_id, $name_badges_settings, $html);
			$url = $this->generate_pdf_dompdf($event_id, $name_badges_settings, $html,false,true);			
		}

		wp_reset_query();
		wp_reset_postdata();

		return $url;
	}

	/**
	* generate_html function.
	*
	* @access public
	* @param $event_id, $attendees
	* @return 
	* @since 1.0.0
	*/
	public function generate_html($event_id = 0, $name_badges_settings = [], $attendees = [], $on_demand_label = false)
	{
		ob_start();

		$template_name = 'wpem-generate-'.$name_badges_settings['badges_style'].'.php';

		if( isset($name_badges_settings['enable_on_demand_label']) && $name_badges_settings['enable_on_demand_label'] && $on_demand_label)
		{
			$template_name = 'wpem-generate-'. $name_badges_settings['on_demand_label'] .'_'. $name_badges_settings['on_demand_label_size'].'.php';
		}

		get_event_manager_template( 
			$template_name, 
			array( 
				'event_id' 				=> $event_id,
				'name_badges_settings'	=> $name_badges_settings,
				'attendees_list' 		=> $attendees->posts,
				'total_attendees' 		=> $attendees->found_posts,
			), 
			'wpem-name-badges', 
			WPEM_NAME_BADGES_PLUGIN_DIR . '/templates/'
		);

		$output = ob_get_clean();

		return $output;
	}

	/**
	* generate_pdf_dompdf function.
	*
	* @access public
	* @param $event_id, $name_badges_settings, $html
	* @return 
	* @since 1.0.0
	*/
	public function generate_pdf_dompdf($event_id = 0, $name_badges_settings = [], $html = '', $on_demand_label = false,$stream = false)
	{	 
		$user_id = get_current_user_id();

		$upload_dir   = wp_upload_dir();
        if ( ! empty( $upload_dir['basedir'] ) ) {
            $badge_dirname = $upload_dir['basedir'].'/wpem-name-badges';
            if ( ! file_exists( $badge_dirname ) ) {
                wp_mkdir_p( $badge_dirname );
            } 
        }

		$file_name = 'label-'. $event_id . '-' . $user_id . '.pdf';
		 $full_path = $badge_dirname.'/'. $file_name;


		// instantiate and use the dompdf class
		$dompdf = new Dompdf\Dompdf();
			$options = new \Dompdf\Options();

			 // set options indvidiually
   			$options->set('isHtml5ParserEnabled', true);
			$options->set('isRemoteEnabled', true);
           $dompdf->setOptions($options);

           	$dompdf->loadHtml($html);

		if(!$on_demand_label && in_array($name_badges_settings['badges_style'], ['microsoft_w233', 'microsoft_w121', 'microsoft_w110', 'microsoft_w239', 'microsoft_w115']))
		{
			$dompdf->setPaper('A4', 'potrait');
		}

		// Render the HTML as PDF
		$dompdf->render();

		if($stream == true)
		{
		    $dompdf->stream($file_name);
		    exit();
		}
		else{
		    $full_path = $ticket_dirname.'/'. $file_name;
		    $pdf_gen = $dompdf->output();
		    
			if(!file_exists( $full_path )){
			    if(!is_wp_error(file_put_contents( $full_path , $pdf_gen ))) 
			    return $full_path;
			}
			else{
			    return $full_path;    
			}    
		}
	}

}

new WPEM_Name_Badges_Generate_Badges();
