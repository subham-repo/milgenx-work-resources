<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

/**
 * WPEM_Name_Badges_Dashboard class.
 */
class WPEM_Name_Badges_Dashboard
{

	/**
	 * __construct function.
	 */
	public function __construct()
	{

		add_action('wp_enqueue_scripts', array($this, 'frontend_scripts'));

		add_filter('wpem_dashboard_menu', array($this, 'wpem_dashboard_menu_add'));
		add_action('event_manager_event_dashboard_content_wpem_name_badges', array($this, 'wpem_name_badges'));
		//generate badges
		include_once (WPEM_NAME_BADGES_PLUGIN_DIR . '/includes/wpem-name-badges-generate-badges.php' );
		$this->generate_badges = new WPEM_Name_Badges_Generate_Badges();

		add_action( 'wp_loaded', array( $this, 'generate_name_badges' ) );
	}

	/**
	 * frontend_scripts function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function frontend_scripts()
	{
		wp_register_style('wpem-name-badges-frontend', WPEM_NAME_BADGES_PLUGIN_URL . '/assets/css/frontend.min.css');

		wp_register_script('wpem-name-badges-dashboard', WPEM_NAME_BADGES_PLUGIN_URL . '/assets/js/name-badges-dashboard.js', array('jquery'), WPEM_NAME_BADGES_VERSION, true);

		wp_localize_script(
			'wpem-name-badges-dashboard',
			'wpem_name_badges_dashboard',
			array(
				'ajax_url' 	 => admin_url('admin-ajax.php'),
				'wpem_name_badges_dashboard_security'  => wp_create_nonce("_nonce_wpem_name_badges_dashboard_security"),
			)
		);
	}

	/**
	 * add dashboard menu function.
	 *
	 * @access public
	 * @return void
	 */
	public function wpem_dashboard_menu_add($menus)
	{
		$menus['wpem_name_badges'] = [
			'title' => __('Name Badges', 'wpem-name-badges'),
			'icon' => 'wpem-icon-printer',
			'query_arg' => ['action' => 'wpem_name_badges'],
		];

		return $menus;
	}

	/**
	 * show_name_badges function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function wpem_name_badges()
	{
		$user_id = get_current_user_id();

		$name_badges_settings = get_name_badges_settings_by_user();
		$event_id = !empty($name_badges_settings['event_id']) ? $name_badges_settings['event_id'] : '';
		$total_attendees = get_event_registration_count($event_id);

		$args = [
			'post_type'   => 'event_listing',
			'post_status' => 'publish',
			'posts_per_page'    => -1,
			'author'      => $user_id,
		];
		$events = get_posts($args);

		wp_enqueue_style('wpem-name-badges-frontend');
		wp_enqueue_script('wpem-name-badges-dashboard');

		get_event_manager_template(
			'wpem-name-badges-settings.php',
			array(
				'events' 	=> $events,
				'name_badges_settings' => $name_badges_settings,
				'total_attendees' => $total_attendees,
			),
			'wpem-name-badges',
			WPEM_NAME_BADGES_PLUGIN_DIR . '/templates/'
		);
	}


	/**
	* generate_name_badges function.
	*
	* @access public
	* @param 
	* @return 
	* @since 1.0.0
	*/
	public function generate_name_badges()
	{
		if(isset($_GET['action']) && $_GET['action'] == 'wpem_name_badges' && isset($_POST['wpem_name_badges_generate'])){

			$user_id= get_current_user_id();
	
	        update_name_badges_settings_by_user('name_badges_settings', $_POST);

	        $event_id = absint( $_POST['event_id'] );

	        $this->generate_badges->generate_badges($event_id);
		}  
	}
}

new WPEM_Name_Badges_Dashboard();
