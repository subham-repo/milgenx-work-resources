<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPEM_Name_Badges_Admin class.
 */
class WPEM_Name_Badges_Admin{

	/**
	 * __construct function.
	 */
	public function __construct() 
	{
		include ('wpem-name-badges-settings.php');
    	$this->settings_class = new WPEM_Name_Badges_Settings();

		add_action( 'admin_menu', array( $this, 'admin_menu' ), 12 );

		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );

		//generate badges
		include_once (WPEM_NAME_BADGES_PLUGIN_DIR . '/includes/wpem-name-badges-generate-badges.php' );
		$this->generate_badges = new WPEM_Name_Badges_Generate_Badges();

		add_action( 'admin_init', array( $this, 'wpem_name_badges_admin_generate_badge' ) );
	}

	/**
	* frontend_scripts function.
	*
	* @access public
	* @param 
	* @return 
	* @since 1.0.0
	*/
	public function admin_enqueue_scripts()
	{
		wp_register_style( 'wpem-name-badges-admin', WPEM_NAME_BADGES_PLUGIN_URL . '/assets/css/backend.min.css' );

		wp_register_script( 'wpem-name-badges-admin', WPEM_NAME_BADGES_PLUGIN_URL . '/assets/js/admin-name-badges.js', array( 'jquery' ), WPEM_NAME_BADGES_VERSION, true );

		wp_localize_script( 'wpem-name-badges-admin', 'wpem_name_badges_admin', array( 
								'ajax_url' 	 => admin_url( 'admin-ajax.php' ),
								'wpem_name_badges_admin_security'  => wp_create_nonce( "_nonce_wpem_name_badges_dashboard_security" ),
							)
						);

		if( isset($_GET['page']) && $_GET['page'] === 'event-manager-name-badges-settings' )
		{
			wp_enqueue_style( 'wpem-name-badges-admin' );

			wp_enqueue_script( 'wpem-name-badges-admin' );
		}
	}

	/**
	 * admin_menu function.
	 *
	 * @access public
	 * @return void
	 * @since 1.0.0
	 */
	public function admin_menu() 
	{
		add_submenu_page(  'edit.php?post_type=event_listing', __( 'WP Event Manager Name Badges Settings', 'wpem-name-badges' ),  __( 'Name Badges', 'wpem-name-badges' ) , 'manage_options', 'event-manager-name-badges-settings', array( $this->settings_class, 'wpem_badges_settings' ), 7 );
	}


	/**
	* wpem_name_badges_admin_generate_badge function.
	*
	* @access public
	* @param 
	* @return 
	* @since 1.0.0
	*/
	public function wpem_name_badges_admin_generate_badge()
	{
		if(isset($_GET['page']) && $_GET['page'] == 'event-manager-name-badges-settings' && isset($_POST['wpem_name_badges_generate'])){

			$user_id= get_current_user_id();
	
	        update_name_badges_settings_by_user('name_badges_settings', $_POST);

	        $event_id = absint( $_POST['event_id'] );

	        $this->generate_badges->generate_badges($event_id);
		}  
	}

	
}

new WPEM_Name_Badges_Admin();
