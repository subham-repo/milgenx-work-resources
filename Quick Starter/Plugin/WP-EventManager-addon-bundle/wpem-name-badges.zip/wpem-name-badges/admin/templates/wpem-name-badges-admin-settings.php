<div class="wrap wp_event_manager wpem-name-badges-admin-wrap">
<h1><?php _e('WP Event Name Badges Settings', 'wpem-name-badges'); ?></h1>
<?php do_action('wp_event_name_badges_settings_before'); ?>
<div class="wpem-name-badges-setting" id="poststuff">
    <form method="post" class="wpem-name-badges-settings-form">
        <div class="wpem-name-badges-settings-field">
            <table class="form-table">
                <tbody>
                    <tr>
                        <th width="20%"><label for="event_id"><?php _e('Select Event:', 'wpem-name-badges'); ?></label></th>
                        <td>
                            <select name="event_id" id="event_id">
                                <option value=""><?php _e('Select Event', 'wpem-name-badges'); ?></option>
                                <?php foreach ($events as $event) : ?>
                                    <option value="<?php echo esc_attr($event->ID); ?>" <?php selected($event_id, $event->ID); ?>>
                                        <?php echo esc_html($event->post_title); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th width="20%"><label for="enable_on_demand_label"><?php _e('On demand badge:', 'wpem-name-badges'); ?></label></th>
                        <td>
                            <input type="checkbox" name="enable_on_demand_label" id="enable_on_demand_label" <?php checked($enable_on_demand_label, 1); ?> value="1">
                        </td>
                    </tr>
                    <?php
                    if ($enable_on_demand_label) :
                        $d_none = '';
                    else :
                        $d_none = 'd-none';
                    endif;
                    ?>
                    <tr class="<?php echo $d_none; ?>" id="on_demand_label_div">
                        <th width="20%"><label for="on_demand_label"><?php _e('Select on demand label:', 'wpem-name-badges'); ?></label></th>
                        <td>
                            <select name="on_demand_label" id="on_demand_label">
                                <option value=""><?php _e('Select label', 'wpem-name-badges'); ?>...</option>
                                <?php foreach (wpem_get_on_demand_label() as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($on_demand_label, $name); ?>>
                                        <?php echo esc_html($label); ?>
                                        <?php if ($name == 'all') : ?>
                                            <?php echo '(' . esc_html($total_attendees) . ')'; ?>
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <?php
                    if ($enable_on_demand_label) :
                        $d_none = '';
                    else :
                        $d_none = 'd-none';
                    endif;
                    ?>
                    <tr class="<?php echo $d_none; ?>" id="on_demand_label_size_div">
                        <th width="20%"><label for="on_demand_label_size"><?php _e('Select on demand label size:', 'wpem-name-badges'); ?></label></th>
                        <td>
                            <select name="on_demand_label_size" id="on_demand_label_size" data-label="<?php echo esc_attr($on_demand_label); ?>" data-label-size="<?php echo esc_attr($on_demand_label_size); ?>">
                                <option value=""><?php _e('Select label size', 'wpem-name-badges'); ?>...</option>
                                <?php if (!empty($on_demand_label)) : ?>
                                    <?php
                                    $arr_label_size = wpem_get_on_demand_label_size();
                                    $get_label_sizes = $arr_label_size[$on_demand_label];
                                    ?>
                                    <?php foreach ($get_label_sizes as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($on_demand_label_size, $name); ?>>
                                            <?php echo esc_html($label); ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th width="20%"><label for="attendees_type"><?php _e('Select Attendees:', 'wpem-name-badges'); ?></label></th>
                        <td>
                            <select name="attendees_type" id="attendees_type">
                                <?php foreach (wpem_get_attendees_type() as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($attendees_type, $name); ?>>
                                        <?php echo esc_html($label); ?>
                                        <?php if ($name == 'all') : ?>
                                            <?php echo '(' . esc_html($total_attendees) . ')'; ?>
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <?php
                    if ($attendees_type == 'ticket_type') :
                        $d_none = '';
                    else :
                        $d_none = 'd-none';
                    endif;
                    ?>
                    <tr class="<?php echo $d_none; ?>" id="ticket_type_div">
                        <th width="20%"><?php if (is_plugin_active('wp-event-manager-sell-tickets/wp-event-manager-sell-tickets.php')) : ?>
                                <label for="ticket_type"><?php _e('Ticket Type:', 'wpem-name-badges'); ?></label>
                            <?php else : ?>
                                <label for="ticket_type"><?php _e('Status Type:', 'wpem-name-badges'); ?></label>
                            <?php endif; ?>
                        </th>
                        <td>
                            <select name="ticket_type" id="ticket_type">
                                <option value=""><?php _e('Select type', 'wpem-name-badges'); ?>...</option>
                                <?php foreach (wpem_get_ticket_type() as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($ticket_type, $name); ?>>
                                        <?php echo esc_html($label); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" id="attendees_list"></td>
                    </tr>
                    <tr>
                        <th width="20%"><label for="sort_by"><?php _e('Sort Attendees By:', 'wpem-name-badges'); ?></label></th>
                        <td>
                            <select name="sort_by" id="sort_by">
                                <?php foreach (wpem_get_sort_by() as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($sort_by, $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    <tr>
                    <tr>
                        <th width="20%"><label for="badges_style"><?php _e('Select Badges Style:', 'wpem-name-badges'); ?></label></th>
                        <td>
                            <select name="badges_style" id="badges_style">
                                <?php foreach (wpem_get_badges_style() as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($badges_style, $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </tbody>
            </table>
            
            <h3 class="wpem-heading-text"><?php _e('Customize attendees badges layout', 'wpem-name-badges'); ?></h3>
            <table class="widefat fixed wp-list-table">
                <thead>
                    <tr>
                        <th>Line number</th>
                        <th>Field</th>
                        <th>Font family</th>
                        <th>Font size</th>
                        <th>Alignment</th>
                        <th>Text Color</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($registration_field)) : ?>
                        <?php foreach ($registration_field as $key => $field_value) : ?>
                            <tr>
                                <th>
                                    <?php if ($key == 1) : ?>
                                        <?php _e('Second Line:', 'wpem-name-badges'); ?>
                                    <?php elseif ($key == 2) : ?>
                                        <?php _e('Third Line:', 'wpem-name-badges'); ?>
                                    <?php elseif ($key == 3) : ?>
                                        <?php _e('Fourth Line:', 'wpem-name-badges'); ?>
                                    <?php elseif ($key == 4) : ?>
                                        <?php _e('Fifth Line:', 'wpem-name-badges'); ?>
                                    <?php else : ?>
                                        <?php _e('First Line:', 'wpem-name-badges'); ?>
                                    <?php endif; ?>
                                </th>
                                <td>
                                    <div class="wpem-form-group">
                                        <select name="registration_field[]" class="registration-field">
                                            <option value=""><?php _e('Select field', 'wpem-name-badges'); ?>...</option>
                                            <?php foreach (wpem_get_registration_form_fields() as $name => $field) : ?>
                                                <option value="<?php echo esc_attr($name); ?>" <?php selected($field_value, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </td>
                                <td>
                                    <div class="wpem-form-group">
                                        <select name="font_name[]" class="font-name">
                                            <option value=""><?php _e('Select font', 'wpem-name-badges'); ?>...</option>
                                            <?php foreach (wpem_get_font_list() as $name => $label) : ?>
                                                <option value="<?php echo esc_attr($name); ?>" <?php selected($font_name[$key], $name); ?>><?php echo esc_html($label); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </td>
                                <td>
                                    <div class="wpem-form-group">
                                        <select name="font_size[]" class="font-size">
                                            <option value=""><?php _e('Select font size', 'wpem-name-badges'); ?>...</option>
                                            <?php foreach (wpem_get_font_size() as $name => $label) : ?>
                                                <option value="<?php echo esc_attr($name); ?>" <?php selected($font_size[$key], $name); ?>><?php echo esc_html($label); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </td>
                                <td>
                                    <div class="wpem-form-group">
                                        <?php foreach (wpem_get_text_align() as $name => $label) : ?>
                                            <input type="radio" name="text_align[<?php echo $key; ?>]" value="<?php echo esc_attr($name); ?>" <?php checked($text_align[$key], $name); ?>><?php echo esc_html($label); ?>
                                        <?php endforeach; ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="wpem-form-group">
                                        <input type="color" name="text_color[<?php echo $key; ?>]" value="<?php echo esc_attr($color[$key]); ?>">
                                   
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <?php for ($i = 0; $i <= 4; $i++) : ?>
                            <tr>
                                <th>
                                    <?php if ($i == 1) : ?>
                                        <?php _e('Second Line:', 'wpem-name-badges'); ?>
                                    <?php elseif ($i == 2) : ?>
                                        <?php _e('Third Line:', 'wpem-name-badges'); ?>
                                    <?php elseif ($i == 3) : ?>
                                        <?php _e('Fourth Line:', 'wpem-name-badges'); ?>
                                    <?php elseif ($i == 4) : ?>
                                        <?php _e('Fifth Line:', 'wpem-name-badges'); ?>
                                    <?php else : ?>
                                        <?php _e('First Line:', 'wpem-name-badges'); ?>
                                    <?php endif; ?>
                                </th>
                                <td>
                                    <div class="wpem-form-group">
                                        <select name="registration_field[]" class="registration-field">
                                            <option value=""><?php _e('Select field', 'wpem-name-badges'); ?>...</option>
                                            <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                                <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </td>
                                <td>
                                    <div class="wpem-form-group">
                                        <select name="font_name[]" class="font-name">
                                            <option value=""><?php _e('Select font', 'wpem-name-badges'); ?>...</option>
                                            <?php foreach (wpem_get_font_list() as $name => $label) : ?>
                                                <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </td>
                                <td>
                                    <div class="wpem-form-group">
                                        <select name="font_size[]" class="font-size">
                                            <option value=""><?php _e('Select font size', 'wpem-name-badges'); ?>...</option>
                                            <?php foreach (wpem_get_font_size() as $name => $label) : ?>
                                                <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </td>
                                <td>
                                    <div class="wpem-form-group">
                                        <?php foreach (wpem_get_text_align() as $name => $label) : ?>
                                            <input type="radio" name="text_align[<?php echo $i; ?>]" value="<?php echo esc_attr($name); ?>" <?php checked('left', $name); ?>><?php echo esc_html($label); ?>
                                        <?php endforeach; ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="wpem-form-group">
                                        <?php foreach (wpem_get_text_align() as $name => $label) : ?>
                                            <input type="radio" name="text_align[<?php echo $i; ?>]" value="<?php echo esc_attr($name); ?>" <?php checked('left', $name); ?>><?php echo esc_html($label); ?>
                                        <?php endforeach; ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="wpem-form-group">
                                        <input type="color" name="text_color[<?php echo $key; ?>]" value="<?php echo esc_attr($color[$key]); ?>">
                                        <label for="text_color[<?php echo $key; ?>]"><?php _e('Select color', 'wpem-name-badges'); ?></label>
                                    </div>
                                </td>
                            <tr>
                            <?php endfor; ?>
                        <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="6">
                            <div class="wpem-customize-btn-flex">
                                <button type="button" class="button-primary" name="wpem_name_badges_save_settings" id="wpem_name_badges_save_settings" value="<?php esc_attr_e('Save Settings', 'wpem-name-badges'); ?>"><?php _e('Save Settings', 'wpem-name-badges'); ?></button>
                                <input type="submit" class="button-primary" name="wpem_name_badges_generate" id="wpem_name_badges_generate" value="<?php esc_attr_e('Generate Badges', 'wpem-name-badges'); ?>" />
                            </div>               
                        </td>
                    </tr>
                </tfoot>
                <table>
<div class="wpem-form-group">
    <div id="response"></div>
</div>
</div>
</form>
</div>
<?php do_action('wp_event_name_badges_settings_after'); ?>
</div>
