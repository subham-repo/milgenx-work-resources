<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Name_Badges_Settings class.
 */
class WPEM_Name_Badges_Settings {

    /**
     * wpem_badges_settings function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wpem_badges_settings() {
        $name_badges_settings = get_name_badges_settings_by_user();

        $event_id = !empty($name_badges_settings['event_id']) ? $name_badges_settings['event_id'] : '';
        $total_attendees = get_event_registration_count($event_id);

        $enable_on_demand_label = !empty($name_badges_settings['enable_on_demand_label']) ? $name_badges_settings['enable_on_demand_label'] : '';
        $on_demand_label = !empty($name_badges_settings['on_demand_label']) ? $name_badges_settings['on_demand_label'] : '';
        $on_demand_label_size = !empty($name_badges_settings['on_demand_label_size']) ? $name_badges_settings['on_demand_label_size'] : '';

        $attendees_type = !empty($name_badges_settings['attendees_type']) ? $name_badges_settings['attendees_type'] : '';
        $ticket_type = !empty($name_badges_settings['ticket_type']) ? $name_badges_settings['ticket_type'] : '';
        $selected_attende_ids = !empty($name_badges_settings['selected_attende_ids']) ? $name_badges_settings['selected_attende_ids'] : '';
        $sort_by = !empty($name_badges_settings['sort_by']) ? $name_badges_settings['sort_by'] : '';
        $badges_style = !empty($name_badges_settings['badges_style']) ? $name_badges_settings['badges_style'] : '';

        $registration_field = !empty($name_badges_settings['registration_field']) ? $name_badges_settings['registration_field'] : '';
        $font_name = !empty($name_badges_settings['font_name']) ? $name_badges_settings['font_name'] : '';
        $font_size = !empty($name_badges_settings['font_size']) ? $name_badges_settings['font_size'] : '';
        $text_align = !empty($name_badges_settings['text_align']) ? $name_badges_settings['text_align'] : '';
        $color = !empty($name_badges_settings['text_color']) ? $name_badges_settings['text_color'] : '';

        $args = [
            'post_type' => 'event_listing',
            'post_status' => 'publish',
            'posts_per_page' => -1,
        ];
        $events = get_posts($args);

        include('templates/wpem-name-badges-admin-settings.php');
       
    }

}
new WPEM_Name_Badges_Settings();
                        
