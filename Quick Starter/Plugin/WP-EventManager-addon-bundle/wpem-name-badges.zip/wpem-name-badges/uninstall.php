<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

$options = array(
		'wpem_name_badges_version',
);

foreach ( $options as $option ) {
	delete_option( $option );
}