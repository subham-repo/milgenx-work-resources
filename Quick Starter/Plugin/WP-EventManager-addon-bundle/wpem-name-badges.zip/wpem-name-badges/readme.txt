=== WP Event Manager - Name Badges ===

Contributors: wpeventmanager
Requires at least: 4.1
Tested up to: 5.8
Stable tag: 1.0.0
License: GNU General Public License v3.0

== Installation ==

To install this plugin, please refer to the guide here: http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation

== Changelog ==

= 1.0.0 =
* First release.

