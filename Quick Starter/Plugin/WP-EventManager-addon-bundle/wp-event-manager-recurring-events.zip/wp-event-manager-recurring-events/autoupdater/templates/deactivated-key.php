<div class="updated">
	<p><?php printf( __('Your licence for <strong>%s</strong> has been deactivated.', 'wp-event-manager-recurring-events'), esc_html( $this->plugin_data['Name'] ) ); ?></p>
</div>
