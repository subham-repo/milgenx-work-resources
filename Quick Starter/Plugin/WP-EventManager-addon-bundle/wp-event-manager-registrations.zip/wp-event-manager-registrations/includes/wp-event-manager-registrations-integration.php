<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP_Event_Manager_Registrations_Integration class.
 *
 * Integrates the registrations plugin with other form plugins.
 */
class WP_Event_Manager_Registrations_Integration {

	/**
	 * Constructor
	 */
	public function __construct() {
		// Integrate register with other platform		
	}
}
new WP_Event_Manager_Registrations_Integration();