<div class="event-manager-registrations-registered-notice wpem-alert wpem-alert-info">
	<?php  _e( 'You have already registered for this event.', 'wp-event-manager-registrations' ); ?>
</div>