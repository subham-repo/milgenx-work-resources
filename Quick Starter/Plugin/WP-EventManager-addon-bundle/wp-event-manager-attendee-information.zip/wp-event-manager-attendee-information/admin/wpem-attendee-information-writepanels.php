<?php

/*
* This file use to cretae fields of gam event manager at admin side.
*/
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
class WPEM_Attendee_Inforamtion_Writepanels {
    
    /**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
	
		add_filter( 'event_manager_event_listing_data_fields', array($this ,'event_listing_attendee_inforatmation_fields') );
		add_filter( 'event_manager_registrations_settings', array($this ,'event_manager_attendee_inforatmation_settings') );
		//add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
		
	}
	
	
/**
	 * event_listing_fields function.
	 *
	 * @access public
	 * @return void
	 */
	public static function event_listing_attendee_inforatmation_fields($fields) 
	{
		$event_field_count = 50;

		if( !empty($fields) )
		{
			$event_field_count = count($fields);	
		}

		$event_form_fields = get_option( 'event_manager_submit_event_form_fields' );

		if( isset($event_form_fields['event']) && !empty($event_form_fields['event']) )
		{
			$event_field_count = count($event_form_fields['event']);
		}

    	$fields['_attendee_information_type'] = array(
			'label'       => __( 'Attendee Information Collection type', 'wp-event-manager-attendee-information' ),
			'type'        => 'radio',
			'options'     => array(
							'buyer_only' => __( 'Buyer Only', 'wp-event-manager-attendee-information' ),
							'each_attendee' => __( 'Each Attendee', 'wp-event-manager-attendee-information' ),				
					        ),
			'required'    => true,
			'priority'    => $event_field_count + 1,
        );


	    //Buyer only and each attendee information field 
	    $options = WPEM_Attendee_Information_Submit_Event_Form ::get_registration_fields_as_options(); 
	    $desc = empty($options) ? __('There is no any field in registration form','wp-event-manager-attendee-information') : __('Based on selected fields, you will collect information from the attendee','wp-event-manager-attendee-information');
	    $fields['_attendee_information_fields'] =  array(
			'label'       => __( 'Attendee Information to collect', 'wp-event-manager-attendee-information' ),
			'type'        => 'multiselect',
			'required'    => true,
			'priority'    => $event_field_count + 2,
			'description' => $desc,
			'options'     =>  $options
		);

    	return $fields;							                       
	}
	
	/**
	 * attendee information setting function.
	 *
	 * @access public
	 * @return array
	 */
	public static function event_manager_attendee_inforatmation_settings($fields) {
	    $fields['attendee_inforatmation'] = array(
	        __( 'Attendee Information', 'wp-event-manager-attendee-information' ),
	        array(
	            array(
	                'name' 		=> 'event_registration_show_attendee',
	                'std' 		=> '0',
	                'label' 	=> __( 'Show Attendee', 'wp-event-manager-attendee-information' ),
	                'cb_label' 	=> __( 'Show attendee Publicly', 'wp-event-manager-attendee-information' ),
	                'desc'		=> __( 'Show attendee publicly at single event page.', 'wp-event-manager-attendee-information' ),
	                'type'      => 'checkbox'
	            ),
	        	array(
	        			'name' 		=> 'event_registration_attendee_limit',
	        			'std' 		=> '10',
	        			'label' 	=> __( 'Attendee per page', 'wp-event-manager-attendee-information' ),
	        			'cb_label' 	=> __( 'Show Attendee per page', 'wp-event-manager-attendee-information' ),
	        			'desc'		=> __( 'Show attendee publicly at single event page.', 'wp-event-manager-attendee-information' ),
	        			'type'      => 'text'
	        	)
	        )
	    );
	    
	    return $fields;
	}
}

new WPEM_Attendee_Inforamtion_Writepanels();
?>