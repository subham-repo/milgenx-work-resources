<div class="updated">
	<p><?php sprintf( __('Your licence for <strong>%s</strong> has been activated. Thanks!', 'wp-event-manager-alerts'), esc_html( $this->plugin_data['Name'] ) ); ?></p>
</div> 