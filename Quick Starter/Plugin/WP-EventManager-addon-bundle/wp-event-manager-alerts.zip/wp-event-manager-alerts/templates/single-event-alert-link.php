<div class="clear">&nbsp;</div>
<div class="event-manager-single-alert-link">

    <a class="wpem-icon-text-button" href="<?php echo esc_url( $alert_link);?>"><i class="wpem-icon-bell"></i> <?php _e( 'Alert me like this event', 'wp-event-manager-alerts' );?></a>
    
</div>
<div class="clearfix">&nbsp;</div>