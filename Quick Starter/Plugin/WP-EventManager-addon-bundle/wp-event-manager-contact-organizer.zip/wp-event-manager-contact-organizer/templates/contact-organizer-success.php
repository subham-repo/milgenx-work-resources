<p class="wpem-alert wpem-alert-success">
	<i class="wpem-icon-user-check"></i> <?php _e( 'Your email has been sent successfully', 'wp-event-manager-contact-organizer' ); ?>
</p>