<p class="wpem-alert wpem-alert-danger">
	<i class="wpem-icon-cross"></i> <?php _e( 'Something went wrong while sending email to organizer.', 'wp-event-manager-contact-organizer' ); ?>
</p>