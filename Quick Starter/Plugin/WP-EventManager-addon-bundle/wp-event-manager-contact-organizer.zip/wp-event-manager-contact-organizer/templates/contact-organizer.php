<?php
/**
 * Contact Organizer Form
 */
if (!defined('ABSPATH')) exit;

global $event_manager;
wp_enqueue_style('wp-event-manager-contact-organizer-frontend');
?>
<div class="wpem-organizer-contact-button">
    <button type="button" class="wpem-theme-button contact-organizer-button" ><?php _e('Contact Organizer', 'wp-event-manager-contact-organizer'); ?></button>
</div>

<p id="status-message" align="center"></p>

<div class="wpem-organizer-contact-form-wrapper wpem-ontact-organizer-form" style="display: none">
    <div class="wpem-organizer-contact-form">
        <form action=" <?php echo $_SERVER['REQUEST_URI']; ?> " method="post" id="contact-organizer-form" name="contact-organizer-form" class="event-manager-form wpem-form-wrapper" enctype="multipart/form-data"> 

            <?php do_action('submit_contact_organizer_form_fields_start'); ?>

            <div class="wpem-row">
                <div class="wpem-col-12"><h4 class="wpem-form-title wpem-heading-text"><?php _e('Contact Organizer', 'wp-event-manager-contact-organizer'); ?></h4></div>
                <?php foreach ($contact_organizer_fields as $key => $field) : ?>
                    <div class="wpem-col-12">
                        <div class="wpem-form-group">
                            <fieldset class="fieldset-<?php esc_attr_e($key); ?>">
                                <label for="<?php esc_attr_e($key); ?>">
                                    <?php echo $field['label'] . apply_filters('submit_event_form_required_label', $field['required'] ? '<span class="require-field">*</span>' : ' <small>' . __('(optional)', 'wp-event-manager-contact-organizer') . '</small>', $field); ?>
                                </label>
                                <div class="field <?php echo $field['required'] ? 'required-field' : ''; ?>">
                                    <?php get_event_manager_template('form-fields/' . $field['type'] . '-field.php', array('key' => $key, 'field' => $field), EVENT_MANAGER_PLUGIN_DIR . '/templates/'); ?>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php do_action('submit_contact_organizer_form_fields_end'); ?>

            <div class="contact-organizer-buttons">
                <p>
                    <input type="hidden" id="contact-organizer-event-id" name="contact-organizer-event-id" value="<?php echo $event_id; ?>"/>
                    <input type="hidden" id="contact-organizer-id" name="contact-organizer-id" value="<?php echo $organizer_id; ?>"/>
                    <input type="hidden" name="event_manager_form" value="<?php echo $form; ?>" />

                    <button type="button" class="wpem-theme-button cancel-contact-organizer-button" value="<?php esc_attr_e($cancel_button_text); ?>"><?php esc_attr_e($cancel_button_text); ?></button>

                    <button type="submit" id="send_mail" name="send_mail" class="wpem-theme-button" value="<?php _e('Send', 'wp-event-manager-contact-organizer'); ?>"><?php _e('Send', 'wp-event-manager-contact-organizer'); ?></button>
                </p>
            </div>
            
        </form> <!-- form  -->
    </div>
</div>
