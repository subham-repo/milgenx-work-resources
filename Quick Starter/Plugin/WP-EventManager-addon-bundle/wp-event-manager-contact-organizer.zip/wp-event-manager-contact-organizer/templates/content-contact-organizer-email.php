<!DOCTYPE html>
<body>

    <table style="overflow: hidden; border: 1px solid rgb(45, 92, 112); border-radius: 6px;" width="700" cellspacing="0" cellpadding="10" border="0" align="center">
        <tr>
            <td style="background: rgb(45, 92, 112) none repeat scroll 0% 0%; color: rgb(255, 255, 255); text-align: center; padding: 20px; font-family: arial; text-transform: uppercase; font-weight: bold; font-size: 20px;"><?php echo get_bloginfo('name'); ?></td>
        </tr>
        <tr>

            <td style="padding: 20px; font-family: arial; font-size: 18px; color: rgb(51, 51, 51);">
                <?php if (!empty($fields))
                {
                    foreach ($fields as $key => $value)
                    {
                        ?>
                        <strong><?php printf(__($value['label'], 'wp-event-manager-contact-organizer')); ?></strong> <?php _e($value['value'], 'wp-event-manager-contact-organizer'); ?><br/>
                        <?php
                    }
                }
                ?>
            </td>
        </tr>
    </table>
    <!-- main container end -->
</body>
</html>