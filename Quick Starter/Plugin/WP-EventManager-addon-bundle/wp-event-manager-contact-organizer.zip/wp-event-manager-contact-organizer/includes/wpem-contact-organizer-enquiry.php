<?php
/**
 * WPEM_Contact_Organizer_Enquiry class.
 */
class WPEM_Contact_Organizer_Enquiry
{
	private $fields     = array();
	private $error      = '';
	private static $secret_dir = '';

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
		add_action( 'wp', array( $this, 'send_mail_handler' ) );
		add_action( 'single_event_listing_organizer_action_end', array( $this, 'contact_organizer_form' ) );
		self::$secret_dir = uniqid();
	}

	/**
	 * frontend_scripts function.
	 *
	 * @access public
	 * @return void
	 */
	public function frontend_scripts() {    
	    wp_register_style( 'wp-event-manager-contact-organizer-frontend', WPEM_CONTACT_ORGANIZER_PLUGIN_URL.'/assets/css/frontend.min.css');
		wp_register_script('wp-event-manager-contact-organizer-contact',WPEM_CONTACT_ORGANIZER_PLUGIN_URL . '/assets/js/contact.min.js', array('jquery','wp-event-manager-common'), WPEM_CONTACT_ORGANIZER_VERSION, true ); 		
	}

	/**
	 * Sanitize a text field, but preserve the line breaks! Can handle arrays.
	 * @param  string $input
	 * @return string
	 */
	private function sanitize_text_field_with_linebreaks( $input ) {
		if ( is_array( $input ) ) {
			foreach ( $input as $k => $v ) {
				$input[ $k ] = $this->sanitize_text_field_with_linebreaks( $v );
			}
			return $input;
		} else {
			return str_replace( '[nl]', "\n", sanitize_text_field( str_replace( "\n", '[nl]', strip_tags( stripslashes( $input ) ) ) ) );
		}
	}

	/**
	 * Handle the book mark form
	 */
	public function send_mail_handler() 
	{
		if( isset( $_POST['send_mail']) && !empty( $_POST['send_mail'] ) ) :
		    try 
			{
		        if( isset($_POST['contact-organizer-event-id']) && !empty($_POST['contact-organizer-event-id']))
		        {
		            $fields = 	get_contact_organizer_form_fields();
		            $values = array();
					$event_id = $_POST['contact-organizer-event-id'];
		            $organizer_id = $_POST['contact-organizer-id'];
					$event    = get_post( $event_id );
					$meta   = array();

		            // Validate posted fields
					foreach ( $fields as $key => $field ) {
						$field['rules'] = array_filter( isset( $field['rules'] ) ? (array) $field['rules'] : array() );

						switch( $field['type'] ) {
							case "file" :
								$values[ $key ] = $this->upload_file( $key, $field );

								if ( is_wp_error( $values[ $key ] ) ) {
									throw new Exception( $field['label'] . ': ' . $values[ $key ]->get_error_message() );
								}
							break;
							default :
								$values[ $key ] = isset( $_POST[ $key ] ) ? $this->sanitize_text_field_with_linebreaks( $_POST[ $key ] ) : '';
							break;
						}

						// Validate required
						if ( $field['required'] && empty( $values[ $key ] ) ) {
							throw new Exception( sprintf( __( ' "%s" is a required field', 'wp-event-manager-contact-organizer' ), $field['label'] ) );
						}

						// Extra validation rules
						if ( ! empty( $field['rules'] ) && ! empty( $values[ $key ] ) ) {
							foreach( $field['rules'] as $rule ) {
								switch( $rule ) {
									case 'email' :
									case 'from_email' :
										if ( ! is_email( $values[ $key ] ) ) {
											throw new Exception( $field['label'] . ': ' . __( 'Please provide a valid email address', 'wp-event-manager-contact-organizer' ) );
										}
									break;
									case 'numeric' :
										if ( ! is_numeric( $values[ $key ] ) ) {
											throw new Exception( $field['label'] . ': ' . __( 'Please enter a number', 'wp-event-manager-contact-organizer' ) );
										}
									break;
								}
							}
						}
					}

					// Validation hook
					$valid = apply_filters( 'contact_organizer_form_validate_fields', true, $fields, $values );

					if ( is_wp_error( $valid ) ) {
						throw new Exception( $valid->get_error_message() );
					}


					foreach ( $fields as $key => $field ) {
						if ( empty( $values[ $key ] ) ) {
							continue;
						}

						$field['rules'] = array_filter( isset( $field['rules'] ) ? (array) $field['rules'] : array() );

						if ( in_array( 'from_name', $field['rules'] ) ) {
							$from_name = $values[ $key ];
						}

						if ( in_array( 'from_email', $field['rules'] ) ) {
							$from_email = $values[ $key ];
						}

						if ( 'file' === $field['type'] ) {
							if ( ! empty( $values[ $key ] ) ) {
								$index = 1;
								foreach ( $values[ $key ] as $attachment ) {
									if ( ! is_wp_error( $attachment ) ) {
										if ( in_array( 'attachment', $field['rules'] ) ) {
											$meta['_attachment'][]      = $attachment->url;
											$meta['_attachment_file'][] = $attachment->file;
										} else {
											$meta[ $key. ' ' . $index ] = $attachment->url;
										}
									}
									$index ++;
								}
							}
						}
						elseif ( 'checkbox' === $field['type'] ) {
							$meta[ $key ] = $values[ $key ] ? __( 'Yes', 'wp-event-manager-contact-organizer' ) : __( 'No', 'wp-event-manager-contact-organizer' );
						}
						elseif ( 'multiselect' === $field['type'] ) {						
							if( is_array( $values[ $key ] ) )
							{
								$meta[ $key ] = $values[ $key ];
							}
							else
							{
								$meta[ $key ] = explode(',', $values[ $key ]);
							}
						}
						/*
						elseif ( is_array( $values[ $key ] ) ) {
							$meta[ $key ] = implode( ', ', $values[ $key ] );
						}
						*/
						else {
							$meta[ $key ] = $values[ $key ];
						}
					}
					//set rule value in meta so we can use those meta velue while sending email in notification
					$meta['contact_person_nmae']  = $from_name;
					$meta['contact_person_email'] = $from_email;
					$meta = apply_filters( 'event_manager_organizer_form_posted_meta', $meta, $values );

		            if(isset($organizer_id) && !empty($organizer_id))
		            {
		            	$to = get_event_organizer_email( $organizer_id );
		            }
		            else
		            {
		            	$to = get_event_organizer_email( $event_id );	
		            }

		            if(!empty($to) && is_email($to))
		            {
		            	do_action( 'event_manager_contact_organizer_send_mail_before', $meta, $event_id, $organizer_id );

		                $contact_organizer_notification = apply_filters( 'send_contact_organizer_notification',get_option('enable_event_manager_contact_organizer_notification',true));
						if ( $contact_organizer_notification ) {
							//send email to organizer
							$organizer_email 		= $to;
							if ( $organizer_email ) {
								$existing_shortcode_tags = $GLOBALS['shortcode_tags'];
								remove_all_shortcodes();
								event_manager_contact_organizer_email_add_shortcodes( array(
										'event_id'              => $event_id,
										'organizer_id'          => $organizer_id,
										'user_id'               => get_current_user_id(),
										'contact_person_name'   => $from_name,
										'contact_person_email'  => $from_email,
										'meta'                  => $meta
								) );
								$subject = do_shortcode( get_contact_organizer_email_subject() );
								$message = do_shortcode( get_contact_organizer_email_content() );
								wpem_send_contact_organizer_email($organizer_email, $subject,$message, $existing_shortcode_tags, 'organizer');
								$GLOBALS['shortcode_tags'] = $existing_shortcode_tags;
							}
						}

						$contact_attendee_notification = apply_filters( 'send_contact_attendee_notification',get_option('enable_event_manager_contact_attendee_notification',true));
						if ( $contact_attendee_notification ) {
							//send email to organizer
							$attendee_email 		= $from_email;
							if ( $attendee_email ) {
								$existing_shortcode_tags = $GLOBALS['shortcode_tags'];
								remove_all_shortcodes();
								event_manager_contact_organizer_email_add_shortcodes( array(
										'event_id'              => $event_id,
										'organizer_id'          => $organizer_id,
										'user_id'             	=> get_current_user_id(),
										'contact_person_name'   => $from_name,
										'contact_person_email'  => $from_email,
										'meta'                	=> $meta
								) );
								$subject = do_shortcode( get_contact_person_email_subject() );
								$message = do_shortcode( get_contact_person_email_content() );
								wpem_send_contact_organizer_email($attendee_email, $subject, $message, $existing_shortcode_tags, 'attendee');
								$GLOBALS['shortcode_tags'] = $existing_shortcode_tags;
							}
						}

						do_action( 'event_manager_contact_organizer_send_mail_after', $meta, $event_id, $organizer_id );
		                
		                add_action('event_content_start', array($this,'contact_organizer_form_success') );
		                add_action('organizer_content_start', array($this,'contact_organizer_form_success') );
		            }
		            else
		            {
		                add_action('event_content_start', array($this,'contact_organizer_form_error') );
		                add_action('organizer_content_start', array($this,'contact_organizer_form_error') );
		            }
		        }
		    } 
		    catch ( Exception $e ) 
		    {
		        $this->error = $e->getMessage();
		        add_action('event_content_start', array($this,'contact_organizer_form_error') );
		        add_action('organizer_content_start', array($this,'contact_organizer_form_error') );
		    }
	    endif;
	}

	/**
	 * Upload a file
	 * @return  string or array
	 */
	public function upload_file( $field_key, $field ) {
		if ( isset( $_FILES[ $field_key ] ) && ! empty( $_FILES[ $field_key ] ) && ! empty( $_FILES[ $field_key ]['name'] ) ) {
			if ( ! empty( $field['allowed_mime_types'] ) ) {
				$allowed_mime_types = $field['allowed_mime_types'];
			} else {
				$allowed_mime_types = get_allowed_mime_types();
			}

			$files           = array();
			$files_to_upload = event_manager_prepare_uploaded_files( $_FILES[ $field_key ] );

			add_filter( 'event_manager_upload_dir', array( $this, 'upload_dir' ), 10, 2 );

			foreach ( $files_to_upload as $file_to_upload ) {
				$uploaded_file = event_manager_upload_file( $file_to_upload, array( 'file_key' => $field_key ) );

				if ( is_wp_error( $uploaded_file ) ) {
					throw new Exception( $uploaded_file->get_error_message() );
				} else {
					if ( ! isset( $uploaded_file->file ) ) {
						$uploaded_file->file = str_replace( site_url(), ABSPATH, $uploaded_file->url );
					}
					$files[] = $uploaded_file;
				}
			}

			remove_filter( 'event_manager_upload_dir', array( $this, 'upload_dir' ), 10, 2 );

			return $files;
		}
	}

	/**
	 * Filter the upload directory
	 */
	public static function upload_dir( $pathdata ) {
		return 'event_contact_organizer/' . self::$secret_dir;
	}

	/**
	 * Show the contact organizer form
	 */
	public function contact_organizer_form($organizer_id = '') {
		global $post, $event_preview;
		if ( $event_preview ) {
			return;
		}
		ob_start();
		wp_enqueue_script('wp-event-manager-contact-organizer-contact');
		wp_localize_script( 'wp-event-manager-contact-organizer-contact', 'event_manager_contact_organizer_contact', array( 
		        	'ajax_url' => WP_Event_Manager_Ajax::get_endpoint()		        	       	
		 )); 	
		get_event_manager_template( 'contact-organizer.php', array(
			'form'               		=> 'contact-organizer',
			'event_id'             		=> get_the_ID(),
			'organizer_id'             	=> $organizer_id,
			'contact_organizer_fields'  => get_contact_organizer_form_fields(),
			'cancel_button_text' 		=> apply_filters( 'contact_organizer_form_cancel_button_text', __( 'Cancel', 'wp-event-manager-contact-organizer' ) ),
			'send_button_text' 			=> apply_filters( 'contact_organizer_form_send_button_text', __( 'Send', 'wp-event-manager-contact-organizer' ) )),
			 'wp-event-manager-contact-organizer',
			  WPEM_CONTACT_ORGANIZER_PLUGIN_DIR . '/templates/' );	
		echo ob_get_clean();
	}
	
	/**
	 * Show the notification when email sent successfully
	 * @param
	 * @return
	 */
	public function contact_organizer_form_success(){
		//Successful, show next step
		get_event_manager_template( 'contact-organizer-success.php', array(), 'wp-event-manager-contact-organizer', WPEM_CONTACT_ORGANIZER_PLUGIN_DIR . '/templates/' );
	}
	
	/**
	 * Show the notification when email failed
	 * @param
	 * @return
	 */
	public function contact_organizer_form_error(){

		//error, show next step
		if ( $this->error ) {
			echo '<p class="wpem-alert wpem-alert-danger"><i class="wpem-icon-cross"></i> ' . esc_html( $this->error ) . '</p>';
		}
		else
		{
			get_event_manager_template( 'contact-organizer-fail.php', array(), 'wp-event-manager-contact-organizer', WPEM_CONTACT_ORGANIZER_PLUGIN_DIR . '/templates/' );	
		}
	}
}

new WPEM_Contact_Organizer_Enquiry();
