<?php
/**
 * Get default form fields
 * @return array
 */
function get_contact_organizer_default_form_fields() {
	return apply_filters('contact_organizer_default_form_fields',
	array(
			'contact_person_name' => array(
					'label'=>__( 'Contact person name', 'wp-event-manager-contact-organizer' ),
					'default' => '',
					'type'  => 'text',
					'required'=>true,
					'placeholder' => __( 'Please enter your name', 'wp-event-manager-contact-organizer' ),
					'priority'    => 1,
					'rules'       => array( 'from_name' )
			),
			'contact_person_email' => array(
					'label'=> __( 'Contact person email', 'wp-event-manager-contact-organizer' ),
					'type'  => 'text',
					'required'=>true,
					'placeholder' => __( 'Please enter your email address', 'wp-event-manager-contact-organizer' ),
					'priority'    => 2,
					'rules'       => array( 'from_email' )
			),
			'contact_person_message' => array(
					'label'=> __( 'Contact person message', 'wp-event-manager-contact-organizer' ),
					'type'  => 'textarea',
					'required'=>true,
					'placeholder' => __( 'Please enter your message', 'wp-event-manager-contact-organizer' ),
					'priority'    => 3
			)
	));
}

/**
 * Get the form fields for the registration form
 * @return array
 */
function get_contact_organizer_form_fields( $suppress_filters = true ) {
	$option = get_option( 'event_manager_contact_organizer_form_fields', get_contact_organizer_default_form_fields() );

	return $suppress_filters ? $option : apply_filters( 'contact_organizer_form_fields', $option );
}

/**
 * Get the default email subject
 * @return string
 */
function get_contact_organizer_default_email_subject() {
	return __( "New Enquiry for [event_title] Event", 'wp-event-manager-contact-organizer' );
}

/**
 * Get email content
 * @return string
 */
function get_contact_organizer_email_subject() {
	return apply_filters( 'contact_organizer_email_subject', get_option( 'event_manager_contact_organizer_email_subject', get_contact_organizer_default_email_subject() ) );
}

/**
 * Get the default email content
 * @return string
 */
function get_contact_organizer_default_email_content() {
	$message = <<<EOF
Hello

A persone ([contact_person_name]) has submitted their enquiry for the event "[event_title]".

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

[contact_person_message]

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

You can contact them directly at: [contact_person_email]
EOF;
	return $message;
}

/**
 * Get email content
 * @return string
 */
function get_contact_organizer_email_content() {
	return apply_filters( 'contact_organizer_email_content', get_option( 'event_manager_contact_organizer_email_content', get_contact_organizer_default_email_content() ) );
}

/**
 * Get the default email subject
 * @return string
 */
function get_contact_person_default_email_subject() {
	return __( "Your Enquiry for [event_title] Event", 'wp-event-manager-contact-organizer' );
}

/**
 * Get email content
 * @return string
 */
function get_contact_person_email_subject() {
	return apply_filters( 'contact_person_email_subject', get_option( 'event_manager_contact_person_email_subject', get_contact_person_default_email_subject() ) );
}

/**
 * Get the default email content
 * @return string
 */
function get_contact_person_default_email_content() {
	$message = <<<EOF
Hello [contact_person_name]

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Thank you for showing interest in our event - "[event_title]".

We have received your enquiry.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Regards - [organizer_name]
[organizer_email]
EOF;
	return $message;
}

/**
 * Get email content
 * @return string
 */
function get_contact_person_email_content() {
	return apply_filters( 'contact_person_email_content', get_option( 'event_manager_contact_person_email_content', get_contact_person_default_email_content() ) );
}

/**
 * Get tags to dynamically replace in the notification email
 * @return array
 */
function get_contact_organizer_email_tags() {
	$tags = array(
		'contact_person_name'	=> __( 'Contact person name', 'wp-event-manager-contact-organizer' ),
		'contact_person_email'  => __( 'Contact person email', 'wp-event-manager-contact-organizer' ),		
		'contact_person_message' => __( 'Contact person message', 'wp-event-manager-contact-organizer' ),		
		'user_id' 			  => __( 'User ID of attendee', 'wp-event-manager-contact-organizer' ),		
		'meta_data'           => __( 'All custom form fields in list format', 'wp-event-manager-contact-organizer' ),
		'event_id'            => __( 'Event ID', 'wp-event-manager-contact-organizer' ),
		'event_title'         => __( 'Event Title', 'wp-event-manager-contact-organizer' ),
		'event_dashboard_url' => __( 'URL to the frontend event dashboard page', 'wp-event-manager-contact-organizer' ),
	    'event_url'           => __( 'URL to the  current event', 'wp-event-manager-contact-organizer' ),
		'organizer_name'      => __( 'Name of the organizer which submitted the event listing', 'wp-event-manager-contact-organizer' ),
		'organizer_email'     => __( 'Email of the organizer which submitted the event listing', 'wp-event-manager-contact-organizer' ),
		'event_post_meta'     => __( 'Some meta data from the event. e.g. <code>[event_post_meta key="_event_location"]</code>', 'wp-event-manager-contact-organizer' )
	);

	foreach ( get_contact_organizer_form_fields() as $key => $field ) {
		if ( isset( $tags[ $key ] ) ) {
			continue;
		}
		if ( in_array( 'from_name', $field['rules'] ) || in_array( 'from_email', $field['rules'] ) ) {
			continue;
		}
		$tags[ $key ] = sprintf( __( 'Custom field named "%s"', 'wp-event-manager-contact-organizer' ), $field['label'] );
	}

	return apply_filters('contact_organizer_email_tags',$tags);
}

/**
 * Shortcode handler
 * @param  array $atts
 * @return string
 */
function event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $value ) {
	$atts = shortcode_atts( array(
		'prefix' => '',
		'suffix' => ''
	), $atts );

	if ( ! empty( $value ) ) {
		if(is_array($value)){
			$new_value = '';
			foreach ($value as  $val) {
				$new_value.= wp_kses_post( $atts['prefix'] ).$val. wp_kses_post( $atts['suffix'] );
			}
			return $new_value;
		}
		
		else
			return wp_kses_post( $atts['prefix'] ) . $value . wp_kses_post( $atts['suffix'] );
	}
}

/**
 * Add shortcodes for email content
 * @param  array $data
 */
function event_manager_contact_organizer_email_add_shortcodes( $data ) {
	extract( $data );

	$event_title         = strip_tags( get_the_title( $event_id ) );
	$dashboard_id      = get_option( 'event_manager_event_dashboard_page_id' );
	$event_dashboard_url = $dashboard_id ? htmlspecialchars_decode( add_query_arg( array( 'action' => 'show_registrations', 'event_id' => $event_id ), get_permalink( $dashboard_id ) ) ) : '';
	$event_url 			= get_permalink($event_id);
	$meta_data         = array();
	$organizer_name      = get_organizer_name( $organizer_id );
	$organizer_email      = get_event_organizer_email( $organizer_id );
	$user_id           = $data['user_id'];

	add_shortcode( 'contact_person_name', function( $atts, $content = '' ) use( $contact_person_name ) {
		return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $contact_person_name );
	} );
	add_shortcode( 'contact_person_email', function( $atts, $content = '' ) use( $contact_person_email ) {
		return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $contact_person_email );
	} );	
	add_shortcode( 'event_id', function( $atts, $content = '' ) use( $event_id ) {
		return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $event_id );
	} );
	add_shortcode( 'event_title', function( $atts, $content = '' ) use( $event_title ) {
		return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $event_title );
	} );
    add_shortcode( 'event_url', function( $atts, $content = '' ) use( $event_url ) {
        return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $event_url );
    } );
	add_shortcode( 'organizer_name', function( $atts, $content = '' ) use( $organizer_name ) {
		return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $organizer_name );
	} );
	add_shortcode( 'organizer_email', function( $atts, $content = '' ) use( $organizer_email ) {
		return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $organizer_email );
	} );
	add_shortcode( 'user_id', function( $atts, $content = '' ) use( $user_id ) {
		return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $user_id );
	} );
	add_shortcode( 'event_post_meta', function( $atts, $content = '' ) use( $event_id ) {
		$atts  = shortcode_atts( array( 'key' => '' ), $atts );
		$value = !empty($atts['key']) ? get_post_meta( $event_id, sanitize_text_field( $atts['key'] ), true ) : '';
		return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $value );
	} );

	foreach ( get_contact_organizer_form_fields() as $key => $field ) {
		if (  in_array( 'from_name', $field['rules'] ) || in_array( 'from_email', $field['rules'] ) ) {
			continue;
		}

		$value = isset( $meta[ $key  ] ) ? $meta[ $key  ] : '';

		if($field['type'] === 'multiselect' && !empty($value))
		{
			$meta_data[ $key ] = implode( ', ', $value);
			$value = implode( ', ', $value);
		}
		else
		{
			$meta_data[ $key ] = $value;	
		}

		add_shortcode( $key, function( $atts, $content = '' ) use( $value ) {
			return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $value );
		} );
	}

	$meta_data         = array_filter( $meta_data );
	$meta_data_strings = array();
	foreach ( $meta_data as $label => $value ) {
		$meta_data_strings[] = $label . ': ' . $value;
	}
	$meta_data_strings = implode( "\n", $meta_data_strings );

	add_shortcode( 'meta_data', function( $atts, $content = '' ) use( $meta_data_strings ) {
		return event_manager_contact_organizer_email_shortcodes_handler( $atts, $content, $meta_data_strings );
	} );

	do_action( 'event_manager_contact_organizer_email_add_shortcodes', $data );
}

if ( ! function_exists( 'wpem_send_contact_organizer_email' ) ) {
	/**
	 *  Registration email
	 * @param  $send_to,$subject,$message,$existing_shortcode_tags,$notification_hook
	 * @return int
	 */
	function wpem_send_contact_organizer_email( $send_to, $subject, $message, $existing_shortcode_tags, $notification_hook = '' ){
		
		$message = str_replace( "\n\n\n\n", "\n\n", implode( "\n", array_map( 'trim', explode( "\n", $message ) ) ) );
		$is_html = ( $message != strip_tags( $message ) );
		// Does this message contain formatting already?
		if ( $is_html && ! strstr( $message, '<p' ) && ! strstr( $message, '<br' ) ) {
			//$message = nl2br( $message );
		}

		$message = nl2br( $message );
		
		$headers =  apply_filters("create_event_manager_contact_organizer_{$notification_hook}_notification_header",array('Content-Type: text/html; charset=UTF-8'));

		wp_mail(
				apply_filters( "create_event_manager_contact_organizer_{$notification_hook}_notification_recipient", $send_to),
				apply_filters( "create_event_manager_contact_organizer_{$notification_hook}_notification_subject", $subject ),
				apply_filters( "create_event_manager_contact_organizer_{$notification_hook}_notification_message", $message ),
				apply_filters( "create_event_manager_contact_organizer_{$notification_hook}_notification_headers", $headers )
				);
	}
}
