<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

$options = array(
	'enable_event_manager_contact_organizer_notification',
	'enable_event_manager_contact_attendee_notification',
	'event_manager_contact_organizer_form_fields',
	'event_manager_contact_organizer_email_content',
	'event_manager_contact_organizer_email_subject',
	'event_manager_contact_person_email_content',
	'event_manager_contact_person_email_subject',
);

foreach ( $options as $option ) {
	delete_option( $option );
}
