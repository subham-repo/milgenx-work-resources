var ContactOrganizer = function ()
{
    /// <summary>Constructor function of the contact to the organizer class.</summary>
    /// <since>1.0.0</since>
    /// <returns type="ContactOrganizer" />

    return {
        /// <summary>
        /// Initializes the ContactOrganizer.
        /// </summary>
        /// <returns type="initialization settings" />
        /// <since>1.0.0</since>
        init: function ()
        {
            Common.logInfo("ContactOrganizer.init...");
            jQuery('.contact-organizer-button').on('click', this.actions.showContactOragnizerForm);
            jQuery('#submit-contact-organizer-button').on('click', this.actions.validateContactOrganizerForm);
            jQuery('.cancel-contact-organizer-button').on('click', this.actions.cancelContactOrganizerForm);
        },

        actions:
                {
                    /// <summary>
                    /// show contact organizer form.
                    ///  </summary>
                    /// <param name="parent" type="Event"></param>
                    /// <returns type="actions" />
                    /// <since>1.0.0</since>
                    showContactOragnizerForm: function (event)
                    {
                        Common.logInfo("ContactOrganizer.actions.showContactOragnizerForm...");
                        jQuery(this).toggleClass("wpem-active-button");

                        jQuery(this).closest('.wpem-organizer-contact-actions').find('.wpem-ontact-organizer-form').slideToggle("slow");
                        event.preventDefault();
                    },

                    /// <summary>
                    /// Cancel button click for close popup window.
                    ///  </summary>
                    /// <param name="parent" type="Event"></param>
                    /// <returns type="actions" />
                    /// <since>1.0.0</since>
                    cancelContactOrganizerForm: function (event)
                    {
                        Common.logInfo("ContactOrganizer.actions.cancelContactOrganizerForm...");
                        jQuery('#wpem_contact_organizer').removeClass("wpem-active-button");
                        jQuery(this).closest('.wpem-organizer-contact-actions').find('.wpem-ontact-organizer-form').slideUp("slow");
                        event.preventDefault();
                    },

                    /// <summary>
                    /// Validate contact organizer form fields before submitting a form.
                    /// Make sure that user has entered correct username.
                    ///  </summary>
                    /// <param name="parent" type="Event"></param>
                    /// <returns type="actions" />
                    /// <since>1.0.0</since>

                    validateContactOrganizerForm: function (event)
                    {
                        Common.logInfo("ContactOrganizer.actions.validateContactOrganizerForm...");
                        event.preventDefault();
                        //Clear old errors messages
                        jQuery('.error-red-message').remove();
                        jQuery('#contact-organizer-form  input').removeClass('error-red-border');
                        var flag = true;
                        var name = jQuery('form#contact-organizer-form #contact_person_name').val();
                        var email = jQuery('form#contact-organizer-form #contact_person_email').val();
                        var message = jQuery('form#contact-organizer-form #contact_person_message').val();

                        //checks for  contact person name.
                        if (name == null || name == '' || name.length < 3)
                        {
                            jQuery('#contact_person_name').removeClass('error-red-border');
                            jQuery('#contact_person_name').addClass('error-red-border');
                            jQuery('#contact_person_name').focus();
                            jQuery('#contact_person_name').after('<span class="error-red-message">Please enter your full name</span>');
                            flag = false;

                        } else
                        {
                            jQuery('#contact_person_name').removeClass('error-red-border');
                        }

                        //checks for valid email id.
                        if (!Common.validateEmail(email))
                        {
                            jQuery('#contact_person_email').removeClass('error-red-border');
                            jQuery('#contact_person_email').addClass('error-red-border');
                            jQuery('#contact_person_email').focus();
                            jQuery('#contact_person_email').after('<span class="error-red-message">Please enter your valid email address</span>');
                            flag = false;
                        } else
                        {
                            jQuery('#contact_person_email').removeClass('error-red-border');

                        }

                        //checks for message.
                        if (message == '')
                        {
                            jQuery('#contact_person_message').removeClass('error-red-border');
                            jQuery('#contact_person_message').addClass('error-red-border');
                            jQuery('#contact_person_message').focus();
                            jQuery('#contact_person_message').after('<span class="error-red-message">Please enter your message.</span>');
                            flag = false;
                        } else
                        {
                            jQuery('#contact_person_message').removeClass('error-red-border');
                        }

                        return flag;
                    }
                } //end of the actions

    } //end of the return
};

ContactOrganizer = ContactOrganizer();
jQuery(document).ready(function ($)
{
    ContactOrganizer.init();
});