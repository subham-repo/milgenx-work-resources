<?php

/**
 * WPEM_Contact_Organizer_Admin class.
 */
class WPEM_Contact_Organizer_Admin {

    /**
     * Constructor
     */
    public function __construct()
    {
        include_once('wpem-contact-organizer-form-editor.php');
        $this->form_editor = new WPEM_Contact_Organizer_Form_Editor();

        add_action('admin_menu', array($this, 'admin_menu'), 20);
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));

        add_filter( 'event_manager_google_recaptcha_settings', array($this, 'google_recaptcha_settings') );
    }

    /**
     * Add form editor menu item
     */
    public function admin_menu()
    {
        add_submenu_page('edit.php?post_type=event_listing', __('Contact Organizer Form', 'wp-event-manager-contact-organizer'), __('Contact Organizer Form', 'wp-event-manager-contact-organizer'), 'manage_options', 'contact-organizer-form-editor', array($this->form_editor, 'output'), 5);
    }

    /**
     * Register scripts
     */
    public function admin_enqueue_scripts()
    {
        wp_register_style( 'wp-event-manager-contact-organizer-admin', WPEM_CONTACT_ORGANIZER_PLUGIN_URL . '/assets/css/admin.css', '', WPEM_CONTACT_ORGANIZER_VERSION );
        
        wp_register_script('chosen', EVENT_MANAGER_PLUGIN_URL . '/assets/js/jquery-chosen/chosen.jquery.min.js', array('jquery'), '1.1.0', true);

        wp_register_script('wp-event-manager-contact-organizer-form-editor', WPEM_CONTACT_ORGANIZER_PLUGIN_URL . '/assets/js/form-editor.min.js', array('jquery', 'jquery-ui-sortable', 'chosen'), WPEM_CONTACT_ORGANIZER_VERSION, true);

        wp_localize_script('wp-event-manager-contact-organizer-form-editor', 'wp_event_manager_guest_list_form_editor', array(
            'cofirm_delete_i18n' => __('Are you sure you want to delete this row?', 'wp-event-manager-contact-organizer'),
            'cofirm_reset_i18n'  => __('Are you sure you want to reset your changes? This cannot be undone.', 'wp-event-manager-contact-organizer')
        ));
    }

    public function google_recaptcha_settings($settings) {

        $settings[1][] = array(
                    'name'       => 'enable_event_manager_google_recaptcha_submit_contact_organizer_form',
                    'std'        => '1',
                    'label'      => __( 'Enable reCAPTCHA for Submit Contact Organizer Form', 'wp-event-manager-registrations' ),
                    'cb_label'   => __( 'Disable this to remove reCAPTCHA for Submit Contact Organizer Form.', 'wp-event-manager-registrations' ),
                    'desc'       => '',
                    'type'       => 'checkbox',
                    'attributes' => array(),
                );

        return $settings;
    }

}

new WPEM_Contact_Organizer_Admin();
