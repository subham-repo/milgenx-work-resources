<?php

/**
 * WPEM_Contact_Organizer_Form_Editor class.
 */
class WPEM_Contact_Organizer_Form_Editor {

    /**
     * Output the screen
     */
    public function output()
    {
        $tabs = array(
            'contact-organizer-settings'    => __('Contact Organizer', 'wp-event-manager-contact-organizer'),
            'fields'                        => __('Form Fields', 'wp-event-manager-contact-organizer'),
            'contact-organizer-notification' => __('Contact Organizer Notification', 'wp-event-manager-contact-organizer'),
            'contact-person-notification' => 'Contact Person Notification'
        );

        $tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'contact-organizer-settings';

        wp_enqueue_style('chosen');
        wp_enqueue_style('wp-event-manager-contact-organizer-admin');

        wp_enqueue_script('wp-event-manager-contact-organizer-form-editor');
        ?>
        <div class="wrap wp-event-manager-contact-organizer-form-editor">
            <h1 class="wp-heading-inline"><?php echo $tabs[$tab]; ?></h1>

            <div class="wpem-wrap wp-event-manager-contact-organizer-form-editor">
                <h2 class="nav-tab-wrapper">
                    <?php
                    foreach ($tabs as $key => $value)
                    {
                        $active = ( $key == $tab ) ? 'nav-tab-active' : '';
                        echo '<a class="nav-tab ' . $active . '" href="' . admin_url('edit.php?post_type=event_listing&page=contact-organizer-form-editor&tab=' . esc_attr($key)) . '">' . esc_html($value) . '</a>';
                    }
                    ?>
                </h2>
                <form method="post" id="mainform" action="edit.php?post_type=event_listing&page=contact-organizer-form-editor&tab=<?php echo esc_attr($tab); ?>">
                    <?php
                    switch ($tab)
                    {
                        case 'contact-organizer-notification' :
                            $this->contact_organizer_notification_editor();
                            break;
                        case 'contact-person-notification' :
                            $this->contact_attendee_notification_editor();
                            break;
                        case 'contact-organizer-settings' :
                            $this->contact_organizer_settings();
                            break;
                        default :
                            $this->form_editor();
                            break;
                    }
                    ?>
                    <?php wp_nonce_field('save-' . $tab); ?>
                </form>
            </div>
        </div>
        <?php
    }

    /**
     * contact organizer settings
     */
    private function contact_organizer_settings()
    {
        if (!empty($_POST) && !empty($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'save-contact-organizer-settings'))
        {
            echo $this->contact_organizer_settings_save();
        }

        $enable_contact_organizer_notification = get_option('enable_event_manager_contact_organizer_notification');
        $enable_contact_attendee_notification = get_option('enable_event_manager_contact_attendee_notification');
        ?>

        <div class="wp-event-contact-organizer-content-wrapper">
            <table class="widefat">
                <thead>
                    <tr>
                        <th width="20%"><?php _e('Name', 'wp-event-manager-contact-organizer' ); ?></th>
                        <th width="80%"><?php _e('Options', 'wp-event-manager-contact-organizer' ); ?></th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <th><?php _e('Contact Organiser Email notification', 'wp-event-manager-contact-organizer' ); ?></th>
                        <td>
                            <label>
                                <input name="enable_event_manager_contact_organizer_notification" type="checkbox" value="1" <?php checked($enable_contact_organizer_notification); ?> /> <?php _e('Enable Contact Organizer email notification', 'wp-event-manager-contact-organizer' ); ?>
                            </label> 
                            <p class="description"><?php _e('Contact Organizer will be notified via email.', 'wp-event-manager-contact-organizer' ); ?></p>
                        </td>
                    </tr>

                    <tr>
                        <th><?php _e('Contact Person Email notification', 'wp-event-manager-contact-organizer' ); ?></th>
                        <td>
                            <label>
                                <input name="enable_event_manager_contact_attendee_notification" type="checkbox" value="1" <?php checked($enable_contact_attendee_notification); ?> /> <?php _e('Enable Contact Attendee email notification', 'wp-event-manager-contact-organizer' ); ?>
                            </label> 
                            <p class="description"><?php _e('Contact Person will be notified via email.', 'wp-event-manager-contact-organizer' ); ?></p>
                        </td>
                    </tr>
                </tbody>

                <tfoot>
                    <tr>
                        <td colspan="2">
                            <input type="submit" class="button-primary" name="wp_event_manager_contact_organizer_settings" value="<?php esc_attr_e( 'Save', 'wp-event-manager-contact-organizer' ); ?>" />
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php
    }

    /**
     * Save the settings
     */
    private function contact_organizer_settings_save()
    {
        $enable_contact_organizer_notification = isset($_POST['enable_event_manager_contact_organizer_notification']) ? $_POST['enable_event_manager_contact_organizer_notification'] : '';

        $enable_contact_attendee_notification = isset($_POST['enable_event_manager_contact_attendee_notification']) ? $_POST['enable_event_manager_contact_attendee_notification'] : '';

        $result        = update_option('enable_event_manager_contact_organizer_notification', $enable_contact_organizer_notification);
        $result2       = update_option('enable_event_manager_contact_attendee_notification', $enable_contact_attendee_notification);

        if (true === $result || true === $result2)
        {
            echo '<div class="updated"><p>' . __('The settings was successfully saved.', 'wp-event-manager-contact-organizer') . '</p></div>';
        }
    }

    /**
     * Output the form editor
     */
    private function form_editor()
    {
        if (!empty($_GET['reset-fields']) && !empty($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'reset'))
        {
            delete_option('event_manager_contact_organizer_form_fields');
            echo '<div class="updated"><p>' . __('The fields were successfully reset.', 'wp-event-manager-contact-organizer') . '</p></div>';
        }

        if (!empty($_POST) && !empty($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'save-fields'))
        {
            echo $this->form_editor_save();
        }

        $fields      = get_contact_organizer_form_fields();
        $field_rules = apply_filters('event_manager_contact_organizer_form_field_rules', array(
            __('Validation', 'wp-event-manager-contact-organizer')    => array(
                'required' => __('Required', 'wp-event-manager-contact-organizer'),
                'email'    => __('Email', 'wp-event-manager-contact-organizer'),
                'numeric'  => __('Numeric', 'wp-event-manager-contact-organizer')
            ),
            __('Data Handling', 'wp-event-manager-contact-organizer') => array(
                'from_name'  => __('From Name', 'wp-event-manager-contact-organizer'),
                'from_email' => __('From Email', 'wp-event-manager-contact-organizer')
            )
        ));
        $field_types = apply_filters('event_manager_contact_organizer_form_field_types', array(
            'text'           => __('Text', 'wp-event-manager-contact-organizer'),
            'textarea'       => __('Textarea', 'wp-event-manager-contact-organizer'),
            'select'         => __('Select', 'wp-event-manager-contact-organizer'),
            'multiselect'    => __('Multiselect', 'wp-event-manager-contact-organizer'),
            'checkbox'       => __('Checkbox', 'wp-event-manager-contact-organizer')
        ));
        ?>
        <table class="widefat">
            <thead>
                <tr>
                    <th width="1%">&nbsp;</th>
                    <th><?php _e('Field Label', 'wp-event-manager-contact-organizer'); ?></th>
                    <th width="1%"><?php _e('Type', 'wp-event-manager-contact-organizer'); ?></th>
                    <th><?php _e('Description', 'wp-event-manager-contact-organizer'); ?></th>
                    <th><?php _e('Placeholder / Options', 'wp-event-manager-contact-organizer'); ?></th>
                    <th width="1%"><?php _e('Validation / Rules', 'wp-event-manager-contact-organizer'); ?></th>
                    <th width="1%" class="field-actions">&nbsp;</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th colspan="4">
                        <a class="button add-field" href="#"><?php _e('Add field', 'wp-event-manager-contact-organizer'); ?></a>
                    </th>
                    <th colspan="4" class="save-actions">
                        <a href="<?php echo wp_nonce_url(add_query_arg('reset-fields', 1), 'reset'); ?>" class="reset"><?php _e('Reset to defaults', 'wp-event-manager-contact-organizer'); ?></a>
                        <input type="submit" class="save-fields button-primary" value="<?php _e('Save Changes', 'wp-event-manager-contact-organizer'); ?>" />
                    </th>
                </tr>
            </tfoot>
            <tbody id="form-fields" data-field="<?php
            ob_start();
            $index       = -1;
            $field_key   = '';
            $field       = array(
                'type'        => 'text',
                'label'       => '',
                'placeholder' => ''
            );
            include( 'wpem-form-editor-field-row.php' );
            echo esc_attr(ob_get_clean());
            ?>"><?php
                       foreach ($fields as $field_key => $field)
                       {
                           $index ++;
                           include( 'wpem-form-editor-field-row.php' );
                       }
                       ?></tbody>
        </table>
        <?php
    }

    /**
     * Save the form fields
     */
    private function form_editor_save()
    {
        $field_types        = !empty($_POST['field_type']) ? array_map('sanitize_text_field', $_POST['field_type']) : array();
        $field_labels       = !empty($_POST['field_label']) ? array_map('sanitize_text_field', $_POST['field_label']) : array();
        $field_descriptions = !empty($_POST['field_description']) ? array_map('sanitize_text_field', $_POST['field_description']) : array();
        $field_placeholder  = !empty($_POST['field_placeholder']) ? array_map('sanitize_text_field', $_POST['field_placeholder']) : array();
        $field_options      = !empty($_POST['field_options']) ? array_map('sanitize_text_field', $_POST['field_options']) : array();
        $field_rules        = !empty($_POST['field_rules']) ? $this->sanitize_array($_POST['field_rules']) : array();
        $new_fields         = array();
        $index              = 0;

        foreach ($field_labels as $key => $field)
        {
            if (empty($field_labels[$key]))
            {
                continue;
            }
            $field_name = sanitize_title( str_replace(' ', '_', $field_labels[ $key ]) );
            $options    = !empty($field_options[$key]) ? array_map('sanitize_text_field', explode('|', $field_options[$key])) : array();

            $new_field                = array();
            $new_field['label']       = $field_labels[$key];
            $new_field['type']        = $field_types[$key];
            $new_field['required']    = !empty($field_rules[$key]) ? in_array('required', $field_rules[$key]) : false;
            $new_field['options']     = $options ? array_combine($options, $options) : array();
            $new_field['placeholder'] = $field_placeholder[$key];
            $new_field['description'] = $field_descriptions[$key];
            $new_field['priority']    = $index ++;
            $new_field['rules']       = !empty($field_rules[$key]) ? $field_rules[$key] : array();
            $new_fields[$field_name]  = $new_field;
        }

        $result = update_option('event_manager_contact_organizer_form_fields', $new_fields);

        if (true === $result)
        {
            echo '<div class="updated"><p>' . __('The fields were successfully saved.', 'wp-event-manager-contact-organizer') . '</p></div>';
        }
    }

    /**
     * Sanitize a 2d array
     * @param  array $array
     * @return array
     */
    private function sanitize_array($input)
    {
        if (is_array($input))
        {
            foreach ($input as $k => $v)
            {
                $input[$k] = $this->sanitize_array($v);
            }
            return $input;
        }
        else
        {
            return sanitize_text_field($input);
        }
    }

    /**
     * Email editor
     */
    private function contact_organizer_notification_editor()
    {
        if (!empty($_GET['reset-email']) && !empty($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'reset'))
        {
            delete_option('event_manager_contact_organizer_email_content');
            delete_option('event_manager_contact_organizer_email_subject');
            echo '<div class="updated"><p>' . __('The email was successfully reset.', 'wp-event-manager-contact-organizer') . '</p></div>';
        }

        if (!empty($_POST) && !empty($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'save-contact-organizer-notification'))
        {
            echo $this->contact_organizer_notification_editor_save();
        }
        ?>

        <div class="wp-event-contact-organizer-content-wrapper">  

            <div class="admin-setting-left">                    
                <div class="white-background">
                    <p><?php _e('Below you will find the detail sent to organizer who tried contacting the organizer via contact organizer form.', 'wp-event-manager-contact-organizer'); ?></p>
                    <div class="wp-event-contact-organizer-email-content">
                        <p>
                            <label><b><?php _e( 'Email Subject', 'wp-event-manager-contact-organizer' ); ?></b></label>
                            <input type="text" name="email-subject" value="<?php echo esc_attr(get_contact_organizer_email_subject()); ?>" placeholder="<?php echo esc_attr(__('Subject', 'wp-event-manager-contact-organizer')); ?>" />
                        </p>
                        <p>
                            <label><b><?php _e( 'Email Content', 'wp-event-manager-contact-organizer' ); ?></b></label>
                            <textarea name="email-content" cols="71" rows="10"><?php echo esc_textarea(get_contact_organizer_email_content()); ?></textarea>
                        </p>
                    </div>
                </div>  <!--white-background-->            
            </div>  <!--    admin-setting-left-->   

            <div class="box-info">
                <div class="wp-event-contact-organizer-email-content-tags">
                    <p><?php _e('The following tags can be used to add content dynamically:', 'wp-event-manager-contact-organizer'); ?></p>
                    <ul>
                        <?php foreach (get_contact_organizer_email_tags() as $tag => $name) : ?>
                            <li><code>[<?php echo esc_html($tag); ?>]</code> - <?php echo wp_kses_post($name); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <p><?php _e('All tags can be passed a prefix and a suffix which is only output when the value is set e.g. <code>[event_title prefix="Event Title: " suffix="."]</code>', 'wp-event-manager-contact-organizer'); ?></p>
                </div>
            </div> <!--box-info--> 
        </div>
        <p class="submit-email save-actions">
            <a href="<?php echo wp_nonce_url(add_query_arg('reset-email', 1), 'reset'); ?>" class="reset"><?php _e('Reset to defaults', 'wp-event-manager-contact-organizer'); ?></a>
            <input type="submit" class="save-email button-primary" value="<?php _e('Save Changes', 'wp-event-manager-contact-organizer'); ?>" />
        </p>
        <?php
    }

    /**
     * Save the email
     */
    private function contact_organizer_notification_editor_save()
    {
        $email_content = wp_unslash($_POST['email-content']);
        $email_subject = sanitize_text_field(wp_unslash($_POST['email-subject']));
        $result        = update_option('event_manager_contact_organizer_email_content', $email_content);
        $result2       = update_option('event_manager_contact_organizer_email_subject', $email_subject);

        if (true === $result || true === $result2)
        {
            echo '<div class="updated"><p>' . __('The email was successfully saved.', 'wp-event-manager-contact-organizer') . '</p></div>';
        }
    }

    /**
     * Email editor
     */
    private function contact_attendee_notification_editor()
    {
        if (!empty($_GET['reset-email']) && !empty($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'reset'))
        {
            delete_option('event_manager_contact_person_email_content');
            delete_option('event_manager_contact_person_email_subject');
            echo '<div class="updated"><p>' . __('The email was successfully reset.', 'wp-event-manager-contact-organizer') . '</p></div>';
        }

        if (!empty($_POST) && !empty($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'save-contact-person-notification'))
        {
            echo $this->contact_attendee_notification_editor_save();
        }
        ?>

        <div class="wp-event-contact-organizer-content-wrapper">

            <div class="admin-setting-left">
                <div class="white-background">      
                    <p><?php _e('Below you will find the detail sent to visitor who tried contacting the organizer via contact organizer form.', 'wp-event-manager-contact-organizer'); ?></p>                    
                        <div class="wp-event-contact-organizer-email-content">
                            <p>
                                <label><b><?php _e( 'Email Subject', 'wp-event-manager-contact-organizer' ); ?></b></label>
                                <input type="text" name="email-subject" value="<?php echo esc_attr(get_contact_person_email_subject()); ?>" placeholder="<?php echo esc_attr(__('Subject', 'wp-event-manager-contact-organizer')); ?>" />
                            </p>
                            <p>
                                <label><b><?php _e( 'Email Content', 'wp-event-manager-contact-organizer' ); ?></b></label>
                                <textarea name="email-content" cols="71" rows="10" placeholder="<?php _e('N/A', 'wp-event-manager-contact-organizer'); ?>"><?php echo esc_textarea(get_contact_person_email_content()); ?></textarea>
                            </p>
                        </div>
                </div>  <!--white-background-->
            </div>  <!-- admin-setting-left-->     

            <div class="box-info">
                <div class="wp-event-contact-organizer-email-content-tags">
                    <p><?php _e('The following tags can be used to add content dynamically:', 'wp-event-manager-contact-organizer'); ?></p>
                    <ul>
                        <?php foreach (get_contact_organizer_email_tags() as $tag => $name) : ?>
                            <li><code>[<?php echo esc_html($tag); ?>]</code> - <?php echo wp_kses_post($name); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <p><?php _e('All tags can be passed a prefix and a suffix which is only output when the value is set e.g. <code>[event_title prefix="Event Title: " suffix="."]</code>', 'wp-event-manager-contact-organizer'); ?></p>
                </div>
            </div> <!--box-info--> 

        </div>

        <p class="submit-email save-actions">
            <a href="<?php echo wp_nonce_url(add_query_arg('reset-email', 1), 'reset'); ?>" class="reset"><?php _e('Reset to defaults', 'wp-event-manager-contact-organizer'); ?></a>
            <input type="submit" class="save-email button-primary" value="<?php _e('Save Changes', 'wp-event-manager-contact-organizer'); ?>" />
        </p>
        <?php
    }

    /**
     * Save the email
     */
    private function contact_attendee_notification_editor_save()
    {
        $email_content = wp_unslash($_POST['email-content']);
        $email_subject = sanitize_text_field(wp_unslash($_POST['email-subject']));
        $result        = update_option('event_manager_contact_person_email_content', $email_content);
        $result2       = update_option('event_manager_contact_person_email_subject', $email_subject);

        if (true === $result || true === $result2)
        {
            echo '<div class="updated"><p>' . __('The email was successfully saved.', 'wp-event-manager-contact-organizer') . '</p></div>';
        }
    }

}
