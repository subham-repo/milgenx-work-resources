<style type="text/css">
	#embeddable-event-widget * { margin:0 ; padding: 0; font-size: 1em; line-height: 1.25em; }
	#embeddable-event-widget { border-bottom-width: 3px; padding: 1em; }
	#embeddable-event-widget-heading { color: #00a5fa; font-family: arial; font-size: 20px; font-weight: bold;  margin: 0; padding: 0 0 0.8em;}
	#embeddable-event-widget-heading > a { color: #00a5fa; text-decoration: none;-webkit-transition: all 0.5s ease; -moz-transition: all 0.5s ease; -ms-transition: all 0.5s ease; -o-transition: all 0.5s ease; transition: all 0.5s ease;}
	#embeddable-event-widget .embeddable-event-widget-content { border: 1px solid #cccccc;}
	#embeddable-event-widget ul li { border-top: 1px solid #cccccc; border-left: 5px solid #FFF; display: block; -webkit-transition: all 0.5s ease; -moz-transition: all 0.5s ease; -ms-transition: all 0.5s ease; -o-transition: all 0.5s ease; transition: all 0.5s ease;}
	#embeddable-event-widget ul li:first-child { border-top: 0px;}
	#embeddable-event-widget ul li:hover { background:#EEE; border-left: 5px solid #00a5fa;}
	#embeddable-event-widget ul li a, #embeddable-event-widget ul li.no-results { padding: 10px; margin: 0; display: block; text-decoration: none; }
	#embeddable-event-widget ul li a .embeddable-event-widget-listing-title { font-weight: bold; font-family: arial; margin-bottom: .5em; font-size: 17px;  text-decoration: none; color: #333; line-height: 20px; }
	#embeddable-event-widget ul li a .embeddable-event-widget-listing-meta { color: #777777; font-family: arial;  font-size: 15px;  text-decoration: none;}
	#embeddable-event-widget-heading > a:hover {color: #111;}
	#embeddable-event-widget-pagination {overflow: hidden;padding: 0.2em 0 0;border-top: 1px solid #eee;}
	#embeddable-event-widget-pagination .embeddable-event-widget-next {
    float: right;
    background: #00A5FA;
    color: #fff;
    border: none;
    padding: 8px 10px;
    width: auto;
    text-transform: uppercase;
    font-weight: 600;
    border-radius: 3px;
    text-decoration: none;
    font-family: arial;
    font-size: 16px;
    line-height: 17px;
    letter-spacing: 0;
    margin: 5px;
    display: inline-block;
    cursor: pointer;
    transition: all .2s;
}
	#embeddable-event-widget-pagination .embeddable-event-widget-prev {
    float: left;
    background: #00a5fa;
    color: #fff;
    border: none;
    padding: 8px 10px;
    width: auto;
    text-transform: uppercase;
    font-weight: 600;
    border-radius: 3px;
    text-decoration:none;
    font-family: arial;
    font-size: 16px;
    line-height: 17px;
    letter-spacing: 0;
    margin: 5px;
    display: inline-block;
    cursor: pointer;
    transition: all .2s;
    }
</style>