<script type='text/javascript' src='<?php echo EMBEDDABLE_EVENT_WIDGET_PLUGIN_URL; ?>/assets/js/embed.min.js'></script>
<div id="embeddable-event-widget">
	<div id="embeddable-event-widget-heading"><?php _e('Events Form', 'wp-event-manager-embeddable-event-widget'); ?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></a></div>
	<div id="embeddable-event-widget-content"></div>
</div>