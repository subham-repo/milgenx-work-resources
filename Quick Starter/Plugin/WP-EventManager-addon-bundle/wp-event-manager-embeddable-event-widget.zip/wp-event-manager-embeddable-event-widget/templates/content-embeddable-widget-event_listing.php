<li class="embeddable-event-widget-listing">
	<a href="<?php echo get_event_permalink(); ?>" target="_blank">
		<div class="embeddable-event-widget-listing-title">
			<?php the_title(); ?>
		</div>
		<div class="embeddable-event-widget-listing-meta">
			<?php
				$meta = array();

				if ( $data = get_event_type() ) {
				    if(isset($data[0]->name))
					$meta[] = '<span class="embeddable-event-widget-listing-event-type">' . $data[0]->name . '</span>';
				}
				if ( $data = get_event_location() ) {
					$meta[] = '<span class="embeddable-event-widget-listing-event-location">' . $data . '</span>';
				}
				if ( $data = get_organizer_name() ) {
					$meta[] = '<span class="embeddable-event-widget-listing-event-company">' . $data . '</span>';
				}

				echo implode( ' - ', $meta );
			?>
			<span class="event-start-date"><?php display_event_start_date();?></span>
		</div>
	</a>
</li>