<?php
/*
* This file is use to create a sortcode of wp event manager embeddbale event widget plugin. 
* Lets users generate and embed a widget containing your event listings on their own sites via a form added to your site with the shortcode [embeddable_event_widget_generator].

*/
?>
<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * WP_Event_Manager_Embeddable_Event_Widget_Shortcodes class.
 */
class WP_Event_Manager_Embeddable_Event_Widget_Shortcodes {	

	/**
	 * Constructor
	 */
	public function __construct() {			
			
		add_shortcode( 'embeddable_event_widget_generator', array( $this, 'embed_code_generator' ) );  
		add_filter('event_manager_chosen_enabled', '__return_true');
	}
    /**
	 * Form users can generate some embed code
	 */
	public function embed_code_generator() {
		
		wp_enqueue_script( 'embeddable-event-widget-form' );
		
		ob_start();
		get_event_manager_template( 'embed-code-generator-form.php', array(), 'wp-event-manager-embeddable-event-widget', EMBEDDABLE_EVENT_WIDGET_PLUGIN_DIR . '/templates/' );
		return ob_get_clean();
	}

}
new WP_Event_Manager_Embeddable_Event_Widget_Shortcodes();