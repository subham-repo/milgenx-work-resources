=== WP Event Manager - Embeddable Event Widget ===
Contributors: WP Event Manager
Requires at least: 4.1
Tested up to: 5.2.2
Stable tag: 1.2.2
License: GNU General Public License v3.0

Lets users generate and embed a widget containing your event listings on their own sites via a form added to your site with the shortcode [embeddable_event_widget_generator].

= Documentation =

Usage instructions for this plugin can be found on the documentation site: [https://wpjobmanager.com/documentation/add-ons/embeddable-event-widget](https://wpjobmanager.com/documentation/add-ons/embeddable-event-widget).

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Changelog ==

= 1.2.2 [ 1st Oct 2020 ] =

* Added - Copy script code to clipboard.
* Fixed - Some design and structure improvements.
* Fixed - Some css and js tweasks.



= 1.2.1 =

* Added - New design responsive structure
* Added - Layout type attribute in events shortcode
* Added - CSS Improved
* Added - All Templates Improved
* Fixed - Minor Bugs

= 1.2 =

* Fixed - multiple category and type issue fixed.

= 1.1 =

* Fixed - Choosend comptiblity shortcode issue fixed
* Fixed - Some css tweak

= 1.0 =

* First release.
