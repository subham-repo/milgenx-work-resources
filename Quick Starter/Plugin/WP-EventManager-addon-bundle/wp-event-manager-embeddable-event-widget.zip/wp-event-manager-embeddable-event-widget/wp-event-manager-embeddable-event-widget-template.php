<?php

	 /**
	 * Outputs Javascript for the widget itself.
	 */
	function event_widget_js() 
    	{
    		
		if ( ! empty( $_GET['embed'] ) && 'wp_event_manager_widget' === $_GET['embed'] ) 
        	{
            		//this is getting form form.js: 51            
			$categories = array_filter( array_map( 'absint', explode( ',', $_GET['categories'] ) ) );
			$event_types  = array_filter( array_map( 'sanitize_text_field', explode( ',', $_GET['event_types'] ) ) );
			$page       = absint( isset( $_GET['page'] ) ? $_GET['page'] : 1 );
			$per_page   = absint( $_GET['per_page'] );
            
			$events       = get_event_listings( apply_filters( 'event_manager_embeddable_event_widget_query_args', array(
				                                                    'search_location'   => urldecode( $_GET['location'] ),
				                                                    'search_keywords'   => urldecode( $_GET['keywords'] ),
				                                                    'search_categories' =>  $categories  ,
				                                                    'search_event_types' =>  $event_types ,
				                                                    'posts_per_page'    => $per_page,
				                                                    'offset'            => ( $page - 1 ) * $per_page
			                ) ) );			
			ob_start();
            
            /* embeddable-event-widget-content is must equal to line 59 
             * also you can find this id embed-code.php:4
            */
			echo '<div class="embeddable-event-widget-content">';
			echo '<ul class="embeddable-event-widget-listings">';

			if ( $events->have_posts() ) : ?>
				<?php while ( $events->have_posts() ) : $events->the_post(); ?>
					<?php get_event_manager_template_part( 'content-embeddable-widget', 'event_listing', 'wp-event-manager-embeddable-event-widget', EMBEDDABLE_EVENT_WIDGET_PLUGIN_DIR . '/templates/' ); ?>
				<?php endwhile; ?>
			<?php else : ?>
				<li class="no-results"><?php _e( 'No matching events found', 'wp-event-manager-embeddable-event-widget' ); ?></li>
			<?php endif;

			echo '</ul>';

			if ( ! empty( $_GET['pagination'] ) ) {
				echo '<div id="embeddable-event-widget-pagination">';
				if ( $page > 1 ) {
					echo '<a href="#" class="embeddable-event-widget-prev" onclick="EmbeddableEventWidget.prev_page(); return false;">' . __( 'Previous', 'wp-event-manager-embeddable-event-widget' ) . '</a>';
				}
				if ( $page < $events->max_num_pages ) {
					echo '<a href="#" class="embeddable-event-widget-next" onclick="EmbeddableEventWidget.next_page(); return false;">' . __( 'Next', 'wp-event-manager-embeddable-event-widget' ) . '</a>';
				}
				echo '</div>';
			}

			echo '</div>';

			$content = ob_get_clean();

			header( "Content-Type: text/javascript; charset=" . get_bloginfo( 'charset' ) );
			header( "Vary: Accept-Encoding" ); // Handle proxies
			header( "Expires: " . gmdate( "D, d M Y H:i:s", time() + DAY_IN_SECONDS ) . " GMT" );
			?>
			if ( EmbeddableEventWidget != undefined ) {
				EmbeddableEventWidget.show_events( 'embeddable-event-widget-content', '<?php echo esc_js( $content ); ?>' );
			}
			<?php
			exit;
		}
	}