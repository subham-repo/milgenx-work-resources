<?php
/*
* Main Admin functions class which responsible for the entire amdin functionality and scripts loaded and files.
*
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * WP_Event_Manager_Admin class.
 */
class WPEM_Google_Maps_Admin {

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() 
	{
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ));
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_autocomplete' ));

		add_action( 'wp_ajax_check_google_api_key', array( $this, 'check_google_api_key' ) );
		/*add_action( 'wp_ajax_nopriv_check_google_api_key', array( $this, 'check_google_api_key' ) );*/
	}
	
	/**
	 * Trigger autocomplete on the location field in backend
	 */
	public function admin_autocomplete() {
		global $post_type;
		
		if ( $post_type != 'event_listing' || get_option('event_manager_google_maps_google_address_autocomplete_backend') == false ) 
			return;
		
		$language = get_option('event_manager_google_maps_api_language');
		$region   = get_option('event_manager_google_maps_api_default_region');
		$api_key   = get_option('event_manager_google_maps_api_key');
		
		//register google maps api
		if ( !wp_script_is( 'google-maps', 'registered' ) ) {
			wp_register_script( 'google-maps', ( is_ssl() ? 'https' : 'http' ) . '://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&language='.$language.'&region='.$region.'&key='.$api_key, array( 'jquery' ), false );
		}
		//register google maps api
		if ( !wp_script_is( 'google-maps', 'enqueued' ) ) {
			wp_enqueue_script( 'google-maps' );
		}
		
		$country= array( 'country' => get_option('event_manager_google_maps_autocomplete_country_restriction'));
		
		$autocomplete_options = array(
				'input_address'	=> '_event_address',
				'input_pincode'	=> '_event_pincode',
				'input_location'   => '_event_location',
				'options' 		=> $country
		);
		wp_enqueue_script( 'wp-event-manager-google-maps-autocomplete-backend', EVENT_MANAGER_GOOGLE_MAPS_PLUGIN_URL .'/assets/js/google-maps-autocomplete.min.js', array( 'jquery' ), EVENT_MANAGER_GOOGLE_MAPS_VERSION, true );
		wp_localize_script( 'wp-event-manager-google-maps-autocomplete-backend', 'AutoCompOptionsLocation', $autocomplete_options );
		
	}

	public function admin_enqueue_scripts() {

		wp_register_script( 'wp-event-manager-google-admin-google-map', EVENT_MANAGER_GOOGLE_MAPS_PLUGIN_URL .'/assets/js/admin-google-map.min.js', array( 'jquery' ), EVENT_MANAGER_GOOGLE_MAPS_VERSION, true );
		wp_localize_script( 'wp-event-manager-google-admin-google-map', 'event_manager_google_map_admin_google_map', array( 
								'ajax_url' 	 => admin_url( 'admin-ajax.php' ),

								'event_manager_google_map_security'  => wp_create_nonce( '_nonce_event_manager_google_map_security' ),
							)
						);
		
	}

	/**
	 * check_zoom_connection function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0
	 */
	public function check_google_api_key() 
	{
		check_ajax_referer( '_nonce_event_manager_google_map_security', 'security' );

		$response = [];

		$address = "WP Event Manager, Varachha Main Road, Ramdarshan Society, Varachha, Surat, Gujarat, India";


		$geocoder  = google_maps_geocoder($address);

		if( isset($geocoder['lat']) && isset($geocoder['lng']) ){
			$response['geocoder'] = array( 'message' => __( 'Google Geocoder API enabled correctly.', 'wp-event-manager-google-maps' ), 'code' => '200' );
		}
		else{
			$response['geocoder'] = array( 'message' => 'Google Geocoder API: '.$geocoder['error'], 'code' => '404' );
		}


		$places  = google_maps_places($address);

		if( isset($places['error']) && !empty($places['error']) ){			
			$response['places'] = array( 'message' => 'Google Places API: '.$places['error'], 'code' => '404' );
		}
		else{
			$response['places'] = array( 'message' => __( 'Google Places API enabled correctly.', 'wp-event-manager-google-maps' ), 'code' => '200' );
		}

		wp_send_json( $response );

		wp_die();
	}
	
}

new WPEM_Google_Maps_Admin();
