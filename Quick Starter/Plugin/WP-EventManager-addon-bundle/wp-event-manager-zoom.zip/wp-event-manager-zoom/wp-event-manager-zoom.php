<?php
/**
Plugin Name: WP Event Manager - Zoom
Plugin URI: https://www.wp-eventmanager.com
Description: Seamlessly integrate zoom accounts, create and manage meetings & webinars, highlight events as virtual,  track reports and control users directly from WordPress dashboard as well as frontend.
Author: WP Event Manager
Author URI: https://www.wp-eventmanager.com/the-team
Text Domain: wp-event-manager-zoom
Domain Path: /languages
Version: 1.0.4
Since: 1.0.0
Requires WordPress Version at least: 4.1
Copyright: 2020 WP Event Manager
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
**/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	
	exit;
}

if ( ! class_exists( 'WPEM_Updater' ) ) 
{
	include( 'autoupdater/wpem-updater.php' );
}

include_once(ABSPATH.'wp-admin/includes/plugin.php');
function pre_check_before_installing_zoom() 
{	
	/*
	* Check weather WP Event Manager is installed or not. If WP Event Manger is not installed or active then it will give notification to admin panel
	*/
	if ( !is_plugin_active( 'wp-event-manager/wp-event-manager.php') ) 
	{
        global $pagenow;
    	if( $pagenow == 'plugins.php' )
    	{
           echo '<div id="error" class="error notice is-dismissible"><p>';
           echo __( 'WP Event Manager is require to use WP Event Manager Sell Tickets' , 'wp-event-manager-zoom');
           echo '</p></div>';	
    	}
    	return true;
	}

}
add_action( 'admin_notices', 'pre_check_before_installing_zoom' );

/**
 * WP_Event_Manager_Zoom class.
 */
class WP_Event_Manager_Zoom extends WPEM_Updater{

	/**
	 * The single instance of the class.
	 *
	 * @var self
	 * @since 1.0.0
	 */
	private static $_instance = null;

	/**
	 * Main WP Event Manager Zoom Instance.
	 *
	 * Ensures only one instance of WP Event Manager is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @static
	 * @see WP_Event_Manager_Zoom()
	 * @return self Main instance.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function __construct() {

		//if wp event manager not active return from the plugin
		if ( !is_plugin_active( 'wp-event-manager/wp-event-manager.php') )
			return;

		// Define constants
		define( 'WPEM_ZOOM_VERSION', '1.0.4' );
		define( 'WPEM_ZOOM_PLUGIN_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
		define( 'WPEM_ZOOM_PLUGIN_URL', untrailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) ) );
		
		include( 'wp-event-manager-zoom-functions.php' );		
		include( 'wp-event-manager-zoom-template.php' );
		
		// includes
		include( 'includes/wpem-zoom-install.php' );
		include( 'includes/wpem-zoom-api.php' );
		include( 'includes/wpem-zoom-user.php' );
		include( 'includes/wpem-zoom-ajax.php' );
		include( 'includes/wpem-zoom-post-types.php' );
		include( 'includes/wpem-zoom-dashboard.php' );
		include( 'includes/wpem-zoom-submit-event.php' );

		if ( is_plugin_active('wp-event-manager-registrations/wp-event-manager-registrations.php') ) 
		{	
			include ('includes/wpem-zoom-registrations.php' );
		}

		if ( is_plugin_active( 'woocommerce/woocommerce.php') ) 
		{
			if ( is_plugin_active( 'wp-event-manager-sell-tickets/wp-event-manager-sell-tickets.php') ) 
			{
				include( 'includes/wpem-zoom-sell-tickets.php' );
			}
			
			include( 'includes/wpem-zoom-woocommerce.php' );
		}


		//shortcodes
		include( 'shortcodes/wpem-zoom-shortcodes.php' );
		

		//forms
		include( 'forms/wpem-zoom-forms.php' );
		

		//external 
		include('external/external.php');


		// Init classes
		$this->forms      = WPEM_Zoom_Forms::instance();


		// Activation / deactivation - works with symlinks
		register_activation_hook( basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ), array( $this, 'activate' ) );
		register_deactivation_hook( basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ), array( $this, 'deactivate' ) );

		// Actions
		add_action( 'after_setup_theme', array( $this, 'load_plugin_textdomain' ) );

		add_action( 'admin_init', array( $this, 'updater' ) );

		add_action( 'init', array( $this, 'load_admin' ), 12 );

		// Init license updates
		$this->init_updates( __FILE__ );
	}

	/**
     * activate function.
     *
     * @access public
     * @param 
     * @return 
     * @since 1.0.0
     */
	public function activate() {
		
		WPEM_Zoom_Install::install();
	}

	/**
     * deactivate function.
     *
     * @access public
     * @param 
     * @return 
     * @since 1.0.0
     */
	public function deactivate() {

		$all_fields = get_option( 'event_manager_form_fields', true );
		if( is_array($all_fields) && !empty($all_fields) )
		{
			$zoom_meeting_fields = array('event_zoom_id');
			
			foreach ($zoom_meeting_fields as $value) {
				if(isset($all_fields['event'][$value]))
					unset($all_fields['event'][$value]);
			}
		}
		update_option('event_manager_form_fields', $all_fields);
		update_option( 'event_manager_submit_event_form_fields', array('event' => $all_fields['event']) );
	}

	/**
     * updater function.
     *
     * @access public
     * @param 
     * @return 
     * @since 1.0.0
     */
	public function updater() {
		if ( version_compare( WPEM_ZOOM_VERSION, get_option( 'wpem_zoom_version' ), '>' ) ) {

			WPEM_Zoom_Install::update();
			flush_rewrite_rules();
		}
	}

	/**
	* load_plugin_textdomain function.
	*
	* @access public
	* @param
	* @return 
	* @since 1.0.0
	*/
	public function load_plugin_textdomain() {

		$domain = 'wp-event-manager-zoom';   

        $locale = apply_filters('plugin_locale', get_locale(), $domain);

		load_textdomain( $domain, WP_LANG_DIR . "/wp-event-manager-zoom/".$domain."-" .$locale. ".mo" );

		load_plugin_textdomain($domain, false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}

	/**
	* load_admin function.
	*
	* @access public
	* @param
	* @return 
	* @since 1.0.0
	*/
	public function load_admin() {
		if ( is_admin() && class_exists( 'WP_Event_Manager_Zoom' ) ) {
			include( 'admin/wpem-zoom-admin.php' );			
		}
	}	
}

/**
 * Main instance of WP Event Manager Zoom.
 *
 * Returns the main instance of WP Event Manager Zoom to prevent the need to use globals.
 *
 * @since 1.0.0
 * @return WP_Event_Manager_Zoom
 */
function WPEM_Zoom() { 
	// phpcs:ignore WordPress.NamingConventions.ValidFunctionName

	/*
	* Check weather WP Event Manager is installed or not. If WP Event Manger is not installed or active then it will give notification to admin panel
	*/
	if ( is_plugin_active( 'wp-event-manager/wp-event-manager.php') ) 
	{
		return WP_Event_Manager_Zoom::instance();
	}
}

$GLOBALS['event_manager_zoom'] = WPEM_Zoom();
