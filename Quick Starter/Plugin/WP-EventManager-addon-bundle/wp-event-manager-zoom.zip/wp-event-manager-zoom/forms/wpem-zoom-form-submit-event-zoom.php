<?php
/**
 * WPEM_Zoom_Form_Submit_Event_Zoom class.
 */

class WPEM_Zoom_Form_Submit_Event_Zoom  extends WPEM_Zoom_Form {
	
	public    $form_name = 'submit-event-zoom';
	protected $event_zoom_id;
	protected $preview_event_zoom;
	
	/** @var 
	* WPEM_Zoom_Form_Submit_Event_Zoom The single instance of the class 
	*/
	protected static $_instance = null;
	/**
	 * Main Instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {

		add_action( 'wp', array( $this, 'process' ) );

		$this->user_page = new WPEM_Zoom_User();
		
		$this->steps  = (array) apply_filters( 'submit_event_zoom_steps', array(
			'submit' => array(
				'name'     => __( 'Submit Details', 'wp-event-manager-zoom' ),
				'view'     => array( $this, 'submit' ),
				'handler'  => array( $this, 'submit_handler' ),
				'priority' => 10
				),

			'done' => array(
				'name'     => __( 'Done', 'wp-event-manager-zoom' ),
				'view'     => array( $this, 'done' ),
				'priority' => 30
			)
		) );

		uasort( $this->steps, array( $this, 'sort_by_priority' ) );
		// Get step/event
		if ( isset( $_POST['step'] ) ) {
			$this->step = is_numeric( $_POST['step'] ) ? max( absint( $_POST['step'] ), 0 ) : array_search( $_POST['step'], array_keys( $this->steps ) );
		} elseif ( !empty( $_GET['step'] ) ) {
			$this->step = is_numeric( $_GET['step'] ) ? max( absint( $_GET['step'] ), 0 ) : array_search( $_GET['step'], array_keys( $this->steps ) );
		}

		$this->event_zoom_id = !empty( $_REQUEST['event_zoom_id'] ) ? absint( $_REQUEST[ 'event_zoom_id' ] ) : 0;
		if ( ! event_manager_user_can_edit_event( $this->event_zoom_id ) ) {
			$this->event_zoom_id = 0;
		}
		
		// Allow resuming from cookie.
		$this->resume_edit = false;
		if ( ! isset( $_GET[ 'new' ] ) && ( !$this->event_zoom_id  ) && !empty( $_COOKIE['wp-event-manager-submitting-event-zoom-id'] ) && !empty( $_COOKIE['wp-event-manager-submitting-event-zoom-key'] ) ){
			$event_zoom_id     = absint( $_COOKIE['wp-event-manager-submitting-event-zoom-id'] );
			$event_zoom_status = get_post_status( $event_zoom_id );
			if ( 'preview' === $event_zoom_status && get_post_meta( $event_zoom_id, '_submitting_key', true ) === $_COOKIE['wp-event-manager-submitting-event-zoom-key'] ) {
				$this->event_zoom_id = $event_zoom_id;
			}
		}
		// Load event details
		if ( $this->event_zoom_id ) {
			$event_zoom_status = get_post_status( $this->event_zoom_id );
			if ( 'expired' === $event_zoom_status ) {
				if ( ! event_manager_user_can_edit_event( $this->event_zoom_id ) ) {
					$this->event_zoom_id = 0;
					$this->step   = 0;
				}
			} elseif ( ! in_array( $event_zoom_status, apply_filters( 'event_manager_valid_submit_event_zoom_statuses', array( 'preview' ) ) ) ) {
				$this->event_zoom_id = 0;
				$this->step   = 0;
			}
		}
	}

	/**
	 * get_event_zoom_id function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function get_event_zoom_id() {
		return absint( $this->event_zoom_id );
	}


	/**
	 * event_manager_zoom_api_get_user_list function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function event_manager_zoom_api_get_user_list() {
		$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();

		$users = [];

		if( !empty($zoom_users) && empty($zoom_users->code) )
		{
			foreach ($zoom_users as $zoom_user) {
				$users[$zoom_user->id] = $zoom_user->email;
			}
		}
		return $users;
	}

	/**
	 * init_fields function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function init_fields() {
		if ( $this->fields ) {
			return;
		}
		
		$zoom_users = $this->event_manager_zoom_api_get_user_list();

		$this->fields = apply_filters( 'submit_zoom_meeting_form_fields', array(
			'event_zoom' => array(
				'event_zoom_name' => array(
								'label'       	=> __( 'Event Zoom Name', 'wp-event-manager-zoom' ),
								'type'        	=> 'text',
								'required'    	=> true,
								'placeholder' 	=> __( 'Enter the name of the Event Zoom Name', 'wp-event-manager-zoom' ),
								'priority'    	=> 1
				),

				'event_zoom_description' => array(
								'label'      	=> __( 'Event Zoom Description', 'wp-event-manager-zoom' ),
								'type'        	=> 'wp-editor',
								'required'    	=> true,
								'placeholder' 	=> '',
								'priority'    	=> 2,
				),

				'meeting_userId' => array(
								'label'       	=> __( 'Meeting Host', 'wp-event-manager-zoom' ),
								'type'        	=> 'select',
								'description'	=> __('This is host ID for the meeting (Required).','wp-event-manager-zoom'),
								'default' 	  	=> '',
								'options'  	  	=> $zoom_users,
								'priority'    	=> 3,
								'required'    	=> true,
				),

				'meeting_type' => array(
								'label'       	=> __( 'Meeting type', 'wp-event-manager-zoom' ),
								'type'        	=> 'select',
								'description'	=> __('Paid Zoom Account is required. Meeting type.','wp-event-manager-zoom'),
								'default' 	  	=> '',
								'options'  	  	=> get_event_manager_zoom_meeting_type(),
								'priority'    	=> 3,
								'required'    	=> false,
				),

				'meeting_start_date' => array(  
								'label'			=> __( 'Start Date', 'wp-event-manager-zoom' ),
								'placeholder'  	=> __( 'Please enter start date', 'wp-event-manager-zoom' ),	
								'description'	=> __('Starting Date of the Meeting (Required).','wp-event-manager-zoom'),
								'type'  		=> 'date',
								'priority'    	=> 4,
								'required'		=> true	  
				),
				
				'meeting_start_time' => array(  
								'label'			=> __( 'Start Time', 'wp-event-manager-zoom' ),
								'placeholder'  	=> __( 'Please enter start time', 'wp-event-manager-zoom' ),
								'description'	=> __('Starting Time of the Meeting (Required).','wp-event-manager-zoom'),								
								'type'  		=> 'time',
								'priority'    	=> 5,
								'required'		=> true	  
				),

				'meeting_timezone' => array(
								'label'			=> __( 'Select timezone', 'wp-event-manager-zoom' ),
								'type'  		=> 'select',
								'description'	=> __('Meeting Timezone','wp-event-manager-zoom'),
								'priority'    	=> 6,
								'required'		=> true,
								'default'		=> 'UTC',
								'options'		=> get_wpem_zoom_timezone_list(),
				),

				'meeting_duration' => array(
								'label'       	=> __( 'Duration', 'wp-event-manager-zoom' ),
								'placeholder'  	=> __( 'Add duration', 'wp-event-manager-zoom' ),		
								'type'        	=> 'number',
								'description'	=> __('Meeting duration (minutes). (As er your zoom plan)','wp-event-manager-zoom'),
								'default' 	  	=> '40',
								'min'    		=> 1,
								'priority'    	=> 7,
								'required'    	=> false,
				),

				'meeting_password' => array(  
								'label'			=> __( 'Password', 'wp-event-manager-zoom' ),
								'placeholder'  	=> __( 'Please password', 'wp-event-manager-zoom' ),								
								'type'  		=> 'password',
								'description'	=> __('Password to join the meeting. Password may only contain the following characters: [a-z A-Z 0-9]. Max of 10 characters.( Leave blank for auto generate )','wp-event-manager-zoom'),
								'priority'    	=> 8,
								'required'		=> false,
								'maxlength'		=> 10
				),
				/*
				'meeting_option_authentication' => array(  
								'label'			=> __( 'Authentication', 'wp-event-manager-zoom' ),
								'type'  		=> 'checkbox',
								'description'	=> __('Authentication for join the meeting.','wp-event-manager-zoom'),
								'priority'    	=> 9,
								'required'		=> false	  
				),
				*/
				'meeting_option_registration' => array(  
								'label'			=> __( 'Registration', 'wp-event-manager-zoom' ),							
								'type'  		=> 'checkbox',
								'description'	=> __('A paid Zoom account is required to enable the joining of the Zoom meeting only for registered users.','wp-event-manager-zoom'),
								'priority'    	=> 10,
								'required'		=> false	  
				),

				'meeting_option_approval_type' => array(
								'label'       	=> __( 'Registration approval type', 'wp-event-manager-zoom' ),
								'type'        	=> 'select',
								'description'	=> __('Paid Zoom Account is required. Registration approval type.','wp-event-manager-zoom'),
								'default' 	  	=> '',
								'options'  	  	=> get_event_manager_zoom_registration_approval_type(),
								'priority'    	=> 11,
								'required'    	=> false,
				),

				'meeting_option_join_before_host' => array(  
								'label'			=> __( 'Join Before Host', 'wp-event-manager-zoom' ),							
								'type'  		=> 'checkbox',
								'description'	=> __('Join meeting before host start the meeting. Only for scheduled or recurring meetings.','wp-event-manager-zoom'),
								'priority'    	=> 12,
								'required'		=> false	  
				),

				'meeting_option_host_video' => array(  
								'label'			=> __( 'Host join start	', 'wp-event-manager-zoom' ),							
								'type'  		=> 'checkbox',
								'description'	=> __('Start video when host join meeting.','wp-event-manager-zoom'),
								'priority'    	=> 13,
								'required'		=> false	  
				),

				'meeting_option_participants_video' => array(  
								'label'			=> __( 'Participants Video', 'wp-event-manager-zoom' ),							
								'type'  		=> 'checkbox',
								'description'	=> __('Start video when participants join meeting.','wp-event-manager-zoom'),
								'priority'    	=> 14,
								'required'		=> false	  
				),

				'meeting_option_mute_participants' => array(  
								'label'			=> __( 'Mute Participants upon entry', 'wp-event-manager-zoom' ),							
								'type'  		=> 'checkbox',
								'description'	=> __('Mutes Participants when entering the meeting.','wp-event-manager-zoom'),
								'priority'    	=> 15,
								'required'		=> false	  
				),				

				'meeting_option_panelists_video' => array(
								'label'       	=> __( 'Panelists Video', 'wp-event-manager-zoom' ),
								'type'        	=> 'checkbox',
								'description'	=> __('Paid Zoom Account is required. Start video when panelists join webinar. Default is none.','wp-event-manager-zoom'),
								'priority'    	=> 16,
								'required'    	=> false,
				),

				'meeting_option_practice_session' => array(
								'label'       	=> __( 'Practice Session', 'wp-event-manager-zoom' ),
								'type'        	=> 'checkbox',
								'description'	=> __('Paid Zoom Account is required. Enable Practise Session. Default is none.','wp-event-manager-zoom'),
								'priority'    	=> 17,
								'required'    	=> false,
				),

				'meeting_option_hd_video' => array(
								'label'       	=> __( 'HD Video', 'wp-event-manager-zoom' ),
								'type'        	=> 'checkbox',
								'description'	=> __('Paid Zoom Account is required. Defaults to HD video. Default is yes.','wp-event-manager-zoom'),
								'priority'    	=> 18,
								'required'    	=> false,
				),

				'meeting_option_allow_multiple_devices' => array(
								'label'       	=> __( 'Allow multiple devices', 'wp-event-manager-zoom' ),
								'type'        	=> 'checkbox',
								'description'	=> __('Paid Zoom Account is required. Set what type of auto recording feature you want to add. Default is none.','wp-event-manager-zoom'),
								'priority'    	=> 19,
								'required'    	=> false,
				),

				'site_option_logged_in' => array(  
								'label'			=> __( 'Requires Login?', 'wp-event-manager-zoom' ),							
								'type'  		=> 'checkbox',
								'description'	=> __('Only logged in users of this site will be able to join this meeting.','wp-event-manager-zoom'),
								'priority'    	=> 93,
								'required'		=> false	  
				),

				'site_option_browser_join' => array(  
								'label'			=> __( 'Hide Join via browser link ?', 'wp-event-manager-zoom' ),							
								'type'  		=> 'checkbox',
								'description'	=> __('This will disable join via browser link in frontend page.','wp-event-manager-zoom'),
								'priority'    	=> 94,
								'required'		=> false	  
				),

				'meeting_option_auto_recording' => array(
								'label'       	=> __( 'Auto Recording', 'wp-event-manager-zoom' ),
								'type'        	=> 'select',
								'description'	=> __('Set what type of auto recording feature you want to add. Default is none.','wp-event-manager-zoom'),
								'default' 	  	=> '',
								'options'  	  	=> get_event_manager_zoom_meeting_recording_type(),
								'priority'    	=> 95,
								'required'    	=> false,
				),

				'meeting_alternative_host_ids' => array(
								'label'       	=> __( 'Alternative Hosts', 'wp-event-manager-zoom' ),
								'type'        	=> 'multiselect',
								'description'	=> __('Paid Zoom Account is required for this !! Alternative hosts IDs. Multiple value separated by comma.','wp-event-manager-zoom'),
								'default' 	  	=> '',
								'options'  	  	=> $zoom_users,
								'priority'    	=> 96,
								'required'    	=> false,
				),

				'enable_wc_purchase' => array(  
								'label'			=> __( 'WooCommerce Integration', 'wp-event-manager-zoom' ),							
								'type'  		=> 'checkbox',
								'description'	=> __('Enable Purchase? Enabling this will create a new WooCommerce product linked with this post which will be Purchasable by customer.','wp-event-manager-zoom'),
								'priority'    	=> 97,
								'required'		=> false	  
				),

				'meeting_wc_product_price' => array(  
								'label'			=> __( 'Ticket Price', 'wp-event-manager-zoom' ),							
								'type'  		=> 'number',
								'placeholder'  	=> __( 'Meeting Price', 'wp-event-manager-zoom' ),
								'description'	=> __( 'Meeting Price.','wp-event-manager-zoom'),
								'min'    		=> 0,
								'priority'    	=> 98,
								'required'		=> false	  
				),

				'meeting_wc_product_show_ticket_buy_button' => array(  
								'label'			=> __( 'Show Ticket Buy Button', 'wp-event-manager-zoom' ),							
								'type'  		=> 'checkbox',
								'description'	=> __('Show Ticket Buy Button? Enabling this will show button on single event page.','wp-event-manager-zoom'),
								'priority'    	=> 99,
								'required'		=> false	  
				),

				'meeting_wc_product_id' => array(  
								'type'  		=> 'hidden',
								'priority'    	=> 99,
								'required'		=> false	  
				),
			)
		));

		//unset timezone field if setting is site wise timezone
		$timezone_setting = get_option( 'event_manager_timezone_setting' ,'site_timezone' );
		if ( $timezone_setting != 'each_event' ) {
			unset( $this->fields['event_zoom']['meeting_timezone'] );
		}

		if ( !is_plugin_active( 'woocommerce/woocommerce.php') ) 
		{
			unset( $this->fields['event_zoom']['enable_wc_purchase'] );
			unset( $this->fields['event_zoom']['meeting_wc_product_price'] );
			unset( $this->fields['event_zoom']['meeting_wc_product_id'] );
			unset( $this->fields['event_zoom']['meeting_wc_product_show_ticket_buy_button'] );
		}

		return $this->fields;
	}

	/**
	 * get_event_manager_fieldeditor_fields function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public  function get_event_manager_fieldeditor_fields(){
		return apply_filters('event_manager_submit_zoom_meeting_form_fields', get_option( 'event_manager_submit_zoom_meeting_form_fields', false ) );
	}

	/**
	 * get_default_fields function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public  function get_default_fields( ) {
		if(empty($this->fields)){
			// Make sure fields are initialized and set
			$this->init_fields();
		}
	
		return $this->fields;
	}
	
	/**
	 * submit function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function submit() {

		$user_id = get_current_user_id();

		// Init fields
		//$this->init_fields(); We dont need to initialize with this function because of field edior
		// Now field editor function will return all the fields 
		//Get merged fields from db and default fields.
		$this->merge_with_custom_fields('frontend' );

		//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
		$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
						
		//covert datepicker format  into php date() function date format
		$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );
			
		// Load data if neccessary
		if ( $this->event_zoom_id ) {
			$event_zoom = get_post( $this->event_zoom_id );
			foreach ( $this->fields as $group_key => $group_fields ) {
				foreach ( $group_fields as $key => $field ) {
					switch ( $key ) {
						case 'event_zoom_name' :
							$this->fields[ $group_key ][ $key ]['value'] = $event_zoom->post_title;
						break;
						case 'event_zoom_description' :
							$this->fields[ $group_key ][ $key ]['value'] = $event_zoom->post_content;
						break;
						case  'event_zoom_logo':
							$this->fields[ $group_key ][ $key ]['value'] = has_post_thumbnail( $event_zoom->ID ) ? get_post_thumbnail_id( $event_zoom->ID ) : get_post_meta( $event_zoom->ID, '_' . $key, true );
						break;
						default:
							$this->fields[ $group_key ][ $key ]['value'] = get_post_meta( $event_zoom->ID, '_' . $key, true );
						break;
					}
					if ( !empty( $field['taxonomy'] ) ) {
						$this->fields[ $group_key ][ $key ]['value'] = wp_get_object_terms( $event_zoom->ID, $field['taxonomy'], array( 'fields' => 'ids' ) );
					}
					
					if(!empty( $field['type'] ) &&  $field['type'] == 'date' ){
						$event_date = get_post_meta( $event_zoom->ID, '_' . $key, true );
						$this->fields[ $group_key ][ $key ]['value'] = date($php_date_format ,strtotime($event_date) );
					}
				}
			}

			$this->fields = apply_filters( 'submit_event_form_fields_get_event_zoom_data', $this->fields, $event_zoom );
		}		

		wp_enqueue_style( 'jquery-ui-datepicker' );
		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );

		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );

		$zoom_settings = get_event_zoom_setting_by_user_id($user_id);

		$zoom_users = [];

		if(!empty($zoom_settings))
		{
			if( isset($zoom_settings['event_zoom_oauth_authorize']) && $zoom_settings['event_zoom_connection_options'] == 'oauth' && $zoom_settings['event_zoom_oauth_authorize'] )
			{
				$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();
			}
			elseif( !empty($zoom_settings['event_zoom_api_key']) && !empty($zoom_settings['event_zoom_api_secret_key']) )
			{
				//Load the Credentials
				WPEM_Zoom_API()->zoom_api_key    = $zoom_settings['event_zoom_api_key'];
				WPEM_Zoom_API()->zoom_api_secret = $zoom_settings['event_zoom_api_secret_key'];

				$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();
			}
		}

		get_event_manager_template( 
			'zoom-meeting-submit.php', 
			array(
				'form'               	=> $this->form_name,
				'event_zoom_id'      	=> $this->get_event_zoom_id(),
				'resume_edit'        	=> $this->resume_edit,
				'action'             	=> $this->get_action(),
				'event_zoom_fields'  	=> $this->get_fields( 'event_zoom' ),
				'step'               	=> $this->get_step(),
				'submit_button_text'	=> apply_filters( 'submit_zoom_meeting_form_submit_button_text',  __( 'Submit', 'wp-event-manager-zoom' ) ),
				'zoom_settings' 	 	=> $zoom_settings,
				'zoom_users' 			=> $zoom_users,
			),
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/'
		);

		
	}

	/**
	 * validate_fields function.
	 *
	 * @access protected
	 * @param $values
	 * @return 
	 * @since 1.0.0
	 */
	protected function validate_fields( $values ) {
		$this->fields =  apply_filters( 'before_submit_zoom_meeting_form_validate_fields', $this->fields , $values );
	      foreach ( $this->fields as $group_key => $group_fields )
    	  {     	      
				 
		        foreach ( $group_fields as $key => $field ) 
              	{
    				if ( $field['required'] && empty( $values[ $group_key ][ $key ] ) ) {	    
    					return new WP_Error( 'validation-error', sprintf( __( '%s is a required field', 'wp-event-manager-zoom' ), $field['label'] ) );
    				}

				    if ( !empty( $field['taxonomy'] ) && in_array( $field['type'], array( 'term-checklist', 'term-select', 'term-multiselect' ) ) ) {
    					if ( is_array( $values[ $group_key ][ $key ] ) ) {
    						$check_value = $values[ $group_key ][ $key ];
    					} else {
    						$check_value = empty( $values[ $group_key ][ $key ] ) ? array() : array( $values[ $group_key ][ $key ] );
    					}
    					foreach ( $check_value as $term ) {    
    						if ( ! term_exists( $term, $field['taxonomy'] ) ) {
    							return new WP_Error( 'validation-error', sprintf( __( '%s is invalid', 'wp-event-manager-zoom' ), $field['label'] ) );    
    						}
    					}
    				}

				if ( 'file' === $field['type'] && !empty( $field['allowed_mime_types'] ) ) {
					if ( is_array( $values[ $group_key ][ $key ] ) ) {
						$check_value = array_filter( $values[ $group_key ][ $key ] );
					} else {
						$check_value = array_filter( array( $values[ $group_key ][ $key ] ) );
					}
					if ( !empty( $check_value ) ) {
						foreach ( $check_value as $file_url ) {
							$file_url = current( explode( '?', $file_url ) );
							$file_info = wp_check_filetype( $file_url );
							if ( ! is_numeric( $file_url ) && $file_info && ! in_array( $file_info['type'], $field['allowed_mime_types'] ) ) {
								throw new Exception( sprintf( __( '"%s" (filetype %s) needs to be one of the following file types: %s', 'wp-event-manager-zoom' ), $field['label'], $info['ext'], implode( ', ', array_keys( $field['allowed_mime_types'] ) ) ) );
							}
						}
					}
				}
			}
		}
		
		//organizer email validation
		if (isset( $values['event_zoom']['event_zoom_email'] ) && !empty( $values['event_zoom']['event_zoom_email'] ) ) {
			if ( ! is_email( $values['event_zoom']['event_zoom_email'] ) ) {
				throw new Exception( __( 'Please enter a valid organizer email address', 'wp-event-manager-zoom' ) );
			}
				
		}
		
		return apply_filters( 'submit_zoom_meeting_form_validate_fields', true, $this->fields, $values );
	}

	/**
	 * submit_handler function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function submit_handler() {
		try {
			// Init fields
			//$this->init_fields(); We dont need to initialize with this function because of field edior
			// Now field editor function will return all the fields 
			//Get merged fields from db and default fields.
			$this->merge_with_custom_fields('frontend' );
			
			// Get posted values
			$values = $this->get_posted_fields();
			if ( empty( $_POST['submit_event_zoom'] ) || !is_user_logged_in() ) {
				return;
			}
			// Validate required
			if ( is_wp_error( ( $return = $this->validate_fields( $values ) ) ) ) {
				throw new Exception( $return->get_error_message() );
			}
			
			// Update the event
			$this->save_event_zoom( $values['event_zoom']['event_zoom_name'], $values['event_zoom']['event_zoom_description'], $this->event_zoom_id ? '' : 'publish', $values );
			$this->update_event_zoom_data( $values );
			// Successful, show next step
			$this->step ++;
		} catch ( Exception $e ) {
			$this->add_error( $e->getMessage() );
			return;
		}
	}

	/**
	 * save_event_zoom function.
	 *
	 * @access protected
	 * @param $$post_title, $post_content, $status, $values, $update_slug
	 * @return 
	 * @since 1.0.0
	 */
	protected function save_event_zoom( $post_title, $post_content, $status = 'publish', $values = array(), $update_slug = true ) {
		$event_zoom_data = array(
			'post_title'     => $post_title,
			'post_content'   => $post_content,
			'post_type'      => 'event_zoom',
			'comment_status' => 'closed'
		);


		if ( $status ) {
			$event_zoom_data['post_status'] = $status;
		}

		$event_zoom_data = apply_filters( 'submit_zoom_meeting_form_save_event_zoom_data', $event_zoom_data, $post_title, $post_content, $status, $values );
		
		if ( $this->event_zoom_id ) {
			$event_zoom_data['ID'] = $this->event_zoom_id;
			wp_update_post( $event_zoom_data );
		} 
		else 
		{
			$this->event_zoom_id = wp_insert_post( $event_zoom_data );
			if ( ! headers_sent() ) {
				$submitting_key = uniqid();
				setcookie( 'wp-event-manager-submitting-event-zoom-id', $this->event_zoom_id, 0, COOKIEPATH, COOKIE_DOMAIN, false );
				setcookie( 'wp-event-manager-submitting-event-zoom-key', $submitting_key, 0, COOKIEPATH, COOKIE_DOMAIN, false );
				update_post_meta( $this->event_zoom_id, '_submitting_key', $submitting_key );
			}
		}

		//Create Zoom Meeting / Webinar Now
		$meeting_id = get_post_meta( $this->event_zoom_id, '_meeting_zoom_meeting_id', true );		
		$event_zoom_post = get_post($this->event_zoom_id);
		$meeting_type = isset($_REQUEST['meeting_type']) ? $_REQUEST['meeting_type'] : 'meeting';

		if($meeting_type === 'webinar')
		{
			if ( empty( $meeting_id ) ) {
				//Create new Zoom Webinar
				$this->create_zoom_webinar( $event_zoom_post );
			} else {
				//Update Zoom Webinar
				$this->update_zoom_webinar( $event_zoom_post, $meeting_id );
			}
		}
		else
		{
			if ( empty( $meeting_id ) ) {
				//Create new Zoom Webinar
				$this->create_zoom_meeting( $event_zoom_post );
			} else {
				//Update Zoom Webinar
				$this->update_zoom_meeting( $event_zoom_post, $meeting_id );
			}
		}

	}

	/**
	 * update_event_zoom_data function.
	 *
	 * @access protected
	 * @param $values
	 * @return 
	 * @since 1.0.0
	 */
	protected function update_event_zoom_data( $values ) {
		$maybe_attach = array();
		
		//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
		$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
		
		//covert datepicker format  into php date() function date format
		$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

		$meeting_wc_product = [];

		// Loop fields and save meta and term data
		foreach ( $this->fields as $group_key => $group_fields ) {
			foreach ( $group_fields as $key => $field ) {
				// Save taxonomies
				if ( !empty( $field['taxonomy'] ) ) {
					if ( is_array( $values[ $group_key ][ $key ] ) ) {
						wp_set_object_terms( $this->event_zoom_id, $values[ $group_key ][ $key ], $field['taxonomy'], false );
					} else {
						wp_set_object_terms( $this->event_zoom_id, array( $values[ $group_key ][ $key ] ), $field['taxonomy'], false );
					}				
				// oragnizer logo is a featured image
				}
				elseif ( 'event_zoom_logo' === $key ) {
					$attachment_id = is_numeric( $values[ $group_key ][ $key ] ) ? absint( $values[ $group_key ][ $key ] ) : $this->create_attachment( $values[ $group_key ][ $key ] );
					if ( empty( $attachment_id ) ) {
						delete_post_thumbnail( $this->event_zoom_id );
					} else {
						set_post_thumbnail( $this->event_zoom_id, $attachment_id );
					}
					update_user_meta( get_current_user_id(), '_event_zoom_logo', $attachment_id );
				}
				elseif ( $field['type'] == 'date' ) {
					$date = $values[ $group_key ][ $key ];	
					if(!empty($date)) {
						//Convert date and time value into DB formatted format and save eg. 1970-01-01
						$date_dbformatted = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format  , $date );
						$date_dbformatted = !empty($date_dbformatted) ? $date_dbformatted : $date;
						update_post_meta( $this->event_zoom_id, '_' . $key, $date_dbformatted );
					}
					else
						update_post_meta( $this->event_zoom_id, '_' . $key, '' );
					
				}
				elseif ( in_array($key, ['enable_wc_purchase', 'meeting_wc_product_price', 'meeting_wc_product_id', 'meeting_wc_product_show_ticket_buy_button']) ) {

					$meeting_wc_product[$key] = $values[ $group_key ][ $key ];

				}
				else { 
					update_post_meta( $this->event_zoom_id, '_' . $key, $values[ $group_key ][ $key ] );
					// Handle attachments.
					if ( 'file' === $field['type']  ) {
						if ( is_array( $values[ $group_key ][ $key ] ) ) {
							foreach ( $values[ $group_key ][ $key ] as $file_url ) {
								$maybe_attach[] = $file_url;
							}
						} else {
							$maybe_attach[] = $values[ $group_key ][ $key ];
						}
					}
				}
			}
		}

		$maybe_attach = array_filter( $maybe_attach );
		// Handle attachments
		if ( sizeof( $maybe_attach ) && apply_filters( 'event_manager_attach_uploaded_files', true ) ) {
			
			// Get attachments
			$attachments     = get_posts( 'post_parent=' . $this->event_zoom_id . '&post_type=attachment&fields=ids&numberposts=-1' );
			$attachment_urls = array();
			// Loop attachments already attached to the event
			foreach ( $attachments as $attachment_key => $attachment ) {
				$attachment_urls[] = wp_get_attachment_url( $attachment );
			}
			foreach ( $maybe_attach as $attachment_url ) {
				if ( ! in_array( $attachment_url, $attachment_urls ) && !is_numeric($attachment_url) ) {
					$this->create_attachment( $attachment_url );
				}
			}
		}


		// Add/Edit product while create or edit meeting
		if ( is_plugin_active( 'woocommerce/woocommerce.php') ) 
		{
			if($meeting_wc_product['enable_wc_purchase'] && empty($meeting_wc_product['meeting_wc_product_id']))
			{
				$product_id = wp_insert_post( array(
							'post_type'     => 'product',
							'post_title'    => $values['event_zoom']['event_zoom_name'],
							'post_content'  => $values['event_zoom']['event_zoom_description'],
							'post_status'   => 'publish',
						) );	

				$meeting_wc_product['meeting_wc_product_id'] = $product_id;
			}			

			if($meeting_wc_product['enable_wc_purchase'] && !empty($meeting_wc_product['meeting_wc_product_id']))
			{
				$is_virtual = apply_filters('meeting_wc_is_virtual','yes');
				$sold_individually = apply_filters('meeting_wc_sold_individually','yes');

				update_post_meta($meeting_wc_product['meeting_wc_product_id'], '_regular_price', $meeting_wc_product['meeting_wc_product_price'] );
				update_post_meta($meeting_wc_product['meeting_wc_product_id'], '_price', $meeting_wc_product['meeting_wc_product_price'] );
				update_post_meta($meeting_wc_product['meeting_wc_product_id'], '_virtual', $is_virtual);
				update_post_meta($meeting_wc_product['meeting_wc_product_id'], '_sold_individually', $sold_individually );

				update_post_meta($meeting_wc_product['meeting_wc_product_id'], '_event_zoom_id', $this->event_zoom_id );

				$meeting_wc_product['meeting_wc_product_show_ticket_buy_button'] = !empty($meeting_wc_product['meeting_wc_product_show_ticket_buy_button']) ? $meeting_wc_product['meeting_wc_product_show_ticket_buy_button'] : '0';
				update_post_meta($this->event_zoom_id, '_meeting_wc_product', $meeting_wc_product );
			}
			else
			{
				update_post_meta($this->event_zoom_id, '_meeting_wc_product', '' );	
			}
		}
		
		do_action( 'event_manager_update_event_zoom_data', $this->event_zoom_id, $values );
	}

	/**
	 * create_attachment function.
	 *
	 * @access protected
	 * @param $attachment_url
	 * @return 
	 * @since 1.0.0
	 */
	protected function create_attachment( $attachment_url ) {
		include_once( ABSPATH . 'wp-admin/includes/image.php' );
		include_once( ABSPATH . 'wp-admin/includes/media.php' );
	
		$upload_dir     = wp_upload_dir();
		$attachment_url = esc_url( $attachment_url, array( 'http', 'https' ) );
		if ( empty( $attachment_url ) ) {
			return 0;
		}
		
		$attachment_url_parts = wp_parse_url( $attachment_url );
		if ( false !== strpos( $attachment_url_parts['path'], '../' ) ) {
			return 0;
		}
		$attachment_url = sprintf( '%s://%s%s', $attachment_url_parts['scheme'], $attachment_url_parts['host'], $attachment_url_parts['path'] );
		$attachment_url = str_replace( array( $upload_dir['baseurl'], WP_CONTENT_URL, site_url( '/' ) ), array( $upload_dir['basedir'], WP_CONTENT_DIR, ABSPATH ), $attachment_url );
		if ( empty( $attachment_url ) || ! is_string( $attachment_url ) ) {
			return 0;
		}
		
		$attachment     = array(
							'post_title'   => get_the_title( $this->event_zoom_id ),
							'post_content' => '',
							'post_status'  => 'inherit',
							'post_parent'  => $this->event_zoom_id,
							'guid'         => $attachment_url
						);
	
		if ( $info = wp_check_filetype( $attachment_url ) ) {
			$attachment['post_mime_type'] = $info['type'];
		}
	
		$attachment_id = wp_insert_attachment( $attachment, $attachment_url, $this->event_zoom_id );
	
		if ( ! is_wp_error( $attachment_id ) ) {
			wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $attachment_url ) );
			return $attachment_id;
		}
	
		return 0;
	}

	/**
	 * done function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function done() {
		do_action( 'event_manager_event_zoom_submitted', $this->event_zoom_id );

		$zoom_meeting_dashboard = get_option('event_zoom_meeting_dashboard_page_id');

		get_event_manager_template( 
			'zoom-meeting-submitted.php', 
			array( 
				'event_zoom' => get_post( $this->event_zoom_id ),
				'zoom_meeting_dashboard' => get_permalink($zoom_meeting_dashboard),
			),
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/'
		);
	}

	/**
	 * create_zoom_meeting function.
	 *
	 * @access private
	 * @param $post
	 * @return 
	 * @since 1.0.0
	 */
	private function create_zoom_meeting( $post ) {
		$pwd       = sanitize_text_field( filter_input( INPUT_POST, 'meeting_password' ) );
		$pwd       = !empty( $pwd ) ? $pwd : $post->ID;

		//timezone field if setting is site wise timezone
		$timezone_setting = get_option( 'event_manager_timezone_setting' ,'site_timezone' );
		if ( $timezone_setting != 'each_event' ) 
		{
			$timezone = WP_Event_Manager_Date_Time::get_current_site_timezone();
		}
		else
		{
			$timezone = sanitize_text_field( filter_input( INPUT_POST, 'meeting_timezone' ) );
		}

		//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
		$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
		
		//covert datepicker format  into php date() function date format
		$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

		$meeting_start_date = sanitize_text_field( filter_input( INPUT_POST, 'meeting_start_date' ) );
		$meeting_start_time = sanitize_text_field( filter_input( INPUT_POST, 'meeting_start_time' ) );

		$meeting_start_time = WP_Event_Manager_Date_Time::get_db_formatted_time($meeting_start_time);

		$date =  $meeting_start_date.' '.$meeting_start_time ;

		$meeting_start_date_time = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format . ' H:i:s', $date);
		$meeting_start_date_time = !empty($meeting_start_date_time) ? $meeting_start_date_time : $date;

		$params = array(
			'userId'                    => sanitize_text_field( filter_input( INPUT_POST, 'meeting_userId' ) ),
			'topic'              		=> $post->post_title,
			'start_date'                => $meeting_start_date_time,
			'timezone'                  => $timezone,
			'duration'                  => sanitize_text_field( filter_input( INPUT_POST, 'meeting_duration' ) ),
			'password'                  => $pwd,
			'option_meeting_authentication'	=> filter_input( INPUT_POST, 'meeting_option_authentication' ),
			'option_registration' 		=> filter_input( INPUT_POST, 'meeting_option_registration' ),
			'option_approval_type' 		=> filter_input( INPUT_POST, 'meeting_option_approval_type' ),
			'option_join_before_host'   => filter_input( INPUT_POST, 'meeting_option_join_before_host' ),
			'option_host_video'         => filter_input( INPUT_POST, 'meeting_option_host_video' ),
			'option_participants_video' => filter_input( INPUT_POST, 'meeting_option_participants_video' ),
			'option_mute_participants'  => filter_input( INPUT_POST, 'meeting_option_mute_participants' ),
			'option_auto_recording'     => filter_input( INPUT_POST, 'meeting_option_auto_recording' ),
			'alternative_host_ids'      => filter_input( INPUT_POST, 'meeting_alternative_host_ids', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY )
		); 
		
		$meeting_created = json_decode( WPEM_Zoom_API()->createAMeeting( $params ) );

		if ( empty( $meeting_created->code ) ) {
			if ( !empty($meeting_created) && isset($meeting_created->id) && !empty($meeting_created->id) ) {
				update_post_meta( $post->ID, '_meeting_zoom_details', $meeting_created );
				update_post_meta( $post->ID, '_meeting_zoom_join_url', $meeting_created->join_url );
				update_post_meta( $post->ID, '_meeting_zoom_start_url', $meeting_created->start_url );
				update_post_meta( $post->ID, '_meeting_zoom_meeting_id', $meeting_created->id );
				update_post_meta( $post->ID, '_meeting_zoom_error', '' );
			}
		}
		else
		{
			update_post_meta( $post->ID, '_meeting_zoom_error', $meeting_created );
		}
	}

	/**
	 * update_zoom_meeting function.
	 *
	 * @access private
	 * @param $post, $meeting_id
	 * @return 
	 * @since 1.0.0
	 */
	private function update_zoom_meeting( $post, $meeting_id ) {
		$pwd       = sanitize_text_field( filter_input( INPUT_POST, 'meeting_password' ) );
		$pwd       = !empty( $pwd ) ? $pwd : $post->ID;

		//timezone field if setting is site wise timezone
		$timezone_setting = get_option( 'event_manager_timezone_setting' ,'site_timezone' );
		if ( $timezone_setting != 'each_event' ) 
		{
			$timezone = WP_Event_Manager_Date_Time::get_current_site_timezone();
		}
		else
		{
			$timezone = sanitize_text_field( filter_input( INPUT_POST, 'meeting_timezone' ) );
		}

		//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
		$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
		
		//covert datepicker format  into php date() function date format
		$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

		$meeting_start_date = sanitize_text_field( filter_input( INPUT_POST, 'meeting_start_date' ) );
		$meeting_start_time = sanitize_text_field( filter_input( INPUT_POST, 'meeting_start_time' ) );

		$meeting_start_time = WP_Event_Manager_Date_Time::get_db_formatted_time($meeting_start_time);

		$date =  $meeting_start_date.' '.$meeting_start_time ;

		$meeting_start_date_time = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format . ' H:i:s', $date);
		$meeting_start_date_time = !empty($meeting_start_date_time) ? $meeting_start_date_time : $date;

		$params = array(
			'meeting_id'                => $meeting_id,
			'topic'                     => $post->post_title,
			'start_date'                => $meeting_start_date_time,
			'timezone'                  => $timezone,
			'duration'                  => sanitize_text_field( filter_input( INPUT_POST, 'meeting_duration' ) ),
			'password'                  => $pwd,
			'option_meeting_authentication'	=> filter_input( INPUT_POST, 'meeting_option_authentication' ),
			'option_registration' 		=> filter_input( INPUT_POST, 'meeting_option_registration' ),
			'option_approval_type' 		=> filter_input( INPUT_POST, 'meeting_option_approval_type' ),
			'option_join_before_host'   => filter_input( INPUT_POST, 'meeting_option_join_before_host' ),
			'option_host_video'         => filter_input( INPUT_POST, 'meeting_option_host_video' ),
			'option_participants_video' => filter_input( INPUT_POST, 'meeting_option_participants_video' ),
			'option_mute_participants'  => filter_input( INPUT_POST, 'meeting_option_mute_participants' ),
			'option_auto_recording'     => filter_input( INPUT_POST, 'meeting_option_auto_recording' ),
			'alternative_host_ids'      => filter_input( INPUT_POST, 'meeting_alternative_host_ids', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY )
		);

		$meeting_updated = json_decode( WPEM_Zoom_API()->updateMeetingInfo( $params ) );

		if ( empty( $meeting_updated->code ) ) {
			$meeting_info = json_decode( WPEM_Zoom_API()->getMeetingInfo( $meeting_id ) );
			if ( !empty($meeting_info) && isset($meeting_info->id) && !empty($meeting_info->id) ) {
				update_post_meta( $post->ID, '_meeting_zoom_details', $meeting_info );
				update_post_meta( $post->ID, '_meeting_zoom_join_url', $meeting_info->join_url );
				update_post_meta( $post->ID, '_meeting_zoom_start_url', $meeting_info->start_url );
				update_post_meta( $post->ID, '_meeting_zoom_meeting_id', $meeting_info->id );
				update_post_meta( $post->ID, '_meeting_zoom_error', '' );
			}
		}
		else
		{
			update_post_meta( $post->ID, '_meeting_zoom_error', $meeting_updated );
		}
	}

		/**
	 * create_zoom_meeting function.
	 *
	 * @access private
	 * @param $post
	 * @return 
	 * @since 1.0.0
	 */
	private function create_zoom_webinar( $post ) {
		$pwd       = sanitize_text_field( filter_input( INPUT_POST, 'meeting_password' ) );
		$pwd       = !empty( $pwd ) ? $pwd : $post->ID;

		//timezone field if setting is site wise timezone
		$timezone_setting = get_option( 'event_manager_timezone_setting' ,'site_timezone' );
		if ( $timezone_setting != 'each_event' ) 
		{
			$timezone = WP_Event_Manager_Date_Time::get_current_site_timezone();
		}
		else
		{
			$timezone = sanitize_text_field( filter_input( INPUT_POST, 'meeting_timezone' ) );
		}

		//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
		$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
		
		//covert datepicker format  into php date() function date format
		$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

		$meeting_start_date = sanitize_text_field( filter_input( INPUT_POST, 'meeting_start_date' ) );
		$meeting_start_time = sanitize_text_field( filter_input( INPUT_POST, 'meeting_start_time' ) );

		$meeting_start_time = WP_Event_Manager_Date_Time::get_db_formatted_time($meeting_start_time);

		$date =  $meeting_start_date.' '.$meeting_start_time ;

		$meeting_start_date_time = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format . ' H:i:s', $date);
		$meeting_start_date_time = !empty($meeting_start_date_time) ? $meeting_start_date_time : $date;

		$params = array(
			'userId'                    => sanitize_text_field( filter_input( INPUT_POST, 'meeting_userId' ) ),
			'topic'              		=> $post->post_title,
			'start_date'                => $meeting_start_date_time,
			'timezone'                  => $timezone,
			'duration'                  => sanitize_text_field( filter_input( INPUT_POST, 'meeting_duration' ) ),
			'password'                  => $pwd,
			'option_meeting_authentication'	=> filter_input( INPUT_POST, 'meeting_option_authentication' ),
			'option_registration' 		=> filter_input( INPUT_POST, 'meeting_option_registration' ),
			'option_approval_type' 		=> filter_input( INPUT_POST, 'meeting_option_approval_type' ),
			'option_host_video'         => filter_input( INPUT_POST, 'meeting_option_host_video' ),
			'option_panelists_video'    => filter_input( INPUT_POST, 'meeting_option_panelists_video' ),
			'option_practice_session'   => filter_input( INPUT_POST, 'meeting_option_practice_session' ),
			'option_hd_video'         	=> filter_input( INPUT_POST, 'meeting_option_hd_video' ),
			'option_allow_multiple_devices'	=> filter_input( INPUT_POST, 'meeting_option_allow_multiple_devices' ),
			'option_auto_recording'     => filter_input( INPUT_POST, 'meeting_option_auto_recording' ),
			'alternative_host_ids'      => filter_input( INPUT_POST, 'meeting_alternative_host_ids', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY )
		);
		
		$webinar_created = json_decode( WPEM_Zoom_API()->createAWebinar( $params ) );

		if ( empty( $webinar_created->code ) ) {
			if ( !empty($webinar_created) && isset($webinar_created->id) && !empty($webinar_created->id) ) {
				update_post_meta( $post->ID, '_meeting_zoom_details', $webinar_created );
				update_post_meta( $post->ID, '_meeting_zoom_join_url', $webinar_created->join_url );
				update_post_meta( $post->ID, '_meeting_zoom_start_url', $webinar_created->start_url );
				update_post_meta( $post->ID, '_meeting_zoom_meeting_id', $webinar_created->id );
				update_post_meta( $post->ID, '_meeting_zoom_error', '' );
			}
		}
		else
		{
			update_post_meta( $post->ID, '_meeting_zoom_error', $webinar_created );
		}
	}

	/**
	 * update_zoom_meeting function.
	 *
	 * @access private
	 * @param $post, $webinar_id
	 * @return 
	 * @since 1.0.0
	 */
	private function update_zoom_webinar( $post, $webinar_id ) {
		$pwd       = sanitize_text_field( filter_input( INPUT_POST, 'meeting_password' ) );
		$pwd       = !empty( $pwd ) ? $pwd : $post->ID;

		//timezone field if setting is site wise timezone
		$timezone_setting = get_option( 'event_manager_timezone_setting' ,'site_timezone' );
		if ( $timezone_setting != 'each_event' ) 
		{
			$timezone = WP_Event_Manager_Date_Time::get_current_site_timezone();
		}
		else
		{
			$timezone = sanitize_text_field( filter_input( INPUT_POST, 'meeting_timezone' ) );
		}

		//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
		$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
		
		//covert datepicker format  into php date() function date format
		$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

		$meeting_start_date = sanitize_text_field( filter_input( INPUT_POST, 'meeting_start_date' ) );
		$meeting_start_time = sanitize_text_field( filter_input( INPUT_POST, 'meeting_start_time' ) );

		$meeting_start_time = WP_Event_Manager_Date_Time::get_db_formatted_time($meeting_start_time);

		$date =  $meeting_start_date.' '.$meeting_start_time ;

		$meeting_start_date_time = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format . ' H:i:s', $date);
		$meeting_start_date_time = !empty($meeting_start_date_time) ? $meeting_start_date_time : $date;

		$params = array(
			'webinar_id'                => $webinar_id,
			'topic'                     => $post->post_title,
			'start_date'                => $meeting_start_date_time,
			'timezone'                  => $timezone,
			'duration'                  => sanitize_text_field( filter_input( INPUT_POST, 'meeting_duration' ) ),
			'password'                  => $pwd,
			'option_meeting_authentication'	=> filter_input( INPUT_POST, 'meeting_option_authentication' ),
			'option_registration' 		=> filter_input( INPUT_POST, 'meeting_option_registration' ),
			'option_approval_type' 		=> filter_input( INPUT_POST, 'meeting_option_approval_type' ),
			'option_host_video'         => filter_input( INPUT_POST, 'meeting_option_host_video' ),
			'option_panelists_video'    => filter_input( INPUT_POST, 'meeting_option_panelists_video' ),
			'option_practice_session'   => filter_input( INPUT_POST, 'meeting_option_practice_session' ),
			'option_hd_video'         	=> filter_input( INPUT_POST, 'meeting_option_hd_video' ),
			'option_allow_multiple_devices'	=> filter_input( INPUT_POST, 'meeting_option_allow_multiple_devices' ),
			'option_auto_recording'     => filter_input( INPUT_POST, 'meeting_option_auto_recording' ),
			'alternative_host_ids'      => filter_input( INPUT_POST, 'meeting_alternative_host_ids', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY )
		);

		$webinar_updated = json_decode( WPEM_Zoom_API()->updateWebinar( $params ) );

		if ( empty( $webinar_updated->code ) ) {
			$webinar_info = json_decode( WPEM_Zoom_API()->getWebinarInfo( $webinar_id ) );
			if ( !empty($webinar_info) && isset($webinar_info->id) && !empty($webinar_info->id) ) {
				update_post_meta( $post->ID, '_meeting_zoom_details', $webinar_info );
				update_post_meta( $post->ID, '_meeting_zoom_join_url', $webinar_info->join_url );
				update_post_meta( $post->ID, '_meeting_zoom_start_url', $webinar_info->start_url );
				update_post_meta( $post->ID, '_meeting_zoom_meeting_id', $webinar_info->id );
				update_post_meta( $post->ID, '_meeting_zoom_error', '' );
			}
		}
		else
		{
			update_post_meta( $post->ID, '_meeting_zoom_error', $webinar_updated );
		}
	}
	
}