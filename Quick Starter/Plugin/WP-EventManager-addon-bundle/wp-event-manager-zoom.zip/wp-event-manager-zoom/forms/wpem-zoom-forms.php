<?php
/**
 * WPEM_Zoom_Forms class.
 */

class WPEM_Zoom_Forms {

	/**
	 * The single instance of the class.
	 *
	 * @var self
	 * @since 1.0.0
	 */
	private static $_instance = null;

	/**
	 * Allows for accessing single instance of class. Class should only be constructed once per call.
	 *
	 * @since 1.0.0
	 * @static
	 * @return self Main instance.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {

		add_action( 'init', array( $this, 'load_posted_form' ) );
	}

	/**
	 * load_posted_form function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function load_posted_form() {

		if ( !empty( $_POST['event_manager_form'] ) ) {

			$this->load_form_class( sanitize_title( $_POST['event_manager_form'] ) );
		}
	}

	/**
	 * load_form_class function.
	 *
	 * @access private
	 * @param $form_name
	 * @return 
	 * @since 1.0.0
	 */
	private function load_form_class( $form_name ) {

		if ( ! class_exists( 'WPEM_Zoom_Form' ) ) {

			include 'wpem-zoom-form-abstract.php';
		}

		// Now try to load the form_name

		$form_class  = 'WPEM_Zoom_Form_' . str_replace( '-', '_', $form_name );

		$form_file   = WPEM_ZOOM_PLUGIN_DIR . '/forms/wpem-zoom-form-' . $form_name . '.php';			

		if ( class_exists( $form_class ) ) {

			return call_user_func( array( $form_class, 'instance' ) );
		}

		if ( ! file_exists( $form_file ) ) {

			return false;
		}

		if ( ! class_exists( $form_class ) ) {

			include $form_file;
		}

		// Init the form
		return call_user_func( array( $form_class, 'instance' ) );
	}

	/**
	 * get_form function.
	 *
	 * @access public
	 * @param $form_name, $atts
	 * @return 
	 * @since 1.0.0
	 */
	public function get_form( $form_name, $atts = array() ) {

		if ( $form = $this->load_form_class( $form_name ) ) {

			ob_start();

			$form->output( $atts );

			return ob_get_clean();
		}
	}
}