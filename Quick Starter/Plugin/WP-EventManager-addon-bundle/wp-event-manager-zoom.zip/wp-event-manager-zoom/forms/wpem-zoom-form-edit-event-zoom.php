<?php

include_once( 'wpem-zoom-form-submit-event-zoom.php' );

/**
 * WPEM_Zoom_Form_Edit_Event_Zoom class.
 */

class WPEM_Zoom_Form_Edit_Event_Zoom extends WPEM_Zoom_Form_Submit_Event_Zoom {

	public $form_name           = 'edit-event-zoom';

	/** @var WP_Event_Manager_Form_Edit_Organizer The single instance of the class */

	protected static $_instance = null;

	/**
	 * Main Instance
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {

			self::$_instance = new self();
		}
		
		return self::$_instance;
	}

	/**
	 * Constructor
	*/	
	public function __construct() {

		$this->user_page = new WPEM_Zoom_User();
		
		$this->event_zoom_id = !empty( $_REQUEST['event_zoom_id'] ) ? absint( $_REQUEST[ 'event_zoom_id' ] ) : 0;

		if  ( ! event_manager_user_can_edit_event( $this->event_zoom_id ) ) {

			$this->event_zoom_id = 0;
		}
	}

	/**
	 * output function.
	 *
	 * @access public
	 * @param $atts
	 * @return 
	 * @since 1.0.0
	 */
	public function output( $atts = array() ) {

		$this->submit_handler();

		$this->submit();
	}

	/**
	 * submit function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function submit() {

		$user_id = get_current_user_id();

		$event_zoom = get_post( $this->event_zoom_id );

		if ( empty( $this->event_zoom_id  ) || ( $event_zoom->post_status !== 'publish') ) {

			echo wpautop( __( 'Invalid listing', 'wp-event-manager-zoom' ) );

			return;
		}

		// Init fields
		//$this->init_fields(); We dont need to initialize with this function because of field edior
		// Now field editor function will return all the fields 
		//Get merged fields from db and default fields.
		$this->merge_with_custom_fields( 'frontend' );
		
		//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
		$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
		
		//covert datepicker format  into php date() function date format
		$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

		$meeting_wc_product = get_post_meta($event_zoom->ID, '_meeting_wc_product', true );
		
		foreach ( $this->fields as $group_key => $group_fields ) {

			foreach ( $group_fields as $key => $field ) {

				if ( ! isset( $this->fields[ $group_key ][ $key ]['value'] ) ) {

					if ( 'event_zoom_name' === $key ) {

						$this->fields[ $group_key ][ $key ]['value'] = $event_zoom->post_title;

					} elseif ( 'event_description' === $key ) {

						$this->fields[ $group_key ][ $key ]['value'] = $event_zoom->post_content;

					} elseif ( 'event_zoom_logo' === $key ) {
						$this->fields[ $group_key ][ $key ]['value'] = has_post_thumbnail( $event_zoom->ID ) ? get_post_thumbnail_id( $event_zoom->ID ) : get_post_meta( $event_zoom->ID, '_' . $key, true );
						
					} elseif ( !empty( $field['taxonomy'] ) ) {

						$this->fields[ $group_key ][ $key ]['value'] = wp_get_object_terms( $event_zoom->ID, $field['taxonomy'], array( 'fields' => 'ids' ) );

					} elseif ( in_array($key, ['enable_wc_purchase', 'meeting_wc_product_price', 'meeting_wc_product_id', 'meeting_wc_product_show_ticket_buy_button']) ) {

						$this->fields[ $group_key ][ $key ]['value'] = isset($meeting_wc_product[$key]) ? $meeting_wc_product[$key] : '';

					}else {

						$this->fields[ $group_key ][ $key ]['value'] = get_post_meta( $event_zoom->ID, '_' . $key, true );
					}
				}
				if(!empty( $field['type'] ) &&  $field['type'] == 'date'){
					$event_zoom_date = get_post_meta( $event_zoom->ID, '_' . $key, true );
					$this->fields[ $group_key ][ $key ]['value'] = !empty($event_zoom_date) ? date($php_date_format ,strtotime($event_zoom_date) ) :'';
				}
			}
		}

		$this->fields = apply_filters( 'submit_zoom_meeting_form_fields_get_event_zoom_data', $this->fields, $event_zoom );

		wp_enqueue_style( 'jquery-ui-datepicker' );
		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );

		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );

		$zoom_settings = get_event_zoom_setting_by_user_id($user_id);

		$zoom_users = [];

		if(!empty($zoom_settings))
		{
			if( isset($zoom_settings['event_zoom_oauth_authorize']) && $zoom_settings['event_zoom_connection_options'] == 'oauth' && $zoom_settings['event_zoom_oauth_authorize'] )
			{
				$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();
			}
			elseif( !empty($zoom_settings['event_zoom_api_key']) && !empty($zoom_settings['event_zoom_api_secret_key']) )
			{
				//Load the Credentials
				WPEM_Zoom_API()->zoom_api_key    = $zoom_settings['event_zoom_api_key'];
				WPEM_Zoom_API()->zoom_api_secret = $zoom_settings['event_zoom_api_secret_key'];

				$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();
			}
		}

		get_event_manager_template( 
			'zoom-meeting-submit.php', 
			array(
				'form'               	=> $this->form_name,
				'event_zoom_id'         => $this->get_event_zoom_id(),
				'action'             	=> $this->get_action(),
				'event_zoom_fields'     => $this->get_fields( 'event_zoom' ),
				'step'               	=> $this->get_step(),
				'submit_button_text'	=> __( 'Save changes', 'wp-event-manager-zoom' ),
				'zoom_settings' 		=> $zoom_settings,
				'zoom_users' 			=> $zoom_users,
			),
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/'
		);
	}

	/**
	 * submit_handler function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function submit_handler() {

		if ( empty( $_POST['submit_event_zoom'] ) ) {

			return;
		}

		try {

			// Get posted values

			$values = $this->get_posted_fields();

			// Validate required

			if ( is_wp_error( ( $return = $this->validate_fields( $values ) ) ) ) {

				throw new Exception( $return->get_error_message() );
			}
			
			// Update the event

			$this->save_event_zoom( $values['event_zoom']['event_zoom_name'], $values['event_zoom']['event_zoom_description'], '', $values, false );

			$this->update_event_zoom_data( $values );

			$zoom_dashboard_page_id = get_option('event_zoom_meeting_dashboard_page_id');

			// Successful

			switch ( get_post_status( $this->event_zoom_id ) ) {

				case 'publish' :

					echo '<div class="event-manager-message wpem-alert wpem-alert-success">' . __( 'Your changes have been saved.', 'wp-event-manager-zoom' ) . ' <a href="' . get_permalink( $zoom_dashboard_page_id ) . '">' . __( 'View &rarr;', 'wp-event-manager-zoom' ) . '</a>' . '</div>';

				break;

				default :

					echo '<div class="event-manager-message wpem-alert wpem-alert-success">' . __( 'Your changes have been saved.', 'wp-event-manager-zoom' ) . '</div>';

				break;
			}

		} catch ( Exception $e ) {

			echo '<div class="wpem-alert wpem-alert-danger">' . $e->getMessage() . '</div>';

			return;
		}
	}
}