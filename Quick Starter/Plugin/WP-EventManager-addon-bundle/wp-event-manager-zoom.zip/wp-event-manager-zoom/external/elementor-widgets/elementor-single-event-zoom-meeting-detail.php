<?php
namespace WPEventManagerZoom\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Meeting Detail
 *
 * Elementor widget for meeting short info
 *
 */
class Elementor_Single_Event_Zoom_Meeting_Detail extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'single-event-zoom-meeting-detail';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Single Event Zoom Meeting / Webinar Detail', 'wp-event-manager-zoom' );
	}
	/**	
	 * Get widget icon.
	 *
	 * Retrieve shortcode widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-video-camera';
	}
	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'single-event-zoom-meeting-detail', 'code' ];
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'wp-event-manager-categories' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'section_shortcode',
			[
				'label' => __( 'Single Event Zoom Meeting / Webinar Detail', 'wp-event-manager-zoom' ),
			]
		);

		$this->add_control(
			'show_title',
			[
				'label' => __( 'Show Title', 'wp-event-manager-zoom' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'no',
				'options' => [
					'no' => __( 'No', 'wp-event-manager-zoom' ),
					'yes' => __( 'Yes', 'wp-event-manager-zoom' ),
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		global $post;

		$user_id = get_current_user_id();

	    $settings = $this->get_settings_for_display();

	    $event_zoom_id = get_post_meta($post->ID, '_event_zoom_id', true);

		if(empty($event_zoom_id)){
			return;
		}

		$meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );

		if( !empty($meeting) && isset($meeting->id) && !empty($meeting->id) )
		{
			$zoom_settings = get_event_zoom_setting_by_meeting_id($meeting->id);
		
			if ( isset($zoom_settings['event_zoom_show_on_single_event']) && !$zoom_settings['event_zoom_show_on_single_event'] ) {
				if($zoom_settings['post_author'] != $user_id){
					return;
				}
			}

			echo '<div class="elementor-single-event-zoom-meeting-detail-widget">';
			echo do_shortcode( '[event_zoom_meeting_detail show_title="'. $settings['show_title'] .'" event_zoom_id="'. $event_zoom_id .'"]' );
			echo '</div>';
		}
	    
	}
	
}
