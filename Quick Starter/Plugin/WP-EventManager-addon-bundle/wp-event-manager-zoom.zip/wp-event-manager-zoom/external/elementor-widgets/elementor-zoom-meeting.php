<?php
namespace WPEventManagerZoom\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Meeting Short Info
 *
 * Elementor widget for meeting short info
 *
 */
class Elementor_Zoom_Meeting extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'zoom-meeting';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Zoom Meeting / Webinar', 'wp-event-manager-zoom' );
	}
	/**	
	 * Get widget icon.
	 *
	 * Retrieve shortcode widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-video-camera';
	}
	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'zoom-meeting', 'code' ];
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'wp-event-manager-zoom-categories' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'section_shortcode',
			[
				'label' => __( 'Zoom Meeting / Webinar', 'wp-event-manager-zoom' ),
			]
		);

		$user_id = get_current_user_id();

		$args = [];
		
		if ( current_user_can( 'manage_options' ) ) 
		{
			
		}
		else
		{
			if(get_option('enable_frontend_zoom_connection', true))
			{
				if(!empty($user_id))
				{
					$args = ['author' => $user_id];
				}
			}
		}		

	    $result = get_event_manager_zoom_meeting_list($args);

	    $event_meeting_list = [];

		if($result->found_posts > 0)
		{
			$event_meeting_list[''] =  __( 'Select Zoom Meeting / Webinar', 'wp-event-manager-zoom' );

			foreach ($result->posts as $post) 
			{
				$meeting_id = get_post_meta( $post->ID, '_meeting_zoom_meeting_id', true );

				if ( !empty( $meeting_id ) ) 
				{
					$event_meeting_list[$meeting_id] = $post->post_title;
				}
			}
		}

	    $this->add_control(
			'meeting_id',
			[
				'label' => __( 'Select Meeting', 'wp-event-manager-zoom' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => $event_meeting_list
			]
		);

		$this->add_control(
			'link_only',
			[
				'label' => __( 'Link Only', 'wp-event-manager-zoom' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'no',
				'options' => [
					'no' => __( 'No', 'wp-event-manager-zoom' ),
					'yes' => __( 'Yes', 'wp-event-manager-zoom' ),
				],
			]
		);

		$this->add_control(
			'show_help',
			[
				'label' => __( 'Show Help', 'wp-event-manager-zoom' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'no',
				'options' => [
					'no' => __( 'No', 'wp-event-manager-zoom' ),
					'yes' => __( 'Yes', 'wp-event-manager-zoom' ),
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
	    $settings = $this->get_settings_for_display();

	    if($settings['meeting_id'] > 0)
		    $meeting_id = $settings['meeting_id'];
	    else
	        $meeting_id = '';

	    echo '<div class="elementor-zoom-meeting-widget">';
	    echo do_shortcode( '[event_zoom_meeting link_only="'. $settings['link_only'] .'" show_help="'. $settings['show_help'] .'" meeting_id="'.$meeting_id.'"]' );
	    echo '</div>';
	}
	
}
