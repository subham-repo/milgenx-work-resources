<?php
namespace WPEventManagerZoom;

/**
 * Class Plugin
 *
 * Main Plugin class
 */
class Plugin {

	/**
	 * Instance
	 *
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 *  Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @access public
	 */
	public function __construct() {
		// Register Categories
		add_action( 'elementor/elements/categories_registered', [ $this, 'register_categories' ]);

		// Register Scripts
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
	}

	/**
	 * Register new category for WP-event-manager-zoom core widget
	 * @param $elementsManager
	 */
	public function register_categories($elementsManager) {
		$elementsManager =\Elementor\Plugin::instance()->elements_manager;
		
		$elementsManager->add_category(
			'wp-event-manager-zoom-categories',
			array(
				'title' => 'WP Event Manager Zoom',
				'icon'  => 'fonts',
			), 0 // 0 to TOP
		);
	}

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @access private
	 */
	private function include_widgets_files() {
		require_once( __DIR__ . '/elementor-widgets/elementor-single-event-zoom-meeting.php' );
		require_once( __DIR__ . '/elementor-widgets/elementor-single-event-zoom-meeting-detail.php' );

		require_once( __DIR__ . '/elementor-widgets/elementor-zoom-meeting-dashboard.php' );
		require_once( __DIR__ . '/elementor-widgets/elementor-zoom-meeting-submit.php' );
		require_once( __DIR__ . '/elementor-widgets/elementor-zoom-meeting.php' );
		require_once( __DIR__ . '/elementor-widgets/elementor-zoom-meeting-detail.php' );
	}

	/**
	 * Widget scripts
	 *
	 * widget_scripts
	 *
	 * @access private
	 */
	public function widget_scripts() {

		$user_id = get_current_user_id();

		wp_enqueue_style( 'wp-event-manager-zoom-frontend', WPEM_ZOOM_PLUGIN_URL . '/assets/css/frontend.min.css' );

		//wp_enqueue_script( 'wp-event-manager-zoom-moment', WPEM_ZOOM_PLUGIN_URL . '/assets/js/moment/moment.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );

		wp_enqueue_script( 'wp-event-manager-zoom-dashboard', WPEM_ZOOM_PLUGIN_URL . '/assets/js/event-zoom-dashboard.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );

		$zoom_settings = get_event_zoom_setting_by_user_id($user_id);

		$translation_array   = array(
			'meeting_started'  => !empty( $zoom_settings['event_zoom_meeting_started_text'] ) ? $zoom_settings['event_zoom_meeting_started_text'] : __( 'Meeting Has Started ! Click below join button to join meeting now !', 'wp-event-manager-zoom' ),
			'meeting_starting' => !empty( $zoom_settings['event_zoom_meeting_going_to_start_text'] ) ? $zoom_settings['event_zoom_meeting_going_to_start_text'] : __( 'Click join button below to join the meeting now !', 'wp-event-manager-zoom' ),
			'meeting_ended'    => !empty( $zoom_settings['event_zoom_meeting_ended_text'] ) ? $zoom_settings['event_zoom_meeting_ended_text'] : __( 'This meeting has been ended by the host.', 'wp-event-manager-zoom' ),
		);
		wp_localize_script( 'wp-event-manager-zoom-dashboard', 'meeting_button', $translation_array );
		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @access public
	 */
	public function register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();

		// Register Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Elementor_Single_Event_Zoom_Meeting() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Elementor_Single_Event_Zoom_Meeting_Detail() );

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Elementor_Zoom_Meeting_Dashboard() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Elementor_Zoom_Meeting_Submit() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Elementor_Zoom_Meeting() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Elementor_Zoom_Meeting_Detail() );
	}

}

// Instantiate Plugin Class
Plugin::instance();
