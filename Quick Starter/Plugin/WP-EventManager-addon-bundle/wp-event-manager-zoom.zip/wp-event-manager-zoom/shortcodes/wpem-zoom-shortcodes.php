<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * WPEM_Zoom_Shortcodes class.
 */

class WPEM_Zoom_Shortcodes {

	private $zoom_meeting_dashboard_message = '';

	public function __construct() {

		add_action( 'wp', array( $this, 'shortcode_action_handler' ) );

		add_shortcode( 'zoom_meeting_dashboard', array( $this, 'zoom_meeting_dashboard' ) );
		add_shortcode( 'submit_zoom_meeting_form', array( $this, 'submit_zoom_meeting_form' ) );

		add_action( 'event_manager_zoom_meeting_dashboard_content_edit', array( $this, 'edit_event_zoom' ) );

		add_shortcode( 'event_zoom_meeting', array( $this, 'event_zoom_meeting' ) );
		add_shortcode( 'event_zoom_meeting_detail', array( $this, 'event_zoom_meeting_detail' ) );

		add_filter( 'event_manager_chosen_enabled', array( $this, 'wpem_event_manager_chosen_enabled') );
	}

	/**
	 * event_manager_zoom_shortcodes function.
	 * add for show host with chosen js in meeting add/edit form.
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function wpem_event_manager_chosen_enabled( $wpem_shortcodes) {	

		return true;
	}

	/**
	 * shortcode_action_handler function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function shortcode_action_handler() {

		global $post;
		
		if ( is_page() && strstr( $post->post_content, '[zoom_meeting_dashboard' ) ) {

			$this->zoom_meeting_dashboard_handler();
		}
	}

	/**
	 * zoom_meeting_dashboard_handler function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function zoom_meeting_dashboard_handler() {

		if ( !empty( $_REQUEST['action'] ) && !empty( $_REQUEST['_wpnonce'] ) && wp_verify_nonce( $_REQUEST['_wpnonce'], 'event_manager_my_event_zoom_actions' ) ) {

			$action = sanitize_title( $_REQUEST['action'] );

			$event_zoom_id = absint( $_REQUEST['event_zoom_id'] );

			try {

				// Get Event
				$event    = get_post( $event_zoom_id );

				// Check ownership
				if ( ! event_manager_user_can_edit_event( $event_zoom_id ) ) {

					throw new Exception( __( 'Invalid ID', 'wp-event-manager-zoom' ) );
				}

				switch ( $action ) {
					case 'delete' :
						// Trash it
						wp_trash_post( $event_zoom_id );

						// Message
						$this->zoom_meeting_dashboard_message = '<div class="event-manager-message wpem-alert wpem-alert-danger">' . sprintf( __( '%s has been deleted', 'wp-event-manager-zoom' ), esc_html( $event->post_title ) ) . '</div>';

						break;
					case 'duplicate' :
						if ( ! event_manager_get_permalink( 'submit_zoom_meeting_form' ) ) {
							throw new Exception( __( 'Missing submission page.', 'wp-event-manager-zoom' ) );
						}
					
						$new_event_id = event_manager_duplicate_listing( $event_zoom_id );
					
						if ( $new_event_id ) {
							$my_post = array(
						      	'ID'           => $new_event_id,
						      	'post_status'   => 'publish',
						  	);
							  
							// Update the post into the database
							wp_update_post( $my_post );


							wp_redirect( add_query_arg( array( 'event_zoom_id' => absint( $new_event_id ) ), event_manager_get_permalink( 'submit_zoom_meeting_form' ) ) );
							exit;
						}
					
					break;

					default :

						do_action( 'event_manager_zoom_meeting_dashboard_do_action_' . $action );

						break;
				}
				
				do_action( 'event_manager_my_event_zoom_do_action', $action, $event_zoom_id );

			} catch ( Exception $e ) {

				$this->zoom_meeting_dashboard_message = '<div class="wpem-alert wpem-alert-danger">' . $e->getMessage() . '</div>';
			}
		}
	}	

	/**
	 * zoom_meeting_dashboard function.
	 *
	 * @access public
	 * @param $atts
	 * @return 
	 * @since 1.0.0
	 */
	public function zoom_meeting_dashboard( $atts = [] ) {

		if ( ! is_user_logged_in() ) {

			ob_start();

			get_event_manager_template( 'event-dashboard-login.php' );

			return ob_get_clean();
		}

		ob_start();

		if(!get_option('enable_frontend_zoom_connection', true) && !current_user_can( 'manage_options' ))
		{
			echo '<div class="wpem-alert wpem-alert-danger">' . __( 'You do not have enough priviledge to access this page. Please contact to Admin.', 'wp-event-manager-zoom' ) . '</div>';

			return;
		}

		$user_id = get_current_user_id();

		$zoom_settings = get_event_zoom_setting_by_user_id($user_id);
		$show_form = false;
		$zoom_dashboard = get_option('event_zoom_meeting_dashboard_page_id');
		$zoom_action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
		$zoom_users = json_decode( WPEM_Zoom_API()->listUsers() );

		if( isset($zoom_settings['event_zoom_connection_options']) && $zoom_settings['event_zoom_connection_options'] == 'jwt' && (empty($zoom_settings['event_zoom_api_key']) || empty($zoom_settings['event_zoom_api_secret_key'])) ) : ?>
			<div class="wpem-alert wpem-alert-danger">
				<?php _e( 'Please add API Key & Secret Key in Zoom Settings', 'wp-event-manager-zoom' ); ?> 
				<?php if($zoom_action != 'show_zoom_settings') : ?>
					<a href="<?php echo add_query_arg( array( 'action' => 'show_zoom_settings' ), get_permalink( $zoom_dashboard ) ); ?>"><?php _e( 'Click Here', 'wp-event-manager-zoom' ); ?></a>
				<?php endif; ?>
			</div>

		<?php elseif( isset($zoom_settings['event_zoom_connection_options']) && $zoom_settings['event_zoom_connection_options'] == 'oauth' && (empty($zoom_settings['event_zoom_client_id']) || empty($zoom_settings['event_zoom_client_secret'])) ) : ?>
		    <div class="wpem-alert wpem-alert-danger">
		    	<?php _e( 'Please add Client ID & Secret Key in Zoom Settings', 'wp-event-manager-zoom' ); ?> 
		    	<?php if($zoom_action != 'show_zoom_settings') : ?>
					<a href="<?php echo add_query_arg( array( 'action' => 'show_zoom_settings' ), get_permalink( $zoom_dashboard ) ); ?>"><?php _e( 'Click Here', 'wp-event-manager-zoom' ); ?></a>
				<?php endif; ?>
		    </div>
		
		<?php elseif ( isset($zoom_users->code) && $zoom_users->code === 124 ) : ?>
		    <div class="wpem-alert wpem-alert-danger"><?php echo $zoom_users->message; ?></div>
		
		<?php elseif( empty($zoom_settings) ) : ?>
			    <div class="wpem-alert wpem-alert-danger">
			    	<?php _e( 'Zoom Account Not Connected.', 'wp-event-manager-zoom' ); ?> 
			    	<?php if($zoom_action != 'show_zoom_settings') : ?>
						<a href="<?php echo add_query_arg( array( 'action' => 'show_zoom_settings' ), get_permalink( $zoom_dashboard ) ); ?>"><?php _e( 'Click Here', 'wp-event-manager-zoom' ); ?></a>
					<?php endif; ?>
			    </div>
		
		<?php else : ?>
			<div class="wpem-alert wpem-alert-success"><?php _e( 'Zoom Account Connected.', 'wp-event-manager-zoom' ); ?></div>

		<?php endif;
		
		extract( shortcode_atts( array(

			'posts_per_page' => '25',

		), $atts ) );

		// If doing an action, show conditional content if needed....

		if ( !empty( $_REQUEST['action'] ) ) {

			$action = sanitize_title( $_REQUEST['action'] );

			// Show alternative content if a plugin wants to

			if ( has_action( 'event_manager_zoom_meeting_dashboard_content_' . $action ) ) {

				do_action( 'event_manager_zoom_meeting_dashboard_content_' . $action, $atts );

				return ob_get_clean();
			}
		}
		
		// ....If not show the event dashboard

		$args     = apply_filters( 'event_manager_get_dashboard_event_zooms_args', array(

			'post_type'           => 'event_zoom',
			'post_status'         => array( 'publish' ),
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $posts_per_page,
			'offset'              => ( max( 1, get_query_var('paged') ) - 1 ) * $posts_per_page,
			'orderby'             => 'date',
			'order'               => 'desc',
			'author'              => get_current_user_id()

		) );

		$event_zooms = new WP_Query;
		echo $this->zoom_meeting_dashboard_message;

		$zoom_meeting_dashboard_columns = apply_filters( 'event_manager_zoom_meeting_dashboard_columns', array(
			'event_zoom_name' => __( 'Title', 'wp-event-manager-zoom' ),
			'zoom_meeting_id' => __( 'Meeting ID', 'wp-event-manager-zoom' ), 
			'zoom_meeting_type' => __( 'Meeting Type', 'wp-event-manager-zoom' ), 
			'zoom_meeting_startdate' => __( 'Start Date & Time', 'wp-event-manager-zoom' ),
			'zoom_meeting_end' => __( 'Status', 'wp-event-manager-zoom' ), 
			'event_zoom_action' => __( 'Action', 'wp-event-manager-zoom' ), 
		) );

		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );
		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );

		get_event_manager_template( 
			'zoom-meeting-dashboard.php', 
			array( 
				'event_zooms' => $event_zooms->query( $args ), 
				'max_num_pages' => $event_zooms->max_num_pages, 
				'zoom_meeting_dashboard_columns' => $zoom_meeting_dashboard_columns,
			),
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/'
		);

		return ob_get_clean();
	}

	/**
	 * submit_zoom_meeting_form function.
	 *
	 * @access public
	 * @param $atts
	 * @return 
	 * @since 1.0.0
	 */
	public function submit_zoom_meeting_form( $atts = [] ) {

		if ( ! is_user_logged_in() ) {

			ob_start();

			get_event_manager_template( 'event-dashboard-login.php' );

			return ob_get_clean();
		}

		ob_start();

		if(!get_option('enable_frontend_zoom_connection', true) && !current_user_can( 'manage_options' ))
		{
			echo '<div class="wpem-alert wpem-alert-danger">' . __( 'You do not have enough priviledge to access this page. Please contact to Admin.', 'wp-event-manager-zoom' ) . '</div>';

			return;
		}

		$user_id = get_current_user_id();

		$zoom_settings = get_event_zoom_setting_by_user_id($user_id);
		$show_form = false;
		$zoom_dashboard = get_option('event_zoom_meeting_dashboard_page_id');
		$zoom_users = json_decode( WPEM_Zoom_API()->listUsers() );

		if( isset($zoom_settings['event_zoom_connection_options']) && $zoom_settings['event_zoom_connection_options'] == 'jwt' && (empty($zoom_settings['event_zoom_api_key']) || empty($zoom_settings['event_zoom_api_secret_key'])) ) : ?>
			<div class="wpem-alert wpem-alert-danger">
				<?php _e( 'Please add API Key & Secret Key in Zoom Settings', 'wp-event-manager-zoom' ); ?> <a href="<?php echo add_query_arg( array( 'action' => 'show_zoom_settings' ), get_permalink( $zoom_dashboard ) ); ?>"><?php _e( 'Click Here', 'wp-event-manager-zoom' ); ?></a>
			</div>
			<?php $show_form = false; ?>

		<?php elseif( isset($zoom_settings['event_zoom_connection_options']) && $zoom_settings['event_zoom_connection_options'] == 'oauth' && (empty($zoom_settings['event_zoom_client_id']) || empty($zoom_settings['event_zoom_client_secret'])) ) : ?>
		    <div class="wpem-alert wpem-alert-danger">
		    	<?php _e( 'Please add Client ID & Secret Key in Zoom Settings', 'wp-event-manager-zoom' ); ?> <a href="<?php echo add_query_arg( array( 'action' => 'show_zoom_settings' ), get_permalink( $zoom_dashboard ) ); ?>"><?php _e( 'Click Here', 'wp-event-manager-zoom' ); ?></a>
		    </div>
		    <?php $show_form = false; ?>
		
		<?php elseif( !empty($zoom_users->code) ) : ?>
		    <div class="wpem-alert wpem-alert-danger"><?php echo $zoom_users->message; ?></div>
		    <?php $show_form = false; ?>
		
		<?php elseif( empty($zoom_settings) ) : ?>
			    <div class="wpem-alert wpem-alert-danger">
			    	<?php _e( 'Zoom Account Not Connected.', 'wp-event-manager-zoom' ); ?> <a href="<?php echo add_query_arg( array( 'action' => 'show_zoom_settings' ), get_permalink( $zoom_dashboard ) ); ?>"><?php _e( 'Click Here', 'wp-event-manager-zoom' ); ?></a>
			    </div>
			    <?php $show_form = false; ?>
		
		<?php else : ?>
		    <div class="wpem-alert wpem-alert-success"><?php _e( 'Zoom Account Connected.', 'wp-event-manager-zoom' ); ?></div>
		    <?php $show_form = true; ?>
		
		<?php endif;

		if(!$show_form)
			return;
		
		ob_get_clean();

		return $GLOBALS['event_manager_zoom']->forms->get_form( 'submit-event-zoom', $atts );
	}

	/**
	 * edit_event_zoom function.
	 *
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function edit_event_zoom() {

		echo $GLOBALS['event_manager_zoom']->forms->get_form( 'edit-event-zoom' );
	}

	/**
	 * event_zoom_meeting function.
	 *
	 * @access public
	 * @param $atts,$content
	 * @return 
	 * @since 1.0.0
	 */
	public function event_zoom_meeting( $atts = [], $content = null ) {

		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );

		if ( ! is_user_logged_in() ) {

			//echo '<div class="wpem-alert wpem-alert-danger">' . __( 'You must sign in to view zoom meeting details.', 'wp-event-manager-zoom' ) . '</div>';

			return;
		}

		extract( shortcode_atts( array(
			'meeting_id' => '',
			'link_only'  => 'no',
			'show_help'  => 'no',
		), $atts ) );

		ob_start();

		$user_id = get_current_user_id();

		if ( empty( $meeting_id ) ) {

			//echo '<div class="wpem-alert wpem-alert-danger">' . __( 'No meeting id set in the shortcode', 'wp-event-manager-zoom' ) . '</div>';

			return;
		}

		$zoom_settings = get_event_zoom_setting_by_meeting_id($meeting_id);
		
		if ( isset($zoom_settings['event_zoom_show_on_single_event_sidebar']) && !$zoom_settings['event_zoom_show_on_single_event_sidebar'] ) {
			if($zoom_settings['post_author'] != $user_id){
				return;
			}
		}

		wp_enqueue_script( 'wp-event-manager-zoom-moment' );
		wp_enqueue_script( 'wp-event-manager-zoom-moment-timezone' );
		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );

		$translation_array   = array(
			'meeting_started'  => !empty( $zoom_settings['event_zoom_meeting_started_text'] ) ? $zoom_settings['event_zoom_meeting_started_text'] : __( 'Meeting Has Started ! Click below join button to join meeting now !', 'wp-event-manager-zoom' ),
			'meeting_starting' => !empty( $zoom_settings['event_zoom_meeting_going_to_start_text'] ) ? $zoom_settings['event_zoom_meeting_going_to_start_text'] : __( 'Click join button below to join the meeting now !', 'wp-event-manager-zoom' ),
			'meeting_ended'    => !empty( $zoom_settings['event_zoom_meeting_ended_text'] ) ? $zoom_settings['event_zoom_meeting_ended_text'] : __( 'This meeting has been ended by the host.', 'wp-event-manager-zoom' ),
		);
		wp_localize_script( 'wp-event-manager-zoom-dashboard', 'meeting_button', $translation_array );
		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );
		

		if ( empty( $zoom_settings['post_id'] ) ) {

			//echo '<div class="wpem-alert wpem-alert-danger">' . __( 'Wrong meeting id set in the shortcode', 'wp-event-manager-zoom' ) . '--</div>';

			return;
		}

		$required_logged_in = get_post_meta($zoom_settings['post_id'], '_site_option_logged_in', true);

		if($required_logged_in && !is_user_logged_in()) {
			
			//echo '<div class="wpem-alert wpem-alert-danger">' . __( 'You must sign in to view zoom meeting details.', 'wp-event-manager-zoom' ) . '</div>';

			return;
		}

		$show_single_event_shortcode = false;
		$show_meeting_button = false;

		if ( is_plugin_active('woocommerce/woocommerce.php') ) 
		{
			if ( current_user_can( 'manage_options' ) || $zoom_settings['post_author'] == $user_id ) 
			{
				$show_single_event_shortcode = true;
			}

			$product_ids = get_all_products_purchased_by_user( $user_id );

			if(!empty($product_ids))
			{
				foreach ($product_ids as $key => $product_data) 
				{
					$event_zoom_id = get_post_meta($product_data['product_id'], '_event_zoom_id', true);

					if($event_zoom_id == $zoom_settings['post_id'])
					{
						$show_single_event_shortcode = true;
					}

					if($product_data['order_status'] === 'completed')
					{
						$show_meeting_button = true;
					}
				}
			}
		}

		if(!$show_single_event_shortcode)
		{
			echo '<div class="wpem-alert wpem-alert-danger">' . __( 'Buy Tickets to get Joining link to Zoom Meeting.', 'wp-event-manager-zoom' ) . '</div>';

			return;
		}

		$meeting = get_post_meta( $zoom_settings['post_id'], '_meeting_zoom_details', true );

		/*
		if ( isset( $meeting->state ) && $meeting->state === "ended" ) {
			echo '<h3>' . esc_html__( 'This meeting has been ended by host.', 'wp-event-manager-zoom' ) . '</h3>';

			return;
		}
		*/
		
		$user_meta = get_userdata($zoom_settings['post_author']);

		//if(in_array('administrator', $user_meta->roles))
		//if ( current_user_can( 'manage_options' ) ) 
		if(in_array('administrator', $user_meta->roles) || current_user_can( 'manage_options' ) )
		{	
			$zoom_users  = get_option( 'event_zoom_user_lists' );
		}
		else
		{
			$zoom_users  = get_user_meta( sanitize_text_field($zoom_settings['post_author']), '_event_zoom_user_lists', true );
		}
		
		$user = [];

		if(!empty($zoom_users))
		{
			foreach ($zoom_users->users as $zoom_user) {
				if($zoom_user->id == $meeting->host_id)
				{
					$user = $zoom_user;
				}
			}	
		}

		$meeting_type = get_post_meta( $zoom_settings['post_id'], '_meeting_type', true );

		if( !empty($meeting) && isset($meeting->id) && !empty($meeting->id) )
		{
			$current_timestamp = strtotime(current_time('Y-m-d H:i:s'));

			$start_date = get_post_meta($zoom_settings['post_id'], '_meeting_start_date', true);
			$start_time = get_post_meta($zoom_settings['post_id'], '_meeting_start_time', true);

			//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
			$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
						
			//covert datepicker format  into php date() function date format
			$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

			$start_time = WP_Event_Manager_Date_Time::get_db_formatted_time( $start_time );

			$date = $start_date . ' ' . $start_time;

			//$meeting_end_time = WP_Event_Manager_Date_Time::date_parse_from_format('Y-m-d H:i:s'  , $date);
			$meeting_end_time = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format . ' H:i:s'  , $date);

			$meeting_end_time = !empty($meeting_end_time) ? $meeting_end_time : $date;

			$meeting_end_time = date('Y-m-d H:i:s', strtotime('+'.$meeting->duration.' minutes', strtotime($meeting_end_time)));

			//$meeting_start_time = strtotime($meeting->start_time);

			//$meeting_end_time = date('Y-m-d H:i:s',strtotime('+'.$meeting->duration.' minutes',$meeting_start_time));

			if ( strtotime($meeting_end_time) <= $current_timestamp )
            {
            	echo sprintf( __( '<div class="wpem-alert wpem-alert-danger">%s</div>', 'wp-event-manager-zoom' ), $zoom_settings['event_zoom_meeting_ended_text'] );
            	
				return;
            }

			get_event_manager_template( 
				'zoom-meeting-single-event.php', 
				array( 
					'zoom_settings' => $zoom_settings,
					'link_only' => $link_only,
					'show_help' => $show_help,
					'meeting' => $meeting,
					'meeting_type' => $meeting_type,
					'zoom_user' => $user,
					'user_id' => $user_id,
					'show_meeting_button' => $show_meeting_button,
				), 
				'wp-event-manager-zoom', 
				WPEM_ZOOM_PLUGIN_DIR . '/templates/'
			);
		}

		return ob_get_clean();
	}

	/**
	 * event_zoom_meeting_detail function.
	 *
	 * @access public
	 * @param $atts,$content
	 * @return 
	 * @since 1.0.0
	 */
	public function event_zoom_meeting_detail( $atts = [] ) {
		
		extract( shortcode_atts( array(
			'event_zoom_id' => '',
			'show_title' 	=> 'no',
		), $atts ) );

		if(empty($event_zoom_id)){
			return;
		}

		ob_start();

		$event_zoom_name = get_post_meta($event_zoom_id, '_event_zoom_name', true);
		$event_zoom_description = get_post_meta($event_zoom_id, '_event_zoom_description', true);
		$meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );
		$meeting_type = get_post_meta( $event_zoom_id, '_meeting_type', true );

		if( !empty($meeting) && isset($meeting->id) && !empty($meeting->id) )
		{
			get_event_manager_template( 
				'zoom-meeting-detail.php', 
				array( 
					'event_zoom_name' => $event_zoom_name,
					'event_zoom_description' => $event_zoom_description,
					'meeting' => $meeting,
					'meeting_type' => $meeting_type,
					'show_title' => $show_title,
				), 
				'wp-event-manager-zoom', 
				WPEM_ZOOM_PLUGIN_DIR . '/templates/'
			);
		}

		return ob_get_clean();
	}

}

new WPEM_Zoom_Shortcodes(); ?>
