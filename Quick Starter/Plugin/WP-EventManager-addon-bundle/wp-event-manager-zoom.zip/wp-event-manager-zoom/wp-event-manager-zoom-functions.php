<?php
if ( ! function_exists( 'event_manager_zoom_api_delete_user_cache' ) ) {
	/**
	 * event_manager_zoom_api_delete_user_cache function.
	 * Delete zoom user catch
	 * @access public
	 * @param 
	 * @return boolean
	 * @since 1.0.0
	 */
	function event_manager_zoom_api_delete_user_cache()
	{
		$user_id = get_current_user_id();

		$user_meta = get_userdata($user_id);

		if( in_array('administrator', $user_meta->roles) || current_user_can( 'manage_options' ) )
		{
			update_option( 'event_zoom_user_lists', '' );
			update_option( 'event_zoom_user_lists_expiry_time', '' );

			return true;
		}
		else
		{
			update_user_meta( $user_id, '_event_zoom_user_lists', '' );
			update_user_meta( $user_id, '_event_zoom_user_lists_expiry_time', '' );

			return true;
		}

		return false;
	}
}

if ( ! function_exists( 'get_event_manager_zoom_add_user_actions' ) ) {
	/**
	 * get_event_manager_zoom_add_user_actions function.
	 * create new zoom user action
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	function get_event_manager_zoom_add_user_actions()
	{
		return apply_filters( 'event_manager_zoom_add_user_action', array(
			'create'   => __( 'Create', 'wp-event-manager-zoom' ),
			'autoCreate'   => __( 'Auto Create', 'wp-event-manager-zoom' ),
			'custCreate'   => __( 'Cust Create', 'wp-event-manager-zoom' ),
			'ssoCreate'   => __( 'SSO Create', 'wp-event-manager-zoom' ),
		) );
	}
}

if ( ! function_exists( 'get_event_manager_zoom_add_user_types' ) ) {
	/**
	 * get_event_manager_zoom_add_user_types function.
	 * zoom user account type
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	function get_event_manager_zoom_add_user_types()
	{
		return apply_filters( 'event_manager_zoom_add_user_type', array(
			'1'   => __( 'Basic User', 'wp-event-manager-zoom' ),
			'2'   => __( 'Licensed', 'wp-event-manager-zoom' ),
			'3'   => __( 'On-prem', 'wp-event-manager-zoom' ),
		) );
	}
}

if ( ! function_exists( 'get_event_manager_zoom_meeting_recording_type' ) ) {
	/**
	 * get_event_manager_zoom_meeting_recording_type function.
	 * while meeting create where to store recordings
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	function get_event_manager_zoom_meeting_recording_type() {
		return apply_filters( 'event_manager_zoom_meeting_recording_type', array(
			'none'   => __( 'No Recordings', 'wp-event-manager-zoom' ),
			'local'   => __( 'Local Recordings', 'wp-event-manager-zoom' ),
			'cloud'   => __( 'Cloud Recordings', 'wp-event-manager-zoom' ),
		) );
	}
}

if ( ! function_exists( 'get_event_manager_zoom_registration_approval_type' ) ) {
	/**
	 * get_event_manager_zoom_registration_approval_type function.
	 * zoom meeting registration approval type
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	function get_event_manager_zoom_registration_approval_type()
	{
		return apply_filters( 'event_manager_zoom_add_user_action', array(
			'0'   => __( 'Automatically approve', 'wp-event-manager-zoom' ),
			/* '1'   => __( 'Manually approve', 'wp-event-manager-zoom' ), */
			'2'   => __( 'No registration required', 'wp-event-manager-zoom' ),
		) );
	}
}

if ( ! function_exists( 'get_event_manager_zoom_meeting_type' ) ) {
	/**
	 * get_event_manager_zoom_meeting_type function.
	 * zoom meeting type
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	function get_event_manager_zoom_meeting_type()
	{
		return apply_filters( 'event_manager_zoom_meeting_type', array(
			'meeting'   => __( 'Meeting', 'wp-event-manager-zoom' ),
			'webinar'   => __( 'Webinar', 'wp-event-manager-zoom' ),
		) );
	}
}

if ( ! function_exists( 'get_event_manager_zoom_join_url_host' ) ) {
	/**
	 * get_event_manager_zoom_join_url_host function.
	 * zoom meeting host url
	 * @access public
	 * @param $meeting_id
	 * @return string
	 * @since 1.0.0
	 */
	function get_event_manager_zoom_join_url_host($meeting_id) 
	{
		$zoom_host_url = 'https://zoom.us' . '/wc/' . $meeting_id . '/start';

        return apply_filters( 'event_manager_zoom_join_url_host', $zoom_host_url );
	}
}

if ( ! function_exists( 'event_manager_zoom_date_converter' ) ) {
	/**
	 * event_manager_zoom_date_converter function.
	 * zoom meeting date / time converter
	 * @access public
	 * @param $start_time, $tz, $format
	 * @return string
	 * @since 1.0.0
	 */
	function event_manager_zoom_date_converter( $start_time, $tz, $format = 'F j, Y, g:i a ( T )' ) {
		$timezone = !empty( $tz ) ? $tz : WP_Event_Manager_Date_Time::get_current_site_timezone();
		$tz       = new DateTimeZone( $timezone );
		$date     = new DateTime( $start_time );
		$date->setTimezone( $tz );

		return $date->format( $format );
	}
}

if ( ! function_exists( 'get_event_manager_zoom_meeting_list' ) ) {
	/**
	 * get_event_manager_zoom_meeting_list function.
	 * Get zoom meeting list
	 * @access public
	 * @param $parmas
	 * @return array
	 * @since 1.0.0
	 */
	function get_event_manager_zoom_meeting_list( $parmas = [] )
	{
		$args = [
			'post_type' => 'event_zoom',
			'post_status' => ['publish'],
			'posts_per_page' => -1
		];

		$args = array_merge($args,$parmas);

		$result = new WP_Query( $args );

		/*
		wp_reset_query();
		wp_reset_postdata();
		*/

		return $result;
	}
}

if ( ! function_exists( 'get_meeting_fields' ) ) {
	/**
	 * get_meeting_fields function.
	 * creare zoom meeting form fields
	 * @access public
	 * @param $post_id
	 * @return array
	 * @since 1.0.0
	 */
	function get_meeting_fields( $post_id ) {
		$fields = array(
			'meeting_userId',
			'meeting_start_date',
			'meeting_start_time',
			'meeting_timezone',
			'meeting_duration',
			'meeting_password',
			'meeting_option_registration',
			'meeting_option_approval_type',
			'meeting_join_before_host',
			'meeting_option_host_video',
			'meeting_option_participants_video',
			'meeting_option_mute_participants',
			'meeting_option_auto_recording',
			'meeting_alternative_host_ids',
			
			'site_option_logged_in',
			'site_option_browser_join',
			'site_option_enable_debug_log',
		);

		$meeting_fields = [];

		foreach ($fields as $field) {
			$meeting_fields[$field] = get_post_meta($post_id, '_'.$field, true);
		}

		return $meeting_fields;
	}
}

if ( ! function_exists( 'get_event_zoom_setting_by_meeting_id' ) ) {
	/**
	 * get_event_zoom_setting_by_meeting_id function.
	 * get zoom seeting by meeting id
	 * @access public
	 * @param $meeting_id
	 * @return array
	 * @since 1.0.0
	 */
	function get_event_zoom_setting_by_meeting_id( $meeting_id ) 
	{		
		global $wpdb;

		$query = "SELECT * FROM `" . $wpdb->prefix . "posts` WHERE 1
							AND `post_status` = 'publish'
							AND `post_type` = 'event_zoom'
							AND `ID` IN (SELECT post_id FROM `" . $wpdb->prefix . "postmeta` WHERE `meta_value` = '" . $meeting_id . "')";

		$result = $wpdb->get_row($query, ARRAY_A);

		$user_meta = get_userdata($result['post_author']);

		$zoom_settings = get_user_meta($result['post_author'], '_zoom_settings', true);

		if(empty($zoom_settings))
		{
			$zoom_settings = [];
			$zoom_settings['event_zoom_connection_options'] = get_option('event_zoom_connection_options');

			$zoom_settings['event_zoom_api_key'] = get_option('event_zoom_api_key');
			$zoom_settings['event_zoom_api_secret_key'] = get_option('event_zoom_api_secret_key');
			$zoom_settings['event_zoom_vanity_url'] = get_option('event_zoom_vanity_url');

			$zoom_settings['event_zoom_client_id'] = get_option('event_zoom_client_id');
			$zoom_settings['event_zoom_client_secret'] = get_option('event_zoom_client_secret');

			$zoom_settings['event_zoom_show_post_join_link'] = get_option('event_zoom_show_post_join_link');
			$zoom_settings['event_zoom_show_zoom_author'] = get_option('event_zoom_show_zoom_author');
			$zoom_settings['event_zoom_meeting_started_text'] = get_option('event_zoom_meeting_started_text');
			$zoom_settings['event_zoom_meeting_going_to_start_text'] = get_option('event_zoom_meeting_going_to_start_text');
			$zoom_settings['event_zoom_meeting_ended_text'] = get_option('event_zoom_meeting_ended_text');
			/* $zoom_settings['event_zoom_enable_all_event'] = get_option('event_zoom_enable_all_event'); */
			$zoom_settings['event_zoom_show_on_single_event'] = get_option('event_zoom_show_on_single_event');
			$zoom_settings['event_zoom_show_on_single_event_sidebar'] = get_option('event_zoom_show_on_single_event_sidebar');
		}

		if(!empty($zoom_settings))
		{
			if(empty($zoom_settings['event_zoom_meeting_started_text']))
			{
				$zoom_settings['event_zoom_meeting_started_text'] = __( 'Meeting Has Started ! Click below join button to join meeting now !', 'wp-event-manager-zoom' );
			}
			if(empty($zoom_settings['event_zoom_meeting_going_to_start_text']))
			{
				$zoom_settings['event_zoom_meeting_going_to_start_text'] = __( 'Click join button below to join the meeting now !', 'wp-event-manager-zoom' );
			}
			if(empty($zoom_settings['event_zoom_meeting_ended_text']))
			{
				$zoom_settings['event_zoom_meeting_ended_text'] = __( 'This meeting has been ended by the host.', 'wp-event-manager-zoom' );
			}

			$zoom_settings['post_id'] = $result['ID'];
			$zoom_settings['post_author'] = $result['post_author'];
		}

		return $zoom_settings;
	}
}

if ( ! function_exists( 'get_event_zoom_setting_by_user_id' ) ) {
	/**
	 * get_event_zoom_setting_by_user_id function.
	 * get zoom seeting by user id
	 * @access public
	 * @param $meeting_id
	 * @return array
	 * @since 1.0.0
	 */
	function get_event_zoom_setting_by_user_id( $user_id = '' ) 
	{
		if ( ! is_user_logged_in() )
			return;

		$user_meta = get_userdata($user_id);

		$zoom_settings = [];

		if ( isset($user_meta->roles) && ( in_array('administrator', $user_meta->roles) || current_user_can( 'manage_options' ) )  ) 
		{
			$zoom_settings['event_zoom_connection_options'] = get_option('event_zoom_connection_options');

			$zoom_settings['event_zoom_api_key'] = get_option('event_zoom_api_key');
			$zoom_settings['event_zoom_api_secret_key'] = get_option('event_zoom_api_secret_key');
			$zoom_settings['event_zoom_vanity_url'] = get_option('event_zoom_vanity_url');

			$zoom_settings['event_zoom_client_id'] = get_option('event_zoom_client_id');
			$zoom_settings['event_zoom_client_secret'] = get_option('event_zoom_client_secret');

			$zoom_settings['event_zoom_show_post_join_link'] = get_option('event_zoom_show_post_join_link');
			$zoom_settings['event_zoom_show_zoom_author'] = get_option('event_zoom_show_zoom_author');
			$zoom_settings['event_zoom_meeting_started_text'] = get_option('event_zoom_meeting_started_text');
			$zoom_settings['event_zoom_meeting_going_to_start_text'] = get_option('event_zoom_meeting_going_to_start_text');
			$zoom_settings['event_zoom_meeting_ended_text'] = get_option('event_zoom_meeting_ended_text');
			/* $zoom_settings['event_zoom_enable_all_event'] = get_option('event_zoom_enable_all_event'); */
			$zoom_settings['event_zoom_show_on_single_event'] = get_option('event_zoom_show_on_single_event');
			$zoom_settings['event_zoom_show_on_single_event_sidebar'] = get_option('event_zoom_show_on_single_event_sidebar');

			$zoom_settings['event_zoom_oauth_authorize'] = get_option('event_zoom_oauth_authorize');
		}
		elseif ( isset($user_meta->roles) && in_array('editor', $user_meta->roles) ) 
		{
			$zoom_settings['event_zoom_connection_options'] = get_option('event_zoom_connection_options');

			$zoom_settings['event_zoom_api_key'] = get_option('event_zoom_api_key');
			$zoom_settings['event_zoom_api_secret_key'] = get_option('event_zoom_api_secret_key');
			$zoom_settings['event_zoom_vanity_url'] = get_option('event_zoom_vanity_url');

			$zoom_settings['event_zoom_client_id'] = get_option('event_zoom_client_id');
			$zoom_settings['event_zoom_client_secret'] = get_option('event_zoom_client_secret');

			$zoom_settings['event_zoom_show_post_join_link'] = get_option('event_zoom_show_post_join_link');
			$zoom_settings['event_zoom_show_zoom_author'] = get_option('event_zoom_show_zoom_author');
			$zoom_settings['event_zoom_meeting_started_text'] = get_option('event_zoom_meeting_started_text');
			$zoom_settings['event_zoom_meeting_going_to_start_text'] = get_option('event_zoom_meeting_going_to_start_text');
			$zoom_settings['event_zoom_meeting_ended_text'] = get_option('event_zoom_meeting_ended_text');
			/* $zoom_settings['event_zoom_enable_all_event'] = get_option('event_zoom_enable_all_event'); */
			$zoom_settings['event_zoom_show_on_single_event'] = get_option('event_zoom_show_on_single_event');
			$zoom_settings['event_zoom_show_on_single_event_sidebar'] = get_option('event_zoom_show_on_single_event_sidebar');

			$zoom_settings['event_zoom_oauth_authorize'] = get_option('event_zoom_oauth_authorize');
		}
		else
		{
			$zoom_settings = get_user_meta($user_id, '_zoom_settings', true);

			if(!empty($zoom_settings))
			{
				$zoom_settings['event_zoom_oauth_authorize'] = get_user_meta($user_id, '_event_zoom_oauth_authorize', true);	
			}
			
		}

		if(!empty($zoom_settings))
		{
			if(empty($zoom_settings['event_zoom_meeting_started_text']))
			{
				$zoom_settings['event_zoom_meeting_started_text'] = __( 'Meeting Has Started ! Click below join button to join meeting now !', 'wp-event-manager-zoom' );
			}
			if(empty($zoom_settings['event_zoom_meeting_going_to_start_text']))
			{
				$zoom_settings['event_zoom_meeting_going_to_start_text'] = __( 'Click join button below to join the meeting now !', 'wp-event-manager-zoom' );
			}
			if(empty($zoom_settings['event_zoom_meeting_ended_text']))
			{
				$zoom_settings['event_zoom_meeting_ended_text'] = __( 'This meeting has been ended by the host.', 'wp-event-manager-zoom' );
			}

			$zoom_settings['post_author'] = $user_id;
		}		

		return $zoom_settings;
	}
}

if ( ! function_exists( 'get_browser_join_shortcode' ) ) {
	/**
	 * get_browser_join_shortcode function.
	 * Generate link for host meeting on our domain
	 * @access public
	 * @param $zoom_settings, $meeting_id, $password, $link_only
	 * @return 
	 * @since 1.0.0
	 */
	function get_browser_join_shortcode( $zoom_settings, $meeting_id, $password = false, $link_only = false ) {
		$link               = get_post_type_archive_link( 'event_zoom' );
		$encrypt_pwd 		= event_manager_zoom_encrypt_decrypt( 'encrypt', $password );
		$encrypt_meeting_id = event_manager_zoom_encrypt_decrypt( 'encrypt', $meeting_id );

		$hide_browser_join_link = get_post_meta($zoom_settings['post_id'], '_site_option_browser_join', true);

		if($hide_browser_join_link)
		{
			return false;
		}

		if ( !empty( $password ) ) {
			
			$query       = add_query_arg( array( 'pak' => $encrypt_pwd, 'join' => $encrypt_meeting_id, 'type' => 'meeting', 'event_zoom_id' => $zoom_settings['post_id'], ), $link );
			$result      = '<a target="_blank" rel="nofollow" href="' . esc_url( $query ) . '" class="btn btn-join-link btn-join-via-browser">' . apply_filters( 'event_manager_join_meeting_via_app_text', __( 'Join via Web Browser', 'wp-event-manager-zoom' ) ) . '</a>';
			$link        = esc_url( $query );
		} else {
			$query  = add_query_arg( array( 'join' => $encrypt_meeting_id, 'type' => 'meeting' ), $link );
			$result = '<a target="_blank" rel="nofollow" href="' . esc_url( $query ) . '" class="btn btn-join-link btn-join-via-browser">' . apply_filters( 'event_manager_join_meeting_via_app_text', __( 'Join via Web Browser', 'wp-event-manager-zoom' ) ) . '</a>';
			$link   = esc_url( $query );
		}

		if ( $link_only ) {
			return $link;
		} else {
			return $result;
		}
	}
}

if ( ! function_exists( 'event_manager_zoom_encrypt_decrypt' ) ) {
	/**
	 * event_manager_zoom_encrypt_decrypt function.
	 * Encrypt and decrypt meeting id and password while meeting host on our site
	 * @access public
	 * @param $action, $string
	 * @return 
	 * @since 1.0.0
	 */
	function event_manager_zoom_encrypt_decrypt( $action, $string ) {
		$output = false;

		$encrypt_method = "AES-256-CBC";
		$secret_key     = 'DPEN_X3!3#23121';
		$secret_iv      = '1231232133213221';

		// hash
		$key = hash( 'sha256', $secret_key );

		// iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
		$iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );

		if ( $action == 'encrypt' ) {
			$output = openssl_encrypt( $string, $encrypt_method, $key, 0, $iv );
			$output = base64_encode( $output );
		} else if ( $action == 'decrypt' ) {
			$output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
		}

		return $output;
	}
}

if ( ! function_exists( 'event_manager_zoom_check_login' ) ) {
	/**
	 * event_manager_zoom_check_login function.
	 * check user login required while join meeting via our site
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	function event_manager_zoom_check_login($event_zoom_id = 0) {
		if ( !empty( $event_zoom_id ) && get_post_meta($event_zoom_id, '_site_option_logged_in', true) ) 
		{
			if ( is_user_logged_in() ) 
			{
				return true;
			} 
			else 
			{
				return false;
			}
		} 
		else 
		{
			return true;
		}
	}
}

if ( ! function_exists( 'get_all_products_purchased_by_user' ) ) {
	/**
	 * get_all_products_purchased_by_user function.
	 * get all product purchased list by user id
	 * @access public
	 * @param $user_id
	 * @return array
	 * @since 1.0.0
	 */
	function get_all_products_purchased_by_user( $user_id ) {
		// GET USER ORDERS (COMPLETED + PROCESSING)
	    $customer_orders = get_posts( array(
	        'numberposts' => -1,
	        'meta_key'    => '_customer_user',
	        'meta_value'  => $user_id,
	        'post_type'   => wc_get_order_types(),
	        'post_status' => array_keys( wc_get_is_paid_statuses() ),
	    ) );
	   
	    // LOOP THROUGH ORDERS AND GET PRODUCT IDS
	    if ( ! $customer_orders ) return;

	    $product_ids = array();

	    foreach ( $customer_orders as $customer_order ) 
	    {
	        $order = wc_get_order( $customer_order->ID );
	        $items = $order->get_items();
	        $order_status  = $order->get_status();

	        //if($order_status === 'completed')
	        {
	        	foreach ( $items as $item ) 
	        	{
		            $product_id = $item->get_product_id();

		            $data = [];
		            $data['order_status'] = $order_status;
		            $data['product_id'] = $product_id;

		            $product_ids[] = $data;
		        }	
	        }
	        
	    }

	    return $product_ids;
	}
}

if ( ! function_exists( 'get_all_orders_by_user' ) ) {
	/**
	 * get_event_from_event_zoom_id function.
	 * get all order by user id
	 * @access public
	 * @param $user_id
	 * @return array
	 * @since 1.0.0
	 */
	function get_all_orders_by_user( $user_id ) {
		$customer_orders = wc_get_orders( array(
		    'meta_key' => '_customer_user',
		    'meta_value' => $user_id,
		    'numberposts' => -1
		) );

		return $customer_orders;
	}
}

if ( ! function_exists( 'get_event_from_event_zoom_id' ) ) {
	/**
	 * get_event_from_event_zoom_id function.
	 * get event from event zoom id
	 * @access public
	 * @param $event_zoom_id
	 * @return array
	 * @since 1.0.0
	 */
	function get_event_from_event_zoom_id( $event_zoom_id ) {
		$args = [
			'post_type' => 'event_listing',
			'meta_key' 	=> '_event_zoom_id',
			'meta_value' => $event_zoom_id,
			'numberposts' => 1,
			'orderby'	=> 'date',
        	'order'     => 'DESC',
		];

		return get_posts($args);
	}
}


if ( ! function_exists( 'get_wpem_zoom_timezone_list' ) ) {
	/**
	 * time zone function.
	 * we use zoom time zone list becuse some time zone not accept : https://marketplace.zoom.us/docs/api-reference/other-references/abbreviation-lists#timezones
	 * @access public
	 * @return array
	 * @since 1.0.3
	 */
	function get_wpem_zoom_timezone_list() {
		$zones_array = array(
			"Pacific/Midway"                 => "(GMT-11:00) Midway Island, Samoa ",
			"Pacific/Pago_Pago"              => "(GMT-11:00) Pago Pago ",
			"Pacific/Honolulu"               => "(GMT-10:00) Hawaii ",
			"America/Anchorage"              => "(GMT-8:00) Alaska ",
			"America/Vancouver"              => "(GMT-7:00) Vancouver ",
			"America/Los_Angeles"            => "(GMT-7:00) Pacific Time (US and Canada) ",
			"America/Tijuana"                => "(GMT-7:00) Tijuana ",
			"America/Phoenix"                => "(GMT-7:00) Arizona ",
			"America/Edmonton"               => "(GMT-6:00) Edmonton ",
			"America/Denver"                 => "(GMT-6:00) Mountain Time (US and Canada) ",
			"America/Mazatlan"               => "(GMT-6:00) Mazatlan ",
			"America/Regina"                 => "(GMT-6:00) Saskatchewan ",
			"America/Guatemala"              => "(GMT-6:00) Guatemala ",
			"America/El_Salvador"            => "(GMT-6:00) El Salvador ",
			"America/Managua"                => "(GMT-6:00) Managua ",
			"America/Costa_Rica"             => "(GMT-6:00) Costa Rica ",
			"America/Tegucigalpa"            => "(GMT-6:00) Tegucigalpa ",
			"America/Winnipeg"               => "(GMT-5:00) Winnipeg ",
			"America/Chicago"                => "(GMT-5:00) Central Time (US and Canada) ",
			"America/Mexico_City"            => "(GMT-5:00) Mexico City ",
			"America/Panama"                 => "(GMT-5:00) Panama ",
			"America/Bogota"                 => "(GMT-5:00) Bogota ",
			"America/Lima"                   => "(GMT-5:00) Lima ",
			"America/Caracas"                => "(GMT-4:30) Caracas ",
			"America/Montreal"               => "(GMT-4:00) Montreal ",
			"America/New_York"               => "(GMT-4:00) Eastern Time (US and Canada) ",
			"America/Indianapolis"           => "(GMT-4:00) Indiana (East) ",
			"America/Puerto_Rico"            => "(GMT-4:00) Puerto Rico ",
			"America/Santiago"               => "(GMT-4:00) Santiago ",
			"America/Halifax"                => "(GMT-3:00) Halifax ",
			"America/Montevideo"             => "(GMT-3:00) Montevideo ",
			"America/Araguaina"              => "(GMT-3:00) Brasilia ",
			"America/Argentina/Buenos_Aires" => "(GMT-3:00) Buenos Aires, Georgetown ",
			"America/Sao_Paulo"              => "(GMT-3:00) Sao Paulo ",
			"Canada/Atlantic"                => "(GMT-3:00) Atlantic Time (Canada) ",
			"America/St_Johns"               => "(GMT-2:30) Newfoundland and Labrador ",
			"America/Godthab"                => "(GMT-2:00) Greenland ",
			"Atlantic/Cape_Verde"            => "(GMT-1:00) Cape Verde Islands ",
			"Atlantic/Azores"                => "(GMT+0:00) Azores ",
			"UTC"                            => "(GMT+0:00) Universal Time UTC ",
			"Etc/Greenwich"                  => "(GMT+0:00) Greenwich Mean Time ",
			"Atlantic/Reykjavik"             => "(GMT+0:00) Reykjavik ",
			"Africa/Nouakchott"              => "(GMT+0:00) Nouakchott ",
			"Europe/Dublin"                  => "(GMT+1:00) Dublin ",
			"Europe/London"                  => "(GMT+1:00) London ",
			"Europe/Lisbon"                  => "(GMT+1:00) Lisbon ",
			"Africa/Casablanca"              => "(GMT+1:00) Casablanca ",
			"Africa/Bangui"                  => "(GMT+1:00) West Central Africa ",
			"Africa/Algiers"                 => "(GMT+1:00) Algiers ",
			"Africa/Tunis"                   => "(GMT+1:00) Tunis ",
			"Europe/Belgrade"                => "(GMT+2:00) Belgrade, Bratislava, Ljubljana ",
			"CET"                            => "(GMT+2:00) Sarajevo, Skopje, Zagreb ",
			"Europe/Oslo"                    => "(GMT+2:00) Oslo ",
			"Europe/Copenhagen"              => "(GMT+2:00) Copenhagen ",
			"Europe/Brussels"                => "(GMT+2:00) Brussels ",
			"Europe/Berlin"                  => "(GMT+2:00) Amsterdam, Berlin, Rome, Stockholm, Vienna ",
			"Europe/Amsterdam"               => "(GMT+2:00) Amsterdam ",
			"Europe/Rome"                    => "(GMT+2:00) Rome ",
			"Europe/Stockholm"               => "(GMT+2:00) Stockholm ",
			"Europe/Vienna"                  => "(GMT+2:00) Vienna ",
			"Europe/Luxembourg"              => "(GMT+2:00) Luxembourg ",
			"Europe/Paris"                   => "(GMT+2:00) Paris ",
			"Europe/Zurich"                  => "(GMT+2:00) Zurich ",
			"Europe/Madrid"                  => "(GMT+2:00) Madrid ",
			"Africa/Harare"                  => "(GMT+2:00) Harare, Pretoria ",
			"Europe/Warsaw"                  => "(GMT+2:00) Warsaw ",
			"Europe/Prague"                  => "(GMT+2:00) Prague Bratislava ",
			"Europe/Budapest"                => "(GMT+2:00) Budapest ",
			"Africa/Tripoli"                 => "(GMT+2:00) Tripoli ",
			"Africa/Cairo"                   => "(GMT+2:00) Cairo ",
			"Africa/Johannesburg"            => "(GMT+2:00) Johannesburg ",
			"Europe/Helsinki"                => "(GMT+3:00) Helsinki ",
			"Africa/Nairobi"                 => "(GMT+3:00) Nairobi ",
			"Europe/Sofia"                   => "(GMT+3:00) Sofia ",
			"Europe/Istanbul"                => "(GMT+3:00) Istanbul ",
			"Europe/Athens"                  => "(GMT+3:00) Athens ",
			"Europe/Bucharest"               => "(GMT+3:00) Bucharest ",
			"Asia/Nicosia"                   => "(GMT+3:00) Nicosia ",
			"Asia/Beirut"                    => "(GMT+3:00) Beirut ",
			"Asia/Damascus"                  => "(GMT+3:00) Damascus ",
			"Asia/Jerusalem"                 => "(GMT+3:00) Jerusalem ",
			"Asia/Amman"                     => "(GMT+3:00) Amman ",
			"Europe/Moscow"                  => "(GMT+3:00) Moscow ",
			"Asia/Baghdad"                   => "(GMT+3:00) Baghdad ",
			"Asia/Kuwait"                    => "(GMT+3:00) Kuwait ",
			"Asia/Riyadh"                    => "(GMT+3:00) Riyadh ",
			"Asia/Bahrain"                   => "(GMT+3:00) Bahrain ",
			"Asia/Qatar"                     => "(GMT+3:00) Qatar ",
			"Asia/Aden"                      => "(GMT+3:00) Aden ",
			"Africa/Khartoum"                => "(GMT+3:00) Khartoum ",
			"Africa/Djibouti"                => "(GMT+3:00) Djibouti ",
			"Africa/Mogadishu"               => "(GMT+3:00) Mogadishu ",
			"Europe/Kiev"                    => "(GMT+3:00) Kiev ",
			"Asia/Dubai"                     => "(GMT+4:00) Dubai ",
			"Asia/Muscat"                    => "(GMT+4:00) Muscat ",
			"Asia/Tehran"                    => "(GMT+4:30) Tehran ",
			"Asia/Kabul"                     => "(GMT+4:30) Kabul ",
			"Asia/Baku"                      => "(GMT+5:00) Baku, Tbilisi, Yerevan ",
			"Asia/Yekaterinburg"             => "(GMT+5:00) Yekaterinburg ",
			"Asia/Tashkent"                  => "(GMT+5:00) Islamabad, Karachi, Tashkent ",
			"Asia/Calcutta"                  => "(GMT+5:30) India ",
			"Asia/Kolkata"                   => "(GMT+5:30) Mumbai, Kolkata, New Delhi ",
			"Asia/Kathmandu"                 => "(GMT+5:45) Kathmandu ",
			"Asia/Novosibirsk"               => "(GMT+6:00) Novosibirsk ",
			"Asia/Almaty"                    => "(GMT+6:00) Almaty ",
			"Asia/Dacca"                     => "(GMT+6:00) Dacca ",
			"Asia/Dhaka"                     => "(GMT+6:00) Astana, Dhaka ",
			"Asia/Krasnoyarsk"               => "(GMT+7:00) Krasnoyarsk ",
			"Asia/Bangkok"                   => "(GMT+7:00) Bangkok ",
			"Asia/Saigon"                    => "(GMT+7:00) Vietnam ",
			"Asia/Jakarta"                   => "(GMT+7:00) Jakarta ",
			"Asia/Irkutsk"                   => "(GMT+8:00) Irkutsk, Ulaanbaatar ",
			"Asia/Shanghai"                  => "(GMT+8:00) Beijing, Shanghai ",
			"Asia/Hong_Kong"                 => "(GMT+8:00) Hong Kong ",
			"Asia/Taipei"                    => "(GMT+8:00) Taipei ",
			"Asia/Kuala_Lumpur"              => "(GMT+8:00) Kuala Lumpur ",
			"Asia/Singapore"                 => "(GMT+8:00) Singapore ",
			"Australia/Perth"                => "(GMT+8:00) Perth ",
			"Asia/Yakutsk"                   => "(GMT+9:00) Yakutsk ",
			"Asia/Seoul"                     => "(GMT+9:00) Seoul ",
			"Asia/Tokyo"                     => "(GMT+9:00) Osaka, Sapporo, Tokyo ",
			"Australia/Darwin"               => "(GMT+9:30) Darwin ",
			"Australia/Adelaide"             => "(GMT+9:30) Adelaide ",
			"Asia/Vladivostok"               => "(GMT+10:00) Vladivostok ",
			"Pacific/Port_Moresby"           => "(GMT+10:00) Guam, Port Moresby ",
			"Australia/Brisbane"             => "(GMT+10:00) Brisbane ",
			"Australia/Sydney"               => "(GMT+10:00) Canberra, Melbourne, Sydney ",
			"Australia/Hobart"               => "(GMT+10:00) Hobart ",
			"Asia/Magadan"                   => "(GMT+10:00) Magadan ",
			"SST"                            => "(GMT+11:00) Solomon Islands ",
			"Pacific/Noumea"                 => "(GMT+11:00) New Caledonia ",
			"Asia/Kamchatka"                 => "(GMT+12:00) Kamchatka ",
			"Pacific/Fiji"                   => "(GMT+12:00) Fiji Islands, Marshall Islands ",
			"Pacific/Auckland"               => "(GMT+12:00) Auckland, Wellington"
		);

		return apply_filters( 'wpem_zoom_timezone_list', $zones_array );
	}
}