<?php
//add action with templates
add_action( 'single_event_sidebar_start', 'add_event_zoom_meeting_shortcode' );
add_action( 'single_event_overview_after', 'zoom_meeting_details' );

/**
 * zoom_meeting_details function.
 * show zoom meeting short details on single event page below description
 * @access public
 * @param 
 * @return 
 * @since 1.0.0
 */
function zoom_meeting_details() {
	global $post;

	$user_id = get_current_user_id();
	
	$event_id = $post->ID;

	$event_zoom_id = get_post_meta($event_id, '_event_zoom_id', true);

	if(empty($event_zoom_id)){
		return;
	}

	$meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );

	if( !empty($meeting) && isset($meeting->id) && !empty($meeting->id) )
	{
		$zoom_settings = get_event_zoom_setting_by_meeting_id($meeting->id);
	
		if ( isset($zoom_settings['event_zoom_show_on_single_event']) && !$zoom_settings['event_zoom_show_on_single_event'] ) {
			if($zoom_settings['post_author'] != $user_id){
				return;
			}
		}

		echo do_shortcode( '[event_zoom_meeting_detail show_title="yes" event_zoom_id="'. $event_zoom_id .'"]' );
	}
	
}

/**
 * add_event_zoom_meeting_shortcode function.
 * show meeting full detail on single event page sidebar
 * @access public
 * @param 
 * @return 
 * @since 1.0.0
 */
function add_event_zoom_meeting_shortcode() {

	global $post;

	$event_zoom_id = get_post_meta( $post->ID, '_event_zoom_id', true );

	if ( !empty( $event_zoom_id ) ) 
	{
		$meeting_id = get_post_meta( $event_zoom_id, '_meeting_zoom_meeting_id', true );

		if ( !empty( $meeting_id ) ) 
		{
			echo do_shortcode( '[event_zoom_meeting meeting_id="'. $meeting_id .'"]' );	
		}
	}
}