<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

// Cleanup all data.
require 'includes/wpem-zoom-data-cleaner.php';

if ( ! is_multisite() ) {

	// Only do deletion if the setting is true.
	$do_deletion = get_option( 'event_zoom_delete_data_on_uninstall' );
	if ( $do_deletion ) {
		WPEM_Zoom_Data_Cleaner::cleanup_all();
	}
} else {
	global $wpdb;

	$blog_ids         = $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );
	$original_blog_id = get_current_blog_id();

	foreach ( $blog_ids as $blog_id ) {
		switch_to_blog( $blog_id );

		// Only do deletion if the setting is true.
		$do_deletion = get_option( 'event_zoom_delete_data_on_uninstall' );
		if ( $do_deletion ) {
			WPEM_Zoom_Data_Cleaner::cleanup_all();
		}
	}

	switch_to_blog( $original_blog_id );
}

$options = array(
		'wpem_zoom_version',
		'event_zoom_connection_options',
		'event_zoom_api_key',
		'event_zoom_api_secret_key',
		'event_zoom_vanity_url',
		'event_zoom_client_id',
		'event_zoom_client_secret',
		'enable_frontend_zoom_connection',
		'event_zoom_show_post_join_link',
		'event_zoom_show_zoom_author',
		'event_zoom_meeting_started_text',
		'event_zoom_meeting_going_to_start_text',
		'event_zoom_meeting_ended_text',
		'event_zoom_enable_all_event',
		'event_zoom_show_on_single_event',
		'event_zoom_show_on_single_event_sidebar',
		'event_zoom_meeting_dashboard_page_id',
		'event_zoom_submit_meeting_form_page_id',
		'event_zoom_delete_data_on_uninstall',

		'event_zoom_oauth_authorize',
		'event_zoom_token',
);

foreach ( $options as $option ) {
	delete_option( $option );
}