<?php
/**
 * Event Zoom Meeting
 */
if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php $meeting_type_title = ($meeting_type === 'webinar') ? __( 'Webinar', 'wp-event-manager-zoom' ) : __( 'Meeting', 'wp-event-manager-zoom' ); ?>

<div class="event-manager-zoom-meeting-author">
	<div class="event-manager-zoom-meeting-start-link">
        <?php if ( !empty( $meeting->start_url ) ) : ?>
	        <a class="wpem-theme-button change-zoom-meeting-state" target="_blank" href="<?php echo esc_url( $meeting->start_url ); ?>" data-type="post_type" data-state="start" data-postid="<?php echo $zoom_settings['post_id']; ?>" data-id="<?php echo $meeting->id ?>">
	        	<?php echo sprintf( __( 'Start %s ', 'wp-event-manager-zoom' ), $meeting_type_title ); ?>
	        </a>
		<?php endif; ?>
    </div>

	

	<?php if (  isset($meeting->state) && !empty( $meeting->state ) && $meeting->state == 'started'  ) : ?>
        <a href="javascript:void(0);" class="wpem-theme-button change-zoom-meeting-state" data-type="post_type" data-state="end" data-postid="<?php echo $zoom_settings['post_id']; ?>" data-id="<?php echo $meeting->id ?>">
        	<?php echo sprintf( __( 'End %s ?', 'wp-event-manager-zoom' ), $meeting_type_title ); ?>
        </a>
	<?php /* else : ?>
        <a href="javascript:void(0);" class="wpem-theme-button change-zoom-meeting-state" data-type="post_type" data-state="resume" data-postid="<?php echo $zoom_settings['post_id']; ?>" data-id="<?php echo $meeting->id ?>">
        	<?php echo sprintf( __( 'Enable %s Join ?', 'wp-event-manager-zoom' ), $meeting_type_title ); ?>
        </a>
	<?php */ endif; ?>

    <p class="wpem-my-3"><?php _e( 'You are seeing this because you are the author of this post.', 'wp-event-manager-zoom' ); ?></p>
</div>
