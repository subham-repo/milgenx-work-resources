<?php
if ( ! defined( 'ABSPATH' ) ) exit;

if ( empty( $zoom_settings['event_zoom_vanity_url'] ) ) 
{
    $mobile_zoom_url = 'https://zoom.us/j/' . $meeting->id;
} 
else 
{
    $mobile_zoom_url = trailingslashit( $zoom_settings['event_zoom_vanity_url'] . '/j' ) . $meeting->id;
}
?>

<div class="event-zoom-app-notice">
    <p><?php echo esc_html__( 'Note: If you are having trouble joining the meeting below, enter Meeting ID: ', 'wp-event-manager-zoom' ) . '<strong>' . esc_html( $meeting->id ) . '</strong> ' . esc_html__( 'and join via Zoom App.', 'wp-event-manager-zoom' ); ?></p>

    <div class="event-zoom-app-links">
        <a href="<?php echo esc_url( $mobile_zoom_url ); ?>" class="wpem-theme-button"><?php _e( 'Join via Zoom App', 'wp-event-manager-zoom' ); ?></a>
        
        <div class="clearfix">&nbsp;</div>
        
        <a href="https://apps.apple.com/us/app/zoom-cloud-meetings/id546505307" class="wpem-theme-button"><?php _e( 'Download iOS App', 'wp-event-manager-zoom' ); ?></a>
        
        <div class="clearfix">&nbsp;</div>
        
        <a href="https://play.google.com/store/apps/details?id=us.zoom.videomeetings" class="wpem-theme-button"><?php _e( 'Download Android App', 'wp-event-manager-zoom' ); ?></a>
    </div>

</div>