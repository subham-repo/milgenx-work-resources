<?php
/**
 * Event Zoom Meeting
 */
if (!defined('ABSPATH'))
    exit;
?>

<?php $meeting_type_title = ($meeting_type === 'webinar') ? __('Webinar', 'wp-event-manager-zoom') : __('Meeting', 'wp-event-manager-zoom'); ?>

<?php $event_content_toggle = apply_filters('event_manager_event_content_toggle', true);
$event_content_toggle_class = $event_content_toggle ? 'wpem-listing-accordion' : 'wpem-event-zoom-meeting-info-title';
?>

<!-- Zoom Meeting Information Start-->
<div class="wpem-zoom-meeting-wrapper">

    <?php if ($show_title == 'yes') : ?>
        <div class="<?php echo $event_content_toggle_class; ?> active">
            <h3 class="wpem-heading-text"><?php printf(__('Zoom %s Information', 'wp-event-manager-zoom'), $meeting_type_title); ?></h3>
            <i class="wpem-icon-minus"></i><i class="wpem-icon-plus"></i>
        </div>
    <?php endif; ?>

    <div class="wpem-zoom-meeting-info-block-wrapper wpem-listing-accordion-panel active" style="display: block;">
        <div class="event-manager-zoom-meeting-short-info-table">

            <?php do_action('single_event_zoom_meeting_overview_before');

            $meeting_type_title = ''; ?>

            <div class="wpem-zoom-title-row">
                <div class="wpem-row">
                    <div class="wpem-col-md-6 wpem-col-sm-12"><div class="wpem-zoom-title wpem-table-title-lines wpem-table-lines"><strong><?php _e('Title', 'wp-event-manager-zoom'); ?></strong></div></div>
                    <div class="wpem-col-md-6 wpem-col-sm-12"><div class="wpem-zoom-title-info wpem-table-lines"><?php echo $event_zoom_name; ?></div></div>
                </div>
            </div>

            <div class="wpem-zoom-time-row" >
                <div class="wpem-row">
                    <div class="wpem-col-md-6 wpem-col-sm-12"><div class="wpem-zoom-time wpem-table-title-lines wpem-table-lines"><strong><?php _e('Time', 'wp-event-manager-zoom'); ?></strong></div></div>
                    <div class="wpem-col-md-6 wpem-col-sm-12"><div class="wpem-zoom-time-info wpem-table-lines"><?php echo event_manager_zoom_date_converter($meeting->start_time, $meeting->timezone, 'F j, Y @ g:i a'); ?></div></div>
                </div>
            </div>

            <div class="wpem-zoom-timezone-row">
                <div class="wpem-row">
                    <div class="wpem-col-md-6 wpem-col-sm-12"><div class="wpem-zoom-timezone wpem-table-title-lines wpem-table-lines"><strong><?php _e('Timezone', 'wp-event-manager-zoom'); ?></strong></div></div>
                    <div class="wpem-col-md-6 wpem-col-sm-12"><div class="wpem-zoom-timezone-info wpem-table-lines"><?php echo $meeting->timezone; ?></div></div>
                </div>
            </div>

            <div class="wpem-zoom-duration-row ">
                <div class="wpem-row">
                    <div class="wpem-col-md-6 wpem-col-sm-12"><div class="wpem-zoom-duration wpem-table-title-lines wpem-table-lines"><strong><?php _e('Duration', 'wp-event-manager-zoom'); ?></strong></div></div>
                    <div class="wpem-col-md-6 wpem-col-sm-12"><div class="wpem-zoom-duration-info wpem-table-lines"><?php echo $meeting->duration; ?> <?php _e('Minutes', 'wp-event-manager-zoom'); ?></div></div>
                </div>
            </div>

            <?php if (!empty($event_zoom_description)) : ?>
            <div class="wpem-zoom-description-row">
                <div class="wpem-row">
                    <div class="wpem-col-12"><div class="wpem-zoom-description wpem-table-title-lines wpem-table-lines"><strong><?php _e('Description', 'wp-event-manager-zoom'); ?></strong></div></div>
                    <div class="wpem-col-12"><div class="wpem-zoom-description-info wpem-table-lines"><?php echo $event_zoom_description; ?></div>
                    </div>
                </div>                
            </div>
            <?php endif; ?>

            <?php do_action('single_event_zoom_meeting_overview_after'); ?>

        </div>
    </div>
</div>


<!-- Zoom Meeting Information End-->
