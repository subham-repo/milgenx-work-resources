<?php
/**
 * Event Zoom Meeting
 * https://stackoverflow.com/questions/39401393/how-to-get-woocommerce-order-details
 * https://stackoverflow.com/questions/42223765/get-the-order-id-from-the-current-user-orders-in-woocommerce
 */
if ( ! defined( 'ABSPATH' ) ) exit; ?>

<table class="woocommerce-zoom-meeting-table woocommerce-MyAccount-zoom-meeting shop_table shop_table_responsive my_account_zoom_meeting account-zoom-meeting-table">
    <thead>
        <tr>
            <th><?php _e('Order', 'wp-event-manager-zoom'); ?></th>
            <th><?php _e('Date', 'wp-event-manager-zoom'); ?></th>
            <th><?php _e('Status', 'wp-event-manager-zoom'); ?></th>
            <th><?php _e('Meeting Title', 'wp-event-manager-zoom'); ?></th>
            <th><?php _e('Meeting Time', 'wp-event-manager-zoom'); ?></th>
            <th><?php _e('Action', 'wp-event-manager-zoom'); ?></th>
        </tr>
    </thead>

    <tbody>
        <?php $total_meetings = []; ?>
        <?php if(!empty($orders)) : ?>

            <?php foreach ( $orders as $order ) : ?>

                <?php
                $order_id = method_exists( $order, 'get_id' ) ? $order->get_id() : $order->id;
                $order_data = $order->get_data();
                $items = $order->get_items();
                $order_status  = $order->get_status();
                ?>

                <?php foreach ( $items as $item ) : 

                    $product_id = method_exists( $item, 'get_product_id' ) ? $item->get_product_id() : $item['product_id'];
                    $event_zoom_id = get_post_meta($product_id, '_event_zoom_id', true);
                    $meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );
                    $event_zoom_name = get_post_meta($event_zoom_id, '_event_zoom_name', true); ?>

                    <?php if(!empty($event_zoom_id) && !empty($meeting) && isset($meeting->id) ) : ?>
                        <tr>
                            <?php
                            $total_meetings[$event_zoom_id] = $meeting->id;
                            $join_uri = apply_filters( 'event_manager_zoom_join_meeting_via_app_shortcode', $meeting->join_url, $meeting );
                            ?>

                            <td><a href="<?php echo $order->get_view_order_url(); ?>"><?php echo $order_id; ?></a></td>
                            <td><?php echo $order_data['date_created']->date('Y-m-d'); ?></td>
                            <td><?php echo $order_data['status']; ?></td>
                            
                            
                            <td><?php echo $event_zoom_name; ?></td>
                            <td><?php echo event_manager_zoom_date_converter( $meeting->start_time, $meeting->timezone, 'F j, Y @ g:i a' ); ?></td>
                            <td>
                                <?php if($order_status === 'completed') : ?>
                                    <a class="wpem-theme-button" target="_blank" href="<?php echo $join_uri; ?>" title="Join via App">
                                        <?php _e( 'Join', 'wp-event-manager-zoom' ); ?>
                                    </a>
                                <?php else: ?>
                                    <p> - </p>
                                <?php endif; ?>
                            </td>                                
                        </tr>
                    <?php endif; ?>

                <?php endforeach; ?>

            <?php endforeach; ?>
            
        <?php endif; ?>


        <?php if(empty($total_meetings)) : ?>
            <tr><td colspan="6"><?php _e('No meetings found.', 'wp-event-manager-zoom'); ?></td></tr>
        <?php endif; ?>

    </tbody>

</table>