<?php
if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="event-manager-zoom-timer" id="event_manager_zoom_timer" data-date="<?php echo $meeting->start_time; ?>" data-state="<?php echo !empty( $meeting->state ) ? $meeting->state : false; ?>" data-tz="<?php echo $meeting->timezone; ?>">
    <div class="event-manager-zoom-timer-cell">
        <div class="event-manager-zoom-timer-cell-number">
            <div id="event_manager_zoom_timer_days"></div>
        </div>
        <div class="event-manager-zoom-timer-cell-string"><?php _e( 'day', 'wp-event-manager-zoom' ); ?></div>
    </div>
    <div class="event-manager-zoom-timer-cell">
        <div class="event-manager-zoom-timer-cell-number">
            <div id="event_manager_zoom_timer_hours"></div>
        </div>
        <div class="event-manager-zoom-timer-cell-string"><?php _e( 'hrs', 'wp-event-manager-zoom' ); ?></div>
    </div>
    <div class="event-manager-zoom-timer-cell">
        <div class="event-manager-zoom-timer-cell-number">
            <div id="event_manager_zoom_timer_minutes"></div>
        </div>
        <div class="event-manager-zoom-timer-cell-string"><?php _e( 'min', 'wp-event-manager-zoom' ); ?></div>
    </div>
    <div class="event-manager-zoom-timer-cell">
        <div class="event-manager-zoom-timer-cell-number">
            <div id="event_manager_zoom_timer_seconds"></div>
        </div>
        <div class="event-manager-zoom-timer-cell-string"><?php _e( 'sec', 'wp-event-manager-zoom' ); ?></div>
    </div>
</div>