<?php
/**
 * Event Zoom Form
 */
if ( ! defined( 'ABSPATH' ) ) exit;

global $post; ?>

<div class="wpem-alert wpem-alert-warning">
    <p><?php _e( 'ATTENTION: Zoom Account & Setting Prerequisites for Reports Section', 'wp-event-manager-zoom' ); ?></p>

    <ol>
        <li><?php _e( 'Pro, Business, Enterprise, Education, or API Account. Check', 'wp-event-manager-zoom' ); ?>
            <a target="_blank" href="https://support.zoom.us/hc/en-us/articles/201363173-Account-Types"><?php _e( 'here', 'wp-event-manager-zoom' ); ?></a>.
        </li>
        <li><?php _e( 'Account owner or admin permissions to access Usage Reports for all users.', 'wp-event-manager-zoom' ); ?></li>
        <li><?php _e( 'Account Owner or a user is given the User activities reports.', 'wp-event-manager-zoom' ); ?>
            <a target="_blank" href="https://support.zoom.us/hc/en-us/articles/115001078646"><?php _e( 'role', 'wp-event-manager-zoom' ); ?></a></li>
    </ol>
</div>

<div class="wpem-event-zoom-report-tabs">
    <div class="wpem-tabs-wrapper">

        <ul class="wpem-tabs-wrap">
            <li class="wpem-tab-link <?php echo $zoom_report == 'daily' ? 'active' : ''; ?>" data-tab="daily">
                <a href="<?php echo add_query_arg( array( 'action' => 'show_zoom_reports', 'report' => 'daily' ), get_permalink( $post->ID ) ); ?>"><?php _e('Monthly Report', 'wpem-event-manager-zoom'); ?></li></a>
            <li class="wpem-tab-link <?php echo $zoom_report == 'account' ? 'active' : ''; ?>" data-tab="account">
                <a href="<?php echo add_query_arg( array( 'action' => 'show_zoom_reports', 'report' => 'account' ), get_permalink( $post->ID ) ); ?>"><?php _e('Account Report', 'wpem-event-manager-zoom'); ?></li></a>
        </ul>

        <div class="event-zoom-report-tab-contents wpem-tab-content current">            
            <div id="daily" class="wpem-tab-pane <?php echo $zoom_report == 'daily' ? 'active' : ''; ?>">
                <form class="wpem-event-zoom wpem-form-wrapper" method="POST">
                    <div class="wpem-event-zoom-field">
                        <div class="wpem-row">
                            <div class="wpem-col-md-4">
                                <div class="wpem-form-group">
                                    <input type="text" name="zoom_month_year" id="zoom_month_year" data-picker="monthpicker" placeholder="<?php _e('Select Month', 'wpem-event-manager-zoom'); ?>" value="">
                                    <small class="description"><?php _e('Enter the month to check', 'wpem-event-manager-zoom'); ?></small>
                                </div>                            
                            </div>
                            <div class="wpem-col-md-4">
                                <div class="wpem-form-group">
                                    <input type="submit" class="wpem-theme-button" name="zoom_check_month_year" value="Check">
                                </div>                            
                            </div>
                        </div>
                    </div>
                </form>

                <?php if ( isset( $_POST['zoom_check_month_year'] ) ) : ?>
                    <?php if ( isset( $result->code ) ) : ?>
                        <div class="wpem-alert wpem-alert-danger">
                            <?php echo $result->message; ?>
                        </div>
                    <?php else : ?>
                        <table class="wpem-main wpem-responsive-table-wrapper">
                            <thead>
                                <tr>
                                    <th><?php _e( 'Date', 'wp-event-manager-zoom' ); ?></th>
                                    <th><?php _e( 'Meetings', 'wp-event-manager-zoom' ); ?></th>
                                    <th><?php _e( 'New Users', 'wp-event-manager-zoom' ); ?></th>
                                    <th><?php _e( 'Participants', 'wp-event-manager-zoom' ); ?></th>
                                    <th><?php _e( 'Meeting Minutes', 'wp-event-manager-zoom' ); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ( isset( $result->dates ) ) :
                                    $count = count( $result->dates );
                                    foreach ( $result->dates as $date ) { ?>
                                        <tr>
                                            <td><?php echo date( 'F j, Y', strtotime( $date->date ) ); ?></td>
                                            <td><?php echo ( $date->meetings > 0 ) ? '<strong style="color: #4300FF; font-size: 16px;">' . $date->meetings . '</strong>' : '-'; ?></td>
                                            <td><?php echo ( $date->new_users > 0 ) ? '<strong style="color:#00A1B5; font-size: 16px;">' . $date->new_users . '</strong>' : '-'; ?></td>
                                            <td><?php echo ( $date->participants > 0 ) ? '<strong style="color:#00AF00; font-size: 16px;">' . $date->participants . '</strong>' : '-'; ?></td>
                                            <td><?php echo ( $date->meeting_minutes > 0 ) ? '<strong style="color:red; font-size: 16px;">' . $date->meeting_minutes . '</strong>' : '-'; ?></td>
                                        </tr>
                                <?php }
                                else : ?>
                                    <tr>
                                        <td colspan="5"><?php _e( "Select a Date to Check..." ); ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                <?php endif; ?>

            </div>

            <div id="account" class="wpem-tab-pane <?php echo $zoom_report == 'account' ? 'active' : ''; ?>">
                <form class="wpem-event-zoom wpem-form-wrapper" method="POST">
                    <div class="wpem-event-zoom-field">
                        <div class="wpem-row">
                            <div class="wpem-col-md-4">
                                <div class="wpem-form-group">
                                    <input type="text" name="zoom_account_from" id="zoom_account_from" placeholder="<?php _e('Select Start Date', 'wpem-event-manager-zoom'); ?>" value="">
                                    <small class="description"><?php _e('Enter the start date', 'wpem-event-manager-zoom'); ?></small>
                                </div>                            
                            </div>
                            <div class="wpem-col-md-4">
                                <div class="wpem-form-group">
                                    <input type="text" name="zoom_account_to" id="zoom_account_to" placeholder="<?php _e('Select End Date', 'wpem-event-manager-zoom'); ?>" value="">
                                    <small class="description"><?php _e('Enter the end date', 'wpem-event-manager-zoom'); ?></small>
                                </div>                            
                            </div>
                            <div class="wpem-col-md-4">
                                <div class="wpem-form-group">
                                    <input type="submit" class="wpem-theme-button" name="zoom_check_account_info" value="Check">
                                </div>                            
                            </div>
                        </div>
                    </div>
                </form>

                <?php if ( isset( $_POST['zoom_check_account_info'] ) ) : ?>
                    <?php if ( isset( $result->code ) ) : ?>
                        <div class="wpem-alert wpem-alert-danger">
                            <?php echo $result->message; ?>
                        </div>
                    <?php else : ?>
                        <table class="wpem-main wpem-responsive-table-wrapper">
                            <thead>
                                <tr>
                                    <th><?php _e( 'By', 'wp-event-manager-zoom' ); ?></th>
                                    <th><?php _e( 'Meetings Held', 'wp-event-manager-zoom' ); ?></th>
                                    <th><?php _e( 'Total Participants', 'wp-event-manager-zoom' ); ?></th>
                                    <th><?php _e( 'Total Meeting Minutes', 'wp-event-manager-zoom' ); ?></th>
                                    <th><?php _e( 'Last Login Time', 'wp-event-manager-zoom' ); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ( isset( $result->users ) ) : ?>
                                    <?php $count = count( $result->users );
                                    if ( $count == 0 ) 
                                    {
                                        echo '<tr colspan="5"><td>' . __( 'No Records Found..', 'wp-event-manager-zoom' ) . '</td></tr>';
                                    } 
                                    else 
                                    {
                                        foreach ( $result->users as $user ) { ?>
                                            <tr>
                                                <td><?php echo $user->email; ?></td>
                                                <td><?php echo $user->meetings; ?></td>
                                                <td><?php echo $user->participants; ?></td>
                                                <td><?php echo $user->meeting_minutes; ?></td>
                                                <td><?php echo date( 'F j, Y g:i a', strtotime( $user->last_login_time ) ); ?></td>
                                            </tr>
                                            <?php
                                        }
                                    } ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="5"><?php _e( "Enter a value to Check...", "video-conferencing-with-zoom-api" ); ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

        </div>

    </div>
</div>