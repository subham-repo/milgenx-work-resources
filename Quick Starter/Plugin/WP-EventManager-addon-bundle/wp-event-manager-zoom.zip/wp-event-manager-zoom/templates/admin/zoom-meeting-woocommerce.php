<?php
$enable_wc_purchase = !empty( $meeting_wc_product['enable_wc_purchase'] ) ? $meeting_wc_product['enable_wc_purchase'] : '';
$meeting_wc_product_price = !empty( $meeting_wc_product['meeting_wc_product_price'] ) ? $meeting_wc_product['meeting_wc_product_price'] : '';
$meeting_wc_product_id = !empty( $meeting_wc_product['meeting_wc_product_id'] ) ? $meeting_wc_product['meeting_wc_product_id'] : '';
$meeting_wc_product_show_ticket_buy_button = !empty( $meeting_wc_product['meeting_wc_product_show_ticket_buy_button'] ) ? $meeting_wc_product['meeting_wc_product_show_ticket_buy_button'] : '';
?>

<div class="zoom-metabox-wrapper zoom-meeting-wc">
    <div class="zoom-metabox-content">
        <p><?php _e( 'Enable Purchase?', 'wp-event-manager-zoom' ); ?>
            <input type="checkbox" name="enable_wc_purchase" id="enable_wc_purchase" value="1" <?php !empty( $enable_wc_purchase ) ? checked( '1', $enable_wc_purchase ) : false; ?> class="regular-text">
        </p>

        <div class="meeting-wc-wrap">
            <p><?php _e( 'Enabling this will create a new WooCommerce product linked with this post which will be Purchasable by customer.', 'wp-event-manager-zoom' ); ?></p>

            <p class="error"><?php _e( 'NOTE : Avoid checking this option if you want to sell this meeting from your WooCommerce shop page.', 'wp-event-manager-zoom' ); ?></p>

            <input type="hidden" name="meeting_wc_product_id" id="meeting_wc_product_id" value="<?php echo $meeting_wc_product_id;?>">

            <p><?php _e( 'Ticket Price', 'wp-event-manager-zoom' ); ?>
                <br/><input type="text" name="meeting_wc_product_price" id="meeting_wc_product_price" class="regular-text" value="<?php echo $meeting_wc_product_price;?>">
            </p>
            
            <?php if( isset($meeting_wc_product_id) && !empty($meeting_wc_product_id) ) : ?>
                <p>
                    <strong><?php _e( 'Product ID', 'wp-event-manager-zoom' ); ?>: #<?php echo $meeting_wc_product_id; ?></strong><br/>
                    <strong><?php _e( 'Product Name', 'wp-event-manager-zoom' ); ?>: <?php echo get_the_title($meeting_wc_product_id); ?></strong>
                </p>
            <?php endif;?>

            <p><?php _e( 'Show Ticket Buy Button?', 'wp-event-manager-zoom' ); ?>
                <input type="checkbox" name="meeting_wc_product_show_ticket_buy_button" id="meeting_wc_product_show_ticket_buy_button" value="1" <?php !empty( $meeting_wc_product_show_ticket_buy_button ) ? checked( '1', $meeting_wc_product_show_ticket_buy_button ) : false; ?> class="regular-text">
            </p>

        </div>

    </div>

</div>