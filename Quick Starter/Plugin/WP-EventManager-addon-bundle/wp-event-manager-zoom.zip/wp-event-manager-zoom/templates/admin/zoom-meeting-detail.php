<div class="zoom-metabox-wrapper zoom-meeting-detail">
    <?php if ( !empty( $meeting_error ) ) : ?>
        <?php if ( !empty( $meeting_error->code ) && !empty( $meeting_error->message ) ) : ?>        
            <p><strong><?php _e( 'Meeting has not been created for this post yet. Publish your meeting or hit update to create a new one for this post
                    !', 'wp-event-manager-zoom' ); ?></strong></p>

            <?php echo sprintf( __( '<p style="color:red;">Zoom Error: %s </p>', 'wp-event-manager-migration' ), $meeting_error->message ); ?>
        <?php endif; ?>

    <?php elseif ( !empty( $meeting_details ) ) : ?>
        <?php $zoom_host_url = get_event_manager_zoom_join_url_host($meeting_details->id); ?>
            <div class="zoom-metabox-content">
                <p><a target="_blank" href="<?php echo esc_url( $meeting_details->start_url ); ?>" title="Start URL"><?php _e( 'Start Meeting', 'wp-event-manager-zoom' ); ?></a></p>
                <p><a target="_blank" href="<?php echo esc_url( $meeting_details->join_url ); ?>" title="Start URL"><?php _e( 'Join Meeting', 'wp-event-manager-zoom' ); ?></a></p>
                <p><a target="_blank" href="<?php echo esc_url( $zoom_host_url ); ?>" title="Start URL"><?php _e( 'Start via Browser', 'wp-event-manager-zoom' ); ?></a></p>
                <p><strong><?php _e( 'Meeting ID:', 'wp-event-manager-zoom' ); ?></strong> <?php echo $meeting_details->id; ?></p>
                <?php do_action( 'event_manager_zoom_meeting_details_admin', $meeting_details ); ?>
            </div>
            <hr>

    <?php else : ?>
        <p><strong><?php _e( 'Meeting has not been created for this post yet. Publish your meeting or hit update to create a new one for this post
                !', 'wp-event-manager-zoom' ); ?></strong></p>

    <?php endif; ?>

    <div class="zoom-metabox-content">
        <p><?php _e( 'Requires Login?', 'wp-event-manager-zoom' ); ?>
            <input type="checkbox" name="site_option_logged_in" value="1" <?php !empty( $meeting_fields['site_option_logged_in'] ) ? checked( '1', $meeting_fields['site_option_logged_in'] ) : false; ?> class="regular-text">
        </p>
        <p class="description"><?php _e( 'Only logged in users of this site will be able to join this meeting.', 'wp-event-manager-zoom' ); ?></p>
        <p><?php _e( 'Hide Join via browser link ?', 'wp-event-manager-zoom' ); ?>
            <input type="checkbox" name="site_option_browser_join" value="1" <?php !empty( $meeting_fields['site_option_browser_join'] ) ? checked( '1', $meeting_fields['site_option_browser_join'] ) : false; ?> class="regular-text">
        </p>
        <p class="description"><?php _e( 'This will disable join via browser link in frontend page.', 'wp-event-manager-zoom' ); ?></p>
    </div>

</div>