<div class="wrap wp_event_manager_zoom_wrap">
    <h2><?php _e('Zoom Users', 'wp-event-manager-zoom'); ?></h2>

    <p><button class="button-primary sync-zoom-users"><?php _e('Sync Zoom User', 'wp-event-manager-zoom' ); ?></button></p>

    <table class="widefat wpem-zoom-user-lists">
        <thead>
            <tr>
                <th width="05%"><?php _e('No', 'wp-event-manager-zoom' ); ?></th>
                <th width="20%"><?php _e('User ID', 'wp-event-manager-zoom' ); ?></th>
                <th width="15%"><?php _e('Email', 'wp-event-manager-zoom' ); ?></th>
                <th width="20%"><?php _e('Name', 'wp-event-manager-zoom' ); ?></th>
                <th width="15%"><?php _e('Created On', 'wp-event-manager-zoom' ); ?></th>
                <th width="15%"><?php _e('Last Login', 'wp-event-manager-zoom' ); ?></th>
                <th width="10%"><?php _e('Last Client', 'wp-event-manager-zoom' ); ?></th>
            </tr>
        </thead>

        <tbody>
            <?php if( !empty($zoom_users) && empty($zoom_users->code) ) : ?>
                <?php foreach ( $zoom_users as $key => $user ) : ?>
                    <tr>
                        <td><?php echo $key + 1 ; ?></td>
                        <td><?php echo $user->id; ?></td>
                        <td><?php echo $user->email; ?></td>
                        <td><?php echo $user->first_name . ' ' . $user->last_name; ?></td>
                        <td><?php echo !empty( $user->created_at ) ? date( 'F j, Y, g:i a', strtotime( $user->created_at ) ) : "N/A"; ?></td>
                        <td><?php echo !empty( $user->last_login_time ) ? date( 'F j, Y, g:i a', strtotime( $user->last_login_time ) ) : "N/A"; ?></td>
                        <td><?php echo !empty( $user->last_client_version ) ? $user->last_client_version : "N/A"; ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="7"><?php _e('Not found any user', 'wp-event-manager-zoom' ); ?></td>
                </tr>
            <?php endif; ?>
        <tbody>

    </table>

</div>