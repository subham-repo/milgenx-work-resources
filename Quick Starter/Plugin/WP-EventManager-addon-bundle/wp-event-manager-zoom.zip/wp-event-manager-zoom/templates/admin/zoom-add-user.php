<?php echo $message; ?>

<div class="notice notice-warning">
    <p><?php echo sprintf( __( 'What does this do ? Check out <a href="%s" target="_blank">Zoom website</a>. Please note this may require a PRO account.', 'wp-event-manager-zoom' ), 'https://support.zoom.us/hc/en-us/articles/201363183-Managing-users' ); ?></p>
</div>

<div class="wrap wp-event-manager-zoom-wrap">
	<h2><?php _e('Add New User', 'wp-event-manager-zoom'); ?></h2>

    <form method="post" class="wp-event-manager-zoom-add-user-form">
		<table class="form-table">

    		<tbody>
                <tr valign="top">
                    <th scope="row"><?php _e('Action (Required).', 'wp-event-manager-zoom' ); ?></th>
                    <td>
                        <select name="user_action" class="regular-text">
                            <?php foreach ( get_event_manager_zoom_add_user_actions() as $name => $label ) : ?>
                                <option value="<?php echo esc_attr( $name ); ?>" ><?php echo esc_html( $label ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="type-description">
                            <p class="description"><?php _e( 'Type of User (Required)', 'wp-event-manager-zoom' ); ?></p>
                            <p class="description">1. <strong>"<?php _e( 'Create', 'wp-event-manager-zoom' ); ?>"</strong>
                                - <?php _e( 'User will get an email sent from Zoom. There is a confirmation link in this email. User will then need to click this link to activate their account to the Zoom service. The user can set or change their password in Zoom.', 'wp-event-manager-zoom' ); ?>
                            </p>

                            <p class="description">2. <strong>"<?php _e( 'Auto Create', 'wp-event-manager-zoom' ); ?>"</strong>
                                - <?php _e( 'This action is provided for enterprise customer who has a managed domain. This feature is disabled by default because of the security risk involved in creating a user who does not belong to your domain without notifying the user.', 'wp-event-manager-zoom' ); ?>
                            </p>

                            <p class="description">3. <strong>"<?php _e( 'Cust Create', 'wp-event-manager-zoom' ); ?>"</strong>
                                - <?php _e( 'This action is provided for API partner only. User created in this way has no password and is not able to log into the Zoom web site or client.', 'wp-event-manager-zoom' ); ?>
                            </p>

                            <p class="description">4. <strong>"<?php _e( 'SSO Create', 'wp-event-manager-zoom' ); ?>"</strong>
                                - <?php _e( 'This action is provided for enabled “Pre-provisioning SSO User” option. User created in this way has no password. If it is not a basic user, will generate a Personal Vanity URL using user name (no domain) of the provisioning email. If user name or pmi is invalid or occupied, will use random number/random personal vanity URL.', 'wp-event-manager-zoom' ); ?>
                            </p>
                        </div>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row"><?php _e('Email Address', 'wp-event-manager-zoom' ); ?></th>
                    <td>
                        <input type="email" name="user_email" class="regular-text" required placeholder="admin@example.com">
                        <p class="description"><?php _e( 'Email address is used for zoom (Required).', 'wp-event-manager-zoom' ); ?></p>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row"><?php _e('First Name', 'wp-event-manager-zoom' ); ?></th>
                    <td>
                        <input type="text" name="user_first_name" class="regular-text" required>
                        <p class="description"><?php _e( 'First Name of the User (Required).', 'wp-event-manager-zoom' ); ?></p>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row"><?php _e('Last Name', 'wp-event-manager-zoom' ); ?></th>
                    <td>
                        <input type="text" name="user_last_name" class="regular-text" required>
                        <p class="description"><?php _e( 'Last Name of the User (Required).', 'wp-event-manager-zoom' ); ?></p>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row"><?php _e('User Type (Required).', 'wp-event-manager-zoom' ); ?></th>
                    <td>
                        <select name="user_type" class="regular-text">
                            <?php foreach ( get_event_manager_zoom_add_user_types() as $name => $label ) : ?>
                                <option value="<?php echo esc_attr( $name ); ?>" ><?php echo esc_html( $label ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description"><?php echo sprintf( __( 'Type of User (Required), Check out <a href="%s" target="_blank">more info</a>.', 'wp-event-manager-zoom' ), 'https://support.zoom.us/hc/en-us/articles/201363173-Account-Types' ); ?></p>
                    </td>
                </tr>

            </tbody>

            <tfoot>
                <tr>
                    <th scope="row" colspan="2">
                        <input type="hidden" name="page" value="event-manager-zoom-user-add" />

                    	<input type="submit" class="button-primary" name="wp_event_manager_zoom_add_user" value="<?php esc_attr_e( 'Submit', 'wp-event-manager-zoom' ); ?>" />

                    	<?php wp_nonce_field( 'event_manager_zoom_add_user' ); ?>
                    </td>
                </tr>
            </tfoot>

        </table>
	</form>

</div>