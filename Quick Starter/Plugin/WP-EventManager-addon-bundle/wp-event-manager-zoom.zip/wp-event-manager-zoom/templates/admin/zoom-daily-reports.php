<div class="wrap wp-event-mamager-zoom-wrap">
    <h1><?php _e( 'Reports', 'wp-event-manager-zoom' ); ?></h1>

    <h2 class="nav-tab-wrapper">
        <a href="?post_type=event_zoom&page=event-manager-zoom-reports&tab=zoom_daily_report" class="nav-tab <?php echo $active_tab == 'zoom_daily_report' ? 'nav-tab-active' : ''; ?>"><?php _e( '1. Monthly Report', 'wp-event-manager-zoom' ); ?></a>
        <a href="?post_type=event_zoom&page=event-manager-zoom-reports&tab=zoom_acount_report" class="nav-tab <?php echo $active_tab == 'zoom_acount_report' ? 'nav-tab-active' : ''; ?>"><?php _e( '2. Account Report', 'wp-event-manager-zoom' ); ?></a>
    </h2>

    <div id="message" class="notice notice-warning">
        <h2><?php _e( 'ATTENTION: Zoom Account & Setting Prerequisites for Reports Section', 'wp-event-manager-zoom' ); ?></h2>
        
        <ol>
            <li><?php _e( 'Pro, Business, Enterprise, Education, or API Account. Check', 'wp-event-manager-zoom' ); ?>
                <a target="_blank" href="https://support.zoom.us/hc/en-us/articles/201363173-Account-Types"><?php _e( 'here', 'wp-event-manager-zoom' ); ?></a>.
            </li>
            <li><?php _e( 'Account owner or admin permissions to access Usage Reports for all users.', 'wp-event-manager-zoom' ); ?></li>
            <li><?php _e( 'Account Owner or a user is given the User activities reports.', 'wp-event-manager-zoom' ); ?>
                <a target="_blank" href="https://support.zoom.us/hc/en-us/articles/115001078646"><?php _e( 'role', 'wp-event-manager-zoom' ); ?></a></li>
        </ol>
    </div>

    <?php if ( isset( $_POST['zoom_check_month_year'] ) ) {
            if ( isset( $result->error ) ) {
                ?>
                <div id="message" class="notice notice-error">
                    <p><?php echo $result->error->message; ?></p>
                </div>
                <?php
            }

            if ( isset( $result->message ) ) { ?>
                <div id="message" class="notice notice-error">
                    <p><?php echo $result->message; ?></p>
                </div>
            <?php }
        } ?>
        
        <div class="zoom-dateinput-field">
            <form action="?post_type=event_zoom&page=event-manager-zoom-reports" class="event-manager-zoom-daily-reports-check-form" method="POST">
                <label><?php _e( 'Enter the month to check:', 'wp-event-manager-zoom' ); ?></label>
                <input name="zoom_month_year" id="reports_date"/> <input type="submit" name="zoom_check_month_year" value="Check">
            </form>
        </div>
        <table class="wp-list-table widefat fixed striped posts">
            <thead>
            <tr>
                <th><span><?php _e( 'Date', 'wp-event-manager-zoom' ); ?></span></th>
                <th><span><?php _e( 'Meetings', 'wp-event-manager-zoom' ); ?></span></th>
                <th><span><?php _e( 'New Users', 'wp-event-manager-zoom' ); ?></span></th>
                <th><span><?php _e( 'Participants', 'wp-event-manager-zoom' ); ?></span></th>
                <th><span><?php _e( 'Meeting Minutes', 'wp-event-manager-zoom' ); ?></span></th>
            </tr>
            </thead>
            <tbody class="the-list">
            <?php
            if ( isset( $result->dates ) ) {
                $count = count( $result->dates );
                foreach ( $result->dates as $date ) { ?>
                    <tr>
                        <td><?php echo date( 'F j, Y', strtotime( $date->date ) ); ?></td>
                        <td><?php echo ( $date->meetings > 0 ) ? '<strong style="color: #4300FF; font-size: 16px;">' . $date->meetings . '</strong>' : '-'; ?></td>
                        <td><?php echo ( $date->new_users > 0 ) ? '<strong style="color:#00A1B5; font-size: 16px;">' . $date->new_users . '</strong>' : '-'; ?></td>
                        <td><?php echo ( $date->participants > 0 ) ? '<strong style="color:#00AF00; font-size: 16px;">' . $date->participants . '</strong>' : '-'; ?></td>
                        <td><?php echo ( $date->meeting_minutes > 0 ) ? '<strong style="color:red; font-size: 16px;">' . $date->meeting_minutes . '</strong>' : '-'; ?></td>
                    </tr>
                    <?php
                }
            } else { ?>
                <tr>
                    <td colspan="5"><?php _e( "Select a Date to Check..." ); ?></td>
                </tr>
                <?php
            }
            ?>
            </tbody>
        </table>
    
</div>