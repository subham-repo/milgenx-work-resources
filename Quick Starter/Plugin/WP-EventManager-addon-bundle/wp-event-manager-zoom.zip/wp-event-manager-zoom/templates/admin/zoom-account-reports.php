<div class="wrap wp-event-mamager-zoom-wrap">
    <h1><?php _e( 'Reports', 'wp-event-manager-zoom' ); ?></h1>

    <h2 class="nav-tab-wrapper">
        <a href="?post_type=event_zoom&page=event-manager-zoom-reports&tab=zoom_daily_report" class="nav-tab <?php echo $active_tab == 'zoom_daily_report' ? 'nav-tab-active' : ''; ?>"><?php _e( '1. Monthly Report', 'wp-event-manager-zoom' ); ?></a>
        <a href="?post_type=event_zoom&page=event-manager-zoom-reports&tab=zoom_acount_report" class="nav-tab <?php echo $active_tab == 'zoom_acount_report' ? 'nav-tab-active' : ''; ?>"><?php _e( '2. Account Report', 'wp-event-manager-zoom' ); ?></a>
    </h2>

    <div id="message" class="notice notice-warning">
        <h2><?php _e( 'ATTENTION: Zoom Account & Setting Prerequisites for Reports Section', 'wp-event-manager-zoom' ); ?></h2>

        <ol>
            <li><?php _e( 'Pro, Business, Enterprise, Education, or API Account. Check', 'wp-event-manager-zoom' ); ?>
                <a target="_blank" href="https://support.zoom.us/hc/en-us/articles/201363173-Account-Types"><?php _e( 'here', 'wp-event-manager-zoom' ); ?></a>.
            </li>
            <li><?php _e( 'Account owner or admin permissions to access Usage Reports for all users.', 'wp-event-manager-zoom' ); ?></li>
            <li><?php _e( 'Account Owner or a user is given the User activities reports.', 'wp-event-manager-zoom' ); ?>
                <a target="_blank" href="https://support.zoom.us/hc/en-us/articles/115001078646"><?php _e( 'role', 'wp-event-manager-zoom' ); ?></a></li>
        </ol>
    </div>

    <?php if ( isset( $_POST['zoom_check_account_info'] ) ) : ?>
        <?php if ( empty( $_POST['zoom_account_from'] ) || empty( $_POST['zoom_account_to'] ) ) : ?>
            <div id="message" class="notice notice-error">
                <?php if ( isset( $result->error ) ) : ?>
                    <p><?php echo $result->error->message; ?></p>
                <?php else : ?>
                    <p><?php echo $result; ?></p>
                <?php endif; ?>
            </div>
        <?php else : ?>
                <?php if ( isset( $result->message ) ) : ?>
                    <div id="message" class="notice notice-error">
                        <p><?php echo $result->message; ?></p>
                    </div>
                <?php else : ?>
                    <div id="message" class="notice notice-success">
                        <ul class="zoom_acount_lists">
                            <li><?php echo isset( $result->from ) ? __( 'Searching From: ', 'wp-event-manager-zoom' ) . $result->from . __( ' to ', 'wp-event-manager-zoom' ) : null; ?><?php echo isset( $result->to ) ? $result->to : null; ?></li>
                            <li><?php echo isset( $result->total_records ) ? __( 'Total Records Found: ', 'wp-event-manager-zoom' ) . $result->total_records : null; ?></li>
                            <li><?php echo isset( $result->total_meetings ) ? __( 'Total Meetings Held: ', 'wp-event-manager-zoom' ) . $result->total_meetings : null; ?></li>
                            <li><?php echo isset( $result->total_participants ) ? __( 'Total Participants Involved: ', 'wp-event-manager-zoom' ) . $result->total_participants : null; ?></li>
                            <li><?php echo isset( $result->total_meeting_minutes ) ? __( 'Total Meeting Minutes Combined: ', 'wp-event-manager-zoom' ) . $result->total_meeting_minutes : null; ?></li>
                        </ul>
                    </div>
                <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>

    <div class="zoom-dateinput-field">
        <p><?php _e( 'Get account report for a specified period.', 'wp-event-manager-zoom' ); ?>
            <a onclick="window.print();" href="javascript:void(0);"><?php _e( 'Print', 'wp-event-manager-zoom' ); ?></a></p>
        <form action="?post_type=event_zoom&page=event-manager-zoom-reports&tab=zoom_acount_report" class="event_manager_zoom_account_reports_check_form" method="POST">
            <label><?php _e( 'From', 'wp-event-manager-zoom' ); ?></label>
            <input name="zoom_account_from" class="zoom-account-datepicker"/>
            <label><?php _e( 'To', 'wp-event-manager-zoom' ); ?></label>
            <input name="zoom_account_to" class="zoom-account-datepicker"/> <input type="submit" name="zoom_check_account_info" value="Check">
        </form>
    </div>

    <table class="wp-list-table widefat fixed striped posts">
        <thead>
        <tr>
            <th><span><?php _e( 'By', 'wp-event-manager-zoom' ); ?></span></th>
            <th><span><?php _e( 'Meetings Held', 'wp-event-manager-zoom' ); ?></span></th>
            <th><span><?php _e( 'Total Participants', 'wp-event-manager-zoom' ); ?></span></th>
            <th><span><?php _e( 'Total Meeting Minutes', 'wp-event-manager-zoom' ); ?></span></th>
            <th><span><?php _e( 'Last Login Time', 'wp-event-manager-zoom' ); ?></span></th>
        </tr>
        </thead>
        <tbody class="the-list">
        <?php if ( isset( $result->users ) ) : ?>
            <?php $count = count( $result->users );
            if ( $count == 0 ) 
            {
                echo '<tr colspan="5"><td>' . __( 'No Records Found..', 'wp-event-manager-zoom' ) . '</td></tr>';
            } 
            else 
            {
                foreach ( $result->users as $user ) { ?>
                    <tr>
                        <td><?php echo $user->email; ?></td>
                        <td><?php echo $user->meetings; ?></td>
                        <td><?php echo $user->participants; ?></td>
                        <td><?php echo $user->meeting_minutes; ?></td>
                        <td><?php echo date( 'F j, Y g:i a', strtotime( $user->last_login_time ) ); ?></td>
                    </tr>
                    <?php
                }
            } ?>
        <?php else : ?>
            <tr>
                <td colspan="5"><?php _e( "Enter a value to Check...", "video-conferencing-with-zoom-api" ); ?></td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
    
</div>