<?php
/**
 * Event Zoom Meeting
 */
if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php $meeting_type_title = ($meeting_type === 'webinar') ? __( 'Webinar', 'wp-event-manager-zoom' ) : __( 'Meeting', 'wp-event-manager-zoom' ); ?>

<div class="event-manager-zoom-meeting-details">
    <div class="clearfix">&nbsp;</div>

    <?php if($show_help == 'yes') : ?>        
        <?php
        get_event_manager_template( 
            'zoom-meeting-help.php', 
            array(
                'zoom_settings' => $zoom_settings,
                'show_help' => $show_help,
                'meeting' => $meeting,
            ), 
            'wp-event-manager-zoom', 
            WPEM_ZOOM_PLUGIN_DIR . '/templates/'
        );
        ?>
        <div class="clearfix">&nbsp;</div>
    <?php endif; ?>
    
    <?php if($link_only == 'no') : ?>
    
        <?php
        get_event_manager_template( 
            'zoom-meeting-countdown.php', 
            array( 
                'meeting' => $meeting,
            ), 
            'wp-event-manager-zoom', 
            WPEM_ZOOM_PLUGIN_DIR . '/templates/'
        );
        ?>

        <div class="clearfix">&nbsp;</div>

        <h3 class="wpem-heading-text"><?php printf(__('%s Details', 'wp-event-manager-zoom'), $meeting_type_title); ?></h3>

        <div class="event-manager-zoom-meeting-info">
            
            <div class="event-manager-zoom-meeting-hosted-by">
                <span><b><?php _e( 'Hosted By:', 'wp-event-manager-zoom' ); ?></b></span>
                <span>
                	<?php
                    if(( $zoom_settings['event_zoom_show_zoom_author'] ))
                    {
                        if(!empty($zoom_user->first_name))
                        {
                            echo $zoom_user->first_name . ' ' . $zoom_user->last_name;
                        }
                        else
                        {
                            $user_data = get_userdata( $zoom_settings['post_author'] );
                            echo $user_data->data->display_name;
                        }    
                    }
                	else
                    {
                        echo get_bloginfo('name');
                    }
                	?>
                	</span>
            </div>

            <div class="event-manager-zoom-meeting-start-date-time">
                <span><b><?php _e( 'Start', 'wp-event-manager-zoom' ); ?></b></span>
                <span class="zoom-meeting-start-time"><?php echo event_manager_zoom_date_converter( $meeting->start_time, $meeting->timezone, 'F j, Y @ g:i a' ); ?></span>
            </div>

            <div class="event-manager-zoom-meeting-timezone">
                <span><b><?php _e( 'Timezone', 'wp-event-manager-zoom' ); ?></b></span>
                <span><?php echo $meeting->timezone; ?></span>
            </div>

            <div class="event-manager-zoom-meeting-duration">
                <span><b><?php _e( 'Duration', 'wp-event-manager-zoom' ); ?></b></span>
                <span><?php echo $meeting->duration; ?> <?php _e( 'Minutes', 'wp-event-manager-zoom' ); ?></span>
            </div>

            <div class="event-manager-zoom-meeting-duration">
                <span><b><?php _e( 'Note', 'wp-event-manager-zoom' ); ?></b></span>
                <span><?php _e('Countdown time is shown based on your local timezone', 'wp-event-manager-zoom'); ?>:</span>
            </div>

        </div>

    <?php endif; ?>

    <div class="event-manager-zoom-meeting-link">
    <div class="clearfix">&nbsp;</div>
        <?php
            $now = new DateTime( 'now -1 hour', new DateTimeZone( $meeting->timezone ) );
            $start_time = !empty( $closest_occurence ) ? $closest_occurence : $meeting->start_time;
            $start_time = new DateTime( $start_time, new DateTimeZone( $meeting->timezone ) );
            $start_time->setTimezone( new DateTimeZone( $meeting->timezone ) );
        ?>

        <?php if($now <= $start_time || $zoom_settings['event_zoom_show_post_join_link']) : ?>
            <?php
            if ( !empty( $meeting->password ) ) 
            {
                $browser_join = get_browser_join_shortcode( $zoom_settings, $meeting->id, $meeting->password, true );
            }
            else 
            {
                $browser_join = get_browser_join_shortcode( $zoom_settings, $meeting->id, false, true );
            }

            $join_uri = apply_filters( 'event_manager_zoom_join_meeting_via_app_shortcode', $meeting->join_url, $meeting );
            $browser_url = apply_filters( 'event_manager_zoom_join_meeting_via_browser_disable', $browser_join );
            ?>

            <?php if ( current_user_can( 'manage_options' ) || $zoom_settings['post_author'] == $user_id || $show_meeting_button ) : ?>

                <div class="wpem-join-meeting-wrapper">
                    <a class="wpem-theme-button wpem-join-meeting-btn" type="button" href="#">
                        <?php echo sprintf( __( 'Join %s', 'wp-event-manager-zoom' ), $meeting_type_title ); ?>
                    </a>
                    <div class="wpem-join-meeting-menu">                        
                        <?php if(!empty( $join_uri )) : ?>
                            <div class="event-manager-zoom-meeting-app-link">
                                <a class="event-manager-zoom-meeting-app-link-button" target="_blank" href="<?php echo $join_uri; ?>" title="Join via App">
                                    <i class="wpem-icon-mobile"></i> <?php _e( 'via App', 'wp-event-manager-zoom' ); ?>
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if(!empty( $browser_url )) : ?>                    
                            <div class="event-manager-zoom-meeting-web-link">
                                <a class="event-manager-zoom-meeting-web-link-button" target="_blank" href="<?php echo $browser_url; ?>" title="Join via Browser">
                                    <i class="wpem-icon-sphere"></i> <?php _e( 'via Browser', 'wp-event-manager-zoom' ); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            <?php else : ?>
                
                <div class="wpem-alert wpem-alert-warning">
                    <?php _e('You will show joining link once your organizer confirm your order.', 'wp-event-manager-zoom'); ?>
                </div>

            <?php endif; ?>

            <?php
            $user_id = get_current_user_id();

            if($user_id == $zoom_settings['post_author'])
            {
                get_event_manager_template( 
                    'zoom-meeting-link.php', 
                    array( 
                        'meeting' => $meeting,
                        'meeting_type' => $meeting_type,
                        'zoom_settings' => $zoom_settings,
                    ), 
                    'wp-event-manager-zoom', 
                    WPEM_ZOOM_PLUGIN_DIR . '/templates/'
                );
            }    
            ?>
        <?php endif; ?>
        
    </div>

</div>