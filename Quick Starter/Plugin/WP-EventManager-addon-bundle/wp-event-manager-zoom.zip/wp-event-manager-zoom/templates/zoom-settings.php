<?php
/**
 * Event Zoom Form
 */
if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php

$event_zoom_connection_options = isset( $zoom_settings['event_zoom_connection_options'] ) ? $zoom_settings['event_zoom_connection_options'] : 'jwt';

$event_zoom_api_key = isset( $zoom_settings['event_zoom_api_key'] ) ? $zoom_settings['event_zoom_api_key'] : '';

$event_zoom_api_secret_key = isset( $zoom_settings['event_zoom_api_secret_key'] ) ? $zoom_settings['event_zoom_api_secret_key'] : '';

$event_zoom_vanity_url = isset( $zoom_settings['event_zoom_vanity_url'] ) ? $zoom_settings['event_zoom_vanity_url'] : '';

$event_zoom_client_id = isset( $zoom_settings['event_zoom_client_id'] ) ? $zoom_settings['event_zoom_client_id'] : '';

$event_zoom_client_secret = isset( $zoom_settings['event_zoom_client_secret'] ) ? $zoom_settings['event_zoom_client_secret'] : '';

$event_zoom_show_post_join_link = isset( $zoom_settings['event_zoom_show_post_join_link'] ) ? $zoom_settings['event_zoom_show_post_join_link'] : '';

$event_zoom_show_zoom_author = isset( $zoom_settings['event_zoom_show_zoom_author'] ) ? $zoom_settings['event_zoom_show_zoom_author'] : '';

$event_zoom_meeting_started_text = isset( $zoom_settings['event_zoom_meeting_started_text'] ) ? $zoom_settings['event_zoom_meeting_started_text'] : '';

$event_zoom_meeting_going_to_start_text = isset( $zoom_settings['event_zoom_meeting_going_to_start_text'] ) ? $zoom_settings['event_zoom_meeting_going_to_start_text'] : '';

$event_zoom_meeting_ended_text = isset( $zoom_settings['event_zoom_meeting_ended_text'] ) ? $zoom_settings['event_zoom_meeting_ended_text'] : '';

/* $event_zoom_enable_all_event = isset( $zoom_settings['event_zoom_enable_all_event'] ) ? $zoom_settings['event_zoom_enable_all_event'] : ''; */

$event_zoom_show_on_single_event = isset( $zoom_settings['event_zoom_show_on_single_event'] ) ? $zoom_settings['event_zoom_show_on_single_event'] : '1';

$event_zoom_show_on_single_event_sidebar = isset( $zoom_settings['event_zoom_show_on_single_event_sidebar'] ) ? $zoom_settings['event_zoom_show_on_single_event_sidebar'] : '1';

$zoom_oauth_redirect_uri = add_query_arg( array(
                                'action' => 'zoom_oauth',
                                'callback' => 'authorize',
                            ), admin_url( 'admin-ajax.php' ) );
?>

<div id="event_manager_zoom_settings" class="event-manager-zoom-settings">
    
    <div class="wpem-main wpem-event-zoom-wrapper">
        <div class="wpem-event-zoom-header">
            <h3 class="wpem-heading-text"><?php _e( 'Zoom Settings', 'wp-event-manager-zoom' ); ?></h3> 
        </div>
        <div class="wpem-event-zoom-body">

            <form class="wpem-event-zoom wpem-form-wrapper" method="POST">
                <div class="wpem-event-zoom-field">
                    <div class="wpem-row">

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input type="radio" name="event_zoom_connection_options" value="jwt" <?php checked($event_zoom_connection_options, 'jwt'); ?> /> <?php _e( 'JWT', 'wp-event-manager-zoom' ); ?>
                                <input type="radio" name="event_zoom_connection_options" value="oauth" <?php checked($event_zoom_connection_options, 'oauth'); ?> /> <?php _e( 'OAuth', 'wp-event-manager-zoom' ); ?>
                                <p><small class="description"><?php echo _e( 'Zoom Connection Options', 'wp-event-manager-zoom' ); ?></small></p>
                            </div>                            
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input type="text" name="event_zoom_api_key" id="event_zoom_api_key" placeholder="<?php _e( 'Enter API Key', 'wp-event-manager-zoom' ); ?>" value="<?php echo $event_zoom_api_key; ?>" />
                                <small class="description"><?php echo sprintf( __( 'Zoom API Key <a href="%s" target="_blank">Create Key</a>.', 'wp-event-manager-zoom' ), 'https://marketplace.zoom.us/develop/create' ); ?></small>
                            </div>                            
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input type="text" name="event_zoom_api_secret_key" id="event_zoom_api_secret_key" placeholder="<?php _e( 'Enter API Secret Key', 'wp-event-manager-zoom' ); ?>" value="<?php echo $event_zoom_api_secret_key; ?>" />
                                <small class="description"><?php echo sprintf( __( 'Zoom API Secret Key <a href="%s" target="_blank">Create Key</a>.', 'wp-event-manager-zoom' ), 'https://marketplace.zoom.us/develop/create' ); ?></small>
                            </div>                            
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input type="text" name="event_zoom_client_id" id="event_zoom_client_id" placeholder="<?php _e( 'Enter Client ID', 'wp-event-manager-zoom' ); ?>" value="<?php echo $event_zoom_client_id; ?>" />
                                <small class="description"><?php echo sprintf( __( 'Zoom <a href="%s" target="_blank">Client ID</a>. <br>', 'wp-event-manager-zoom' ), 'https://marketplace.zoom.us/develop/create' ) . $zoom_oauth_redirect_uri; ?></small>
                            </div>
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input type="text" name="event_zoom_client_secret" id="event_zoom_client_secret" placeholder="<?php _e( 'Enter Client Secret', 'wp-event-manager-zoom' ); ?>" value="<?php echo $event_zoom_client_secret; ?>" />
                                <small class="description"><?php echo sprintf( __( 'Zoom <a href="%s" target="_blank">Client Secret</a>. <br>', 'wp-event-manager-zoom' ), 'https://marketplace.zoom.us/develop/create' ) . $zoom_oauth_redirect_uri; ?></small>
                            </div>                            
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input type="text" name="event_zoom_vanity_url" id="event_zoom_vanity_url" placeholder="<?php _e( 'https://example.zoom.us', 'wp-event-manager-zoom' ); ?>" value="<?php echo $event_zoom_vanity_url; ?>" />
                                <small class="description"><?php echo sprintf( __( 'If you are using Zoom Vanity URL then please insert it here else leave it empty. <a href="%s" target="_blank">Read more about Vanity URLs</a>.', 'wp-event-manager-zoom' ), 'https://support.zoom.us/hc/en-us/articles/215062646-Guidelines-for-Vanity-URL-Requests' ); ?></small>
                            </div>
                        </div>

                        <?php if( $event_zoom_connection_options =='oauth' && !empty($event_zoom_client_id) && !empty($event_zoom_client_secret) ) : ?>
                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <?php
                                if( get_user_meta($user_id, '_event_zoom_oauth_authorize', true) )
                                {
                                    $oauth_url = add_query_arg( array(
                                                    'action' => 'zoom_oauth',
                                                    'callback' => 'disconnect',
                                                ), admin_url( 'admin-ajax.php' ) );

                                    $oatuh_button_text = __('Disconnect', 'wp-event-manager-zoom');
                                }
                                else
                                {
                                    $zoom_oauth_url = 'https://zoom.us/oauth/authorize/';
                                    
                                    $oauth_url = add_query_arg( array(
                                        'response_type' => 'code',
                                        'client_id' => $event_zoom_client_id,
                                        'redirect_uri' => admin_url( 'admin-ajax.php' ) . '?action%3Dzoom_oauth%26callback%3Dauthorize',            
                                    ), $zoom_oauth_url );

                                    $oatuh_button_text = __('Connect', 'wp-event-manager-zoom');
                                }
                                ?>
                                <a class="wpem-theme-button wpem-zoom-oauth-connect-button" href="<?php echo $oauth_url; ?>"><?php echo $oatuh_button_text; ?></a>
                            </div>                            
                        </div>
                        <?php endif; ?>


                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input <?php echo !empty($event_zoom_show_post_join_link) ? 'checked' : ''; ?> type="checkbox" name="event_zoom_show_post_join_link" id="event_zoom_show_post_join_link" value="1" /> <?php _e( 'Show Past Join Link ?', 'wp-event-manager-zoom' ); ?><br>
                                <small class="description"><?php __('This will show join meeting links on frontend even after meeting time is already past.', 'wp-event-manager-zoom' ) ; ?></small>
                            </div>
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input <?php echo !empty($event_zoom_show_zoom_author) ? 'checked' : ''; ?> type="checkbox" name="event_zoom_show_zoom_author" id="event_zoom_show_zoom_author" value="1" /> <?php _e( 'Show Zoom Author ?', 'wp-event-manager-zoom' ); ?><br>
                                <small class="description"><?php echo sprintf( __( 'Checking this show Zoom original Author in single meetings page which are created from  <a href="%s" target="_blank">Zoom Meetings</a>.', 'wp-event-manager-zoom' ), admin_url( '/edit.php?post_type=event_zoom' ) ); ?></small>
                            </div>
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input type="text" name="event_zoom_meeting_started_text" id="event_zoom_meeting_started_text" placeholder="<?php _e( 'Start Meeting Text', 'wp-event-manager-zoom' ); ?>" value="<?php echo $event_zoom_meeting_started_text; ?>" />
                                <small class="description"></small>
                            </div>
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input type="text" name="event_zoom_meeting_going_to_start_text" id="event_zoom_meeting_going_to_start_text" placeholder="<?php _e( 'Join Meeting Text', 'wp-event-manager-zoom' ); ?>" value="<?php echo $event_zoom_meeting_going_to_start_text; ?>" />
                                <small class="description"></small>
                            </div>
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input type="text" name="event_zoom_meeting_ended_text" id="event_zoom_meeting_ended_text" placeholder="<?php _e( 'End Meeting Text', 'wp-event-manager-zoom' ); ?>" value="<?php echo $event_zoom_meeting_ended_text; ?>" />
                                <small class="description"></small>
                            </div>
                        </div>
                        <?php /* ?>
                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input <?php echo !empty($event_zoom_enable_all_event) ? 'checked' : ''; ?> type="checkbox" name="event_zoom_enable_all_event" id="event_zoom_enable_all_event" value="1" /> <?php _e( 'Enable for all event.', 'wp-event-manager-zoom' ); ?><br>
                                <small class="description"><?php _e( 'This will show in all event.', 'wp-event-manager-zoom' ); ?></small>
                            </div>
                        </div>
                        <?php */ ?>
                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input <?php echo !empty($event_zoom_show_on_single_event) ? 'checked' : ''; ?> type="checkbox" name="event_zoom_show_on_single_event" id="event_zoom_show_on_single_event" value="1" /> <?php _e( 'Show on single event', 'wp-event-manager-zoom' ); ?><br>
                                <small class="description"><?php _e( 'Show Zoom metting on single event page', 'wp-event-manager-zoom' ); ?></small>
                            </div>
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <input <?php echo !empty($event_zoom_show_on_single_event_sidebar) ? 'checked' : ''; ?> type="checkbox" name="event_zoom_show_on_single_event_sidebar" id="event_zoom_show_on_single_event_sidebar" value="1" /> <?php _e( 'Show on single event sidebar', 'wp-event-manager-zoom' ); ?><br>
                                <small class="description"><?php _e( 'Show Zoom metting on single event sidebar', 'wp-event-manager-zoom' ); ?></small>
                            </div>
                        </div>

                        <div class="wpem-col-md-4">
                            <div class="wpem-form-group">
                                <input type="hidden" name="action" value="show_zoom_settings" />
                                <?php if ( !empty( $_GET['page_id'] ) ) : ?>
                                    <input type="hidden" name="page_id" value="<?php echo absint( $_GET['page_id'] ); ?>" />
                                <?php endif; ?>

                                <button type="submit" class="wpem-theme-button" name="wp_event_manager_zoom_setting" value="<?php esc_attr_e( 'Save Setting', 'wp-event-manager-zoom' ); ?>"><?php _e('Save Setting','wp-event-manager-zoom');?></button>

                                <?php wp_nonce_field( 'event_manager_zoom_setting' ); ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>

</div>