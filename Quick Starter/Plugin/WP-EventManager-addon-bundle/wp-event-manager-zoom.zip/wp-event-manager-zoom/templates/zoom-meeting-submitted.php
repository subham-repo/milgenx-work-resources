<?php
/**
 * Event Submission Form
 */
if ( ! defined( 'ABSPATH' ) ) exit;

global $wp_post_types;

switch ( $event_zoom->post_status ) :

	case 'publish' :
		printf('<p class="post-submitted-success-green-message wpem-alert wpem-alert-success">'.__( '%s listed successfully. To view your %s <a href="%s">click here</a>.', 'wp-event-manager-zoom' ).'</p>', $wp_post_types['event_zoom']->labels->singular_name,  $wp_post_types['event_zoom']->labels->singular_name, $zoom_meeting_dashboard );
	break;
	
	case 'pending' :
		printf( '<p class="post-submitted-success-green-message wpem-alert wpem-alert-success">'.__( '%s submitted successfully. Your %s will be visible once approved.', 'wp-event-manager-zoom' ).'</p>', $wp_post_types['event_zoom']->labels->singular_name, $wp_post_types['event_zoom']->labels->singular_name, $zoom_meeting_dashboard );
	break;

	default :
		do_action( 'event_manager_event_zoom_submitted_content_' . str_replace( '-', '_', sanitize_title( $event_zoom->post_status ) ), $event_zoom );
	break;

endswitch;

do_action( 'event_manager_event_zoom_submitted_content_after', sanitize_title( $event_zoom->post_status ), $event_zoom );
