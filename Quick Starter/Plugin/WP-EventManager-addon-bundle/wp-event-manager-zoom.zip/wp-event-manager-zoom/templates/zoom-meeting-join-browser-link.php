<?php
/**
 * The Template for joining meeting via browser
 *
 * This template can be overridden by copying it to yourtheme/video-conferencing-zoom/join-web-browser.php.
 *
 * @package    Video Conferencing with Zoom API/Templates
 * @since      3.0.0
 * @modified   3.3.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( event_manager_zoom_check_login($event_zoom_id) ) {

	if ( !empty( $zoom_meeting->state ) && $zoom_meeting->state === "ended" ) {
		echo "<h3>" . __( 'This meeting has been ended by host.', 'wp-event-manager-zoom' ) . "</h3>";
		die;
	}
	?>

    <!DOCTYPE html>
    <html lang="en">

        <head>
            <meta charset="UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title><?php echo !empty( $zoom_meeting->topic ) ? $zoom_meeting->topic : 'Join Meeting'; ?></title>
            <link rel='stylesheet' type="text/css" href="<?php echo WPEM_ZOOM_PLUGIN_URL . '/assets/css/browser-meeting.min.css?ver=' . WPEM_ZOOM_VERSION; ?>" media='all'>
        </head>

        <body>
            <div class="form-box-container event-manager-zoom-browser-meeting-wrapper">
                <div class="event-manager-zoom-browser-meeting-info">
                    <?php if ( ! is_ssl() ) : ?>
                        <p style="line-height: 1.5;">
                            <strong style="color:red;"><?php _e( '!!!ALERT!!!: ', 'wp-event-manager-zoom' ); ?></strong><?php _e('Browser did not detect a valid SSL certificate. Audio and Video for Zoom meeting will not work on a non HTTPS site, please install a valid SSL certificate to allow audio and video in your Meetings via browser.', 'wp-event-manager-zoom' ); ?>
                        </p>
                    <?php endif; ?>

                    <div class="event-manager-zoom-browser-meeting-info-browser"></div>
                    
                </div>

                <form class="event-manager-zoom-browser-meeting-meeting-form" id="event_manager_zoom_browser_meeting_join_form" action="">

                    <input type="text" name="display_name" id="display_name" value="" placeholder="Your Name Here" class="name-input-form" required />

                    <input type="email" name="display_email" id="display_email" value="" placeholder="Your Email Here" class="name-input-form" required />

                    <button type="submit" class="wpem-form-button" id="event_manager_zoom_browser_meeting_join_form_button"><?php _e( 'Join', 'wp-event-manager-zoom' ); ?></button>
                </form>
            </div>

            <?php wp_footer(); ?>

      </body>

    </html>

	<?php
} 
else {
	echo "<h3>" . __( 'You do not have enough priviledge to access this page. Please login to continue or contact administrator.', 'wp-event-manager-zoom' ) . "</h3>";
	die;
}
