<?php
global $post;

if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php do_action('event_manager_event_zoom_add_user_before'); ?>

<?php
    if ( !isset( $zoom_settings['event_zoom_api_key'] ) && empty($zoom_settings['event_zoom_api_key']) && !isset( $zoom_settings['event_zoom_api_secret_key'] ) && empty($zoom_settings['event_zoom_api_secret_key']) ) {

        echo '<div class="wpem-alert wpem-alert-danger">' . __( 'Please add API Key & Secret Key in Zoom Setting', 'wp-event-manager-zoom' ) . '</div>';
    }

    if(!empty($message))
    {
        echo $message;
    }
?>

<div class="wpem-alert wpem-alert-warning"><?php echo sprintf( __( 'What does this do ? Check out <a href="%s" target="_blank">Zoom website</a>. Please note this may require a PRO account.', 'wp-event-manager-zoom' ), 'https://support.zoom.us/hc/en-us/articles/201363183-Managing-users' ); ?></div>

<div id="event_manager_event_zoom_add_user" class="event-manager-zoom-add-user">

	<div class="wpem-main wpem-event-zoom-wrapper">
		
		<div class="wpem-event-zoom-header">
            <h3 class="wpem-heading-text"><?php _e( 'Add New User', 'wp-event-manager-zoom' ); ?></h3> 
        </div>

        <div class="wpem-event-zoom-body">
        	<form class="wpem-event-zoom-add-user wpem-form-wrapper" method="POST">
        		<div class="wpem-event-zoom-field">
        			<div class="wpem-row">

        				<div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                                <select name="user_action" id="user_action">
		                            <?php foreach ( get_event_manager_zoom_add_user_actions() as $name => $label ) : ?>
		                                <option value="<?php echo esc_attr( $name ); ?>" ><?php echo esc_html( $label ); ?></option>
		                            <?php endforeach; ?>
		                        </select>
                                <small class="description">
                                	<p class="description"><?php _e( 'Type of User (Required)', 'wp-event-manager-zoom' ); ?></p>
		                            <p class="description">1. <strong>"<?php _e( 'Create', 'wp-event-manager-zoom' ); ?>"</strong>
		                                - <?php _e( 'User will get an email sent from Zoom. There is a confirmation link in this email. User will then need to click this link to activate their account to the Zoom service. The user can set or change their password in Zoom.', 'wp-event-manager-zoom' ); ?>
		                            </p>

		                            <p class="description">2. <strong>"<?php _e( 'Auto Create', 'wp-event-manager-zoom' ); ?>"</strong>
		                                - <?php _e( 'This action is provided for enterprise customer who has a managed domain. This feature is disabled by default because of the security risk involved in creating a user who does not belong to your domain without notifying the user.', 'wp-event-manager-zoom' ); ?>
		                            </p>

		                            <p class="description">3. <strong>"<?php _e( 'Cust Create', 'wp-event-manager-zoom' ); ?>"</strong>
		                                - <?php _e( 'This action is provided for API partner only. User created in this way has no password and is not able to log into the Zoom web site or client.', 'wp-event-manager-zoom' ); ?>
		                            </p>

		                            <p class="description">4. <strong>"<?php _e( 'SSO Create', 'wp-event-manager-zoom' ); ?>"</strong>
		                                - <?php _e( 'This action is provided for enabled “Pre-provisioning SSO User” option. User created in this way has no password. If it is not a basic user, will generate a Personal Vanity URL using user name (no domain) of the provisioning email. If user name or pmi is invalid or occupied, will use random number/random personal vanity URL.', 'wp-event-manager-zoom' ); ?>
		                            </p>
                                </small>
                            </div>                            
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                            	<input type="email" name="user_email" class="regular-text" required placeholder="admin@example.com">
                        		<p class="description"><?php _e( 'Email address is used for zoom (Required).', 'wp-event-manager-zoom' ); ?></p>
                            </div>                            
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                            	<input type="text" name="user_first_name" class="regular-text" required>
                        		<p class="description"><?php _e( 'First Name of the User (Required).', 'wp-event-manager-zoom' ); ?></p>
                            </div>                            
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                            	<input type="text" name="user_last_name" class="regular-text" required>
                        		<p class="description"><?php _e( 'Last Name of the User (Required).', 'wp-event-manager-zoom' ); ?></p>
                            </div>                            
                        </div>

                        <div class="wpem-col-md-12">
                            <div class="wpem-form-group">
                            	<select name="user_type" class="regular-text">
		                            <?php foreach ( get_event_manager_zoom_add_user_types() as $name => $label ) : ?>
		                                <option value="<?php echo esc_attr( $name ); ?>" ><?php echo esc_html( $label ); ?></option>
		                            <?php endforeach; ?>
		                        </select>
		                        <p class="description"><?php echo sprintf( __( 'Type of User (Required), Check out <a href="%s" target="_blank">more info</a>.', 'wp-event-manager-zoom' ), 'https://support.zoom.us/hc/en-us/articles/201363173-Account-Types' ); ?></p>
                            </div>                            
                        </div>

                        <div class="wpem-col-md-4">
                            <div class="wpem-form-group">
                            	<input type="hidden" name="action" value="add_zoom_user" />
                                <?php if ( !empty( $_GET['page_id'] ) ) : ?>
                                    <input type="hidden" name="page_id" value="<?php echo absint( $_GET['page_id'] ); ?>" />
                                <?php endif; ?>

                                <input type="submit" class="wpem-theme-button" name="wp_event_manager_zoom_add_user" value="<?php esc_attr_e( 'Add User', 'wp-event-manager-zoom' ); ?>" />

                                <?php wp_nonce_field( 'event_manager_zoom_add_user' ); ?>
                            </div>                            
                        </div>

        			</div>
        		</div>
        	</form>
        </div>

	</div>

</div>

<?php do_action('event_manager_event_zoom_add_user_after'); ?>
