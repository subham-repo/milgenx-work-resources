<?php
global $post;

if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php do_action('event_manager_event_zoom_user_lists_before'); ?>

<p>
	<a class="wpem-theme-button" href="<?php echo add_query_arg( array( 'action' => 'add_zoom_user' ), get_permalink( $post->ID ) ); ?>"><?php _e( 'Add Zoom User', 'wp-event-manager-zoom' ); ?></a>  
	<a href="javascript:void(0)" class="wpem-theme-button sync-zoom-users"><?php _e('Sync Zoom User', 'wp-event-manager-zoom' ); ?></a>
</p>

<div id="event_manager_event_zoom_user_lists">
	<div class="wpem-responsive-table-block">
		<table class="wpem-main wpem-responsive-table-wrapper">
			<thead>
				<tr>
					<th class="wpem-heading-text"><?php _e( 'User ID', 'wp-event-manager-zoom' ); ?></th>
					<th class="wpem-heading-text"><?php _e( 'Email', 'wp-event-manager-zoom' ); ?></th>
					<th class="wpem-heading-text"><?php _e( 'Name', 'wp-event-manager-zoom' ); ?></th>
					<th class="wpem-heading-text"><?php _e( 'Created On', 'wp-event-manager-zoom' ); ?></th>
					<th class="wpem-heading-text"><?php _e( 'Last Login', 'wp-event-manager-zoom' ); ?></th>
					<th class="wpem-heading-text"><?php _e( 'Last Client', 'wp-event-manager-zoom' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( !empty($zoom_users) && empty($zoom_users->code) ) : ?>
					
					<?php foreach ( $zoom_users as $key => $user ) : ?>
						<tr>
							<td><?php echo $user->id; ?></td>
	                        <td><?php echo $user->email; ?></td>
	                        <td><?php echo $user->first_name . ' ' . $user->last_name; ?></td>
	                        <td><?php echo !empty( $user->created_at ) ? date( 'F j, Y, g:i a', strtotime( $user->created_at ) ) : "N/A"; ?></td>
	                        <td><?php echo !empty( $user->last_login_time ) ? date( 'F j, Y, g:i a', strtotime( $user->last_login_time ) ) : "N/A"; ?></td>
	                        <td><?php echo !empty( $user->last_client_version ) ? $user->last_client_version : "N/A"; ?></td>
						</tr>
					<?php endforeach; ?>

				<?php else : ?>
					<tr>
						<td colspan="6"><?php _e( 'No user found.', 'wp-event-manager-zoom' ); ?></td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>

</div>
<?php do_action('event_manager_event_zoom_user_lists_after'); ?>
