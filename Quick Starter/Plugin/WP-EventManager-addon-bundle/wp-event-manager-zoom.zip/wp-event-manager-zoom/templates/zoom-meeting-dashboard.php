<?php
if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php do_action('event_manager_zoom_meeting_dashboard_before'); ?>
<p>
	<?php $submit_event_zoom 		= get_option('event_manager_submit_zoom_meeting_form_page_id');
	if(!empty($submit_event_zoom )){ ?>
		<a  href="<?php echo get_permalink($submit_event_zoom);?>"><?php  _e('Add Event Zoom','wp-event-manager-zoom');?></a>
	<?php
	}
	?>	
</p>
<div id="event_manager_event_dashboard">
	<div class="wpem-responsive-table-block">
		<table class="wpem-main wpem-responsive-table-wrapper">
			<thead>
				<tr>
					<?php foreach ( $zoom_meeting_dashboard_columns as $key => $column ) : ?>
					<th class="wpem-heading-text <?php echo esc_attr( $key ); ?>"><?php echo esc_html( $column ); ?></th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<tbody>
				<?php if ( ! $event_zooms ) : ?>
					<tr>
						<td colspan="6"><?php _e( 'You do not have any zoom meeting.', 'wp-event-manager-zoom' ); ?></td>
					</tr>
				<?php else : ?>
					<?php foreach ( $event_zooms as $event_zoom ) : ?>
						
						<?php 
						$meeting = get_post_meta( $event_zoom->ID, '_meeting_zoom_details', true ); 
						$meeting_type = get_post_meta( $event_zoom->ID, '_meeting_type', true );
						$meeting_occurrence_id = get_post_meta( $event_zoom->ID, '_meeting_occurrence_id', true );
						
						if(!empty($meeting) && !isset($meeting->state))
						{
							$meeting->state = '';
						}
						?>

						<tr>
							<?php foreach ( $zoom_meeting_dashboard_columns as $key => $column ) : ?>

								<td data-title="<?php echo esc_html( $column ); ?>" class="<?php echo esc_attr( $key ); ?>">

									<?php if ('event_zoom_name' === $key ) : ?>
										
										<?php echo esc_html( $event_zoom->post_title ); ?>
									
									<?php elseif ('zoom_meeting_startdate' === $key ) :?>
										<?php
										if ( !empty( $meeting ) && isset($meeting->type) && !empty( $meeting->start_time ) ) {
											echo event_manager_zoom_date_converter( $meeting->start_time, $meeting->timezone, 'F j, Y, g:i a' );
										} else {
											_e( ' - ', 'wp-event-manager-zoom' );
										}
										?>

									<?php elseif ('zoom_meeting_id' === $key ) :?>
										<?php
										if ( !empty( $meeting ) && isset($meeting->id) && !empty( $meeting->id ) ) {
											echo $meeting->id;
										} else {
											_e( '- ', 'wp-event-manager-zoom' );
										}
										?>

									<?php elseif ('zoom_meeting_type' === $key ) :?>
										<?php $meeting_type === 'webinar' ? _e( 'Webinar', 'wp-event-manager-zoom' ) : _e( 'Meeting', 'wp-event-manager-zoom' ); ?>
										<?php
										if ( !empty( $meeting ) && isset($meeting->type) && in_array($meeting->type, [3, 8, 9]) ) {
											echo '(' . __( 'Recurring', 'wp-event-manager-zoom' ) . ')';
										}
										?>

									<?php elseif ('zoom_meeting_end' === $key ) :?>
										<?php
										if ( !empty( $meeting ) && !empty( $meeting->id ) ) 
										{
											if ( isset($meeting->state) && $meeting->state=='started' ) : ?>
												<a href="javascript:void(0);" class="change-zoom-meeting-state wpem-meeting-end wpem-theme-button wpem-button-sm" data-type="post_type" data-state="end" data-postid="<?php echo $event_zoom->ID; ?>" data-id="<?php echo isset($meeting->id) ? $meeting->id : ''; ?>"><?php _e( 'End', 'wp-event-manager-zoom' ); ?></a>
											<?php else : ?>
												<a href="<?php echo isset($meeting->start_url) ? $meeting->start_url : 'javascript:void(0)'; ?>" target="_blank" class="change-zoom-meeting-state wpem-meeting-start wpem-theme-button wpem-button-sm" data-type="post_type" data-state="start" data-postid="<?php echo $event_zoom->ID; ?>" data-id="<?php echo isset($meeting->id) ? $meeting->id : ''; ?>"><?php _e( 'Start', 'wp-event-manager-zoom' ); ?></a>
											<?php endif;

										} 
										else {
											echo  __( 'Meeting not synced with Zoom', 'wp-event-manager-zoom' ).' <div class="wpem-tooltip wpem-tooltip-top wpem-icon-question"><span class="wpem-tooltiptext">'. __( 'Meeting created at local but not created at Zoom. After Syncing with Zoom, It will create at Zoom.', 'wp-event-manager-zoom' ) .'</span></div>';
										}
										?>

									<?php elseif ('event_zoom_action' === $key ) :?>
			                            <div class="wpem-dboard-event-action">
											<?php
											$actions = array ();
											switch ($event_zoom->post_status) {
												case 'publish' :
													$actions ['edit'] = array (
															'label' => __ ( 'Edit', 'wp-event-manager-zoom' ),
															'nonce' => false
													);
													break;
											}
											$actions ['delete'] = array (
													'label' => __ ( 'Delete', 'wp-event-manager-zoom' ),
													'nonce' => true
											);
											$actions = apply_filters ( 'event_manager_my_event_zoom_actions', $actions, $event_zoom );
											foreach ( $actions as $action => $value ) {
												$action_url = add_query_arg ( array (
														'action' => $action,
														'event_zoom_id' => $event_zoom->ID
												) );
												if ($value['nonce']) {
													$action_url = wp_nonce_url ( $action_url, 'event_manager_my_event_zoom_actions' );
												}
												echo '<div class="wpem-dboard-event-act-btn"><a href="' . esc_url ( $action_url ) . '" class="event-dashboard-action-' . esc_attr ( $action ) . '" title="' . esc_html ( $value ['label'] ) . '" >' . esc_html ( $value ['label'] ) . '</a></div>';
											}
											?>
										</div>
									<?php else : ?>
										<?php do_action( 'event_manager_zoom_meeting_dashboard_column_' . $key, $event_zoom ); ?>
									<?php endif; ?>

								</td>

							<?php endforeach; ?>
						</tr>

					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
	<?php get_event_manager_template( 'pagination.php', array( 'max_num_pages' => $max_num_pages ) ); ?>


   </div>
<?php do_action('event_manager_zoom_meeting_dashboard_after'); ?>
