=== WP Event Manager - Zoom ===

Contributors: WPEM Team,ashokdudhat,hiteshmakvana
Requires at least: 4.1
Tested up to: 5.5
Stable tag: 1.0.4
License: GNU General Public License v3.0

= Support Policy =

I will happily patch any confirmed bugs with this plugin, however, I will not offer support for:

1. Customisations of this plugin or any plugins it relies upon
2. Conflicts with "premium" themes from ThemeForest and similar marketplaces (due to bad practice and not being readily available to test)
3. CSS Styling (this is customisation work)

If you need help with customisation you will need to find and hire a developer capable of making the changes.

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Changelog ==

= 1.0.4 [25 Nov 2020] =

* Fixed - synchronize webinar meeting.
* Fixed - synchronize registration addon with zoom registrations.
* Fixed - Date format imrpovements.
* Fixed - some js and css tweaks.

= 1.0.3 [13 Oct 2020] =

* Added - Zoom webinar.
* Fixed - Meeting countdown.
* Fixed - Meeting validation improved.
* Fixed - Meeting start and end button.
* Fixed - Meeting duration value.
* Fixed - Meeting details at single event page improved.
* Remove - Author enable meeting link at single event page.


= 1.0.2 [11 August 2020] =

* Added - OAuthentication added with JWT
* Fixed - User sync issue.
* Fixed - Datepicker format issue.
* Fixed - some css,js and code improvements.

= 1.0.1 [27 July 2020] =
 
 * Fixed - Meeting field syncronise issue.
 * Fixed - Some css and js tweaks.


= 1.0.0 [July 17th, 2020] =

* Initial release.

