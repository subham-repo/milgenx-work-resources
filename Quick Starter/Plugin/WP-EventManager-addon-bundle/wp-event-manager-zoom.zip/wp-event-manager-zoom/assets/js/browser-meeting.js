jQuery(function ($) {
    var zoom_browser_integration = {

        init: function () {
            var browseinfo = ZoomMtg.checkSystemRequirements();
            var page_html = '<ul><li><strong>' + event_manager_zoom_meeting_browser.label_browser_info + ':</strong> ' + browseinfo.browserInfo + '</li>';
            page_html += '<li><strong>' + event_manager_zoom_meeting_browser.label_browser_name + ':</strong> ' + browseinfo.browserName + '</li>';
            page_html += '<li><strong>' + event_manager_zoom_meeting_browser.label_browser_version + ':</strong> ' + browseinfo.browserVersion + '</li></ul>';
            // page_html += '<li><strong>Available:</strong> ' + browseinfo.features + '</li></ul>';
            $('.event-manager-zoom-browser-meeting-info-browser').html(page_html);

            ZoomMtg.preLoadWasm();
            ZoomMtg.prepareJssdk();

            this.eventHandlers();
        },

        eventHandlers: function () {
            $('#event_manager_zoom_browser_meeting_join_form_button').on('click', this.loadMeeting.bind(this));
        },

        loadMeeting: function (e) {
            e.preventDefault();

            var meeting_id = event_manager_zoom_meeting_browser.meeting_id;
            var API_KEY = false;
            var SIGNATURE = false;
            var REDIRECTION = event_manager_zoom_meeting_browser.redirect_page;
            var PASSWD = event_manager_zoom_meeting_browser.meeting_pwd;

            $('body').append('<span id="wpem-zoom-cover"></span>');
            if (meeting_id) {
                $.post(event_manager_zoom_meeting_browser.ajax_url, {
                    action: 'get_auth',
                    security: event_manager_zoom_meeting_browser.event_manager_zoom_security,
                    meeting_id: meeting_id,
                }).done(function (response) {
                    if (response.success) {
                        
                        $('.event-manager-zoom-browser-meeting-wrapper').hide();
                        $("#wpem-zoom-cover").remove();

                        API_KEY = response.data.key;
                        SIGNATURE = response.data.sig;

                        if (API_KEY && SIGNATURE) {
                            var display_name = $('#display_name');
                            if (!display_name.val()) {
                                alert(event_manager_zoom_meeting_browser.name_required_error);
                                return false;
                            }

                            var meetConfig = {
                                apiKey: API_KEY,
                                meetingNumber: parseInt(meeting_id, 10),
                                leaveUrl: REDIRECTION,
                                userName: document.getElementById('display_name').value,
                                userEmail: document.getElementById('display_email').value,
                                passWord: PASSWD,
                                signature: SIGNATURE,
                            };

                            ZoomMtg.init({
                                leaveUrl: meetConfig.leaveUrl,
                                isSupportAV: true,
                                success: function () {
                                    ZoomMtg.join(
                                        {
                                            meetingNumber: meetConfig.meetingNumber,
                                            userName: meetConfig.userName,
                                            userEmail: meetConfig.userEmail,
                                            signature: meetConfig.signature,
                                            apiKey: meetConfig.apiKey,
                                            passWord: meetConfig.passWord,
                                            success: function (res) {
                                                $('.event-manager-zoom-browser-meeting-wrapper').hide();
                                                $("#wpem-zoom-cover").remove();
                                                $('#event_manager_zoom_browser_meeting').hide();
                                                console.log('join meeting success');
                                            },
                                            error: function (res) {
                                                $("#wpem-zoom-cover").remove();
                                                console.log(res);
                                            }
                                        }
                                    );
                                },
                                error: function (res) {
                                    console.log(res);
                                }
                            });
                        } else {
                            $("#wpem-zoom-cover").remove();
                            alert(event_manager_zoom_meeting_browser.not_authorized_error);
                        }
                    }
                });
            } else {
                $("#wpem-zoom-cover").remove();
                alert(event_manager_zoom_meeting_browser.incorrect_meeting_id_error);
            }
        }
    };

    zoom_browser_integration.init();
});