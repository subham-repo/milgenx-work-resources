var ZoomDashboard = function () {

    return {

        init: function() 
        {
            jQuery( '.change-zoom-meeting-state' ).on('click', ZoomDashboard.actions.meetingStateChange);            

            if(jQuery( 'input[data-picker="datepicker"]' ).length > 0)
            {
                jQuery('input[data-picker="datepicker"]').datepicker({
                    minDate     : 0,
                    dateFormat  : event_manager_zoom_dashboard.i18n_datepicker_format,
                });
            }

            if(jQuery( 'input[data-picker="timepicker"]' ).length > 0)
            {
                jQuery('input[data-picker="timepicker"]').timepicker({ 
                    'timeFormat': event_manager_zoom_dashboard.i18n_timepicker_format,
                    'step': event_manager_zoom_dashboard.i18n_timepicker_step,
                });
            }

            /* For Daily Reports Section */
            if(jQuery( 'input[data-picker="monthpicker"]' ).length > 0)
            {
                jQuery('input[data-picker="monthpicker"]').datepicker({
                    changeMonth: true,
                    changeYear: false,
                    showButtonPanel: true,
                    beforeShow: function(el, dp) { 
                        jQuery('#ui-datepicker-div').addClass('hide-calendar');
                    },
                    dateFormat: 'MM yy'
                }).focus(function () {
                    var thisCalendar = jQuery(this);
                    jQuery('.ui-datepicker-calendar').detach();
                    jQuery('.ui-datepicker-close').click(function () {
                        var month = jQuery("#ui-datepicker-div .ui-datepicker-month :selected").val();
                        var year = jQuery("#ui-datepicker-div .ui-datepicker-year").html();
                        thisCalendar.datepicker('setDate', new Date(year, month, 1));
                    });
                });
            }

            if(jQuery( 'input#zoom_account_from' ).length > 0)
            {
                jQuery('input#zoom_account_from').datepicker({
                    dateFormat  : event_manager_zoom_dashboard.i18n_datepicker_format,
                });
            }
            if(jQuery( 'input#zoom_account_to' ).length > 0)
            {
                jQuery('input#zoom_account_to').datepicker({
                    dateFormat  : event_manager_zoom_dashboard.i18n_datepicker_format,
                });
            }

            /* For Daily Reports Section */
            if(jQuery( 'input#reports_date' ).length > 0)
            {
                jQuery('input#reports_date').datepicker({
                    changeMonth: true,
                    changeYear: false,
                    showButtonPanel: true,
                    dateFormat: 'MM yy'
                }).focus(function () {
                    var thisCalendar = jQuery(this);
                    jQuery('.ui-datepicker-calendar').detach();
                    jQuery('.ui-datepicker-close').click(function () {
                        var month = jQuery("#ui-datepicker-div .ui-datepicker-month :selected").val();
                        var year = jQuery("#ui-datepicker-div .ui-datepicker-year").html();
                        thisCalendar.datepicker('setDate', new Date(year, month, 1));
                    });
                });
            }

            /* For Account Reports Section */
            if(jQuery( 'input.zoom-account-datepicker' ).length > 0)
            {
                jQuery('input.zoom-account-datepicker').datepicker({dateFormat: "yy-mm-dd"});
            }

            /* Meeting countdown timer */
            /*if(jQuery( '#event_manager_zoom_timer' ).length > 0)
            {   
                ZoomDashboard.actions.countDownTimerMoment();
            }
            */
            setTimeout(function(){ 
                if(jQuery( '#event_manager_zoom_timer' ).length > 0)
                {   
                    ZoomDashboard.actions.countDownTimerMoment();
                }
            }, 1000);
            

            if(jQuery( 'section.event-registration-zoom' ).length > 0)
            {
                jQuery('section.event-registration-zoom').hide().prepend('<a href="#" class="hide_section" title="'+ event_manager_registration.i18n_hide +'">' + event_manager_registration.i18n_hide + '</a>');
                jQuery( '.event-registration-toggle-zoom' ).on('click', ZoomDashboard.actions.showMeetingRegistrationDashboard);    
            }

            if(jQuery( '#meeting_option_registration' ).length > 0)
            {
                jQuery( '#meeting_option_registration' ).on('change', ZoomDashboard.actions.showApprovalType);

                jQuery( "#meeting_option_registration" ).trigger( "change" );
            }

            if(jQuery( '.fieldset-enable_wc_purchase' ).length > 0)
            {
                jQuery( '#enable_wc_purchase' ).on('change', ZoomDashboard.actions.enablePurchase);

                jQuery( "#enable_wc_purchase" ).trigger( "change" );
            }

            jQuery( 'body' ).on('click', '.sync-zoom-meetings', ZoomDashboard.actions.syncZoomMeetings);
            jQuery( 'body' ).on('click', '.sync-zoom-users', ZoomDashboard.actions.syncZoomUsers);
            jQuery( 'body' ).on('click', '.sync-zoom-webinars', ZoomDashboard.actions.syncZoomWebinars);

            //initially hide zoom meeting.
            jQuery("input[name=event_online]").on('change', ZoomDashboard.actions.onlineEvent);
            if (jQuery('input[name=event_online]:checked').length > 0)
            {
                jQuery('input[name=event_online]:checked').trigger('change');
            }

            jQuery( 'input[name="event_zoom_connection_options"]' ).on('change', ZoomDashboard.actions.zoomConnectionOptions);
            jQuery( 'input[name="event_zoom_connection_options"][checked="checked"]' ).trigger( "change" );

            if(jQuery('.event_zoom_action .event-dashboard-action-delete').length >0)
            {
                jQuery('.event_zoom_action .event-dashboard-action-delete').on('click', ZoomDashboard.actions.deleteMeeting);
            }
            
            jQuery( '#meeting_type' ).on('change', ZoomDashboard.actions.showMeetingFields);
            jQuery( '#meeting_type' ).trigger( 'change' );

            if(jQuery('.wpem-join-meeting-wrapper').length >0)
            {
                jQuery('.wpem-join-meeting-wrapper .wpem-join-meeting-menu').hide();

                jQuery('.wpem-join-meeting-wrapper').on('click', '.wpem-join-meeting-btn', function() 
                {
                    jQuery(this).toggleClass('wpem-active-button');
                    jQuery(this).closest('div.wpem-join-meeting-wrapper').find('div.wpem-join-meeting-menu').slideToggle();
                    return false;
                });
            }
        },

        actions:
        {
            /**
             * Meeting/Webinar fields
             * @param event
             */
            showMeetingFields: function (event) 
            {
                if(jQuery(event.target).val() == 'webinar')
                {
                    jQuery('.fieldset-meeting_option_panelists_video').removeClass('d-none');
                    jQuery('.fieldset-meeting_option_practice_session').removeClass('d-none');
                    jQuery('.fieldset-meeting_option_hd_video').removeClass('d-none');
                    jQuery('.fieldset-meeting_option_allow_multiple_devices').removeClass('d-none');

                    jQuery('.fieldset-meeting_option_join_before_host').addClass('d-none');
                    jQuery('.fieldset-meeting_option_participants_video').addClass('d-none');
                    jQuery('.fieldset-meeting_option_mute_participants').addClass('d-none');
                }
                else
                {
                    jQuery('.fieldset-meeting_option_panelists_video').addClass('d-none');
                    jQuery('.fieldset-meeting_option_practice_session').addClass('d-none');
                    jQuery('.fieldset-meeting_option_hd_video').addClass('d-none');
                    jQuery('.fieldset-meeting_option_allow_multiple_devices').addClass('d-none');

                    jQuery('.fieldset-meeting_option_join_before_host').removeClass('d-none');
                    jQuery('.fieldset-meeting_option_participants_video').removeClass('d-none');
                    jQuery('.fieldset-meeting_option_mute_participants').removeClass('d-none');
                }
            },

            /**
             * Change Meeting State
             * @param event
             */
            meetingStateChange: function (event) 
            {
                var state = jQuery(event.currentTarget).data('state');
                var post_id = jQuery(event.currentTarget).data('postid');
                var postData = {
                    id: jQuery(event.currentTarget).data('id'),
                    state: state,
                    type: jQuery(event.currentTarget).data('type'),
                    post_id: post_id ? post_id : false,
                    action: 'state_change',
                    security: event_manager_zoom_dashboard.event_manager_zoom_security
                };

                if (state === "start") {
                    ZoomDashboard.actions.changeState(postData);
                } else if (state === "resume") {
                    ZoomDashboard.actions.changeState(postData);
                    event.preventDefault();
                } else if (state === "end") {
                    if (confirm(event_manager_zoom_dashboard.confirm_end)) 
                    {
                        ZoomDashboard.actions.changeState(postData);
                    } 
                    else 
                    {
                        return;
                    }

                    event.preventDefault();
                }
            },

            /**
             * Change the state triggere now
             * @param postData
             */
            changeState: function (postData) {
                jQuery.post(event_manager_zoom_dashboard.ajax_url, postData).done(function (response) {
                    location.reload();
                });
            },

            countDownTimerMoment: function () {
                var clock = jQuery( '#event_manager_zoom_timer' );
               
                var valueDate = clock.data('date');
                var mtgTimezone = clock.data('tz');
                var mtgState = clock.data('state');

                /* var dateFormat = moment(valueDate).format('MMM D, YYYY HH:mm:ss'); */

                var user_timezone = moment.tz.guess();
                if (user_timezone === 'Asia/Katmandu') {
                    user_timezone = 'Asia/Kathmandu';
                }

                /* Converting Timezones to locals */
                var source_timezone = moment.tz(valueDate, mtgTimezone).format();
                var converted_timezone = moment.tz(source_timezone, user_timezone).format('MMM D, YYYY HH:mm:ss');
                var convertedTimezonewithoutFormat = moment.tz(source_timezone, user_timezone).format();

                /* Check Time Difference for Validations */
                var currentTime = moment().unix();
                var eventTime = moment(convertedTimezonewithoutFormat).unix();
                var diffTime = eventTime - currentTime;

                var formatedTime = moment.parseZone(convertedTimezonewithoutFormat).local().format('LLLL');
                if(formatedTime != '' && formatedTime != 'LLLL')
                {
                    jQuery('.zoom-meeting-start-time').html(formatedTime);
                }

                var second = 1000,
                    minute = second * 60,
                    hour = minute * 60,
                    day = hour * 24;

                if (mtgState === "ended") {
                    jQuery(clock).html("<div class='event-manager-zoom-meeting-ended wpem-alert wpem-alert-danger'><h3 class='wpem-heading-text'>" + meeting_button.meeting_ended + "</h3></div>");
                } else {
                    /* if time to countdown */
                    if (diffTime > 0) {
                        var countDown = new Date(converted_timezone).getTime();
                        var x = setInterval(function () {
                            var now = new Date().getTime();
                            var distance = countDown - now;

                            document.getElementById('event_manager_zoom_timer_days').innerText = Math.floor(distance / (day));
                            document.getElementById('event_manager_zoom_timer_hours').innerText = Math.floor((distance % (day)) / (hour));
                            document.getElementById('event_manager_zoom_timer_minutes').innerText = Math.floor((distance % (hour)) / (minute));
                            document.getElementById('event_manager_zoom_timer_seconds').innerText = Math.floor((distance % (minute)) / second);

                            if (distance < 0) {
                                clearInterval(x);
                                jQuery(clock).html("<div class='event-manager-zoom-meeting-starting wpem-alert wpem-alert-warning'><h3 class='wpem-heading-text'>" + meeting_button.meeting_starting + "</h3></div>");
                            }
                        }, second);
                    } else {
                        jQuery(clock).html("<div class='event-manager-zoom-meeting-started wpem-alert wpem-alert-success'><h3 class='wpem-heading-text'>" + meeting_button.meeting_started + "</h3></div>");
                    }
                }
            },

            /**
             * Change the state triggere now
             * @param postData
             */
            showMeetingRegistrationDashboard: function (event) {
                jQuery(event.target).closest('div.event-registration').find('section:not(.event-registration-zoom)').slideUp();
                jQuery(event.target).closest('div.event-registration').find('section.event-registration-zoom').slideToggle();
                return false;
            },

            showApprovalType: function (event) 
            {
                if(jQuery(event.target).prop("checked") == true){
                    jQuery('.fieldset-meeting_option_approval_type').removeClass('d-none');
                }
                else if(jQuery(event.target).prop("checked") == false){
                    jQuery('.fieldset-meeting_option_approval_type').addClass('d-none');
                }
            },

            enablePurchase: function (event) 
            {
                if(jQuery(event.target).prop("checked") == true){
                    jQuery('.fieldset-meeting_wc_product_price').removeClass('d-none');
                    jQuery('.fieldset-meeting_wc_product_show_ticket_buy_button').removeClass('d-none');
                }
                else if(jQuery(event.target).prop("checked") == false){
                    jQuery('.fieldset-meeting_wc_product_price').addClass('d-none');
                    jQuery('.fieldset-meeting_wc_product_show_ticket_buy_button').addClass('d-none');
                }
            },

            /**
             * Sync Zoom Meetings
             * @param event
             */
            syncZoomMeetings: function (event) 
            {
                if ( confirm( event_manager_zoom_dashboard.sync_meeting_confirmation_text ) ) {
                    jQuery.ajax({
                        url: event_manager_zoom_dashboard.ajax_url,
                        method: 'post',
                        type: 'json',
                        data: {
                            action: 'sync_zoom_meetings',
                            security: event_manager_zoom_dashboard.event_manager_zoom_security,
                        },
                        beforeSend: function() {
                            jQuery('.wpem-alert').remove();
                            jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-warning">' + event_manager_zoom_dashboard.sync_meeting_before_send_text + '...</div>');
                        },
                        success: function(response) {

                            /* console.log(response); */

                            jQuery('.wpem-alert').remove();

                            if ( response.code == '200' ) {
                                jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-success">' + response.message + '</div>');
                            } else if ( response.code == '400' ) {
                                jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-warning">' + response.message + '</div>');
                            } else if ( response.code == '404' ) {
                                jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-warning">' + response.message + '</div>');
                            } else {
                                jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-danger">' + event_manager_zoom_dashboard.sync_meeting_error_text + '</div>');
                            }
                        },
                        error: function (request, status, error) {
                            jQuery('.wpem-alert').remove();

                            jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-danger">' + event_manager_zoom_dashboard.sync_meeting_error_text + ' : ' + request.responseText + '</div>');
                        }
                    })
                }
            },

            /**
             * Sync Zoom User
             * @param event
             */
            syncZoomUsers: function (event) 
            {
                if ( confirm( event_manager_zoom_dashboard.sync_user_confirmation_text ) ) {
                    jQuery.ajax({
                        url: event_manager_zoom_dashboard.ajax_url,
                        method: 'post',
                        type: 'json',
                        data: {
                            action: 'sync_zoom_users',
                            security: event_manager_zoom_dashboard.event_manager_zoom_security,
                        },
                        beforeSend: function() {
                            jQuery('.wpem-alert').remove();
                            jQuery('#event_manager_event_zoom_user_lists').before('<div class="wpem-alert wpem-alert-warning">' + event_manager_zoom_dashboard.sync_user_before_send_text + '...</div>');
                        },
                        success: function(response) {

                            console.log(response);

                            jQuery('.wpem-alert').remove();

                            if ( response.code == '200' ) {
                                jQuery('#event_manager_event_zoom_user_lists').before('<div class="wpem-alert wpem-alert-success">' + response.message + '</div>');
                            } else if ( response.code == '404' ) {
                                jQuery('#event_manager_event_zoom_user_lists').before('<div class="wpem-alert wpem-alert-warning">' + response.message + '</div>');
                            } else {
                                jQuery('#event_manager_event_zoom_user_lists').before('<div class="wpem-alert wpem-alert-danger">' + event_manager_zoom_dashboard.sync_user_error_text + '</div>');
                            }
                        },
                        error: function (request, status, error) {
                            jQuery('.wpem-alert').remove();

                            jQuery('#event_manager_event_zoom_user_lists').before('<div class="wpem-alert wpem-alert-danger">' + event_manager_zoom_dashboard.sync_user_error_text + ' : ' + request.responseText + '</div>');
                        }
                    })
                }

                event.preventDefault();
            },

            /**
             * Sync Zoom Webinar
             * @param event
             */
            syncZoomWebinars: function (event) 
            {
                if ( confirm( event_manager_zoom_dashboard.sync_webinar_confirmation_text ) ) {
                    jQuery.ajax({
                        url: event_manager_zoom_dashboard.ajax_url,
                        method: 'post',
                        type: 'json',
                        data: {
                            action: 'sync_zoom_webinars',
                            security: event_manager_zoom_dashboard.event_manager_zoom_security,
                        },
                        beforeSend: function() {
                            jQuery('.wpem-alert').remove();
                            jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-warning">' + event_manager_zoom_dashboard.sync_webinar_before_send_text + '...</div>');
                        },
                        success: function(response) {

                            /* console.log(response); */

                            jQuery('.wpem-alert').remove();

                            if ( response.code == '200' ) {
                                jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-success">' + response.message + '</div>');
                            } else if ( response.code == '400' ) {
                                jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-warning">' + response.message + '</div>');
                            } else if ( response.code == '404' ) {
                                jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-warning">' + response.message + '</div>');
                            } else {
                                jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-danger">' + event_manager_zoom_dashboard.sync_webinar_error_text + '</div>');
                            }
                        },
                        error: function (request, status, error) {
                            jQuery('.wpem-alert').remove();

                            jQuery('#event_manager_event_dashboard').before('<div class="wpem-alert wpem-alert-danger">' + event_manager_zoom_dashboard.sync_webinar_error_text + ' : ' + request.responseText + '</div>');
                        }
                    })
                }
            },

            /**
             * Online Event
             * @param event
             */
            onlineEvent: function(event) 
            {
                if(jQuery(this).val() == "yes") 
                {
                    jQuery('.fieldset-event_zoom_id').show();
                }
                else
                {
                    jQuery('.fieldset-event_zoom_id').hide();
                }

                if(jQuery('.fieldset-paid_tickets').length > 0)
                {
                    if(jQuery(this).val() == "yes") 
                    {
                        var paid_tickets_html = jQuery('.fieldset-paid_tickets .event_ticket_add_link').attr('data-row');
                        var paid_tickets_html = paid_tickets_html.replace('fieldset-event_zoom_id" style="display:none"', 'fieldset-event_zoom_id"');
                        jQuery('.fieldset-paid_tickets .event_ticket_add_link').attr('data-row', paid_tickets_html);
                    }
                    else
                    {
                        var paid_tickets_html = jQuery('.fieldset-paid_tickets .event_ticket_add_link').attr('data-row');
                        var paid_tickets_html = paid_tickets_html.replace('fieldset-event_zoom_id"', 'fieldset-event_zoom_id" style="display:none"');
                        jQuery('.fieldset-paid_tickets .event_ticket_add_link').attr('data-row', paid_tickets_html);
                    }
                }

                if(jQuery('.fieldset-free_tickets').length > 0)
                {
                    if(jQuery(this).val() == "yes") 
                    {
                        var free_tickets_html = jQuery('.fieldset-free_tickets .event_ticket_add_link').attr('data-row');
                        var free_tickets_html = free_tickets_html.replace('fieldset-event_zoom_id" style="display:none"', 'fieldset-event_zoom_id"');
                        jQuery('.fieldset-free_tickets .event_ticket_add_link').attr('data-row', free_tickets_html);
                    }
                    else
                    {
                        var free_tickets_html = jQuery('.fieldset-free_tickets .event_ticket_add_link').attr('data-row');
                        var free_tickets_html = free_tickets_html.replace('fieldset-event_zoom_id"', 'fieldset-event_zoom_id" style="display:none"');
                        jQuery('.fieldset-free_tickets .event_ticket_add_link').attr('data-row', free_tickets_html);
                    }
                }

                if(jQuery('.fieldset-donation_tickets').length > 0)
                {
                    if(jQuery(this).val() == "yes") 
                    {
                        var donation_tickets_html = jQuery('.fieldset-donation_tickets .event_ticket_add_link').attr('data-row');
                        var donation_tickets_html = donation_tickets_html.replace('fieldset-event_zoom_id" style="display:none"', 'fieldset-event_zoom_id"');
                        jQuery('.fieldset-donation_tickets .event_ticket_add_link').attr('data-row', donation_tickets_html);
                    }
                    else
                    {
                        var donation_tickets_html = jQuery('.fieldset-donation_tickets .event_ticket_add_link').attr('data-row');
                        var donation_tickets_html = donation_tickets_html.replace('fieldset-event_zoom_id"', 'fieldset-event_zoom_id" style="display:none"');
                        jQuery('.fieldset-donation_tickets .event_ticket_add_link').attr('data-row', donation_tickets_html);
                    }
                }
            },

            /**
             * Zoom Connection Options
             * @param event
             */
            zoomConnectionOptions: function (event) 
            {
                var connection_option = jQuery(event.target).val();

                if(connection_option == 'oauth')
                {
                    jQuery('input[name="event_zoom_api_key"]').closest('.wpem-col-md-12').hide();
                    jQuery('input[name="event_zoom_api_secret_key"]').closest('.wpem-col-md-12').hide();

                    jQuery('input[name="event_zoom_client_id"]').closest('.wpem-col-md-12').show();
                    jQuery('input[name="event_zoom_client_secret"]').closest('.wpem-col-md-12').show();
                    jQuery('a.wpem-zoom-oauth-connect-button').closest('.wpem-col-md-12').show();
                }
                else
                {
                    jQuery('input[name="event_zoom_client_id"]').closest('.wpem-col-md-12').hide();
                    jQuery('input[name="event_zoom_client_secret"]').closest('.wpem-col-md-12').hide();
                    jQuery('a.wpem-zoom-oauth-connect-button').closest('.wpem-col-md-12').hide();
                    
                    jQuery('input[name="event_zoom_api_key"]').closest('.wpem-col-md-12').show();
                    jQuery('input[name="event_zoom_api_secret_key"]').closest('.wpem-col-md-12').show();
                }
            },

            /**
             * Delete Meeting
             * @param postData
             */
            deleteMeeting: function (event) {
                return confirm(event_manager_zoom_dashboard.i18n_confirm_delete);
                event.preventDefault(); 
            },

        
        } /* end of action */

    }; /* end of return */
}; /* end of class */

ZoomDashboard = ZoomDashboard();

jQuery(document).ready(function($) 
{
   ZoomDashboard.init();
});
