var ZoomAdmin = function () {

    return {

	    init: function() 
        {
        	jQuery( '.change-zoom-meeting-state' ).on('click', ZoomAdmin.actions.meetingStateChange);            

        	if(jQuery( 'input[data-picker="datepicker"]' ).length > 0)
		    {
                //console.log(event_manager_zoom_admin_zoom.i18n_datepicker_format);
                jQuery('input[data-picker="datepicker"]').datepicker({
                    minDate     : 0,
                    dateFormat  : event_manager_zoom_admin_zoom.i18n_datepicker_format,
                });
		    }

            if(jQuery( 'input[data-picker="timepicker"]' ).length > 0)
            {
                jQuery('input[data-picker="timepicker"]').timepicker({ 
                    'timeFormat': event_manager_zoom_admin_zoom.i18n_timepicker_format,
                    'step': event_manager_zoom_admin_zoom.i18n_timepicker_step,
                });
            }

		    /* For Daily Reports Section */
            if(jQuery( 'input#reports_date' ).length > 0)
		    {
                jQuery('input#reports_date').datepicker({
                    changeMonth: true,
                    changeYear: false,
                    showButtonPanel: true,
                    beforeShow: function(el, dp) { 
                        jQuery('#ui-datepicker-div').addClass('hide-calendar');
                    },
                    dateFormat: 'MM yy'
                }).focus(function () {
                    var thisCalendar = jQuery(this);
                    jQuery('.ui-datepicker-calendar').detach();
                    jQuery('.ui-datepicker-close').click(function () {
                        var month = jQuery("#ui-datepicker-div .ui-datepicker-month :selected").val();
                        var year = jQuery("#ui-datepicker-div .ui-datepicker-year").html();
                        thisCalendar.datepicker('setDate', new Date(year, month, 1));
                    });
                });
            }

            /* For Account Reports Section */
            if(jQuery( 'input.zoom-account-datepicker' ).length > 0)
            {
                jQuery('input.zoom-account-datepicker').datepicker({dateFormat: "yy-mm-dd"});
            }

            /* For Account Reports Section */
            if(jQuery( 'select#_meeting_alternative_host_ids' ).length > 0)
            {
                jQuery( 'select#_meeting_alternative_host_ids' ).chosen();
            }

            jQuery( '#_meeting_option_registration' ).on('change', ZoomAdmin.actions.showApprovalType);
            jQuery( "#_meeting_option_registration" ).trigger( "change" );

            jQuery( '#enable_wc_purchase' ).on('change', ZoomAdmin.actions.enablePurchase);
            jQuery( "#enable_wc_purchase" ).trigger( "change" );

            var jQueryevent_listing = jQuery( '.edit-php.post-type-event_zoom' );
            jQueryevent_listing_action   = jQueryevent_listing.find( '.page-title-action:first' );
            jQueryevent_listing_action.after( '<a href="javascript:void(0)" class="page-title-action sync-zoom-meetings">' + event_manager_zoom_admin_zoom.sync_meeting_button_text + '</a>' );
            jQueryevent_listing_action.after( '<a href="javascript:void(0)" class="page-title-action sync-zoom-webinars">' + event_manager_zoom_admin_zoom.sync_webinar_button_text + '</a>' );

            jQuery( 'body' ).on('click', '.sync-zoom-meetings', ZoomAdmin.actions.syncZoomMeetings);
            jQuery( 'body' ).on('click', '.sync-zoom-users', ZoomAdmin.actions.syncZoomUsers);
            jQuery( 'body' ).on('click', '.sync-zoom-webinars', ZoomAdmin.actions.syncZoomWebinars);

            jQuery( 'input[name="event_zoom_connection_options"]' ).on('change', ZoomAdmin.actions.zoomConnectionOptions);
            jQuery( 'input[name="event_zoom_connection_options"][checked="checked"]' ).trigger( "change" );

            jQuery( '#_meeting_type' ).on('change', ZoomAdmin.actions.showMeetingFields);
            jQuery( '#_meeting_type' ).trigger( 'change' );
        },

	    actions:
	    {
            /**
             * Meeting/Webinar fields
             * @param event
             */
            showMeetingFields: function (event) 
            {
                if(jQuery(event.target).val() == 'webinar')
                {
                    jQuery('#_meeting_option_panelists_video').closest('.form-field').removeClass('d-none');
                    jQuery('#_meeting_option_practice_session').closest('.form-field').removeClass('d-none');
                    jQuery('#_meeting_option_hd_video').closest('.form-field').removeClass('d-none');
                    jQuery('#_meeting_option_allow_multiple_devices').closest('.form-field').removeClass('d-none');

                    jQuery('#_meeting_option_join_before_host').closest('.form-field').addClass('d-none');
                    jQuery('#_meeting_option_participants_video').closest('.form-field').addClass('d-none');
                    jQuery('#_meeting_option_mute_participants').closest('.form-field').addClass('d-none');
                }
                else
                {
                    jQuery('#_meeting_option_panelists_video').closest('.form-field').addClass('d-none');
                    jQuery('#_meeting_option_practice_session').closest('.form-field').addClass('d-none');
                    jQuery('#_meeting_option_hd_video').closest('.form-field').addClass('d-none');
                    jQuery('#_meeting_option_allow_multiple_devices').closest('.form-field').addClass('d-none');

                    jQuery('#_meeting_option_join_before_host').closest('.form-field').removeClass('d-none');
                    jQuery('#_meeting_option_participants_video').closest('.form-field').removeClass('d-none');
                    jQuery('#_meeting_option_mute_participants').closest('.form-field').removeClass('d-none');
                }
            },

            /**
             * Change Meeting State
             * @param event
             */
            meetingStateChange: function (event) 
            {
                var state = jQuery(event.currentTarget).data('state');
                var post_id = jQuery(event.currentTarget).data('postid');
                var postData = {
                    id: jQuery(event.currentTarget).data('id'),
                    state: state,
                    type: jQuery(event.currentTarget).data('type'),
                    post_id: post_id ? post_id : false,
                    action: 'state_change',
                    security: event_manager_zoom_admin_zoom.event_manager_zoom_security
                };

                if (state === "start") {
                    ZoomAdmin.actions.changeState(postData);
                } else if (state === "resume") {
                    ZoomAdmin.actions.changeState(postData);
                    event.preventDefault();
                } else if (state === "end") {
                    if (confirm(event_manager_zoom_admin_zoom.confirm_end)) 
                    {
                        ZoomAdmin.actions.changeState(postData);
                    } 
                    else 
                    {
                        return;
                    }

                    event.preventDefault();
                }
            },

            /**
             * Change the state triggere now
             * @param postData
             */
            changeState: function (postData) {
                jQuery.post(event_manager_zoom_admin_zoom.ajax_url, postData).done(function (response) {
                    location.reload();
                });
            },

            /**
             * Refistration approval type
             * @param event
             */
            showApprovalType: function (event) 
            {
                if(jQuery(event.target).prop("checked") == true){
                    jQuery('#_meeting_option_approval_type').closest('.form-field').removeClass('d-none');
                }
                else if(jQuery(event.target).prop("checked") == false){
                    jQuery('#_meeting_option_approval_type').closest('.form-field').addClass('d-none');
                }
            },

            /**
             * Enable for Purchase
             * @param event
             */
            enablePurchase: function (event) 
            {
                if(jQuery(event.target).prop("checked") == true){
                    jQuery('.meeting-wc-wrap').removeClass('d-none');
                }
                else if(jQuery(event.target).prop("checked") == false){
                    jQuery('.meeting-wc-wrap').addClass('d-none');
                }
            },

            /**
             * Sync Zoom Meetings
             * @param event
             */
            syncZoomMeetings: function (event) 
            {
                if ( confirm( event_manager_zoom_admin_zoom.sync_meeting_confirmation_text ) ) {
                    jQuery.ajax({
                        url: event_manager_zoom_admin_zoom.ajax_url,
                        method: 'post',
                        type: 'json',
                        data: {
                            action: 'sync_zoom_meetings',
                            security: event_manager_zoom_admin_zoom.event_manager_zoom_security,
                        },
                        beforeSend: function() {
                            jQuery('.wrap > .update-message').remove();
                            jQuery('.wrap > hr.wp-header-end.extra').remove();
                            jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-warning notice-alt updating-message"><p>' + event_manager_zoom_admin_zoom.sync_meeting_before_send_text + '...</p></div><hr class="wp-header-end extra">');
                        },
                        success: function(response) {

                            /* console.log(response); */

                            jQuery('.wrap > .update-message').remove();
                            jQuery('.wrap > hr.wp-header-end.extra').remove();
                            if ( response.code == '200' ) {
                                jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-alt updated-message notice-success"><p>' + response.message + '</p></div><hr class="wp-header-end extra">');
                            } else if ( response.code == '400' ) {
                                jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-alt notice-error"><p>' + response.message + '</p></div><hr class="wp-header-end extra">');
                            } else if ( response.code == '404' ) {
                                jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-alt notice-error"><p>' + response.message + '</p></div><hr class="wp-header-end extra">');
                            } else {
                                jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-alt notice-error"><p>' + event_manager_zoom_admin_zoom.sync_meeting_error_text + '</p></div><hr class="wp-header-end extra">');
                            }
                        },
                        error: function (request, status, error) {
                            jQuery('.wrap > .update-message').remove();
                            jQuery('.wrap > hr.wp-header-end.extra').remove();
                            jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-alt notice-error"><p>' + event_manager_zoom_admin_zoom.sync_meeting_error_text + ' : ' + request.responseText + '</p></div><hr class="wp-header-end extra">');
                        }
                    })
                }
            },

            /**
             * Sync Zoom User
             * @param event
             */
            syncZoomUsers: function (event) 
            {
                if ( confirm( event_manager_zoom_admin_zoom.sync_user_confirmation_text ) ) {
                    jQuery.ajax({
                        url: event_manager_zoom_admin_zoom.ajax_url,
                        method: 'post',
                        type: 'json',
                        data: {
                            action: 'sync_zoom_users',
                            security: event_manager_zoom_admin_zoom.event_manager_zoom_security,
                        },
                        beforeSend: function() {
                            jQuery('.wrap > .update-message').remove();
                            jQuery('.wrap > hr.wp-header-end.extra').remove();
                            jQuery('.wpem-zoom-user-lists').before('<div class="update-message notice inline notice-warning notice-alt updating-message"><p>' + event_manager_zoom_admin_zoom.sync_user_before_send_text + '...</p></div><hr class="wp-header-end extra">');
                        },
                        success: function(response) {

                            /* console.log(response); */

                            jQuery('.wrap > .update-message').remove();
                            jQuery('.wrap > hr.wp-header-end.extra').remove();
                            if ( response.code == '200' ) {
                                jQuery('.wpem-zoom-user-lists').before('<div class="update-message notice inline notice-alt updated-message notice-success"><p>' + response.message + '</p></div><hr class="wp-header-end extra">');
                            } else if ( response.code == '404' ) {
                                jQuery('.wpem-zoom-user-lists').before('<div class="update-message notice inline notice-alt notice-error"><p>' + response.message + '</p></div><hr class="wp-header-end extra">');
                            } else {
                                jQuery('.wpem-zoom-user-lists').before('<div class="update-message notice inline notice-alt notice-error"><p>' + event_manager_zoom_admin_zoom.sync_user_error_text + '</p></div><hr class="wp-header-end extra">');
                            }
                        },
                        error: function (request, status, error) {
                            jQuery('.wrap > .update-message').remove();
                            jQuery('.wrap > hr.wp-header-end.extra').remove();
                            jQuery('.wpem-zoom-user-lists').before('<div class="update-message notice inline notice-alt notice-error"><p>' + event_manager_zoom_admin_zoom.sync_user_error_text + ' : ' + request.responseText + '</p></div><hr class="wp-header-end extra">');
                        }
                    })
                }

                event.preventDefault();
            },

            /**
             * Sync Zoom Meetings
             * @param event
             */
            syncZoomWebinars: function (event) 
            {
                if ( confirm( event_manager_zoom_admin_zoom.sync_webinar_confirmation_text ) ) {
                    jQuery.ajax({
                        url: event_manager_zoom_admin_zoom.ajax_url,
                        method: 'post',
                        type: 'json',
                        data: {
                            action: 'sync_zoom_webinars',
                            security: event_manager_zoom_admin_zoom.event_manager_zoom_security,
                        },
                        beforeSend: function() {
                            jQuery('.wrap > .update-message').remove();
                            jQuery('.wrap > hr.wp-header-end.extra').remove();
                            jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-warning notice-alt updating-message"><p>' + event_manager_zoom_admin_zoom.sync_webinar_before_send_text + '...</p></div><hr class="wp-header-end extra">');
                        },
                        success: function(response) {

                            /* console.log(response); */

                            jQuery('.wrap > .update-message').remove();
                            jQuery('.wrap > hr.wp-header-end.extra').remove();
                            if ( response.code == '200' ) {
                                jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-alt updated-message notice-success"><p>' + response.message + '</p></div><hr class="wp-header-end extra">');
                            } else if ( response.code == '400' ) {
                                jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-alt notice-error"><p>' + response.message + '</p></div><hr class="wp-header-end extra">');
                            } else if ( response.code == '404' ) {
                                jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-alt notice-error"><p>' + response.message + '</p></div><hr class="wp-header-end extra">');
                            } else {
                                jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-alt notice-error"><p>' + event_manager_zoom_admin_zoom.sync_webinar_error_text + '</p></div><hr class="wp-header-end extra">');
                            }
                        },
                        error: function (request, status, error) {
                            jQuery('.wrap > .update-message').remove();
                            jQuery('.wrap > hr.wp-header-end.extra').remove();
                            jQuery('.wrap > hr.wp-header-end').after('<div class="update-message notice inline notice-alt notice-error"><p>' + event_manager_zoom_admin_zoom.sync_webinar_error_text + ' : ' + request.responseText + '</p></div><hr class="wp-header-end extra">');
                        }
                    })
                }
            },

            /**
             * Zoom Connection Options
             * @param event
             */
            zoomConnectionOptions: function (event) 
            {
                var connection_option = jQuery(event.target).val();

                if(connection_option == 'oauth')
                {
                    jQuery('input[name="event_zoom_api_key"]').closest('tr').hide();
                    jQuery('input[name="event_zoom_api_secret_key"]').closest('tr').hide();

                    jQuery('input[name="event_zoom_client_id"]').closest('tr').show();
                    jQuery('input[name="event_zoom_client_secret"]').closest('tr').show();
                    jQuery('a.wpem-zoom-oauth-connect-button').closest('tr').show();
                }
                else
                {
                    jQuery('input[name="event_zoom_client_id"]').closest('tr').hide();
                    jQuery('input[name="event_zoom_client_secret"]').closest('tr').hide();
                    jQuery('a.wpem-zoom-oauth-connect-button').closest('tr').hide();
                    
                    jQuery('input[name="event_zoom_api_key"]').closest('tr').show();
                    jQuery('input[name="event_zoom_api_secret_key"]').closest('tr').show();
                }
            },
		
		} //end of action

    }; //enf of return
}; //end of class

ZoomAdmin = ZoomAdmin();

jQuery(document).ready(function($) 
{
   ZoomAdmin.init();
});
