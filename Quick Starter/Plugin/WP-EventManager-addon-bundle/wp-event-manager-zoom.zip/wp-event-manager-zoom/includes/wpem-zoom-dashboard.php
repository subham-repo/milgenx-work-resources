<?php
class WPEM_Zoom_Dashboard {

	public function __construct() {

		$this->user_page = new WPEM_Zoom_User();

		add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
		add_action( 'wp_loaded', array( $this, 'edit_handler' ) );

		add_action( 'event_manager_zoom_meeting_dashboard_before', array( $this, 'add_zoom_setting_button' ),10 );
		add_action( 'event_manager_zoom_meeting_dashboard_before', array( $this, 'sync_zoom_meeting_button' ), 11 );
		add_action( 'event_manager_zoom_meeting_dashboard_before', array( $this, 'sync_zoom_webinar_button' ), 12 );
		add_action( 'event_manager_zoom_meeting_dashboard_before', array( $this, 'zoom_user_lists' ), 13 );
		add_action( 'event_manager_zoom_meeting_dashboard_before', array( $this, 'zoom_reports' ), 13 );

		add_action( 'event_manager_zoom_meeting_dashboard_content_add_zoom_user', array( $this, 'add_zoom_user' ) );
		add_action( 'event_manager_zoom_meeting_dashboard_content_show_zoom_user_lists', array( $this, 'show_zoom_user_lists' ) );
		add_action( 'event_manager_zoom_meeting_dashboard_content_show_zoom_settings', array( $this, 'show_zoom_settings' ) );
		add_action( 'event_manager_zoom_meeting_dashboard_content_show_zoom_reports', array( $this, 'show_zoom_reports' ) );
	}

	/**
	 * frontend_scripts function.
	 * enqueue script and style for frontend side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function frontend_scripts() 
	{
		wp_register_style( 'wp-event-manager-zoom-frontend', WPEM_ZOOM_PLUGIN_URL . '/assets/css/frontend.min.css' );

		wp_register_script( 'wp-event-manager-zoom-moment', WPEM_ZOOM_PLUGIN_URL . '/assets/js/moment/moment.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );
		
		wp_register_script( 'wp-event-manager-zoom-moment-timezone', WPEM_ZOOM_PLUGIN_URL . '/assets/js/moment-timezone/moment-timezone-with-data-10-year-range.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );

		wp_register_script( 'wp-event-manager-zoom-dashboard', WPEM_ZOOM_PLUGIN_URL . '/assets/js/event-zoom-dashboard.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );

		wp_localize_script( 'wp-event-manager-zoom-dashboard', 'event_manager_zoom_dashboard', array( 
								'ajax_url' 	 => admin_url( 'admin-ajax.php' ),

								'i18n_datepicker_format' => WP_Event_Manager_Date_Time::get_datepicker_format(),
								'i18n_timepicker_format' => WP_Event_Manager_Date_Time::get_timepicker_format(),		
								'i18n_timepicker_step'	=> WP_Event_Manager_Date_Time::get_timepicker_step(),

								'event_manager_zoom_security'  => wp_create_nonce( "_nonce_event_manager_zoom_security" ),

								'confirm_end' => __( "Are you sure you want to end this meeting ?", 'wp-event-manager-zoom'),

								'i18n_confirm_delete' => __( 'Are you sure you want to delete this meeting?', 'wp-event-manager-zoom' ),

								'sync_meeting_confirmation_text'=> __( "Are you sure you want to synchronize Zoom Meetings", 'wp-event-manager-zoom'),
								'sync_meeting_before_send_text' => __( "Zoom Meetings are synchronizing now", 'wp-event-manager-zoom'),
								'sync_meeting_success_text'  	=> __( 'Zoom Meetings are synchronized successfully! Please <a href="javascript:window.location.href=window.location.href">reload</a> this page in order to see changes.', 'wp-event-manager-zoom'),
								'sync_meeting_error_text'  		=> __( "Zoom Meetings Synchronization Failed. Please try once again!", 'wp-event-manager-zoom'),

								'sync_user_confirmation_text'=> __( "Are you sure you want to synchronize Zoom Users", 'wp-event-manager-zoom'),
								'sync_user_before_send_text' => __( "Zoom Users are synchronizing now", 'wp-event-manager-zoom'),
								'sync_user_success_text'  	=> __( 'Zoom Users are synchronized successfully! Please <a href="javascript:window.location.href=window.location.href">reload</a> this page in order to see changes.', 'wp-event-manager-zoom'),
								'sync_user_error_text'  		=> __( "Zoom Users Synchronization Failed. Please try once again!", 'wp-event-manager-zoom'),

								'sync_webinar_confirmation_text'=> __( "Are you sure you want to synchronize Zoom Webinars", 'wp-event-manager-zoom'),
								'sync_webinar_before_send_text' => __( "Zoom Webinars are synchronizing now", 'wp-event-manager-zoom'),
								'sync_webinar_success_text'  	=> __( 'Zoom Webinars are synchronized successfully! Please <a href="javascript:window.location.href=window.location.href">reload</a> this page in order to see changes.', 'wp-event-manager-zoom'),
								'sync_webinar_error_text'  		=> __( "Zoom Webinars Synchronization Failed. Please try once again!", 'wp-event-manager-zoom'),
							)
						);
	}

	/**
	 * add_zoom_setting_button function.
	 * add zoom setting button on zoom meeting dashboard front side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function add_zoom_setting_button() {
		global $post;

		$user_id = get_current_user_id();

		$user_meta = get_userdata($user_id);

		if ( current_user_can( 'manage_options' ) ) 
		{	
			//echo '<a class="wpem-theme-button" href="' . admin_url( 'edit.php?post_type=event_zoom&page=event-manager-zoom-settings' ) . '">'. __( 'Zoom Settings', 'wp-event-manager-zoom' ) .'</a>';
		}
		elseif ( in_array('editor', $user_meta->roles) ) 
		{
			//echo '<a class="wpem-theme-button" href="' . admin_url( 'edit.php?post_type=event_zoom&page=event-manager-zoom-settings' ) . '">'. __( 'Zoom Settings', 'wp-event-manager-zoom' ) .'</a>';
		}
		else
		{
			echo '<a class="wpem-theme-button" href="' . add_query_arg( array( 'action' => 'show_zoom_settings' ), get_permalink( $post->ID ) ) . '">'. __( 'Zoom Settings', 'wp-event-manager-zoom' ) .'</a>';
		}
	}

	/**
	 * sync_zoom_meeting_button function.
	 * add sync zoom metting button on zoom meeting dashboard front side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function sync_zoom_meeting_button() {
		global $post;

		$user_id = get_current_user_id();

		$user_meta = get_userdata($user_id);

		if ( !in_array('editor', $user_meta->roles) ) 
		{
			echo '<a class="wpem-theme-button sync-zoom-meetings" href="javascript:void(0)">'. __( 'Sync Zoom Meetings', 'wp-event-manager-zoom' ) .'</a>';	
		}
	}

	/**
	 * sync_zoom_webinar_button function.
	 * add sync zoom webinar button on zoom webinar dashboard front side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function sync_zoom_webinar_button() {
		global $post;

		$user_id = get_current_user_id();

		$user_meta = get_userdata($user_id);

		if ( !in_array('editor', $user_meta->roles) ) 
		{
			echo '<a class="wpem-theme-button sync-zoom-webinars" href="javascript:void(0)">'. __( 'Sync Zoom Webinars', 'wp-event-manager-zoom' ) .'</a>';	
		}
	}

	/**
	 * show_zoom_user function.
	 * show zoom user list button on zoom meeting dashboard front side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function zoom_user_lists() {
		global $post;

		$user_id = get_current_user_id();

		$user_meta = get_userdata($user_id);

		if ( current_user_can( 'manage_options' ) ) 
		{	
			//echo '<a class="wpem-theme-button" href="' . admin_url( 'edit.php?post_type=event_zoom&page=event-manager-zoom-list-users' ) . '">'. __( 'Zoom User Lists', 'wp-event-manager-zoom' ) .'</a>';
		}
		elseif ( in_array('editor', $user_meta->roles) ) 
		{
			//echo '<a class="wpem-theme-button" href="' . admin_url( 'edit.php?post_type=event_zoom&page=event-manager-zoom-list-users' ) . '">'. __( 'Zoom User Lists', 'wp-event-manager-zoom' ) .'</a>';
		}
		else
		{
			echo '<a class="wpem-theme-button" href="' . add_query_arg( array( 'action' => 'show_zoom_user_lists' ), get_permalink( $post->ID ) ) . '">'. __( 'Zoom User Lists', 'wp-event-manager-zoom' ) .'</a>';
		}
	}

	/**
	 * zoom_reports function.
	 * zoom reports button on zoom meeting dashboard front side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.3
	 */
	public function zoom_reports() {
		global $post;

		$user_id = get_current_user_id();

		$user_meta = get_userdata($user_id);

		if ( current_user_can( 'manage_options' ) ) 
		{	
			//echo '<a class="wpem-theme-button" href="' . admin_url( 'edit.php?post_type=event_zoom&page=event-manager-zoom-reports' ) . '">'. __( 'Zoom Reports', 'wp-event-manager-zoom' ) .'</a>';
		}
		elseif ( in_array('editor', $user_meta->roles) ) 
		{
			//echo '<a class="wpem-theme-button" href="' . admin_url( 'edit.php?post_type=event_zoom&page=event-manager-zoom-reports' ) . '">'. __( 'Zoom Reports', 'wp-event-manager-zoom' ) .'</a>';
		}
		else
		{
			echo '<a class="wpem-theme-button" href="' . add_query_arg( array( 'action' => 'show_zoom_reports', 'report' => 'daily' ), get_permalink( $post->ID ) ) . '">'. __( 'Zoom Reports', 'wp-event-manager-zoom' ) .'</a>';
		}
	}

	/**
	 * show_zoom_user function.
	 * get zoom user list and show user dashboard on front side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function show_zoom_user_lists() {

		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );
		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );

		$user_id = get_current_user_id();

		$zoom_settings = get_user_meta($user_id, '_zoom_settings', true);
		$zoom_users = [];
		
		$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();

		get_event_manager_template( 
			'zoom-user-list.php', 
			array( 
				'user_id' => $user_id,
				'zoom_settings' => $zoom_settings,
				'zoom_users' => $zoom_users,
			), 
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/'
		);
	}

	/**
	 * add_zoom_user function.
	 * add new user on zoom account in front side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function add_zoom_user() {

		$user_id = get_current_user_id();

		$zoom_settings = get_user_meta($user_id, '_zoom_settings', true);

		$message = '';

		if ( !empty( $_POST['wp_event_manager_zoom_add_user'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'event_manager_zoom_add_user' ) ) 
		{
			if( isset($zoom_settings['event_zoom_api_key']) && !empty($zoom_settings['event_zoom_api_key']) && isset($zoom_settings['event_zoom_api_secret_key']) && !empty($zoom_settings['event_zoom_api_secret_key'] ) )
			{
				//Load the Credentials
				WPEM_Zoom_API()->zoom_api_key    = $zoom_settings['event_zoom_api_key'];
				WPEM_Zoom_API()->zoom_api_secret = $zoom_settings['event_zoom_api_secret_key'];

				$params = array(
					'action'     => !empty( $_POST['user_action'] ) ? sanitize_text_field( $_POST['user_action'] ) : '',
					'email'      => !empty( $_POST['user_email'] ) ? sanitize_text_field( $_POST['user_email'] ) : '',
					'first_name' => !empty( $_POST['user_first_name'] ) ? sanitize_text_field( $_POST['user_first_name'] ) : '',
					'last_name'  => !empty( $_POST['user_last_name'] ) ? sanitize_text_field( $_POST['user_last_name'] ) : '',
					'type'       => !empty( $_POST['user_type'] ) ? sanitize_text_field( $_POST['user_type'] ) : '',
				);

				$created_user = WPEM_Zoom_API()->createAUser( $params );

				$result       = json_decode( $created_user );

				if ( !empty( $result->code ) ) 
				{
					$message = '<div class="wpem-alert wpem-alert-danger">' . $result->message . '</div>';
				} 
				else 
				{
					$message = '<div class="wpem-alert wpem-alert-success">' .  __( "The user has been created! Please check the email for confirmation. The added user will appear in the list after approval only.", "wp-event-manager-zoom" ) . '</div>';

					//After user has been created delete this transient in order to fetch latest Data.
					event_manager_zoom_api_delete_user_cache();
				}
			}
		}

		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );

		get_event_manager_template( 
			'zoom-add-user.php', 
			array( 
				'user_id' => $user_id,
				'zoom_settings' => $zoom_settings,
				'message' => $message,
			), 
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/'
		);
	}

	/**
	 * show_zoom_settings function.
	 * show zoom seeting in front side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function show_zoom_settings() {

		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );
		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );

		$user_id = get_current_user_id();

		$zoom_settings = get_user_meta($user_id, '_zoom_settings', true);

		$zoom_users = [];
		if(isset($zoom_settings['event_zoom_api_key']) && isset($zoom_settings['event_zoom_api_secret_key']))
		{
			//Load the Credentials
			WPEM_Zoom_API()->zoom_api_key    = $zoom_settings['event_zoom_api_key'];
			WPEM_Zoom_API()->zoom_api_secret = $zoom_settings['event_zoom_api_secret_key'];

			$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();
		}

		get_event_manager_template( 
			'zoom-settings.php', 
			array( 
				'user_id' => $user_id,
				'zoom_settings' => $zoom_settings,
				'zoom_users' => $zoom_users,
			), 
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/'
		);
	}

	/**
	 * show_zoom_reports function.
	 * show zoom reports in front side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.3
	 */
	public function show_zoom_reports() {

		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );

		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );

		$user_id = get_current_user_id();
		$zoom_settings = get_user_meta($user_id, '_zoom_settings', true);
		$zoom_report = isset($_REQUEST['report']) ? $_REQUEST['report'] : 'daily';

		if($zoom_report === 'daily')
		{
			$result = $this->get_daily_report_html();	
		}
		elseif($zoom_report === 'account')
		{
			$result = $this->get_account_report_html();	
		}
		else
		{
			$result = [];
		}

		get_event_manager_template( 
			'zoom-reports.php', 
			array( 
				'user_id' => $user_id,
				'zoom_settings' => $zoom_settings,
				'zoom_report' => $zoom_report,
				'result' => $result,
			), 
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/'
		);
	}

	/**
	 * get_daily_report_html function.
	 * get daily report month wise in admin side
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	public function get_daily_report_html() {
		$return_result = false;
		$months        = array(
			1  => 'January',
			2  => 'February',
			3  => 'March',
			4  => 'April',
			5  => 'May',
			6  => 'June',
			7  => 'July',
			8  => 'August',
			9  => 'September',
			10 => 'October',
			11 => 'November',
			12 => 'December'
		);

		if ( isset( $_POST['zoom_check_month_year'] ) ) {
			$zoom_monthyear = $_POST['zoom_month_year'];
			if ( $zoom_monthyear == null || $zoom_monthyear == "" ) {
				$return_result = __( "Date field cannot be Empty !!", "wp-event-manager-zoom" );
			} else {
				$exploded_data = explode( ' ', $zoom_monthyear );
				foreach ( $months as $key => $month ) {
					if ( $exploded_data[0] == $month ) {
						$month_int = $key;
					}
				}
				$year          = $exploded_data[1];
				$result        = WPEM_Zoom_API()->getDailyReport( $month_int, $year );
				$return_result = json_decode( $result );
			}
		}

		return $return_result;
	}

	/**
	 * get_account_report_html function.
	 * get user account report with sub account
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	public function get_account_report_html() {
		$return_result = false;
		if ( isset( $_POST['zoom_account_from'] ) && isset( $_POST['zoom_account_to'] ) ) 
		{
			$zoom_account_from = $_POST['zoom_account_from'];
			$zoom_account_to   = $_POST['zoom_account_to'];

			if ( $zoom_account_from == null || $zoom_account_to == null ) 
			{
				$return_result = __( "The fields cannot be Empty !!", "wp-event-manager-zoom" );
			} 
			else 
			{
				//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
				$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
	
				//covert datepicker format  into php date() function date format
				$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

				$zoom_account_from = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format, $zoom_account_from );
				$zoom_account_to = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format, $zoom_account_to );

				$result        = WPEM_Zoom_API()->getAccountReport( $zoom_account_from, $zoom_account_to );
				$return_result = json_decode( $result );
			}
		}

		return $return_result;
	}

	/**
	 * edit_handler function.
	 * save zoom seeting in front side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function edit_handler() 
	{
		$user_id = get_current_user_id();

		if ( !empty( $_POST['wp_event_manager_zoom_setting'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'event_manager_zoom_setting' ) ) 
		{
			$array_setting = [
				'event_zoom_connection_options' 		=> !empty( $_POST['event_zoom_connection_options'] ) ? sanitize_text_field( $_POST['event_zoom_connection_options'] ) : '',
				
				'event_zoom_api_key' 		=> !empty( $_POST['event_zoom_api_key'] ) ? sanitize_text_field( $_POST['event_zoom_api_key'] ) : '',
				'event_zoom_api_secret_key' => !empty( $_POST['event_zoom_api_secret_key'] ) ? sanitize_text_field( $_POST['event_zoom_api_secret_key'] ) : '',
				'event_zoom_vanity_url'		=> !empty( $_POST['event_zoom_vanity_url'] ) ? sanitize_text_field( $_POST['event_zoom_vanity_url'] ) : '',

				'event_zoom_client_id' 		=> !empty( $_POST['event_zoom_client_id'] ) ? sanitize_text_field( $_POST['event_zoom_client_id'] ) : '',
				'event_zoom_client_secret' => !empty( $_POST['event_zoom_client_secret'] ) ? sanitize_text_field( $_POST['event_zoom_client_secret'] ) : '',

				'event_zoom_show_post_join_link' 		=> !empty( $_POST['event_zoom_show_post_join_link'] ) ? sanitize_text_field( $_POST['event_zoom_show_post_join_link'] ) : '',
				'event_zoom_show_zoom_author'			=> !empty( $_POST['event_zoom_show_zoom_author'] ) ? sanitize_text_field( $_POST['event_zoom_show_zoom_author'] ) : '',
				'event_zoom_meeting_started_text'		=> !empty( $_POST['event_zoom_meeting_started_text'] ) ? sanitize_text_field( $_POST['event_zoom_meeting_started_text'] ) : '',
				'event_zoom_meeting_going_to_start_text'=> !empty( $_POST['event_zoom_meeting_going_to_start_text'] ) ? sanitize_text_field( $_POST['event_zoom_meeting_going_to_start_text'] ) : '',
				'event_zoom_meeting_ended_text' => !empty( $_POST['event_zoom_meeting_ended_text'] ) ? sanitize_text_field( $_POST['event_zoom_meeting_ended_text'] ) : '',

				/* 'event_zoom_enable_all_event' => !empty( $_POST['event_zoom_enable_all_event'] ) ? sanitize_text_field( $_POST['event_zoom_enable_all_event'] ) : '', */

				'event_zoom_show_on_single_event' => !empty( $_POST['event_zoom_show_on_single_event'] ) ? sanitize_text_field( $_POST['event_zoom_show_on_single_event'] ) : '',
				'event_zoom_show_on_single_event_sidebar' => !empty( $_POST['event_zoom_show_on_single_event_sidebar'] ) ? sanitize_text_field( $_POST['event_zoom_show_on_single_event_sidebar'] ) : '',
			];

			update_user_meta($user_id, '_zoom_settings', $array_setting);
		}
	}
	
}

new WPEM_Zoom_Dashboard();
