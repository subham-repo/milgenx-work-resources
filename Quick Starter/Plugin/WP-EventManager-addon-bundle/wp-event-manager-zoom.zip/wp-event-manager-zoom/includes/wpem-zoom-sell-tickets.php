<?php
/**
 * WPEM_Zoom_Sell_Tickets class.
 */
class WPEM_Zoom_Sell_Tickets {

	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function __construct() {
		// add event zoom field in ticket form front side
		add_filter( 'submit_event_paid_tickekts_fields', array( $this, 'event_zoom_meeting_list' ), 10, 2);
		add_filter( 'submit_event_free_tickekts_fields', array( $this, 'event_zoom_meeting_list' ), 10, 2); // add in code
		add_filter( 'submit_event_donation_tickekts_fields', array( $this, 'event_zoom_meeting_list' ), 10, 2); // add in code

		// add event zoom field in ticket form backend side
		add_filter( 'submit_event_paid_tickekts_backend_fields', array( $this, 'event_zoom_meeting_list_backend' ), 10, 2);
		add_filter( 'submit_event_free_tickekts_backend_fields', array( $this, 'event_zoom_meeting_list_backend' ), 10, 2); // add in code
		add_filter( 'submit_event_donation_tickekts_backend_fields', array( $this, 'event_zoom_meeting_list_backend' ), 10, 2); // add in code

		// save event zoom field in ticket form
		add_action( 'sell_tickets_save_paid_ticket_product_meta_end',  array( $this, 'add_event_zoom_meeting_id' ), 10, 2);
		add_action( 'sell_tickets_save_free_ticket_product_meta_end',  array( $this, 'add_event_zoom_meeting_id' ), 10, 2); // add in code
		add_action( 'sell_tickets_save_donation_ticket_product_meta_end',  array( $this, 'add_event_zoom_meeting_id' ), 10, 2);
	}

	/**
	 * event_zoom_meeting_list function.
	 * add zoom meeting field in sell ticket form in front side.
	 * @access public
	 * @param $fields
	 * @return 
	 * @since 1.0.0
	 */
	public function event_zoom_meeting_list($fields) 
	{
		$user_id = get_current_user_id();

		$args = [];
		
		if ( current_user_can( 'manage_options' ) ) 
		{
			
		}
		else
		{
			if(get_option('enable_frontend_zoom_connection', true))
			{
				if(!empty($user_id))
				{
					$args = ['author' => $user_id];
				}
			}
		}

	    $result = get_event_manager_zoom_meeting_list($args);

	    $event_meeting_list = [];

		if($result->found_posts > 0)
		{
			$event_meeting_list[''] =  __( 'Select Zoom Meeting / Webinar', 'wp-event-manager-zoom' );

			foreach ($result->posts as $post) 
			{
				$meeting_id = get_post_meta( $post->ID, '_meeting_zoom_meeting_id', true );

				if ( !empty( $meeting_id ) ) 
				{
					$event_meeting_list[$post->ID] = $post->post_title;
				}
			}
		}
		else
		{
			$event_meeting_list[''] =  __( 'No Any Zoom Meeting / Webinar', 'wp-event-manager-zoom' );
		}

		$fields['event_zoom_id'] =  array(
								'label'       => __( 'Zoom Meeting / Webinar', 'wp-event-manager-zoom' ),
								'type'        => 'select',
								'required'    => false,
								'description' => __('Select Zoom Meeting / Webinar','wp-event-manager-zoom'),
								'priority'    => 6,
								'options'     => $event_meeting_list
							);

		return $fields;
	}
	
	/**
	 * event_zoom_meeting_list_admin function.
	 * add zoom meeting field in sell ticket form
	 * @access public
	 * @param $fields
	 * @return array
	 * @since 1.0.0
	 */
	public function event_zoom_meeting_list_backend($fields)
	{
		$result = get_event_manager_zoom_meeting_list();

		$event_meeting_list = [];

		if($result->found_posts > 0)
		{
			$event_meeting_list[''] =  __( 'Select Zoom Meeting / Webinar', 'wp-event-manager-zoom' );

			foreach ($result->posts as $post) 
			{
				$meeting_id = get_post_meta( $post->ID, '_meeting_zoom_meeting_id', true );

				if ( !empty( $meeting_id ) ) 
				{
					$event_meeting_list[$post->ID] = $post->post_title;
				}
			}
		}

		$fields['event_zoom_id'] =  array(
								'label'       => __( 'Zoom Meeting / Webinar', 'wp-event-manager-zoom' ),
								'type'        => 'select',
								'required'    => false,
								'description' => __('Select Zoom Meeting / Webinar','wp-event-manager-zoom'),
								'priority'    => 20,
								'options'     => $event_meeting_list							
							);

		return $fields;
	}

	/**
	 * add_event_zoom_meeting_id function.
	 * save zoom meeting while save tickets
	 * @access public
	 * @param $ticket, $product_id
	 * @return 
	 * @since 1.0.0
	 */
	public function add_event_zoom_meeting_id($ticket, $product_id) 
	{
		$event_zoom_id         = isset($ticket['event_zoom_id']) ? $ticket['event_zoom_id'] : '';
		update_post_meta($product_id, '_event_zoom_id', $event_zoom_id);
	}
}

new WPEM_Zoom_Sell_Tickets();
