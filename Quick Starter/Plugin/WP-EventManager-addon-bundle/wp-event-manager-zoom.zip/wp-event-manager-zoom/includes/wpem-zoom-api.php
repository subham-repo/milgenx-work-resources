<?php
require WPEM_ZOOM_PLUGIN_DIR . '/includes/libs/vendor/autoload.php';

use \Firebase\JWT\JWT;

if ( ! class_exists( 'WPEM_Zoom_API' ) ) {

	class WPEM_Zoom_API {

		/**
		 * Zoom API KEY
		 *
		 * @var
		 */
		public $zoom_api_key;

		/**
		 * Zoom API Secret
		 *
		 * @var
		 */
		public $zoom_api_secret;

		/**
		 * Hold my instance
		 *
		 * @var
		 */
		protected static $_instance;

		/**
		 * API endpoint base
		 *
		 * @var string
		 */
		public $api_url = 'https://api.zoom.us/v2/';

		public $oauth_authorize_url = 'https://zoom.us/oauth/authorize';
		public $oauth_request_token_url = 'https://zoom.us/oauth/token';
		public $oauth_refresh_token_url = 'https://zoom.us/oauth/token';
		public $oauth_revoke_url = 'https://zoom.us/oauth/revoke';

		/**
		 * instance function.
		 *
		 * @access public
		 * @param 
		 * @return 
		 * @since 1.0.0
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 * Constructor - get the plugin hooked in and ready
		 */
		public function __construct( $zoom_api_key = '', $zoom_api_secret = '' ) {
			$this->zoom_api_key    = $zoom_api_key;
			$this->zoom_api_secret = $zoom_api_secret;
		}

		/**
		 * oauth_authorize function.
		 *
		 * @access protected
		 * @param
		 * @return 
		 * @since 1.0.2
		 */
		public function oauth_authorize() {

			$user_id = get_current_user_id();

			$result = '';

			if( $_REQUEST['code'] != '' )
			{
				$response = $this->request_access_token( $_REQUEST['code'] );

				$result = json_decode($response);

				if ( empty( $result->error ) )
				{
					if ( current_user_can( 'manage_options' ) ) 
					{
						update_option('event_zoom_oauth_authorize', '1');
						update_option('event_zoom_token', $result);
					}
					else
					{
						update_user_meta($user_id, '_event_zoom_oauth_authorize', '1');
						update_user_meta($user_id, '_event_zoom_token', $result);
					}

					event_manager_zoom_api_delete_user_cache();

					wp_clear_scheduled_hook( 'event_manager_zoom_refresh_access_token', array( $user_id ) );

					// Create cron
					wp_schedule_event( time(), 'hourly', 'event_manager_zoom_refresh_access_token', array( $user_id ) );
				}
			}

			return $result;
		}

		/**
		 * request_access_token function.
		 *
		 * @access protected
		 * @param $code
		 * @return array
		 * @since 1.0.2
		 */
		public function request_access_token( $code = '' ){

			$user_id = get_current_user_id();

			$zoom_settings = get_event_zoom_setting_by_user_id($user_id);

			$zoom_client_id = $zoom_settings['event_zoom_client_id'];
			$zoom_client_secret = $zoom_settings['event_zoom_client_secret'];

			$args = array(
				'headers' => array(
					'Authorization' => 'Basic ' . base64_encode($zoom_client_id . ':' . $zoom_client_secret),
					'Content-Type' => 'application/x-www-form-urlencoded',
				)
			);

			$args['body'] = [
				'grant_type' => 'authorization_code',
				'code' 		 => $_REQUEST['code'],
				'redirect_uri' => add_query_arg( array('action' => 'zoom_oauth','callback' => 'authorize',), admin_url( 'admin-ajax.php' ) ),
			];

			$response = wp_remote_post($this->oauth_request_token_url, $args);

			$response = wp_remote_retrieve_body( $response );

			if ( ! $response ) {
				return false;
			}

			return $response;
		}

				/**
		 * request_access_token function.
		 *
		 * @access protected
		 * @param $code
		 * @return array
		 * @since 1.0.2
		 */
		public function refresh_access_token($user_id)
		{
			$user_meta = get_userdata($user_id);

			$zoom_settings = get_event_zoom_setting_by_user_id($user_id);

			$zoom_connection_type = $zoom_settings['event_zoom_connection_options'];
			$zoom_client_id = $zoom_settings['event_zoom_client_id'];
			$zoom_client_secret = $zoom_settings['event_zoom_client_secret'];

			if($zoom_connection_type != 'oauth')
				return;

			if ( isset($user_meta->roles) && in_array('administrator', $user_meta->roles) ) 
			{
				$event_zoom_token = get_option('event_zoom_token');				
				$zoom_oauth_authorize = get_option('event_zoom_oauth_authorize');
			}
			else
			{
				$event_zoom_token = get_user_meta($user_id, '_event_zoom_token', true);				
				$zoom_oauth_authorize = get_user_meta($user_id, '_event_zoom_oauth_authorize', true);
			}

			if( isset($event_zoom_token->refresh_token) && !empty($event_zoom_token->refresh_token) )
			{
				$args = array(
					'headers' => array(
						'Authorization' => 'Basic ' . base64_encode($zoom_client_id . ':' . $zoom_client_secret),
						'Content-Type' => 'application/x-www-form-urlencoded',
					)
				);

				$args['body'] = [
					'grant_type' => 'refresh_token',
					'refresh_token' => $event_zoom_token->refresh_token,
				];

				$response = wp_remote_post($this->oauth_refresh_token_url, $args);

				$response = wp_remote_retrieve_body( $response );

				$result = json_decode($response);

				if ( empty( $result->error ) )
				{
					if ( current_user_can( 'manage_options' ) ) 
					{
						update_option('event_zoom_token', $result);
					}
					else
					{
						update_user_meta($user_id, '_event_zoom_token', $result);
					}	
				}
			}
			
		}

		/**
		 * oauth_disconnect function.
		 *
		 * @access protected
		 * @param 
		 * @return 
		 * @since 1.0.2
		 */
		public function oauth_disconnect() {

			$user_id = get_current_user_id();

			if ( current_user_can( 'manage_options' ) ) 
			{
				update_option('event_zoom_oauth_authorize', '');
				update_option('event_zoom_token', '');
			}
			else
			{
				update_user_meta($user_id, '_event_zoom_oauth_authorize', '');
				update_user_meta($user_id, '_event_zoom_token', '');
			}

			event_manager_zoom_api_delete_user_cache();

			wp_clear_scheduled_hook( 'event_manager_zoom_refresh_access_token', array( $user_id ) );
		}

		/**
		 * sendRequest function.
		 *
		 * @access protected
		 * @param $calledFunction, $data, $request
		 * @return 
		 * @since 1.0.0
		 */
		protected function sendRequest( $calledFunction, $data, $request = "GET" ) {
			$request_url = $this->api_url . $calledFunction;
			$args        = array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->generateJWTKey(),
					'Content-Type'  => 'application/json'
				)
			);

			if ( $request == "GET" ) 
			{
				$args['body'] = !empty( $data ) ? $data : array();

				$response     = wp_remote_get( $request_url, $args );
			} 
			else if ( $request == "DELETE" ) 
			{
				$args['body']   = !empty( $data ) ? json_encode( $data ) : array();
				$args['method'] = "DELETE";
				$response       = wp_remote_request( $request_url, $args );
			} 
			else if ( $request == "PATCH" ) 
			{
				$args['body']   = !empty( $data ) ? json_encode( $data ) : array();
				$args['method'] = "PATCH";
				$response       = wp_remote_request( $request_url, $args );
			} 
			else if( $request == "PUT" )
			{
				$args['body'] 	= !empty( $data ) ? json_encode( $data ) : array();
				$args['method'] = "PUT";
				$response 		= wp_remote_post($request_url, $args);
			} 
			else 
			{
				$args['body']   = !empty( $data ) ? json_encode( $data ) : array();
				$args['method'] = "POST";
				$response       = wp_remote_post( $request_url, $args );
			}

			$response = wp_remote_retrieve_body( $response );			
			/*dump($response);
			die;*/

			if ( ! $response ) {
				return false;
			}

			return $response;
		}

		/**
		 * generateJWTKey function.
		 *
		 * @access private
		 * @param 
		 * @return 
		 * @since 1.0.0
		 */
		private function generateJWTKey() {

			$user_id = get_current_user_id();

			$event_id = isset($_REQUEST['event_id']) ? $_REQUEST['event_id'] : '';

			$user_meta = get_userdata($user_id);

			$zoom_user_settings = get_event_zoom_setting_by_user_id($user_id);

			if(empty($zoom_user_settings))
				return;

			$zoom_connection_type = $zoom_user_settings['event_zoom_connection_options'];

			if($zoom_connection_type == 'oauth')
			{
				if ( current_user_can( 'manage_options' ) ) 
				{
					$event_zoom_oauth_authorize = get_option('event_zoom_oauth_authorize');
					$event_zoom_token = get_option('event_zoom_token');
				}
				elseif ( isset($user_meta->roles) && in_array('editor', $user_meta->roles) )
				{
					$event_zoom_oauth_authorize = get_option('event_zoom_oauth_authorize');
					$event_zoom_token = get_option('event_zoom_token');
				}
				else
				{
					$event_zoom_oauth_authorize = get_user_meta($user_id, '_event_zoom_oauth_authorize', true);
					$event_zoom_token = get_user_meta($user_id, '_event_zoom_token', true);
				}

				if( isset($event_id) && !empty($event_id) )
				{
					$event_zoom_id = get_post_meta($event_id, '_event_zoom_id', true);
					$meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );
					
					if( !empty($meeting) && isset($meeting->id) && !empty($meeting->id) )
					{
						$zoom_settings = get_event_zoom_setting_by_meeting_id($meeting->id);

						$meeting_auther = get_userdata($zoom_settings['post_author']);

						if ( isset($meeting_auther->roles) && in_array('administrator', $meeting_auther->roles) )
						{
							$event_zoom_oauth_authorize = get_option('event_zoom_oauth_authorize');
							$event_zoom_token = get_option('event_zoom_token');
						}
						elseif ( isset($meeting_auther->roles) && in_array('editor', $meeting_auther->roles) )
						{
							$event_zoom_oauth_authorize = get_option('event_zoom_oauth_authorize');
							$event_zoom_token = get_option('event_zoom_token');
						}
					}
				}

				if($event_zoom_oauth_authorize)
				{
					return $event_zoom_token->access_token;
				}
			}
			else
			{
				if ( current_user_can( 'manage_options' ) ) 
				{
					$key = get_option('event_zoom_api_key');
					$secret = get_option('event_zoom_api_secret_key');
				}
				elseif ( isset($user_meta->roles) && in_array('editor', $user_meta->roles) )
				{
					$key = get_option('event_zoom_api_key');
					$secret = get_option('event_zoom_api_secret_key');
				}
				else
				{
					$key = $zoom_user_settings['event_zoom_api_key'];
					$secret = $zoom_user_settings['event_zoom_api_secret_key'];
				}

				if( isset($event_id) && !empty($event_id) )
				{
					$event_zoom_id = get_post_meta($event_id, '_event_zoom_id', true);
					$meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );
					
					if( !empty($meeting) && isset($meeting->id) && !empty($meeting->id) )
					{
						$zoom_settings = get_event_zoom_setting_by_meeting_id($meeting->id);
						$key = $zoom_settings['event_zoom_api_key'];
						$secret = $zoom_settings['event_zoom_api_secret_key'];
					}
				}

				$token = array(
					"iss" => $key,
					"exp" => time() + 3600 //60 seconds as suggested
				);

				return JWT::encode( $token, $secret );
			}
		}

		/**
		 * createAUser function.
		 *
		 * @access public
		 * @param $postedData
		 * @return 
		 * @since 1.0.0
		 */
		public function createAUser( $postedData = array() ) {
			$createAUserArray              = array();
			$createAUserArray['action']    = $postedData['action'];
			$createAUserArray['user_info'] = array(
				'email'      => $postedData['email'],
				'type'       => $postedData['type'],
				'first_name' => $postedData['first_name'],
				'last_name'  => $postedData['last_name']
			);
			$createAUserArray              = apply_filters( 'event_manager_zoom_create_user', $createAUserArray );

			return $this->sendRequest( 'users', $createAUserArray, "POST" );
		}

		/**
		 * listUsers function.
		 *
		 * @access public
		 * @param $page
		 * @return 
		 * @since 1.0.0
		 */
		public function listUsers( $page = 1 ) {
			$listUsersArray                = array();
			$listUsersArray['page_size']   = 300;
			$listUsersArray['page_number'] = absint( $page );
			$listUsersArray                = apply_filters( 'event_manager_zoom_list_users', $listUsersArray );

			return $this->sendRequest( 'users', $listUsersArray, "GET" );
		}

		/**
		 * getUserInfo function.
		 *
		 * @access public
		 * @param $user_id
		 * @return 
		 * @since 1.0.0
		 */
		public function getUserInfo( $user_id ) {
			$getUserInfoArray = array();
			$getUserInfoArray = apply_filters( 'event_manager_zoom_get_user_info', $getUserInfoArray );

			return $this->sendRequest( 'users/' . $user_id, $getUserInfoArray );
		}

		/**
		 * deleteAUser function.
		 *
		 * @access public
		 * @param $userid
		 * @return 
		 * @since 1.0.0
		 */
		public function deleteAUser( $userid ) {
			$deleteAUserArray       = array();
			$deleteAUserArray['id'] = $userid;

			return $this->sendRequest( 'users/' . $userid, false, "DELETE" );
		}

		/**
		 * listMeetings function.
		 *
		 * @access public
		 * @param $host_id
		 * @return 
		 * @since 1.0.0
		 */
		public function listMeetings( $host_id ) {
			$listMeetingsArray              = array();
			$listMeetingsArray['page_size'] = 300;
			$listMeetingsArray              = apply_filters( 'event_manager_zoom_list_meetings', $listMeetingsArray );

			return $this->sendRequest( 'users/' . $host_id . '/meetings', $listMeetingsArray, "GET" );
		}

		/**
		 * getMeetingRegistrantQuestions function.
		 *
		 * @access public
		 * @param $meeting_id
		 * @return 
		 * @since 1.0.0
		 */
		public function getMeetingRegistrantQuestions( $meeting_id ) {			
			$data = array();
			return $this->sendRequest( 'meetings/' . $meeting_id . '/registrants/questions', $data, "GET" );
		}

		/**
		 * createMeetingRegistrant function.
		 *
		 * @access public
		 * @param $meeting_id, $data
		 * @return 
		 * @since 1.0.0
		 */
		public function createMeetingRegistrant( $meeting_id, $data = array() ) {			
			
			$data = apply_filters( 'event_manager_zoom_create_meeting_registrants', $data );

			return $this->sendRequest( 'meetings/' . $meeting_id . '/registrants', $data, "POST" );
		}

		/**
		 * createAMeeting function.
		 *
		 * @access public
		 * @param $data
		 * @return 
		 * @since 1.0.0
		 */
		public function createAMeeting( $data = array() ) {
			$post_time  = $data['start_date'];
			$start_time = gmdate( "Y-m-d\TH:i:s", strtotime( $post_time ) );

			$postData = array();

			if ( !empty( $data['alternative_host_ids'] ) ) {
				if ( count( $data['alternative_host_ids'] ) > 1 ) {
					$alternative_host_ids = implode( ",", $data['alternative_host_ids'] );
				} else {
					$alternative_host_ids = $data['alternative_host_ids'][0];
				}
			}

			$postData['topic']      = $data['topic'];
			$postData['agenda']     = !empty( $data['agenda'] ) ? $data['agenda'] : "";
			$postData['type']       = !empty( $data['type'] ) ? $data['type'] : 2; //Scheduled
			$postData['start_time'] = $start_time;
			$postData['timezone']   = $data['timezone'];
			$postData['password']   = !empty( $data['password'] ) ? $data['password'] : "";
			$postData['duration']   = !empty( $data['duration'] ) ? $data['duration'] : 60;
			$postData['settings']   = array(
				'meeting_authentication' => !empty( $data['option_meeting_authentication'] ) ? true : false,
				'join_before_host'  => !empty( $data['option_join_before_host'] ) ? true : false,
				'host_video'        => !empty( $data['option_host_video'] ) ? true : false,
				'participant_video' => !empty( $data['option_participants_video'] ) ? true : false,
				'mute_upon_entry'   => !empty( $data['option_mute_participants'] ) ? true : false,
				'enforce_login'     => !empty( $data['option_enforce_login'] ) ? true : false,
				'auto_recording'    => !empty( $data['option_auto_recording'] ) ? $data['option_auto_recording'] : "none",
				'alternative_hosts' => isset( $alternative_host_ids ) ? $alternative_host_ids : ""
			);

			if( !empty($data['option_registration']) )
			{
				$postData['settings']['approval_type'] = isset( $data['option_approval_type'] ) ? $data['option_approval_type'] : 2;
			}
			else
			{
				$postData['settings']['approval_type'] = 2;	
			}

			$postData = apply_filters( 'event_manager_zoom_create_meeting', $postData );

			if ( !empty( $postData ) ) {
				return $this->sendRequest( 'users/' . $data['userId'] . '/meetings', $postData, "POST" );
			} else {
				return;
			}
		}

		/**
		 * updateMeetingInfo function.
		 *
		 * @access public
		 * @param $data
		 * @return 
		 * @since 1.0.0
		 */
		public function updateMeetingInfo( $data = array() ) {
			$post_time  = $data['start_date'];
			$start_time = gmdate( "Y-m-d\TH:i:s", strtotime( $post_time ) );

			$postData = array();

			if ( !empty( $data['alternative_host_ids'] ) ) {
				if ( count( $data['alternative_host_ids'] ) > 1 ) {
					$alternative_host_ids = implode( ",", $data['alternative_host_ids'] );
				} else {
					$alternative_host_ids = $data['alternative_host_ids'][0];
				}
			}

			$postData['topic']      = $data['topic'];
			$postData['agenda']     = !empty( $data['agenda'] ) ? $data['agenda'] : "";
			$postData['type']       = !empty( $data['type'] ) ? $data['type'] : 2; //Scheduled
			$postData['start_time'] = $start_time;
			$postData['timezone']   = $data['timezone'];
			$postData['password']   = !empty( $data['password'] ) ? $data['password'] : "";
			$postData['duration']   = !empty( $data['duration'] ) ? $data['duration'] : 60;
			$postData['settings']   = array(
				'meeting_authentication' => !empty( $data['option_meeting_authentication'] ) ? true : false,
				'join_before_host'  => !empty( $data['option_join_before_host'] ) ? true : false,
				'host_video'        => !empty( $data['option_host_video'] ) ? true : false,
				'participant_video' => !empty( $data['option_participants_video'] ) ? true : false,
				'mute_upon_entry'   => !empty( $data['option_mute_participants'] ) ? true : false,
				'enforce_login'     => !empty( $data['option_enforce_login'] ) ? true : false,
				'auto_recording'    => !empty( $data['option_auto_recording'] ) ? $data['option_auto_recording'] : "none",
				'alternative_hosts' => isset( $alternative_host_ids ) ? $alternative_host_ids : ""
			);

			if( !empty($data['option_registration']) )
			{
				$postData['settings']['approval_type'] = isset( $data['option_approval_type'] ) ? $data['option_approval_type'] : 2;
			}
			else
			{
				$postData['settings']['approval_type'] = 2;	
			}

			$postData = apply_filters( 'event_manager_zoom_update_meeting', $postData );

			if ( !empty( $postData ) ) {
				return $this->sendRequest( 'meetings/' . $data['meeting_id'], $postData, "PATCH" );
			} else {
				return;
			}
		}

		/**
		 * getMeetingInfo function.
		 *
		 * @access public
		 * @param $id
		 * @return 
		 * @since 1.0.0
		 */
		public function getMeetingInfo( $meeting_id ) {
			$getMeetingInfoArray = array();
			$getMeetingInfoArray = apply_filters( 'event_manager_zoom_get_meeting_info', $getMeetingInfoArray );

			return $this->sendRequest( 'meetings/' . $meeting_id, $getMeetingInfoArray, "GET" );
		}

		/**
		 * deleteAMeeting function.
		 *
		 * @access public
		 * @param $meeting_id
		 * @return 
		 * @since 1.0.0
		 */
		public function deleteAMeeting( $meeting_id ) {
			$deleteAMeetingArray = array();

			return $this->sendRequest( 'meetings/' . $meeting_id, $deleteAMeetingArray, "DELETE" );
		}

		/**
		 * deleteAWebinar function.
		 *
		 * @access public
		 * @param $meeting_id
		 * @return 
		 * @since 1.0.0
		 */
		public function deleteAWebinar( $webinar_id ) {
			return $this->sendRequest( 'webinars/' . $webinar_id, false, "DELETE" );
		}

		/**
		 * getDailyReport function.
		 *
		 * @access public
		 * @param $month, $year
		 * @return 
		 * @since 1.0.0
		 */
		public function getDailyReport( $month, $year ) {
			$getDailyReportArray          = array();
			$getDailyReportArray['year']  = $year;
			$getDailyReportArray['month'] = $month;
			$getDailyReportArray          = apply_filters( 'event_manager_zoom_get_daily_report', $getDailyReportArray );

			return $this->sendRequest( 'report/daily', $getDailyReportArray, "GET" );
		}

		/**
		 * getAccountReport function.
		 *
		 * @access public
		 * @param $zoom_account_from, $zoom_account_to
		 * @return 
		 * @since 1.0.0
		 */
		public function getAccountReport( $zoom_account_from, $zoom_account_to ) {
			$getAccountReportArray              = array();
			$getAccountReportArray['from']      = $zoom_account_from;
			$getAccountReportArray['to']        = $zoom_account_to;
			$getAccountReportArray['page_size'] = 300;
			$getAccountReportArray              = apply_filters( 'event_manager_zoom_get_account_report', $getAccountReportArray );

			return $this->sendRequest( 'report/users', $getAccountReportArray, "GET" );
		}

		/**
		 * getMeetingRegistrantQuestions function.
		 *
		 * @access public
		 * @param $webinar_id
		 * @return 
		 * @since 1.0.3
		 */
		public function getWebinarRegistrantQuestions( $webinar_id ) {			
			$data = array();
			return $this->sendRequest( 'webinars/' . $webinar_id . '/registrants/questions', $data, "GET" );
		}

		/**
		 * registerWebinarParticipants function.
		 *
		 * @access public
		 * @param $webinar_id, $first_name, $last_name, $email
		 * @return 
		 * @since 1.0.0
		 */
		public function createWebinarRegistrant( $webinar_id, $data = array() ) {
			
			$data = apply_filters( 'event_manager_zoom_create_webinar_registrants', $data );

			return $this->sendRequest( 'webinars/' . $webinar_id . '/registrants', $data, "POST" );
		}

		/**
		 * listWebinar function.
		 *
		 * @access public
		 * @param $userId
		 * @return 
		 * @since 1.0.0
		 */
		public function listWebinar( $host_id ) {
			$postData              = array();
			$postData['page_size'] = 300;
			$postData              = apply_filters( 'event_manager_zoom_list_webinars', $postData );

			return $this->sendRequest( 'users/' . $host_id . '/webinars', $postData, "GET" );
		}

		/**
		 * Create Webinar
		 *
		 * @param $userID
		 * @param array $data
		 * @return array|bool|string|void|WP_Error
		 * @since 1.0.3
		 */
		public function createAWebinar( $data = array() ) {
			$post_time  = $data['start_date'];
			$start_time = gmdate( "Y-m-d\TH:i:s", strtotime( $post_time ) );

			$postData = array();

			if ( !empty( $data['alternative_host_ids'] ) ) {
				if ( count( $data['alternative_host_ids'] ) > 1 ) {
					$alternative_host_ids = implode( ",", $data['alternative_host_ids'] );
				} else {
					$alternative_host_ids = $data['alternative_host_ids'][0];
				}
			}

			$postData['topic']      = $data['topic'];
			$postData['agenda']     = !empty( $data['agenda'] ) ? $data['agenda'] : "";
			$postData['type']       = !empty( $data['type'] ) ? $data['type'] : 2; //Scheduled
			$postData['start_time'] = $start_time;
			$postData['timezone']   = $data['timezone'];
			$postData['password']   = !empty( $data['password'] ) ? $data['password'] : "";
			$postData['duration']   = !empty( $data['duration'] ) ? $data['duration'] : 60;
			$postData['settings']   = array(
				'meeting_authentication' => !empty( $data['option_meeting_authentication'] ) ? true : false,
				'host_video'        => !empty( $data['option_host_video'] ) ? true : false,
				'panelists_video'   => !empty( $data['option_panelists_video'] ) ? true : false,
				'practice_session'  => !empty( $data['option_practice_session'] ) ? true : false,
				'hd_video'        	=> !empty( $data['option_hd_video'] ) ? true : false,
				'allow_multiple_devices'	=> !empty( $data['option_allow_multiple_devices'] ) ? true : false,
				'enforce_login'     => !empty( $data['option_enforce_login'] ) ? true : false,
				'auto_recording'    => !empty( $data['option_auto_recording'] ) ? $data['option_auto_recording'] : "none",
				'alternative_hosts' => isset( $alternative_host_ids ) ? $alternative_host_ids : ""
			);

			if( !empty($data['option_registration']) )
			{
				$postData['settings']['approval_type'] = isset( $data['option_approval_type'] ) ? $data['option_approval_type'] : 2;
			}
			else
			{
				$postData['settings']['approval_type'] = 2;	
			}

			$postData = apply_filters( 'event_manager_zoom_create_webinars', $postData );

			if ( !empty( $postData ) ) {
				return $this->sendRequest( 'users/' . $data['userId'] . '/webinars', $postData, "POST" );
			} else {
				return;
			}			
		}

		/**
		 * Update Webinar
		 *
		 * @param $webinar_id
		 * @param array $data
		 * @return array|bool|string|void|WP_Error
		 * @since 1.0.3
		 */
		public function updateWebinar( $data = array() ) {

			$post_time  = $data['start_date'];
			$start_time = gmdate( "Y-m-d\TH:i:s", strtotime( $post_time ) );

			$postData = array();

			if ( !empty( $data['alternative_host_ids'] ) ) {
				if ( count( $data['alternative_host_ids'] ) > 1 ) {
					$alternative_host_ids = implode( ",", $data['alternative_host_ids'] );
				} else {
					$alternative_host_ids = $data['alternative_host_ids'][0];
				}
			}

			$postData['topic']      = $data['topic'];
			$postData['agenda']     = !empty( $data['agenda'] ) ? $data['agenda'] : "";
			$postData['type']       = !empty( $data['type'] ) ? $data['type'] : 2; //Scheduled
			$postData['start_time'] = $start_time;
			$postData['timezone']   = $data['timezone'];
			$postData['password']   = !empty( $data['password'] ) ? $data['password'] : "";
			$postData['duration']   = !empty( $data['duration'] ) ? $data['duration'] : 60;
			$postData['settings']   = array(
				'meeting_authentication' => !empty( $data['option_meeting_authentication'] ) ? true : false,
				'host_video'        => !empty( $data['option_host_video'] ) ? true : false,
				'panelists_video'   => !empty( $data['option_panelists_video'] ) ? true : false,
				'practice_session'  => !empty( $data['option_practice_session'] ) ? true : false,
				'hd_video'        	=> !empty( $data['option_hd_video'] ) ? true : false,
				'allow_multiple_devices'	=> !empty( $data['option_allow_multiple_devices'] ) ? true : false,
				'enforce_login'     => !empty( $data['option_enforce_login'] ) ? true : false,
				'auto_recording'    => !empty( $data['option_auto_recording'] ) ? $data['option_auto_recording'] : "none",
				'alternative_hosts' => isset( $alternative_host_ids ) ? $alternative_host_ids : ""
			);

			if( !empty($data['option_registration']) )
			{
				$postData['settings']['approval_type'] = isset( $data['option_approval_type'] ) ? $data['option_approval_type'] : 2;
			}
			else
			{
				$postData['settings']['approval_type'] = 2;	
			}

			$postData = apply_filters( 'event_manager_zoom_update_webinar', $postData );

			if ( !empty( $postData ) ) {
				return $this->sendRequest( 'webinars/' . $data['webinar_id'], $postData, "PATCH" );
			} else {
				return;
			}


			

			return $this->sendRequest( 'webinars/' . $webinar_id, $postData, "PATCH" );
		}

		/**
		 * Get Webinar Info
		 *
		 * @param $id
		 * @return array|bool|string|WP_Error
		 * @since 1.0.3
		 */
		public function getWebinarInfo( $webinar_id ) {
			$getMeetingInfoArray = array();

			return $this->sendRequest( 'webinars/' . $webinar_id, $getMeetingInfoArray, "GET" );
		}

		/**
		 * listWebinarParticipants function.
		 *
		 * @access public
		 * @param $webinarId
		 * @return 
		 * @since 1.0.0
		 */
		public function listWebinarParticipants( $webinar_id ) {
			$postData              = array();
			$postData['page_size'] = 300;

			return $this->sendRequest( 'webinars/' . $webinar_id . '/registrants', $postData, "GET" );
		}

		/**
		 * recordingsByMeeting function.
		 *
		 * @access public
		 * @param $meetingId
		 * @return 
		 * @since 1.0.0
		 */
		public function recordingsByMeeting( $meetingId ) {
			return $this->sendRequest( 'meetings/' . $meetingId . '/recordings', false, "GET" );
		}

		/**
		 * listRecording function.
		 *
		 * @access public
		 * @param $host_id, $data
		 * @return 
		 * @since 1.0.0
		 */
		public function listRecording( $host_id, $data = array() ) {
			$postData = array();
			$from     = date( 'Y-m-d', strtotime( '-1 year', time() ) );
			$to       = date( 'Y-m-d' );

			$postData['from'] = !empty( $data['from'] ) ? $data['from'] : $from;
			$postData['to']   = !empty( $data['to'] ) ? $data['to'] : $to;
			$postData         = apply_filters( 'event_manager_zoom_list_recording', $postData );

			return $this->sendRequest( 'users/' . $host_id . '/recordings', $postData, "GET" );
		}

		/**
		 * endMeetingStatus function.
		 *
		 * @access public
		 * @param $meeting_id
		 * @return 
		 * @since 1.0.0
		 */
		public function endMeetingStatus($meeting_id) {
			$postData               = array();
			$postData['action'] = "end";

			return $this->sendRequest( 'meetings/' . $meeting_id . '/status', $postData, "PUT" );
		}

		/**
		 * endWebinarStatus function.
		 *
		 * @access public
		 * @param $meeting_id
		 * @return 
		 * @since 1.0.0
		 */
		public function endWebinarStatus($webinar_id) {
			$postData               = array();
			$postData['action'] = "end";

			return $this->sendRequest( 'webinars/' . $webinar_id . '/status', $postData, "PUT" );
		}
	}

	function WPEM_Zoom_API() {
		return WPEM_Zoom_API::instance();
	}

	WPEM_Zoom_API();
}
