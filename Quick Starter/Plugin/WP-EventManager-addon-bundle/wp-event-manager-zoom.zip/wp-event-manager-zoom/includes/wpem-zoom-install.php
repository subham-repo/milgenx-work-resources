<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPEM_Zoom_Install class.
 */
class WPEM_Zoom_Install {

	/**
     * install function.
     *
     * @access public static
     * @param 
     * @return 
     * @since 1.0.0
     */
	public static function install() 
	{
          // Redirect to setup screen for new installs
          if ( ! get_option( 'wpem_zoom_version' ) ) {

               set_transient( '_event_zoom_activation_redirect', 1, HOUR_IN_SECONDS );
          }

		update_option( 'wpem_zoom_version', WPEM_ZOOM_VERSION );

          $all_fields = get_option( 'event_manager_form_fields', true );
          if( is_array($all_fields) && !empty($all_fields) )
          {
               $all_fields['event']['event_zoom_id'] =  array(
                                        'label'       => __( 'Zoom Meeting / Webinar', 'wp-event-manager-zoom' ),
                                        'type'        => 'select',
                                        'required'    => false,
                                        'description' => __('Select Zoom Meeting / Webinar','wp-event-manager-zoom'),
                                        'priority'    => 50,
                                        'options'     => array()
                                   );
          }

          update_option('event_manager_form_fields', $all_fields);
	}

     public static function update() 
     {
          global $wpdb;

          $update_fields = [
               '_meeting_join_before_host' => '_meeting_option_join_before_host',
          ];

          if(!empty($update_fields))
          {
               foreach ($update_fields as $old_name => $new_name) 
               {
                    $wpdb->query('UPDATE `' . $wpdb->prefix . 'postmeta` SET `meta_key` = "'. $new_name .'" WHERE `meta_key` = "'. $old_name .'";');     
               }
          }

          $all_fields = get_option( 'event_manager_form_fields', true );
          if( is_array($all_fields) && !empty($all_fields) )
          {
               $all_fields['event']['event_zoom_id'] =  array(
                                        'label'       => __( 'Zoom Meeting / Webinar', 'wp-event-manager-zoom' ),
                                        'type'        => 'select',
                                        'required'    => false,
                                        'description' => __('Select Zoom Meeting / Webinar','wp-event-manager-zoom'),
                                        'priority'    => 50,
                                        'options'     => array()
                                   );
          }

          update_option('event_manager_form_fields', $all_fields);

          $pages_to_create = [
               'zoom_submit_meeting_form' => [
                    'page_title' => 'Submit Zoom Meeting Form',
                    'page_content' => '[submit_zoom_meeting_form]',
               ],
               'zoom_meeting_dashboard' => [
                    'page_title' => 'Zoom Meeting Dashboard',
                    'page_content' => '[zoom_meeting_dashboard]',
               ],
          ];

          foreach ( $pages_to_create as $page_slug => $page ) 
          {
               self::create_page( sanitize_text_field( $page['page_title'] ), $page['page_content'], 'event_' . $page_slug . '_page_id' );
          }

          update_option( 'wpem_zoom_version', WPEM_ZOOM_VERSION );
     }

     /**
     * create_page function.
     *
     * @access public static
     * @param 
     * @return 
     * @since 1.0.3
     */
     private static function create_page( $title, $content, $option ) 
     {
          if(get_option($option) == '')
          {
               $page_data = array(

                    'post_status'    => 'publish',

                    'post_type'      => 'page',

                    'post_author'    => 1,

                    'post_name'      => sanitize_title( $title ),

                    'post_title'     => $title,

                    'post_content'   => $content,

                    'post_parent'    => 0,

                    'comment_status' => 'closed'
               );

               $page_id = wp_insert_post( $page_data );

               if ( $option ) {

                    update_option( $option, $page_id );
               }
          }         
     }
}