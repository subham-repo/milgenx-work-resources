<?php
/**
 * WPEM_Zoom_Submit_Event class.
 */
class WPEM_Zoom_Submit_Event {
		
	/**
	 * Constructor.
	 */
	public function __construct() {
		
		// Add filters
		add_filter( 'merge_with_custom_fields', array( $this, 'init_fields'), 10, 2 );
		//add_filter( 'submit_event_form_fields_get_user_data', array( $this, 'init_fields') );
		//add_filter( 'submit_event_form_fields_get_event_data', array( $this, 'init_fields') );

		add_filter( 'event_manager_event_listing_data_fields', array( $this, 'event_listing_data_fields') );

		//add_filter( 'submit_event_form_validate_fields', array( $this, 'zoom_meeting_validate_fields'), 10, 3);

		//add_filter( 'event_registration_form_fields', array( $this, 'event_zoom_meeting_list' ), 10, 2); // add in code

		add_filter( 'event_manager_show_additional_details_fields', array( $this, 'remove_zoom_meeting_fields'));
	}
	
	/**
	 * init_fields function.
	 * add zoom meeting list field on submit event form in front side
	 * @access public
	 * @param $fields
	 * @return 
	 * @since 1.0.0
	 */
	public function init_fields($fields) 
	{

		if(is_admin())
			return $fields;

		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );

		$user_id = get_current_user_id();

		$args = [];
		
		if ( current_user_can( 'manage_options' ) ) 
		{
			
		}
		else
		{
			if(get_option('enable_frontend_zoom_connection', true))
			{
				if(!empty($user_id))
				{
					$args = ['author' => $user_id];
				}
			}
		}		

	    $result = get_event_manager_zoom_meeting_list($args);

	    $event_meeting_list = [];

		if($result->found_posts > 0)
		{
			$event_meeting_list[''] =  __( 'Select Zoom Meeting / Webinar', 'wp-event-manager-zoom' );

			foreach ($result->posts as $post) 
			{
				$meeting_id = get_post_meta( $post->ID, '_meeting_zoom_meeting_id', true );

				if ( !empty( $meeting_id ) ) 
				{
					$event_meeting_list[$post->ID] = $post->post_title;
				}
			}
		}
		else
		{
			$event_meeting_list[''] =  __( 'No Any Zoom Meeting / Webinar', 'wp-event-manager-zoom' );
		}

		$fields['event']['event_zoom_id'] =  array(
								'label'       => __( 'Zoom Meeting / Webinar', 'wp-event-manager-zoom' ),
								'type'        => 'select',
								'required'    => false,
								'description' => __('Select Zoom Meeting / Webinar','wp-event-manager-zoom'),
								'priority'    => 50,
								'options'     => $event_meeting_list							
							);

		return $fields;
	}

	/**
	 * init_fields function.
	 * add zoom meeting list field on add event in admin side
	 * @access public
	 * @param $fields
	 * @return 
	 * @since 1.0.0
	 */
	public function event_listing_data_fields($fields) 
	{
		$user_id = get_current_user_id();

		$args = [];
		
		if ( current_user_can( 'manage_options' ) ) 
		{
			
		}
		else
		{
			if(get_option('enable_frontend_zoom_connection', true))
			{
				if(!empty($user_id))
				{
					$args = ['author' => $user_id];
				}
			}
		}		

	    $result = get_event_manager_zoom_meeting_list($args);

	    $event_meeting_list = [];

		if($result->found_posts > 0)
		{
			$event_meeting_list[''] =  __( 'Select Zoom Meeting / Webinar', 'wp-event-manager-zoom' );

			foreach ($result->posts as $post) 
			{
				$meeting_id = get_post_meta( $post->ID, '_meeting_zoom_meeting_id', true );

				if ( !empty( $meeting_id ) ) 
				{
					$event_meeting_list[$post->ID] = $post->post_title;
				}
			}
		}
		else
		{
			$event_meeting_list[''] =  __( 'No Any Zoom Meeting / Webinar', 'wp-event-manager-zoom' );
		}

		$fields['_event_zoom_id'] =  array(
								'label'       => __( 'Zoom Meeting / Webinar', 'wp-event-manager-zoom' ),
								'type'        => 'select',
								'required'    => false,
								'description' => __('Select Zoom Meeting / Webinar','wp-event-manager-zoom'),
								'priority'    => 50,
								'options'     => $event_meeting_list							
							);

		return $fields;
	}

	/**
	 * zoom_meeting_validate_fields function.
	 * add zoom meeting field validation while event is online in front side event submission
	 * @access public
	 * @param $string, $fields, $values
	 * @return 
	 * @since 1.0.0
	 */
    public function zoom_meeting_validate_fields($string, $fields, $values)
    {
    	$user_id = get_current_user_id();

    	/*
    	if ( current_user_can( 'manage_options' ) ) 
		{
			$enable_meeting_all_event = get_option('event_zoom_enable_all_event');
		}
		else
		{
			$zoom_settings = get_user_meta($user_id, '_zoom_settings', true);

			$enable_meeting_all_event = !empty($zoom_settings['event_zoom_enable_all_event']) ? $zoom_settings['event_zoom_enable_all_event'] : '0' ;
		}
		*/

		$enable_meeting_all_event = apply_filters( 'event_zoom_enable_all_event', false);

    	foreach ( $fields as $group_key => $group_fields )
        {
        	if($group_key == 'event')
        	{
        		if($enable_meeting_all_event == false)
        		{
        			if($group_fields['event_zoom_id']['value'] != '' && $group_fields['event_online']['value'] == 'no' )
	        		{
	        			return new WP_Error( 'validation-error', __( 'Zoom Meeting / Webinar available only for online event.', 'wp-event-manager-zoom' ) );
	        		}
	        		else if($group_fields['event_zoom_id']['value'] == '' && $group_fields['event_online']['value'] == 'yes' )
	        		{
	        			return new WP_Error( 'validation-error', __( 'Please select Zoom Meeting / Webinar', 'wp-event-manager-zoom' ) );
	        		}
        		}        		
        	}
        }

        return $string;
    }

    /**
	 * remove_zoom_meeting_fields function.
	 * remove zoom meeting fields in additional fields array on single event page template
	 * @access public
	 * @param $additional_fields
	 * @return array
	 * @since 1.0.3
	 */
    public function remove_zoom_meeting_fields($additional_fields)
    {
    	if(isset($additional_fields['event_zoom_id']))
    		unset($additional_fields['event_zoom_id']);

    	return $additional_fields;
    }
	
}

new WPEM_Zoom_Submit_Event();
