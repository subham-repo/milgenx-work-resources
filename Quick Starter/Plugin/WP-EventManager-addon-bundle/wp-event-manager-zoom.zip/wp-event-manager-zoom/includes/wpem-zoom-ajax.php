<?php
class WPEM_Zoom_Ajax {

	public function __construct() {

		$this->user_page = new WPEM_Zoom_User();

		add_action( 'wp_ajax_check_zoom_connection', array( $this, 'check_zoom_connection' ) );
		//add_action( 'wp_ajax_nopriv_check_zoom_connection', array( $this, 'check_zoom_connection' ) );

		add_action( 'wp_ajax_zoom_oauth', array( $this, 'zoom_oauth' ) );
		//add_action( 'wp_ajax_nopriv_zoom_oauth', array( $this, 'zoom_oauth' ) );

		add_action( 'wp_ajax_sync_zoom_users', array( $this, 'sync_zoom_users' ) );
		//add_action( 'wp_ajax_nopriv_sync_zoom_users', array( $this, 'sync_zoom_users' ) );

		add_action( 'wp_ajax_nopriv_state_change', array( $this, 'state_change' ) );
		//add_action( 'wp_ajax_state_change', array( $this, 'state_change' ) );

		add_action( 'wp_ajax_sync_zoom_meetings', array( $this, 'sync_zoom_meetings' ) );
		//add_action( 'wp_ajax_nopriv_sync_zoom_meetings', array( $this, 'sync_zoom_meetings' ) );

		add_action( 'wp_ajax_sync_zoom_webinars', array( $this, 'sync_zoom_webinars' ) );
		//add_action( 'wp_ajax_nopriv_sync_zoom_webinars', array( $this, 'sync_zoom_webinars' ) );

		//Join via browser Auth Call
		add_action( 'wp_ajax_nopriv_get_auth', array( $this, 'get_auth' ) );
		add_action( 'wp_ajax_get_auth', array( $this, 'get_auth' ) );

		// cron
		add_action( 'event_manager_zoom_refresh_access_token', array( $this, 'event_manager_zoom_refresh_access_token_callback' ) );
	}

	/**
	 * check_zoom_connection function.
	 * check zoom connection for zoom api working or not
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function check_zoom_connection() 
	{
		check_ajax_referer( '_nonce_event_manager_zoom_security', 'security' );

		$test = json_decode( WPEM_Zoom_API()->listUsers() );

		if ( !empty( $test ) ) {
			if ( isset($test->code) && $test->code === 124 ) {
				wp_send_json( $test->message );
			}

			if ( !empty( $test->error ) ) {
				wp_send_json( __( 'Please check your API keys !', 'wp-event-manager-zoom' ) );
			}

			if ( http_response_code() === 200 ) {
				//After user has been created delete this transient in order to fetch latest Data.
				event_manager_zoom_api_delete_user_cache();

				wp_send_json( __( 'API Connection is good. Please refresh !', 'wp-event-manager-zoom' ) );
			} else {
				wp_send_json( $test );
			}
		}

		wp_die();
	}

	/**
	 * zoom_oauth function.
	 * connect zoom oauth
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function zoom_oauth() 
	{
		$user_id = get_current_user_id();

		if( !empty($_REQUEST['callback']) )
		{
			if( $_REQUEST['callback'] == 'authorize' )
			{
				WPEM_Zoom_API()->oauth_authorize();
			}
			else if( $_REQUEST['callback'] == 'disconnect' ) 
			{
				WPEM_Zoom_API()->oauth_disconnect();
			}
		}

		if ( current_user_can( 'manage_options' ) ) 
		{
			$url = admin_url( 'edit.php?post_type=event_zoom&page=event-manager-zoom-settings' );
		}
		else
		{
			$page_id = get_option( 'event_zoom_meeting_dashboard_page_id' );
			$url = add_query_arg( array(
                        'action' => 'show_zoom_settings',
                    ), get_permalink($page_id) );
		}

		wp_redirect($url);
		exit;

		wp_die();
	}

	/**
	 * sync_zoom_users function.
	 * sync zoom user to user dashboard
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function sync_zoom_users() 
	{
		check_ajax_referer( '_nonce_event_manager_zoom_security', 'security' );

		$is_sync = event_manager_zoom_api_delete_user_cache();

		$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();
		if( isset($zoom_users->code) && !empty($zoom_users->code))
		{
			$is_sync = false;
		}

		$responce = [];

		if($is_sync)
		{
			$responce['code'] = '200';
			$responce['message'] = sprintf( __( 'Zoom Users are synchronized successfully! Please <a href="%s">reload</a> this page in order to see changes.', 'wp-event-manager-zoom' ), 'javascript:window.location.href=window.location.href' );
		}
		else
		{
			if( isset($zoom_users->code) && !empty($zoom_users->code))
			{
				$responce['code'] = '404';
				$responce['message'] = $zoom_users->message . __( ' OR may be your Key is wrong.', 'wp-event-manager-zoom');
			}
			else
			{
				$responce['code'] = '404';
				$responce['message'] = __( 'No found any meeting host', 'wp-event-manager-zoom');	
			}
		}

		wp_send_json( $responce );

		wp_die();
	}

	/**
	 * state_change function.
	 * zoom meeting status change while meeting start and end
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function state_change() 
	{
		check_ajax_referer( '_nonce_event_manager_zoom_security', 'security' );

		$type       = sanitize_text_field( filter_input( INPUT_POST, 'type' ) );
		$state      = sanitize_text_field( filter_input( INPUT_POST, 'state' ) );
		$meeting_id = sanitize_text_field( filter_input( INPUT_POST, 'id' ) );
		$post_id    = sanitize_text_field( filter_input( INPUT_POST, 'post_id' ) );

		$meeting_type = get_post_meta( $post_id, '_meeting_type', true );

		$success = false;
		switch ( $state ) {
			case 'end':

				if($meeting_type === 'webinar')
				{
					$responce = WPEM_Zoom_API()->endWebinarStatus($meeting_id);
				}
				else
				{
					$responce = WPEM_Zoom_API()->endMeetingStatus($meeting_id);
				}

				$result   = json_decode( $responce );

				if ( !empty( $result->code ) ) 
				{
					$success = false;
				} 
				else
				{
					$meeting = get_post_meta( $post_id, '_meeting_zoom_details', true );

					if ( !empty( $meeting ) ) {
						$meeting->state = 'ended';
						update_post_meta( $post_id, '_meeting_zoom_details', $meeting );
					}
				}

				$success = true;

				break;
			case 'start':
				$meeting = get_post_meta( $post_id, '_meeting_zoom_details', true );
				if ( !empty( $meeting ) ) {
					$meeting->state = 'started';
					update_post_meta( $post_id, '_meeting_zoom_details', $meeting );
				}

				$success = true;

				break;
			case 'resume':
				$meeting = get_post_meta( $post_id, '_meeting_zoom_details', true );
				if ( !empty( $meeting ) ) {
					$meeting->state = '';
					update_post_meta( $post_id, '_meeting_zoom_details', $meeting );
				}

				$success = true;

				break;

		}

		if ( $success ) {
			wp_send_json_success( $success );
		} else {
			wp_send_json_error( $success );
		}

		wp_die();
	}

	/**
	 * get_auth function.
	 * generate auth token while meeting host on our site
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function get_auth() {
		check_ajax_referer( '_nonce_event_manager_zoom_security', 'security' );

		$meeting_id = filter_input( INPUT_POST, 'meeting_id' );

		$zoom_settings = get_event_zoom_setting_by_meeting_id($meeting_id);

		$zoom_api_key = $zoom_settings['event_zoom_api_key'];
		$zoom_api_secret = $zoom_settings['event_zoom_api_secret_key'];

		if ( !empty( $zoom_api_key ) && !empty( $zoom_api_secret ) ) {
			$signature = $this->generate_signature( $zoom_api_key, $zoom_api_secret, $meeting_id, 0 );
			wp_send_json_success( array( 'sig' => $signature, 'key' => $zoom_api_key ) );
		} else {
			wp_send_json_error( 'Error occured!' );
		}

		wp_die();
	}

	/**
	 * generate_signature function.
	 * generate signature while meeting host on our site
	 * @access private
	 * @param $api_key, $api_sercet, $meeting_number, $role
	 * @return 
	 * @since 1.0.0
	 */
	private function generate_signature( $api_key, $api_sercet, $meeting_number, $role ) {
		$time = time() * 1000; //time in milliseconds (or close enough)
		$data = base64_encode( $api_key . $meeting_number . $time . $role );
		$hash = hash_hmac( 'sha256', $data, $api_sercet, true );
		$_sig = $api_key . "." . $meeting_number . "." . $time . "." . $role . "." . base64_encode( $hash );

		//return signature, url safe base64 encoded
		return rtrim( strtr( base64_encode( $_sig ), '+/', '-_' ), '=' );
	}

	/**
	 * sync_zoom_meetings function.
	 * sync zoom meeting on user meeting dashboard
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function sync_zoom_meetings() 
	{
		check_ajax_referer( '_nonce_event_manager_zoom_security', 'security' );
		
		$user_id = get_current_user_id();
		
		$responce = [];

		$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();

		if( !empty($zoom_users) && empty($zoom_users->code) )
		{
			foreach ($zoom_users as $key => $zoom_user) 
			{
				$meetings = json_decode( WPEM_Zoom_API()->listMeetings( $zoom_user->id ) );

				if(!empty($meetings) && isset($meetings->total_records) && $meetings->total_records > 0)
				{
					foreach ($meetings->meetings as $key => $meeting) 
					{
						if(isset($meeting->id) && !empty($meeting->id))
						{
							$get_meeting = $this->check_meeting_webinar_exist($meeting->id);
							wp_reset_query();

							$meeting_info = json_decode( WPEM_Zoom_API()->getMeetingInfo( $meeting->id ) );

							if(isset($meeting_info->id) && !empty($meeting_info->id))
							{
								if(empty($get_meeting))
								{
									$meeting_data = array(
											'post_type'     => 'event_zoom',
											'post_title'    => $meeting_info->topic,
											'post_status'   => 'publish',
											'comment_status' => 'closed'
										);

									if( isset($meeting_info->type) && in_array($meeting_info->type, [3, 8, 9]) )
									{
										if( isset($meeting_info->occurrences) && !empty($meeting_info->occurrences) )
										{
											$parent_event_zoom_id = 0;

											foreach ($meeting_info->occurrences as $recurrence_key => $occurrences) 
											{
												if($recurrence_key == 0)
												{
													$event_zoom_id = wp_insert_post($meeting_data);

													if(!empty($event_zoom_id) && !empty($meeting_info))
													{
														$parent_event_zoom_id = $event_zoom_id;

														$this->update_meeting_webinar_info($event_zoom_id, $meeting_info, $occurrences->occurrence_id);
													}
												}
												else
												{
													$meeting_data['post_parent'] = $parent_event_zoom_id;

													$event_zoom_id = wp_insert_post($meeting_data);

													if(!empty($event_zoom_id) && !empty($meeting_info))
													{
														$this->update_meeting_webinar_info($event_zoom_id, $meeting_info, $occurrences->occurrence_id);
													}
												}
											}											
										}										
									}
									else
									{
										$event_zoom_id = wp_insert_post($meeting_data);

										$this->update_meeting_webinar_info($event_zoom_id, $meeting_info);
									}
								}
								else
								{
									$event_zoom_id = $get_meeting[0]->ID;
									$meeting_occurrence_id = get_post_meta( $event_zoom_id, '_meeting_occurrence_id', true );

									if( isset($meeting_info->type) && in_array($meeting_info->type, [3, 8, 9]) )
									{
										if( isset($meeting_info->occurrences) && !empty($meeting_info->occurrences) )
										{
											$parent_event_zoom_id = 0;

											foreach ($meeting_info->occurrences as $recurrence_key => $occurrences) 
											{
												if($meeting_occurrence_id == $occurrences->occurrence_id)
												{
													if(!empty($event_zoom_id) && !empty($meeting_info))
													{
														$parent_event_zoom_id = $event_zoom_id;

														$this->update_meeting_webinar_info($event_zoom_id, $meeting_info, $occurrences->occurrence_id);
													}
												}
												else
												{
													$get_child_meeting = $this->check_recurring_meeting_webinar_exist($parent_event_zoom_id, $occurrences->occurrence_id);
													wp_reset_query();

													if(!empty($get_child_meeting[0]->ID) && !empty($meeting_info))
													{
														$this->update_meeting_webinar_info($get_child_meeting[0]->ID, $meeting_info, $occurrences->occurrence_id);
													}
												}
											}											
										}										
									}
									else
									{
										$this->update_meeting_webinar_info($event_zoom_id, $meeting_info);
									}
								}
							}
						}							
					}
				}
			}

			$responce['code'] = '200';
			$responce['message'] = sprintf( __( 'Zoom Meetings are synchronized successfully! Please <a href="%s">reload</a> this page in order to see changes.', 'wp-event-manager-zoom' ), 'javascript:window.location.href=window.location.href' );
		}
		else
		{
			if( isset($zoom_users->code) && !empty($zoom_users->code))
			{
				$responce['code'] = '404';
				$responce['message'] = $zoom_users->message . __( ' OR may be your Key is wrong.', 'wp-event-manager-zoom');
			}
			else
			{
				$responce['code'] = '404';
				$responce['message'] = __( 'No found any meeting host', 'wp-event-manager-zoom');
			}			
		}

		wp_send_json( $responce );

		wp_die();
	}

	/**
	 * sync_zoom_webinars function.
	 * sync zoom webinar on user webinar dashboard
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function sync_zoom_webinars() 
	{
		check_ajax_referer( '_nonce_event_manager_zoom_security', 'security' );
		
		$user_id = get_current_user_id();
		
		$responce = [];

		$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();

		if( !empty($zoom_users) && empty($zoom_users->code) )
		{
			foreach ($zoom_users as $key => $zoom_user) 
			{
				$webinars = json_decode( WPEM_Zoom_API()->listWebinar( $zoom_user->id ) );

				if(!empty($webinars) && isset($webinars->total_records) && $webinars->total_records > 0)
				{
					foreach ($webinars->webinars as $key => $webinar) 
					{
						if(isset($webinar->id) && !empty($webinar->id))
						{
							$get_webinar = $this->check_meeting_webinar_exist($webinar->id);
							wp_reset_query();

							$webinar_info = json_decode( WPEM_Zoom_API()->getWebinarInfo( $webinar->id ) );

							if(isset($webinar_info->id) && !empty($webinar_info->id))
							{
								if(empty($get_webinar))
								{
									$meeting_data = array(
											'post_type'     => 'event_zoom',
											'post_title'    => $webinar_info->topic,
											'post_status'   => 'publish',
											'comment_status' => 'closed'
										);

									if( isset($webinar_info->type) && in_array($webinar_info->type, [3, 8, 9]) )
									{
										if( isset($webinar_info->occurrences) && !empty($webinar_info->occurrences) )
										{
											$parent_event_zoom_id = 0;

											foreach ($webinar_info->occurrences as $recurrence_key => $occurrences) 
											{
												if($recurrence_key == 0)
												{
													$event_zoom_id = wp_insert_post($meeting_data);

													if(!empty($event_zoom_id) && !empty($webinar_info))
													{
														$parent_event_zoom_id = $event_zoom_id;

														$this->update_meeting_webinar_info($event_zoom_id, $webinar_info, $occurrences->occurrence_id);
													}
												}
												else
												{
													$meeting_data['post_parent'] = $parent_event_zoom_id;

													$event_zoom_id = wp_insert_post($meeting_data);

													if(!empty($event_zoom_id) && !empty($webinar_info))
													{
														$this->update_meeting_webinar_info($event_zoom_id, $webinar_info, $occurrences->occurrence_id);
													}
												}
											}											
										}										
									}
									else
									{
										$event_zoom_id = wp_insert_post($meeting_data);

										$this->update_meeting_webinar_info($event_zoom_id, $webinar_info);
									}
								}
								else
								{
									$event_zoom_id = $get_webinar[0]->ID;
									$meeting_occurrence_id = get_post_meta( $event_zoom_id, '_meeting_occurrence_id', true );

									if( isset($webinar_info->type) && in_array($webinar_info->type, [3, 8, 9]) )
									{
										if( isset($webinar_info->occurrences) && !empty($webinar_info->occurrences) )
										{
											$parent_event_zoom_id = 0;

											foreach ($webinar_info->occurrences as $recurrence_key => $occurrences) 
											{
												if($meeting_occurrence_id == $occurrences->occurrence_id)
												{
													if(!empty($event_zoom_id) && !empty($webinar_info))
													{
														$parent_event_zoom_id = $event_zoom_id;

														$this->update_meeting_webinar_info($event_zoom_id, $webinar_info, $occurrences->occurrence_id);
													}
												}
												else
												{
													$get_child_webinar = $this->check_recurring_meeting_webinar_exist($parent_event_zoom_id, $occurrences->occurrence_id);
													wp_reset_query();

													if(!empty($get_child_webinar[0]->ID) && !empty($webinar_info))
													{
														$this->update_meeting_webinar_info($get_child_webinar[0]->ID, $webinar_info, $occurrences->occurrence_id);
													}
												}
											}											
										}										
									}
									else
									{
										$this->update_meeting_webinar_info($event_zoom_id, $webinar_info);
									}
								}
							}
						}							
					}
				}
			}

			$responce['code'] = '200';
			$responce['message'] = sprintf( __( 'Zoom Webinar are synchronized successfully! Please <a href="%s">reload</a> this page in order to see changes.', 'wp-event-manager-zoom' ), 'javascript:window.location.href=window.location.href' );
		}
		else
		{
			if( isset($zoom_users->code) && !empty($zoom_users->code))
			{
				$responce['code'] = '404';
				$responce['message'] = $zoom_users->message . __( ' OR may be your Key is wrong.', 'wp-event-manager-zoom');
			}
			else
			{
				$responce['code'] = '404';
				$responce['message'] = __( 'No found any meeting host', 'wp-event-manager-zoom');
			}			
		}

		wp_send_json( $responce );

		wp_die();
	}

	/**
	 * check_meeting_webinar_exist function.
	 * check meeting/webinar exist while sync meeting form zoom account
	 * @access public
	 * @param $meeting_id
	 * @return array
	 * @since 1.0.0
	 */
	public function check_meeting_webinar_exist($meeting_id) 
	{
		$args = [
			'post_type' 	=> 'event_zoom',
			'post_status'	=> 'publish',
			'post_parent'	=> 0,
			'meta_query'	=> [
				[
					'key'   => '_meeting_zoom_meeting_id',
					'value' => $meeting_id,
					'compare' => '=',
				],
				
			],
		];

		return get_posts($args);
	}

	/**
	 * check_recurring_meeting_webinar_exist function.
	 * check recurring meeting/webinar exist while sync meeting form zoom account
	 * @access public
	 * @param $meeting_id
	 * @return array
	 * @since 1.0.0
	 */
	public function check_recurring_meeting_webinar_exist($event_zoom_id = '', $occurrence_id = '') 
	{
		$args = [
			'post_type' 	=> 'event_zoom',
			'post_status'	=> 'publish',
			'post_parent'	=> $event_zoom_id,
			'meta_query'	=> [
				[
					'key'   => '_meeting_occurrence_id',
					'value' => $occurrence_id,
					'compare' => '=',
				],
			],
		];

		return get_posts($args);
	}

	/**
	 * add_meeting function.
	 * add meeting data while sync meeting from zoom account
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function update_meeting_webinar_info($event_zoom_id = '', $meeting_info = [], $occurrence_id = '') 
	{
		if(!empty($occurrence_id))
		{
			update_post_meta( $event_zoom_id, '_meeting_occurrence_id', $occurrence_id );

			foreach ($meeting_info->occurrences as $recurrence_key => $occurrences) 
			{
				if($occurrences->occurrence_id === $occurrence_id)
				{
					$meeting_info->start_time = $occurrences->start_time;
					$meeting_info->duration = $occurrences->duration;
				}
			}
		}

		$start_date = date_i18n( 'Y-m-d', strtotime( $meeting_info->start_time ) );
		update_post_meta( $event_zoom_id, '_meeting_start_date', $start_date );

		$start_time = date_i18n( 'H:i', strtotime( $meeting_info->start_time ) );
		update_post_meta( $event_zoom_id, '_meeting_start_time', $start_time );		

		update_post_meta( $event_zoom_id, '_meeting_duration', $meeting_info->duration );

		update_post_meta( $event_zoom_id, '_meeting_zoom_details', $meeting_info );
		update_post_meta( $event_zoom_id, '_meeting_zoom_join_url', $meeting_info->join_url );
		update_post_meta( $event_zoom_id, '_meeting_zoom_start_url', $meeting_info->start_url );
		update_post_meta( $event_zoom_id, '_meeting_zoom_meeting_id', $meeting_info->id );


		// Meeting Details
		update_post_meta( $event_zoom_id, '_event_zoom_name', $meeting_info->topic );
		update_post_meta( $event_zoom_id, '_meeting_userId', $meeting_info->host_id );

		update_post_meta( $event_zoom_id, '_meeting_timezone', $meeting_info->timezone );		
		update_post_meta( $event_zoom_id, '_meeting_password', $meeting_info->password );

		// Meeting authentication Options
		$meeting_authentication = isset($meeting_info->meeting_authentication) ? $meeting_info->meeting_authentication : '';
		update_post_meta( $event_zoom_id, '_meeting_option_authentication', $meeting_authentication );

		// Meeting Registration Options
		$approval_type = isset($meeting_info->approval_type) ? $meeting_info->approval_type : '';
		update_post_meta( $event_zoom_id, '_meeting_option_approval_type', $approval_type );
		if($approval_type == 2)
			update_post_meta( $event_zoom_id, '_meeting_option_registration', '0' );	
		else
			update_post_meta( $event_zoom_id, '_meeting_option_registration', '1' );


		// Meeting Settings
		$join_before_host = isset($meeting_info->settings->join_before_host) ? $meeting_info->settings->join_before_host : '';
		update_post_meta( $event_zoom_id, '_meeting_option_join_before_host', $join_before_host );

		$host_video = isset($meeting_info->settings->host_video) ? $meeting_info->settings->host_video : '';
		update_post_meta( $event_zoom_id, '_meeting_option_host_video', $host_video );

		$participant_video = isset($meeting_info->settings->participant_video) ? $meeting_info->settings->participant_video : '';
		update_post_meta( $event_zoom_id, '_meeting_option_participants_video', $participant_video );

		$mute_upon_entry = isset($meeting_info->settings->mute_upon_entry) ? $meeting_info->settings->mute_upon_entry : '';
		update_post_meta( $event_zoom_id, '_meeting_option_mute_participants', $mute_upon_entry );

		$auto_recording = isset($meeting_info->settings->auto_recording) ? $meeting_info->settings->auto_recording : '';
		update_post_meta( $event_zoom_id, '_meeting_option_auto_recording', $auto_recording );


		// Webinar Settings
		$panelists_video = isset($meeting_info->settings->panelists_video) ? $meeting_info->settings->panelists_video : '';
		update_post_meta( $event_zoom_id, '_meeting_option_panelists_video', $panelists_video );

		$practice_session = isset($meeting_info->settings->practice_session) ? $meeting_info->settings->practice_session : '';
		update_post_meta( $event_zoom_id, '_meeting_option_practice_session', $practice_session );

		$hd_video = isset($meeting_info->settings->hd_video) ? $meeting_info->settings->hd_video : '';
		update_post_meta( $event_zoom_id, '_meeting_option_hd_video', $hd_video );

		$allow_multiple_devices = isset($meeting_info->settings->allow_multiple_devices) ? $meeting_info->settings->allow_multiple_devices : '';
		update_post_meta( $event_zoom_id, '_meeting_option_allow_multiple_devices', $allow_multiple_devices );

		if(isset($meeting_info->settings->hd_video))
			update_post_meta( $event_zoom_id, '_meeting_type', 'webinar' );
		else
			update_post_meta( $event_zoom_id, '_meeting_type', 'meeting' );
	}

	/**
	 * event_manager_zoom_refresh_access_token_callback function.
	 * generate token when user token expire
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.2
	 */
	public function event_manager_zoom_refresh_access_token_callback($user_id)
	{
		WPEM_Zoom_API()->refresh_access_token( $user_id );
	}
	
}

new WPEM_Zoom_Ajax();
