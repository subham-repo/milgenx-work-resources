<?php
class WPEM_Zoom_Post_Types {

	/**
	 * Post Type Flag
	 * @var string
	 */
	private $post_type = 'event_zoom';


	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function __construct() 
	{
		add_action( 'init', array( $this, 'register_post_types' ), 20 );
		add_filter( 'archive_template', array( $this, 'archive' ) );
	}

	/**
	 * register_post_types function.
	 * register post types Zoom Event
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function register_post_types() {
		if ( post_type_exists( $this->post_type ) ) {
			return;
		}

		$menu_name   = __( 'Zoom', 'wp-event-manager-zoom' );
		$plural   = __( 'Meetings / Webinars', 'wp-event-manager-zoom' );
		$singular = __( 'Meeting / Webinar', 'wp-event-manager-zoom' );

		register_post_type( $this->post_type,
			apply_filters( "register_post_type_event_zoom", array(
				'labels' => array(
					'name' 					=> $plural,
					'singular_name' 		=> $singular,
					'menu_name'             => $menu_name,
					'all_items'             => sprintf( __( 'All %s', 'wp-event-manager-zoom' ), $plural ),
					'add_new' 				=> sprintf( __( 'Add New %s', 'wp-event-manager-zoom' ), $singular ),
					'add_new_item' 			=> sprintf( __( 'Add %s', 'wp-event-manager-zoom' ), $singular ),
					'edit' 					=> sprintf( __( 'Edit %s', 'wp-event-manager-zoom' ), $singular ),
					'edit_item' 			=> sprintf( __( 'Edit %s', 'wp-event-manager-zoom' ), $singular ),
					'new_item' 				=> sprintf( __( 'New %s', 'wp-event-manager-zoom' ), $singular ),
					'view' 					=> sprintf( __( 'View %s', 'wp-event-manager-zoom' ), $singular ),
					'view_item' 			=> sprintf( __( 'View %s', 'wp-event-manager-zoom' ), $singular ),
					'search_items' 			=> sprintf( __( 'Search %s', 'wp-event-manager-zoom' ), $plural ),
					'not_found' 			=> sprintf( __( 'No %s found', 'wp-event-manager-zoom' ), $plural ),
					'not_found_in_trash' 	=> sprintf( __( 'No %s found in trash', 'wp-event-manager-zoom' ), $plural ),
					'parent' 				=> sprintf( __( 'Parent %s', 'wp-event-manager-zoom' ), $singular )
				),
				'description'         => __( 'This is where you can edit and view zoom.', 'wp-event-manager-zoom' ),
				'public'             => true,
				'publicly_queryable' => true,
				'show_ui'            => true,
				'show_in_menu'       => true,
				'query_var'          => true,
				'menu_icon'          => 'dashicons-video-alt2',
				'capability_type'    => 'post',
				'has_archive'        => true,
				'hierarchical'       => false,
				'map_meta_cap'       => true,
				'supports'           => array( 'title', 'editor', 'thumbnail' ),
				'rewrite'            => array( 'slug' => $this->post_type ),
			) )
		);
	}	

	/**
	 * archive function.
	 * archive for host meeting on our side
	 * @access public
	 * @param $template
	 * @return 
	 * @since 1.0.0
	 */
	public function archive( $template ) {
		global $post;

		if ( ! is_post_type_archive( $this->post_type ) ) {
			return $template;
		}

		if ( isset( $_GET['type'] ) && $_GET['type'] === "meeting" && isset( $_GET['join'] ) ) {
			wp_enqueue_script('event-manager-zoom-jquery', WPEM_ZOOM_PLUGIN_URL . '/assets/js/zoom/jquery.min.js');
			wp_enqueue_script( 'event-manager-zoom-api-react', WPEM_ZOOM_PLUGIN_URL . '/assets/js/zoom/react.production.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );
			wp_enqueue_script( 'event-manager-zoom-api-react-dom', WPEM_ZOOM_PLUGIN_URL . '/assets/js/zoom/react-dom.production.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );
			wp_enqueue_script( 'event-manager-zoom-api-redux', WPEM_ZOOM_PLUGIN_URL . '/assets/js/zoom/redux.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );
			wp_enqueue_script( 'event-manager-zoom-api-thunk', WPEM_ZOOM_PLUGIN_URL . '/assets/js/zoom/redux-thunk.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );
			wp_enqueue_script( 'event-manager-zoom-api-lodash', WPEM_ZOOM_PLUGIN_URL . '/assets/js/zoom/lodash.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );
			wp_enqueue_script( 'zoom-meeting-source', WPEM_ZOOM_PLUGIN_URL . '/assets/js/zoom/zoomus-websdk.umd.min.js', array(
				'jquery',
				'event-manager-zoom-jquery',
				'event-manager-zoom-api-react',
				'event-manager-zoom-api-react-dom',
				'event-manager-zoom-api-redux',
				'event-manager-zoom-api-thunk',
				'event-manager-zoom-api-lodash'
			), WPEM_ZOOM_VERSION, true );

			wp_enqueue_script( 'event-manager-zoom-api-browser', WPEM_ZOOM_PLUGIN_URL . '/assets/js/browser-meeting.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true );
			wp_localize_script( 'event-manager-zoom-api-browser', 'event_manager_zoom_meeting_browser', array(
				'ajax_url'       => admin_url( 'admin-ajax.php' ),
				'event_manager_zoom_security'  => wp_create_nonce( "_nonce_event_manager_zoom_security" ),
				'redirect_page' => esc_url( home_url( '/' ) ),
				'meeting_id'    => absint( event_manager_zoom_encrypt_decrypt( 'decrypt', $_GET['join'] ) ),
				'meeting_pwd'   => !empty( $_GET['pak'] ) ? sanitize_text_field( event_manager_zoom_encrypt_decrypt( 'decrypt', $_GET['pak'] ) ) : false,
				
				'name_required_error' 	=> __( 'Name is required to enter the meeting or webinar !', 'wp-event-manager-zoom' ),
				'email_required_error' 	=> __( 'Email is required to enter the meeting or webinar !', 'wp-event-manager-zoom' ),
				'not_authorized_error' 	=> __( 'Not Authorized !', 'wp-event-manager-zoom' ),
				'incorrect_meeting_id_error' 	=> __( 'Incorrect Meeting or Webinar ID !', 'wp-event-manager-zoom' ),

				'label_browser_info' 	=> __( 'Browser Info', 'wp-event-manager-zoom' ),
				'label_browser_name' 	=> __( 'Browser Name', 'wp-event-manager-zoom' ),
				'label_browser_version' => __( 'Browser Version', 'wp-event-manager-zoom' ),
			) );

			$template = 'zoom-meeting-join-browser-link.php';
			$meeting = get_post_meta( $_GET['event_zoom_id'], '_meeting_zoom_details', true );
		} else {
			wp_redirect( get_site_url() );
			exit;
			wp_die();
		}

		get_event_manager_template( 
			$template, 
			array( 
				'zoom_meeting' => $meeting,
				'event_zoom_id' => $_GET['event_zoom_id'],
			), 
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/'
		);
		wp_die();

		return $template;
	}

}

new WPEM_Zoom_Post_Types();