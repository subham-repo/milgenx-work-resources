<?php
class WPEM_Zoom_Registrations {

	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function __construct() {
		add_filter( 'event_registration_email_tags', array( $this, 'get_event_registration_zoom_meeting_email_tags' ), 10, 2);

		add_action( 'event_registration_email_add_shortcodes', array( $this, 'event_registration_zoom_meeting_email_add_shortcodes' ), 10, 2 );

		add_filter( 'manage_event_zoom_posts_columns', array( $this, 'add_columns' ), 20 );
		add_action( 'manage_event_zoom_posts_custom_column', array( $this, 'render_data' ), 20, 2 );

		add_filter( 'event_manager_zoom_meeting_dashboard_columns', array( $this, 'add_registrations_columns_dashboard' ), 20 );
		add_action( 'event_manager_zoom_meeting_dashboard_column_zoom_meeting_registrations', array( $this, 'add_registrations_content_dashboard' ) );

		add_filter( 'event_registration_footer_action_end', array( $this, 'add_zoom_meeting_icon' ) );
		add_action( 'event_registration_dashboard_footer_end', array( $this, 'show_meeting_details_registration_dashboard' ) );

		add_action( 'wpem_create_event_registration_meta_update_end', array( $this, 'add_attendees_data_in_zoom' ), 10 );

	}

	/**
	 * add_columns function.
	 * add registration column in event zoom post type in admin side
	 * @access public
	 * @param $columns
	 * @return 
	 * @since 1.0.0
	 */
	public function add_columns( $columns ) {
		$columns['zoom_meeting_registrations'] = __( 'Registrations', 'wp-event-manager-zoom' );

		return $columns;
	}

	/**
	 * render_data function.
	 * add registration column content in event zoom post type in admin side
	 * @access public
	 * @param $column, $post_id
	 * @return 
	 * @since 1.0.0
	 */
	public function render_data( $column, $post_id ) {
		$meeting = get_post_meta( $post_id, '_meeting_zoom_details', true );
		switch ( $column ) {
			case 'zoom_meeting_registrations' :
				$events = get_event_from_event_zoom_id($post_id);
				if(!empty($events))
				{
					$dashboard_id = get_option( 'event_manager_event_dashboard_page_id' );

					foreach ( $events as $event ) {
						echo ( $count = get_event_registration_count( $event->ID ) ) ? '<a href="' . admin_url( 'edit.php?s&post_status=all&post_type=event_registration&_event_listing=' . $event->ID ) . '">' . $count . '</a>' : '&ndash;';
					}
				}
				else{
					echo " - ";
				}
				break;
		}
	}

	/**
	 * add_registrations_columns_dashboard function.
	 * add registration column in zoom meeting dashboard in front side
	 * @access public
	 * @param $columns
	 * @return 
	 * @since 1.0.0
	 */
	public function add_registrations_columns_dashboard( $columns ) {
		$columns['zoom_meeting_registrations'] = __( 'Registrations', 'wp-event-manager-zoom' );

		return $columns;
	}

	/**
	 * add_registrations_content_dashboard function.
	 * add registration column content in event zoom meeting dashboard in front side
	 * @access public
	 * @param $column, $post_id
	 * @return 
	 * @since 1.0.0
	 */
	public function add_registrations_content_dashboard( $event_zoom ) {
		$events = get_event_from_event_zoom_id($event_zoom->ID);
		if(!empty($events))
		{
			$dashboard_id = get_option( 'event_manager_event_dashboard_page_id' );

			foreach ( $events as $event ) {
				echo ( $count = get_event_registration_count( $event->ID ) ) ? '<div class="wpem-dboard-event-act-btn1"><a href="' . add_query_arg( array( 'action' => 'show_registrations', 'event_id' => $event->ID ), get_permalink( $dashboard_id ) ) . '">' . $count . '</a></div>' : '&ndash;';
			}
		}
		else{
			echo " - ";
		}
	}

	/**
	 * add_zoom_meeting_icon function.
	 * add zoom meeting icon on registation list page in front side
	 * @access public
	 * @param $columns
	 * @return 
	 * @since 1.0.0
	 */
	public function add_zoom_meeting_icon( $registration ) {
		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );

		$event_id = isset($_GET['event_id']) ? $_GET['event_id'] : '';

		$event_zoom_id = get_post_meta($event_id, '_event_zoom_id', true);

		$event_zoom_id = get_post_meta($event_id, '_event_zoom_id', true);

		if ( is_plugin_active('wp-event-manager-sell-tickets/wp-event-manager-sell-tickets.php') ) 
		{
			$ticket_id = get_post_meta($registration->ID, '_ticket_id', true);

			if(isset($ticket_id) && !empty($ticket_id))
			{
				$event_zoom_id = get_post_meta($ticket_id, '_event_zoom_id', true);
			}

			if(empty($event_zoom_id))
			{
				$event_zoom_id = get_post_meta($event_id, '_event_zoom_id', true);
			}
		}

		if(!empty($event_zoom_id))
		{
			$meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );

			if(!empty($meeting) && isset($meeting->id) && !empty($meeting->id) ) : ?>
				
				<div class="zoom action-btn"><a href="#" title="<?php _e( 'Zoom', 'wp-event-manager-zoom' ); ?>" class="event-registration-toggle-zoom"><?php _e( 'Zoom', 'wp-event-manager-zoom' ); ?></a></div>

			<?php endif;
		}
	}

	/**
	 * show_meeting_details_registration_dashboard function.
	 * show meeting details on registation list page while click on zoom meeting icon
	 * @access public
	 * @param $columns
	 * @return 
	 * @since 1.0.0
	 */
	public function show_meeting_details_registration_dashboard( $registration_id ) {
		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );

		wp_enqueue_script( 'wp-event-manager-zoom-dashboard' );

		$event_id = isset($_GET['event_id']) ? $_GET['event_id'] : '';

		$event_zoom_id = get_post_meta($event_id, '_event_zoom_id', true);

		if ( is_plugin_active('wp-event-manager-sell-tickets/wp-event-manager-sell-tickets.php') ) 
		{
			$ticket_id = get_post_meta($registration_id, '_ticket_id', true);

			if(isset($ticket_id) && !empty($ticket_id))
			{
				$event_zoom_id = get_post_meta($ticket_id, '_event_zoom_id', true);
			}

			if(empty($event_zoom_id))
			{
				$event_zoom_id = get_post_meta($event_id, '_event_zoom_id', true);
			}
		}

		if(!empty($event_zoom_id))
		{
			echo '<section class="event-registration-zoom">';

			echo do_shortcode( '[event_zoom_meeting_detail event_zoom_id="'. $event_zoom_id .'"]' );

			echo '</section>';
		}
	}

	/**
	 * get_event_registration_zoom_meeting_email_tags function.
	 * create zoom meeting details tag for send meeting details via mail while new regisstation
	 * @access public
	 * @param $tags
	 * @return array
	 * @since 1.0.0
	 */
	public function get_event_registration_zoom_meeting_email_tags($tags) {
		$tags['meeting_name']       	= __( 'Zoom Meeting Name', 'wp-event-manager-zoom' );
		$tags['meeting_description']  = __( 'Zoom Meeting Description', 'wp-event-manager-zoom' );
		$tags['meeting_start_date']      = __( 'Zoom Meeting Date', 'wp-event-manager-zoom' );
		$tags['meeting_start_time']      = __( 'Zoom Meeting Time', 'wp-event-manager-zoom' );
		$tags['meeting_timezone']        = __( 'Zoom Meeting Timezone', 'wp-event-manager-zoom' );
		$tags['meeting_duration']    	= __( 'Zoom Meeting Duration', 'wp-event-manager-zoom' );
		$tags['meeting_zoom_join_url']   = __( 'Zoom Meeting Join URL', 'wp-event-manager-zoom' );

		return $tags;
	}

	/**
	 * event_registration_zoom_meeting_email_add_shortcodes function.
	 * create zoom meeting details tag shortcode for send meeting details via mail while new regisstation
	 * @access public
	 * @param $data
	 * @return 
	 * @since 1.0.0
	 */
	public function event_registration_zoom_meeting_email_add_shortcodes($data) {
		extract( $data );

		$event_zoom_id = get_post_meta($event_id, '_event_zoom_id', true);

		$meeting_name = get_post_meta($event_zoom_id, '_event_zoom_name', true);
		$meeting_description = get_post_meta($event_zoom_id, '_event_zoom_description', true);
		$meeting_start_date = get_post_meta($event_zoom_id, '_meeting_start_date', true);
		$meeting_start_time = get_post_meta($event_zoom_id, '_meeting_start_time', true);
		$meeting_timezone = get_post_meta($event_zoom_id, '_meeting_timezone', true);
		$meeting_duration = get_post_meta($event_zoom_id, '_meeting_duration', true);
		$meeting_zoom_join_url = get_post_meta($event_zoom_id, '_meeting_zoom_join_url', true);

		add_shortcode( 'meeting_name', function( $atts, $content = '' ) use( $meeting_name ) {
			return $this->event_registration_zoom_meeting_email_shortcode_handler( $atts, $content, $meeting_name );
		});

		add_shortcode( 'meeting_description', function( $atts, $content = '' ) use( $meeting_description ) {
			return $this->event_registration_zoom_meeting_email_shortcode_handler( $atts, $content, $meeting_description );
		});

		add_shortcode( 'meeting_start_date', function( $atts, $content = '' ) use( $meeting_start_date ) {
			return $this->event_registration_zoom_meeting_email_shortcode_handler( $atts, $content, $meeting_start_date );
		});

		add_shortcode( 'meeting_start_time', function( $atts, $content = '' ) use( $meeting_start_time ) {
			return $this->event_registration_zoom_meeting_email_shortcode_handler( $atts, $content, $meeting_start_time );
		});

		add_shortcode( 'meeting_timezone', function( $atts, $content = '' ) use( $meeting_timezone ) {
			return $this->event_registration_zoom_meeting_email_shortcode_handler( $atts, $content, $meeting_timezone );
		});

		add_shortcode( 'meeting_duration', function( $atts, $content = '' ) use( $meeting_duration ) {
			return $this->event_registration_zoom_meeting_email_shortcode_handler( $atts, $content, $meeting_duration );
		});

		add_shortcode( 'meeting_zoom_join_url', function( $atts, $content = '' ) use( $meeting_zoom_join_url ) {
			return $this->event_registration_zoom_meeting_email_shortcode_handler( $atts, $content, $meeting_zoom_join_url );
		});
	}

	/**
	 * event_registration_zoom_meeting_email_shortcode_handler function.
	 *
	 * @access public
	 * @param $atts, $content, $value
	 * @return 
	 * @since 1.0.0
	 */
	public function event_registration_zoom_meeting_email_shortcode_handler( $atts, $content, $value ) {
		$atts = shortcode_atts( array(
			'prefix' => '',
			'suffix' => ''
		), $atts );

		if ( !empty( $value ) ) {
			return wp_kses_post( $atts['prefix'] ) . $value . wp_kses_post( $atts['suffix'] );
		}
	}

	/**
	 * add_attendees_data_in_zoom function.
	 * add attendees data in zoom account while new registartion on event
	 * @access public
	 * @param $attendees_id
	 * @return 
	 * @since 1.0.0
	 */
	public function add_attendees_data_in_zoom( $attendees_id ) 
	{
		//$event_id = isset($_REQUEST['event_id']) ? $_REQUEST['event_id'] : '';
		$event_id = wp_get_post_parent_id($attendees_id);

		$event_zoom_id = get_post_meta( $event_id, '_event_zoom_id', true );

		if(!empty($event_zoom_id))
		{
			$meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );
			$meeting_type = get_post_meta( $event_zoom_id, '_meeting_type', true );
			$enable_meeting_option_registration = get_post_meta($event_zoom_id, '_meeting_option_registration', true);			

			if($enable_meeting_option_registration)
			{
				if( !empty($meeting) && isset($meeting->id) && !empty($meeting->id) )
				{
					if($meeting_type === 'webinar')
					{
						$registrant_questions = json_decode( WPEM_Zoom_API()->getWebinarRegistrantQuestions( $meeting->id ), true );
					}
					else
					{
						$registrant_questions = json_decode( WPEM_Zoom_API()->getMeetingRegistrantQuestions( $meeting->id ), true );	
					}

					$params = [];

					if(!empty($registrant_questions['questions']))
					{
						foreach ($registrant_questions['questions'] as $field) {
							$name = $field['field_name'];

							$params[$name] = isset($_REQUEST[$name]) ? $_REQUEST[$name] : '';
						}
					}

					$params['email'] = get_post_meta( $attendees_id, '_attendee_email', true );
					$params['first_name'] = get_post_meta( $attendees_id, '_attendee_name', true );
					//$params['last_name'] = get_post_meta( $attendees_id, '_attendee_name', true );

					$params = apply_filters( 'event_manager_zoom_add_attendees_data', $params);

					if($meeting_type === 'webinar')
					{
						$registrant_created = json_decode( WPEM_Zoom_API()->createWebinarRegistrant( $meeting->id, $params ) );
					}
					else
					{
						$registrant_created = json_decode( WPEM_Zoom_API()->createMeetingRegistrant( $meeting->id, $params ) );
					}
				}
			}			
		}
	}

}

new WPEM_Zoom_Registrations();
