<?php
/**
 * WPEM_Zoom_WooCommerce class.
 */
class WPEM_Zoom_WooCommerce {

	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function __construct() {
		add_action( 'single_event_zoom_meeting_overview_after',   array( $this, 'add_zoom_meeting_wc' ), 10);

		add_filter( 'woocommerce_product_tabs', array( $this, 'woo_zoom_meeting_tab') );

		add_action( 'init', array( $this, 'add_zoom_meeting_endpoint' ) );
		add_filter( 'query_vars', array( $this, 'zoom_meeting_query_vars' ), 0 );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'add_zoom_meeting_link_my_account'), 10, 1 );
		add_action( 'woocommerce_account_zoom-meeting_endpoint', array( $this, 'zoom_meeting_content' ) );

		add_action( 'woocommerce_order_item_meta_end', array( $this, 'add_meeting_link_order_details' ), 10, 3 );

		add_action( 'woocommerce_order_status_completed', array( $this, 'add_customer_details_in_meeting_registrant' ) );
	}

	/**
	 * add_zoom_meeting_wc function.
	 * add zoom meeting product buy button on single event page below event description
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function add_zoom_meeting_wc() {
	    global $post;

		$user_id = get_current_user_id();
		
		$event_id = $post->ID;

		$event_zoom_id = get_post_meta($event_id, '_event_zoom_id', true);

		if(!empty($event_zoom_id))
		{
			$meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );

			$current_timestamp = strtotime(current_time('Y-m-d H:i:s'));

			$start_date = get_post_meta($event_zoom_id, '_meeting_start_date', true);
			$start_time = get_post_meta($event_zoom_id, '_meeting_start_time', true);

			//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
			$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
						
			//covert datepicker format  into php date() function date format
			$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

			$start_time = WP_Event_Manager_Date_Time::get_db_formatted_time( $start_time );

			$date = $start_date . ' ' . $start_time;

			//$meeting_end_time = WP_Event_Manager_Date_Time::date_parse_from_format('Y-m-d H:i:s'  , $date);
			$meeting_end_time = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format . ' H:i:s'  , $date);
			$meeting_end_time = !empty($meeting_end_time) ? $meeting_end_time : $date;

			$meeting_end_time = date('Y-m-d H:i:s', strtotime('+'.$meeting->duration.' minutes', strtotime($meeting_end_time)));

			if ( strtotime($meeting_end_time) > $current_timestamp )
            {
				$meeting_type = get_post_meta( $event_zoom_id, '_meeting_type', true );
				$meeting_wc_product = get_post_meta($event_zoom_id, '_meeting_wc_product', true );

				$meeting_type_title = ($meeting_type === 'webinar') ? __( 'Webinar', 'wp-event-manager-zoom' ) : __( 'Meeting', 'wp-event-manager-zoom' );
				
				if( !empty($meeting_wc_product) && !empty($meeting_wc_product['meeting_wc_product_id']) )
				{
					if($meeting_wc_product['meeting_wc_product_show_ticket_buy_button'] == '' || $meeting_wc_product['meeting_wc_product_show_ticket_buy_button'] == true)
					{
						if( isset($meeting_wc_product['meeting_wc_product_price']) && $meeting_wc_product['meeting_wc_product_price'] == '0')
						{
							?>
							<div class="wpem-zoom-sell-ticket-button-wrapper">
			                	<a href="<?php echo wc_get_cart_url().'?add-to-cart='.$meeting_wc_product['meeting_wc_product_id']; ?>" class="wpem-theme-button wpem-zoom-sell-ticket-button"><span><?php _e( 'Free Ticket', 'wp-event-manager-zoom' ); ?></span></a>
			                </div>
							<?php
						}
						else
						{
							?>
							<div class="wpem-zoom-sell-ticket-button-wrapper">
			                	<a href="<?php echo wc_get_cart_url().'?add-to-cart='.$meeting_wc_product['meeting_wc_product_id']; ?>" class="wpem-theme-button wpem-zoom-sell-ticket-button"><span><?php printf(__( 'Buy tickets (%s%d)', 'wp-event-manager-zoom' ), get_woocommerce_currency_symbol(), $meeting_wc_product['meeting_wc_product_price']); ?></span></a>
			                </div>
							<?php
						}
					}
				}
			}
		}
	}

	/**
	 * add_zoom_meeting_wc function.
	 * add zoom meeting tab in product tab if product have bind with zoom meeting
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function woo_zoom_meeting_tab($tabs) {
		global $product;

		$event_zoom_id = get_post_meta($product->get_id(), '_event_zoom_id', true);
		$meeting_type = get_post_meta( $event_zoom_id, '_meeting_type', true );

		if( $meeting_type === 'webinar' )
		{
			$tab_title = __('Webinar Details', 'wp-event-manager-zoom');
		}
		else
		{
			$tab_title = __('Meeting Details', 'wp-event-manager-zoom');
		}

		if(!empty($event_zoom_id)){
			$tabs['woo_zoom_meeting'] = array(
		        'title'    => $tab_title,
		        'priority' => 50,
		        'callback' => array( $this, 'woo_zoom_meeting_tab_content' )
		    );
		}

		return $tabs;
	}

	/**
	 * woo_zoom_meeting_tab_content function.
	 * show zoom meeting details on woocommerce single product page
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function woo_zoom_meeting_tab_content() {
		global $product;

		wp_enqueue_style( 'wp-event-manager-zoom-frontend' );

		$event_zoom_id = get_post_meta($product->get_id(), '_event_zoom_id', true);

		echo do_shortcode( '[event_zoom_meeting_detail event_zoom_id="'. $event_zoom_id .'"]' );
	}

	/**
	 * add_zoom_meeting_endpoint function.
	 * add zoom meeting tag in woocoomerce my account page
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function add_zoom_meeting_endpoint() {
	    add_rewrite_endpoint( 'zoom-meeting', EP_ROOT | EP_PAGES );
	    flush_rewrite_rules();
	}

	/**
	 * zoom_meeting_query_vars function.
	 *
	 * @access public
	 * @param $vars
	 * @return 
	 * @since 1.0.0
	 */
	public function zoom_meeting_query_vars( $vars ) {
	    $vars[] = 'zoom-meeting';
	    return $vars;
	}

	/**
	 * add_zoom_meeting_link_my_account function.
	 *
	 * @access public
	 * @param $items
	 * @return árray
	 * @since 1.0.0
	 */
	public function add_zoom_meeting_link_my_account( $items ) {
		
		$items = array_slice($items, 0, 3, true) + array('zoom-meeting' => __('Zoom Meeting / Webinar', 'wp-event-manager-zoom')) + array_slice($items, 3, count($items)-3, true);

    	return $items;
	}

	/**
	 * zoom_meeting_content function.
	 * add zoom meeting list in woocoomerce my account page
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function zoom_meeting_content() {
	    $user_id = get_current_user_id();
	    if ( 0 == $user_id ) return;

	    $orders = get_all_orders_by_user( $user_id );

	    wp_enqueue_style( 'wp-event-manager-zoom-frontend' );
	    
	    get_event_manager_template( 
			'zoom-meeting-woocommerce.php', 
			array( 
				'user_id' => $user_id,
				'orders' => $orders,
			), 
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/'
		);
	}
 
	/**
	 * add_meeting_link_order_details function.
	 * add zoom meeting link on woocoomerce single order details
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function add_meeting_link_order_details($item_id, $item, $order) {
		$product_id = method_exists( $item, 'get_product_id' ) ? $item->get_product_id() : $item['product_id'];
		$event_zoom_id = get_post_meta($product_id, '_event_zoom_id', true);
		
		if(!empty($event_zoom_id)) :
			$meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );
			if(!empty($meeting) && isset($meeting->join_url)) : 
            	$join_uri = apply_filters( 'event_manager_zoom_join_meeting_via_app_shortcode', $meeting->join_url, $meeting ); ?>
            	<p style="margin: 10px 0 0 0;"><?php _e( 'Join from:', 'wp-event-manager-zoom' ); ?> <a target="_blank" href="<?php echo $join_uri; ?>" title="Join via App">
                    <?php _e( 'here', 'wp-event-manager-zoom' ); ?>
                </a></p>            
			<?php endif;
		endif;
	}

	/**
	 * add_customer_details_in_meeting_registrant function.
	 * add customer details in meeting registrant while zoom product buy
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function add_customer_details_in_meeting_registrant($order_id) 
	{
		$order = new WC_Order( $order_id );

		$first_name = $order->get_billing_first_name();
		$last_name = $order->get_billing_last_name();
		$email = $order->get_billing_email();

		$items = $order->get_items();

		foreach ( $items as $item )
		{
			$product_id = method_exists( $item, 'get_product_id' ) ? $item->get_product_id() : $item['product_id'];
			$product = wc_get_product( $product_id );
            $get_product_type = $product->get_type();

            $event_zoom_id = get_post_meta($product_id, '_event_zoom_id', true);

            if(!empty($event_zoom_id))
			{
				$meeting = get_post_meta( $event_zoom_id, '_meeting_zoom_details', true );
				$meeting_type = get_post_meta( $event_zoom_id, '_meeting_type', true );            

				$event = get_event_from_event_zoom_id($event_zoom_id);

				if( !empty($event) && isset($event[0]) )			
				{
					$_REQUEST['event_id'] = $event[0]->ID;
				}

	            if( in_array($get_product_type, ['simple']) )
	            {
	            	if( !empty($meeting) && isset($meeting->id) && !empty($meeting->id) )
					{
						$enable_meeting_option_registration = get_post_meta($event_zoom_id, '_meeting_option_registration', true);

						if($enable_meeting_option_registration)
						{
							if($meeting_type === 'webinar')
							{
								$registrant_questions = json_decode( WPEM_Zoom_API()->getWebinarRegistrantQuestions( $meeting->id ), true );
							}
							else
							{
								$registrant_questions = json_decode( WPEM_Zoom_API()->getMeetingRegistrantQuestions( $meeting->id ), true );	
							}

							$params = [];

							if(!empty($registrant_questions['questions']))
							{
								foreach ($registrant_questions['questions'] as $field) {
									$name = $field['field_name'];

									$params[$name] = isset($_REQUEST[$name]) ? $_REQUEST[$name] : '';
								}
							}

							$params['email'] = $email;
							$params['first_name'] = $first_name;
							$params['last_name'] = $last_name;

							$params = apply_filters( 'event_manager_zoom_add_attendees_data', $params);

							if($meeting_type === 'webinar')
							{
								$registrant_created = json_decode( WPEM_Zoom_API()->createWebinarRegistrant( $meeting->id, $params ) );
							}
							else
							{
								$registrant_created = json_decode( WPEM_Zoom_API()->createMeetingRegistrant( $meeting->id, $params ) );
							}					
						}
					}
	            }
			}
		}
	}

}

new WPEM_Zoom_WooCommerce();
