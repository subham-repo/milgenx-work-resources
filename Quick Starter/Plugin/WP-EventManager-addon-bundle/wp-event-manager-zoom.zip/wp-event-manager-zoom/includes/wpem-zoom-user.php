<?php
class WPEM_Zoom_User {

	/**
	 * zoom_list_usersarray function.
	 * get zoom user list
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	public function zoom_list_users() 
	{
		$zoom_users = $this->event_manager_zoom_api_get_user_list();

		wp_enqueue_script( 'wp-event-manager-zoom-admin-zoom' );

		get_event_manager_template( 
			'zoom-user-list.php', 
			array(
				'zoom_users' => $zoom_users,
			), 
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/admin/'
		);
	}

	/**
	 * zoom_add_user function.
	 * add new user in zoon account
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function zoom_add_user() 
	{
		$message = '';

		if ( !empty( $_POST['wp_event_manager_zoom_add_user'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'event_manager_zoom_add_user' ) ) 
		{
			$params = array(
				'action'     => !empty( $_POST['user_action'] ) ? sanitize_text_field( $_POST['user_action'] ) : '',
				'email'      => !empty( $_POST['user_email'] ) ? sanitize_text_field( $_POST['user_email'] ) : '',
				'first_name' => !empty( $_POST['user_first_name'] ) ? sanitize_text_field( $_POST['user_first_name'] ) : '',
				'last_name'  => !empty( $_POST['user_last_name'] ) ? sanitize_text_field( $_POST['user_last_name'] ) : '',
				'type'       => !empty( $_POST['user_type'] ) ? sanitize_text_field( $_POST['user_type'] ) : '',
			);

			$created_user = WPEM_Zoom_API()->createAUser( $params );

			$result       = json_decode( $created_user );

			if ( !empty( $result->code ) ) 
			{
				$message = '<div class="error"><p>' . $result->message . '</p></div>';
			} 
			else 
			{
				$message = '<div class="updated"><p>' .  __( "The user has been created! Please check the email for confirmation. The added user will appear in the list after approval only.", "wp-event-manager-zoom" ) . '</p></div>';

				//After user has been created delete this transient in order to fetch latest Data.
				event_manager_zoom_api_delete_user_cache();
			}
		}

		get_event_manager_template( 
			'zoom-add-user.php', 
			array(
				'message' => $message,
			), 
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/admin/'
		);
	}

	/**
	 * event_manager_zoom_api_get_user_list function.
	 * get user list form zoom account
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function event_manager_zoom_api_get_user_list() 
	{
		if(!is_user_logged_in())
			return;
		
		$user_id = get_current_user_id();

		$user_meta = get_userdata($user_id);

		if ( isset( $_GET['page'] ) && $_GET['page'] === "event-manager-zoom-list-users" && isset( $_GET['pg'] ) ) {
			$page          = $_GET['pg'];
			$encoded_users = WPEM_Zoom_API()->listUsers( $page );
			$decoded_users = json_decode( $encoded_users );
			if ( !empty( $decoded_users->code ) ) {
				$users = false;
			} else {
				$users = $decoded_users->users;
			}
		} 
		else 
		{
			if ( current_user_can( 'manage_options' ) ) 
			{
				$check_user_cache_expiry = get_option( 'event_zoom_user_lists_expiry_time' );
				if ( time() > $check_user_cache_expiry ) {
					update_option( 'event_zoom_user_lists', '' );
				}

				//Check if any transient by name is available
				$check_transient = get_option( 'event_zoom_user_lists' );
				if ( $check_transient ) {
					$users = $check_transient->users;
				} else {
					$encoded_users = WPEM_Zoom_API()->listUsers();
					$decoded_users = json_decode( $encoded_users );
					if ( !empty( $decoded_users->code ) ) {
						$users = $decoded_users;
					} else {
						$users = $decoded_users->users;
						update_option( 'event_zoom_user_lists', $decoded_users );
						update_option( 'event_zoom_user_lists_expiry_time', time() + 108000 );
					}
				}
			}
			elseif ( in_array('editor', $user_meta->roles) ) {
				$check_transient = get_option( 'event_zoom_user_lists' );

				$users = $check_transient->users;
			}
			else
			{
				$check_user_cache_expiry = get_user_meta( $user_id, '_event_zoom_user_lists_expiry_time', true );
				if ( time() > $check_user_cache_expiry ) {
					update_user_meta( $user_id, '_event_zoom_user_lists', '' );
				}

				//Check if any transient by name is available
				$check_transient = get_user_meta( $user_id, '_event_zoom_user_lists', true );
				if ( $check_transient ) {
					$users = $check_transient->users;
				} else {
					$encoded_users = WPEM_Zoom_API()->listUsers();
					$decoded_users = json_decode( $encoded_users );
					if ( !empty( $decoded_users->code ) ) {
						$users = $decoded_users;
					} else {
						$users = $decoded_users->users;
						update_user_meta( $user_id, '_event_zoom_user_lists', $decoded_users );
						update_user_meta( $user_id, '_event_zoom_user_lists_expiry_time', time() + 108000 );
					}
				}
			}
			
		}

		return apply_filters( 'event_manager_zoom_users_list', $users );
	}
	
}

new WPEM_Zoom_User();
