<?php
class WPEM_Zoom_Settings extends WP_Event_Manager_Settings  {

	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function __construct() {
		$this->settings_group = 'wp-event-manager-zoom';
		$this->user_page = new WPEM_Zoom_User();

		add_action( 'admin_init', array( $this, 'register_settings' ) );

		if( isset($_GET['page']) && $_GET['page'] == 'event-manager-zoom-settings' )
		{
			add_action( 'admin_notices', array( $this, 'check_zoom_api_connection' ) );	
		}

		add_action( 'wp_event_manager_admin_field_link', array( $this, 'event_manager_admin_field_link' ), 10, 2 );

		add_action( 'wp_event_manager_admin_field_shortcode_description', array( $this, 'event_manager_admin_field_shortcode_description' ), 10, 2 );
	}

	/**
	 * check_zoom_api_connection function.
	 * check api connection
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function check_zoom_api_connection() {

		$zoom_users = [];

		$zoom_users = $this->user_page->event_manager_zoom_api_get_user_list();

		if( !empty($zoom_users) && empty($zoom_users->code) )
		{
			?>
			<div class="notice notice-success is-dismissible">
                <p><?php _e('Zoom Account Connected.', 'wp-event-manager-zoom') ?></p>
            </div>
			<?php
		}
		else
		{
			if( isset($zoom_users->code) && !empty($zoom_users->code))
			{
				$message = $zoom_users->message;
			}
			else
			{
				$message = __('Your API Key is may be wrong, please check API Key in Zoom Account.', 'wp-event-manager-zoom');
			}

			?>
			<div class="notice notice-error is-dismissible">
                <p><?php echo $message; ?></p>
            </div>
			<?php
		}
	}

	/**
	 * init_settings function.
	 * zoom settings for admin side
	 * @access protected
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	protected function init_settings() {
		wp_enqueue_script( 'wp-event-manager-zoom-admin-zoom' );

		$zoom_oauth_redirect_uri = add_query_arg( array(
												'action' => 'zoom_oauth',
												'callback' => 'authorize',
											), admin_url( 'admin-ajax.php' ) );

		$this->settings = apply_filters( 'event_manager_zoom_settings', array(
			'zoom_api_settings' => array(
				__( 'API Settings', 'wp-event-manager-zoom' ),
				array(
					array(
						'name' 		=> 'event_zoom_connection_options',
						'std' 		=> 'jwt',
						'label' 	=> __( 'Connection Options', 'wp-event-manager-zoom' ),
						'desc'		=> '',
						'type'      => 'radio',
						'options'	=>  array(
							'jwt' 	=> __( 'JWT ', 'wp-event-manager-zoom' ),
							'oauth' => __( 'OAuth', 'wp-event-manager-zoom' ),
							
						)
					),
					array(
						'name'        => 'event_zoom_api_key',
						'std'         => '',
						'placeholder' => __( 'Enter API Key', 'wp-event-manager-zoom' ),
						'label'       => __( 'API Key', 'wp-event-manager-zoom' ),
						'desc'        => sprintf( __( 'Zoom API Key <a href="%s" target="_blank">Create Key</a>.', 'wp-event-manager-zoom' ), 'https://marketplace.zoom.us/develop/create' ),
						'type'        => 'text'
					),
					array(
						'name'        => 'event_zoom_api_secret_key',
						'std'         => '',
						'placeholder' => __( 'Enter API Secret Key', 'wp-event-manager-zoom' ),
						'label'       => __( 'API Secret Key', 'wp-event-manager-zoom' ),
						'desc'        => sprintf( __( 'Zoom API Secret Key <a href="%s" target="_blank">Create Key</a>.', 'wp-event-manager-zoom' ), 'https://marketplace.zoom.us/develop/create' ),
						'type'        => 'text'
					),
					
					array(
						'name'        => 'event_zoom_client_id',
						'std'         => '',
						'placeholder' => __( 'Enter Client ID', 'wp-event-manager-zoom' ),
						'label'       => __( 'Client ID', 'wp-event-manager-zoom' ),
						'desc'        => sprintf( __( 'Zoom <a href="%s" target="_blank">Create App</a>. <br>', 'wp-event-manager-zoom' ), 'https://marketplace.zoom.us/develop/create' ) . $zoom_oauth_redirect_uri,
						'type'        => 'text'
					),
					array(
						'name'        => 'event_zoom_client_secret',
						'std'         => '',
						'placeholder' => __( 'Enter Client Secret', 'wp-event-manager-zoom' ),
						'label'       => __( 'Client Secret', 'wp-event-manager-zoom' ),
						'desc'        => sprintf( __( 'Zoom <a href="%s" target="_blank">Create App</a>. <br>', 'wp-event-manager-zoom' ), 'https://marketplace.zoom.us/develop/create' ) . $zoom_oauth_redirect_uri,
						'type'        => 'text'
					),

					array(
						'name'        => 'event_zoom_vanity_url',
						'std'         => '',
						'placeholder' => __( 'https://example.zoom.us', 'wp-event-manager-zoom' ),
						'label'       => __( 'Vanity URL', 'wp-event-manager-zoom' ),
						'desc'        => sprintf( __( 'If you are using Zoom Vanity URL then please insert it here else leave it empty. <a href="%s" target="_blank">Read more about Vanity URLs</a>.', 'wp-event-manager-zoom' ), 'https://support.zoom.us/hc/en-us/articles/215062646-Guidelines-for-Vanity-URL-Requests' ),
						'type'        => 'text'
					),
				)
			),
			'zoom_general_settings' => array(
				__( 'General Settings', 'wp-event-manager-zoom' ),
				array(
					array(
						'name' 		=> 'enable_frontend_zoom_connection',
						'std' 		=> '0',
						'label' 	=> __( 'Frontend Zoom Connection', 'wp-event-manager-zoom' ),
						'cb_label' 	=> __( 'Allow organizer (frontend side of organizer) create zoom meetings', 'wp-event-manager-zoom' ),
						'desc'		=> '',
						'type'      => 'checkbox'
					),
					array(
						'name' 		=> 'event_zoom_show_post_join_link',
						'std' 		=> '0',
						'label' 	=> __( 'Show Past Join Link ?', 'wp-event-manager-zoom' ),
						'cb_label' 	=> __( 'This will show join meeting links on frontend even after meeting time is already past.', 'wp-event-manager-zoom' ),
						'desc'		=> '',
						'type'      => 'checkbox'
					),
					array(
						'name' 		=> 'event_zoom_show_zoom_author',
						'std' 		=> '0',
						'label' 	=> __( 'Show Zoom Author ?', 'wp-event-manager-zoom' ),
						'cb_label'        => sprintf( __( 'Checking this show Zoom original Author in single meetings page which are created from  <a href="%s" target="_blank">Zoom Meetings</a>.', 'wp-event-manager-zoom' ), admin_url( '/edit.php?post_type=event_zoom' ) ),
						'desc'		=> '',
						'type'      => 'checkbox'
					),					
					array(
						'name'        => 'event_zoom_meeting_going_to_start_text',
						'std'         => '',
						'placeholder' => __( 'Join Meeting', 'wp-event-manager-zoom' ),
						'label'       => __( 'Meeting going to start Text', 'wp-event-manager-zoom' ),
						'desc'		  => '',
						'type'        => 'text'
					),
					array(
						'name'        => 'event_zoom_meeting_started_text',
						'std'         => '',
						'placeholder' => __( 'Start Meeting', 'wp-event-manager-zoom' ),
						'label'       => __( 'Meeting Started Text', 'wp-event-manager-zoom' ),
						'desc'		  => '',
						'type'        => 'text'
					),
					array(
						'name'        => 'event_zoom_meeting_ended_text',
						'std'         => '',
						'placeholder' => __( 'End Meeting', 'wp-event-manager-zoom' ),
						'label'       => __( 'Meeting Ended Text', 'wp-event-manager-zoom' ),
						'desc'		  => '',
						'type'        => 'text'
					), /*
					array(
						'name' 		=> 'event_zoom_enable_all_event',
						'std' 		=> '0',
						'label' 	=> __( 'Enable for the offline event', 'wp-event-manager-zoom' ),
						'cb_label' 	=> __( 'Allow zoom meeting for the offline events.', 'wp-event-manager-zoom' ),
						'desc'		=> '',
						'type'      => 'checkbox'
					), */
					array(
						'name' 		=> 'event_zoom_show_on_single_event',
						'std' 		=> '1',
						'label' 	=> __( 'Show on single event', 'wp-event-manager-zoom' ),
						'cb_label' 	=> __( 'Show Zoom metting on single event page' ),
						'desc'		=> '',
						'type'      => 'checkbox'
					),
					array(
						'name' 		=> 'event_zoom_show_on_single_event_sidebar',
						'std' 		=> '1',
						'label' 	=> __( 'Show on single event sidebar', 'wp-event-manager-zoom' ),
						'cb_label' 	=> __( 'Show Zoom metting on single event sidebar' ),
						'desc'		=> '',
						'type'      => 'checkbox'
					),
					array(
						'name' 		=> 'event_zoom_meeting_dashboard_page_id',
						'std' 		=> '',
						'label' 	=> __( 'Zoom Meeting / Webinar Dashboard Page', 'wp-event-manager-zoom' ),
						'desc'		=> __( 'Select the page where you have placed the [zoom_meeting_dashboard] shortcode. This lets the plugin know where the dashboard is located.', 'wp-event-manager-zoom' ),
						'type'      => 'page'
					),
					array(
						'name' 		=> 'event_zoom_submit_meeting_form_page_id',
						'std' 		=> '',
						'label' 	=> __( 'Submit Zoom Meeting / Webinar Form Page', 'wp-event-manager-zoom' ),
						'desc'		=> __( 'Select the page where you have placed the [submit_zoom_meeting_form] shortcode. This lets the plugin know where the form is located.', 'wp-event-manager-zoom' ),
						'type'      => 'page'
					),
					array(
						'name' 		=> 'event_zoom_delete_data_on_uninstall',
						'std' 		=> '0',
						'label' 	=> __( 'Delete Data On Uninstall', 'wp-event-manager-zoom' ),
						'cb_label'  => __( 'Delete WP Event Manager Zoom data when the plugin is deleted. Once removed, this data cannot be restored.', 'wp-event-manager-zoom' ),
						'desc'		=> '',
						'type'      => 'checkbox'
					),
				)
			),
			'zoom_shortcode' => array(
				__( 'Shortcode Description', 'wp-event-manager-zoom' ),
				array(
					array(
						'name'        => 'event_zoom_shortcode_description',
						'std'         => '',
						'placeholder' => __( 'End Meeting', 'wp-event-manager-zoom' ),
						'label'       => __( 'Using Shortcode Example', 'wp-event-manager-zoom' ),
						'class'       => '',
						'link'        => 'javascript:void(0);',
						'desc'		  => '',
						'type'        => 'shortcode_description'
					),
				)
			)
		) );

		
		if( get_option('event_zoom_client_id') != '' && get_option('event_zoom_client_secret') != '' )
		{
			$this->settings['zoom_api_settings'][1][] = array(
						'name'        => 'event_zoom_oauth_connect',
						'label'       => __( 'Zoom OAuth', 'wp-event-manager-zoom' ),
						'link_label'=> __( 'Connect', 'wp-event-manager-zoom' ),
						'link'       => '',
						'desc'		  => '',
						'type'        => 'link',
					);
		}
		

	}

	/**
	 * event_manager_admin_field_link function.
	 *
	 * @access public
	 * @param $option, $attributes
	 * @return 
	 * @since 1.0
	 */
	public function event_manager_admin_field_link($option, $attributes)
	{
		if( $option['name'] == 'event_zoom_oauth_connect' )
		{
			$user_id = get_current_user_id();

			if( get_option('event_zoom_oauth_authorize') )
			{
				$oauth_url = add_query_arg( array(
								'action' => 'zoom_oauth',
								'callback' => 'disconnect',
							), admin_url( 'admin-ajax.php' ) );

				$option['link_label'] = __('Disconnect', 'wp-event-manager-zoom');
			}
			else
			{
				$zoom_oauth_url = 'https://zoom.us/oauth/authorize/';
				$zoom_client_id = get_option('event_zoom_client_id');
				$zoom_client_secret = get_option('event_zoom_client_secret');

				$oauth_url = add_query_arg( array(
				    'response_type' => 'code',
				    'client_id' => $zoom_client_id,
				    'redirect_uri' => admin_url( 'admin-ajax.php' ) . '?action%3Dzoom_oauth%26callback%3Dauthorize',		    
				), $zoom_oauth_url );
			}

			$zoom_oauth_redirect_uri = add_query_arg( array(
												'action' => 'zoom_oauth',
												'callback' => 'authorize',
											), admin_url( 'admin-ajax.php' ) );

			?>
			<label><a class="button-primary wpem-zoom-oauth-connect-button" href="<?php echo $oauth_url; ?>"><?php echo $option['link_label']; ?></a></label>
			<?php
		}		
	}

	/**
	 * event_manager_admin_field_shortcode_description function.
	 * zoom shortcode description 
	 * @access public
	 * @param $option, $attributes
	 * @return 
	 * @since 1.0.0
	 */
	public function event_manager_admin_field_shortcode_description($option, $attributes)
	{
		if( $option['name'] == 'event_zoom_shortcode_description' )
		{			
			?>
			<p><?php _e( 'Below are few examples of how you can add shortcodes manually into your posts.', 'wp-event-manager-zoom' ); ?></p>

			<h3><?php _e( 'Basic Usage:', 'wp-event-manager-zoom' ); ?></h3>

			<p>[event_zoom_meeting meeting_id="123456789" link_only="no" show_help="no"]</p>

			<h4><?php _e( 'Description:', 'wp-event-manager-zoom' ); ?></h4>
			<p><?php _e( 'Show a list with meeting details for a specific meeting ID with join links.', 'wp-event-manager-zoom' ); ?></p>

			<h4><?php _e( 'Parameters:', 'wp-event-manager-zoom' ); ?></h4>
			<p><?php _e( '<b>meeting_id:</b> Your meeting ID.', 'wp-event-manager-zoom' ); ?></p>
			<p><?php _e( '<b>link_only:</b> Yes or No - Adding yes will show join link only. Removing this parameter from shortcode will output description.', 'wp-event-manager-zoom' ); ?></p>
			<p><?php _e( '<b>show_help:</b> Yes or No - Adding yes will show join mobile app link only and download mobile app.', 'wp-event-manager-zoom' ); ?></p>


			<h3><?php _e( 'Front side', 'wp-event-manager-zoom' ); ?></h3>

			<h4>[submit_zoom_meeting_form]</h4>
			<p><?php _e( 'Create Zoom Meeting / Webinar from frontend side', 'wp-event-manager-zoom' ); ?></p>

			<h4>[zoom_meeting_dashboard]</h4>
			<p><?php _e( 'Manage Zoom Meeting / Webinar from frontend side', 'wp-event-manager-zoom' ); ?></p>

			<?php
		}
	}


}