<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
if ( ! class_exists( 'WP_Event_Manager_Writepanels' ) && defined( 'EVENT_MANAGER_PLUGIN_DIR' ) ) {
	include( EVENT_MANAGER_PLUGIN_DIR . '/admin/wp-event-manager-writepanels.php' );
}

/**
 * WPEM_Zoom_Writepanels class.
 */
if ( class_exists( 'WP_Event_Manager_Writepanels' ) ) 
{
	class WPEM_Zoom_Writepanels extends WP_Event_Manager_Writepanels {

		/**
		 * Post Type Flag
		 * @var string
		 */
		private $post_type = 'event_zoom';

		/**
		 * Constructor - get the plugin hooked in and ready
		 */
		public function __construct() {

			$this->user_page = new WPEM_Zoom_User();

			add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
			add_action( 'save_post', array( $this, 'save_post' ), 1, 2 );
			add_action( 'before_delete_post', array( $this, 'delete' ) );
			
			add_filter( 'manage_event_zoom_posts_columns', array( $this, 'add_columns' ), 10 );
			add_action( 'manage_event_zoom_posts_custom_column', array( $this, 'render_data' ), 10, 2 );

			// add and save zoom connection tab in woocoomerce 
			add_filter( 'woocommerce_product_data_tabs', array( $this, 'add_zoom_meeting_tab' ));
			add_filter( 'woocommerce_product_data_panels', array( $this, 'zoom_meeting_product_tab_content' ));
			add_action( 'woocommerce_process_product_meta_event_ticket', array( $this, 'save_zoom_meeting_fields' ));
			add_action( 'woocommerce_process_product_meta_simple', array( $this, 'save_zoom_meeting_fields' ));
			
		}

		/**
		 * add_meta_boxes function.
		 * 
		 * @access public
		 * @param 
		 * @return 
		 * @since 1.0.3
		 */
		public function zoom_meeting_fields() {
			global $post;
			$current_user = wp_get_current_user();

			$GLOBALS['event_manager_zoom']->forms->get_form( 'submit-event-zoom', array() );
			$form_submit_event_zoom_instance = call_user_func( array( 'WPEM_Zoom_Form_Submit_Event_Zoom', 'instance' ) );
			$fields = $form_submit_event_zoom_instance->merge_with_custom_fields();

			foreach ($fields as $group_key => $group_fields) 
			{
				foreach ($group_fields as $field_key => $field_value) 
				{
					if( strpos($field_key, '_') !== 0 ) {
						$fields['_'.$field_key]  = $field_value;	
					}else{
						$fields[$field_key]  = $field_value;	
					}
				}

				unset($fields[$group_key]);
			}

			$fields = apply_filters( 'event_manager_event_zoom_data_fields', $fields );

			if(isset($fields['_event_zoom_name']))
				unset($fields['_event_zoom_name']);

			if(isset($fields['_event_zoom_description']))
				unset($fields['_event_zoom_description']);

			if(isset($fields['_site_option_logged_in']))
				unset($fields['_site_option_logged_in']);

			if(isset($fields['_site_option_browser_join']))
				unset($fields['_site_option_browser_join']);

			if(isset($fields['_enable_wc_purchase']))
				unset($fields['_enable_wc_purchase']);

			if(isset($fields['_meeting_wc_product_price']))
				unset($fields['_meeting_wc_product_price']);

			if(isset($fields['_meeting_wc_product_id']))
				unset($fields['_meeting_wc_product_id']);

			if(isset($fields['_meeting_wc_product_show_ticket_buy_button']))
				unset($fields['_meeting_wc_product_show_ticket_buy_button']);

			return $fields;
		}

		/**
		 * add_meta_boxes function.
		 * 
		 * @access public
		 * @param 
		 * @return 
		 * @since 1.0.0
		 */
		public function add_meta_boxes() {
			global $wp_post_types;

			add_meta_box( 'event_zoom_meeting_data', sprintf( __( '%s Data', 'wp-event-manager-zoom' ), $wp_post_types[$this->post_type]->labels->singular_name ), array( $this, 'event_zoom_meeting_data' ), $this->post_type, 'normal', 'high' );

			add_meta_box( 'event_zoom_meeting_detail', __( 'Meeting Details', 'wp-event-manager-zoom' ), array($this, 'event_zoom_meeting_detail'), $this->post_type, 'side', 'high' );

			if ( is_plugin_active( 'woocommerce/woocommerce.php') ) 
			{
				add_meta_box( 'event_zoom_meeting_wc', __( 'WooCommerce Integration', 'wp-event-manager-zoom' ), array($this, 'event_zoom_meeting_wc'), $this->post_type, 'side', 'high' );
			}
		}

		/**
		 * event_zoom_meeting_data function.
		 * add meeting data meta box
		 * @access public
		 * @param $post
		 * @return 
		 * @since 1.0.0
		 */
		public function event_zoom_meeting_data($post) {
			global $post, $thepostid;
			$thepostid = $post->ID;

			wp_enqueue_style( 'jquery-ui' );
			wp_enqueue_style( 'wp-event-manager-zoom-backend' );

			wp_enqueue_script( 'jquery-ui-datepicker' );
			wp_enqueue_script( 'wp-event-manager-jquery-timepicker' );		
			wp_enqueue_script( 'wp-event-manager-zoom-admin-zoom' );

			echo '<div class="wp_event_manager_meta_data zoom-metabox-wrapper zoom-meeting-data">';
			wp_nonce_field( 'save_meta_data', 'event_manager_zoom_nonce' );
			do_action( 'event_manager_event_zoom_data_start', $thepostid );

			$meeting_id = get_post_meta($thepostid, '_meeting_zoom_meeting_id', true);
			?>

			<?php if( isset($meeting_id) && !empty($meeting_id) ) : ?>
			<p class="form-field">
				<label for="_meeting_start_date"><?php _e('Shortcode', 'wp-event-manager-zoom'); ?>:</label>
				<input id="meeting-shortcode" type="text" value='[event_zoom_meeting meeting_id="<?php echo $meeting_id; ?>" link_only="no"]' onclick="this.select(); document.execCommand('copy'); alert('Copied to clipboard');">
			</p>
			<?php endif; ?>

			<?php
			foreach ( $this->zoom_meeting_fields() as $key => $field ) {
				$type = !empty( $field['type'] ) ? $field['type'] : 'text';
				if($type == 'wp-editor') $type = 'textarea';

	            if ( has_action( 'event_manager_input_' . $type ) ) {
					do_action( 'event_manager_input_' . $type, $key, $field );
				} elseif ( method_exists( $this, 'input_' . $type ) ) {
					call_user_func( array( $this, 'input_' . $type ), $key, $field );
				}
			}

			do_action( 'event_manager_event_zoom_data_end', $thepostid );
			echo '</div>';
		}

		/**
		 * event_zoom_meeting_detail function.
		 * add meeting details meta box
		 * @access public
		 * @param $post
		 * @return 
		 * @since 1.0.0
		 */
		public function event_zoom_meeting_detail($post) {

			// Add nonce for security and authentication.
			wp_nonce_field( 'save_meta_data', 'event_manager_zoom_nonce' );

			$meeting_fields = get_meeting_fields($post->ID);
			$meeting_details = get_post_meta( $post->ID, '_meeting_zoom_details', true );
			$meeting_error = get_post_meta( $post->ID, '_meeting_zoom_error', true );

			get_event_manager_template( 
				'zoom-meeting-detail.php', 
				array(
					'meeting_fields' => $meeting_fields,
					'meeting_details' => $meeting_details,
					'meeting_error' => $meeting_error,
					'post' => $post,
				), 
				'wp-event-manager-zoom', 
				WPEM_ZOOM_PLUGIN_DIR . '/templates/admin/'
			);
		}

		/**
		 * event_zoom_meeting_wc function.
		 * add meeting as product in woocoomerce meta box
		 * @access public
		 * @param $post
		 * @return 
		 * @since 1.0.0
		 */
		public function event_zoom_meeting_wc($post){
			// Add nonce for security and authentication.
			wp_nonce_field( 'save_meta_data', 'event_manager_zoom_nonce' );

			wp_enqueue_style( 'wp-event-manager-zoom-backend' );

			wp_enqueue_script( 'wp-event-manager-zoom-admin-zoom' );

			$meeting_wc_product = get_post_meta($post->ID, '_meeting_wc_product', true );

			get_event_manager_template( 
				'zoom-meeting-woocommerce.php', 
				array(
					'meeting_wc_product' => $meeting_wc_product,
					'post' => $post,
				), 
				'wp-event-manager-zoom', 
				WPEM_ZOOM_PLUGIN_DIR . '/templates/admin/'
			);
		}

		/**
		 * save_post function.
		 *
		 * @access public
		 * @param $post_id, $post
		 * @return 
		 * @since 1.0.0
		 */
		public function save_post( $post_id, $post ) {
			if ( empty( $post_id ) || empty( $post ) || empty( $_POST ) ) return;
			if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
			if ( is_int( wp_is_post_revision( $post ) ) ) return;
			if ( is_int( wp_is_post_autosave( $post ) ) ) return;
			if ( empty($_POST['event_manager_zoom_nonce']) || ! wp_verify_nonce( $_POST['event_manager_zoom_nonce'], 'save_meta_data' ) ) return;
			if ( ! current_user_can( 'edit_post', $post_id ) ) return;
			if ( $post->post_type !== $this->post_type ) return;

			
			$pwd = sanitize_text_field( filter_input( INPUT_POST, '_meeting_password' ) );
			$pwd = !empty( $pwd ) ? $pwd : $post_id;

			//timezone field if setting is site wise timezone
			$timezone_setting = get_option( 'event_manager_timezone_setting' ,'site_timezone' );
			if ( $timezone_setting != 'each_event' ) 
			{
				$timezone = WP_Event_Manager_Date_Time::get_current_site_timezone();
			}
			else
			{
				$timezone = sanitize_text_field( filter_input( INPUT_POST, '_meeting_timezone' ) );
			}

			//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
			$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
			
			//covert datepicker format  into php date() function date format
			$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

			$meeting_date = sanitize_text_field( filter_input( INPUT_POST, '_meeting_start_date' ) );
			$meeting_start_date = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format, $meeting_date);
			$meeting_start_date = !empty($meeting_start_date) ? $meeting_start_date : $meeting_date;

			$meeting_time = sanitize_text_field( filter_input( INPUT_POST, '_meeting_start_time' ) );
			$meeting_start_time = WP_Event_Manager_Date_Time::get_db_formatted_time($meeting_time);
			$meeting_start_time = !empty($meeting_start_time) ? $meeting_start_time : $meeting_time;

			$params = array(
				'event_zoom_name'                   => $post->post_title,
				'event_zoom_description'            => $post->post_content,
				'meeting_userId'                    => sanitize_text_field( filter_input( INPUT_POST, '_meeting_userId' ) ),
				'meeting_type'                    	=> sanitize_text_field( filter_input( INPUT_POST, '_meeting_type' ) ),
				'meeting_start_date'                => $meeting_start_date,
				'meeting_start_time'                => $meeting_start_time,
				'meeting_timezone'                  => $timezone,
				'meeting_duration'                  => sanitize_text_field( filter_input( INPUT_POST, '_meeting_duration' ) ),
				'meeting_password'                  => $pwd,
				'meeting_option_authentication'     => filter_input( INPUT_POST, '_meeting_option_authentication' ),
				'meeting_option_registration'      	=> filter_input( INPUT_POST, '_meeting_option_registration' ),
				'meeting_option_approval_type'     	=> filter_input( INPUT_POST, '_meeting_option_approval_type' ),
				'meeting_option_join_before_host'	=> filter_input( INPUT_POST, '_meeting_option_join_before_host' ),
				'meeting_option_host_video'         => filter_input( INPUT_POST, '_meeting_option_host_video' ),
				'meeting_option_participants_video' => filter_input( INPUT_POST, '_meeting_option_participants_video' ),
				'meeting_option_mute_participants'  => filter_input( INPUT_POST, '_meeting_option_mute_participants' ),
				'meeting_option_auto_recording'     => filter_input( INPUT_POST, '_meeting_option_auto_recording' ),
				'meeting_option_panelists_video'    => filter_input( INPUT_POST, '_meeting_option_panelists_video' ),
				'meeting_option_practice_session'   => filter_input( INPUT_POST, '_meeting_option_practice_session' ),
				'meeting_option_hd_video'     		=> filter_input( INPUT_POST, '_meeting_option_hd_video' ),
				'meeting_option_allow_multiple_devices'	=> filter_input( INPUT_POST, '_meeting_option_allow_multiple_devices' ),
				'meeting_alternative_host_ids'      => filter_input( INPUT_POST, '_meeting_alternative_host_ids', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY )
			);

			$params['site_option_logged_in']        = filter_input( INPUT_POST, '_site_option_logged_in' );
			$params['site_option_browser_join']     = filter_input( INPUT_POST, '_site_option_browser_join' );

			foreach ($params as $key => $value) {
				update_post_meta( $post_id, '_' . $key, $value );
			}

			if ( is_plugin_active( 'woocommerce/woocommerce.php') ) 
			{
				$meeting_wc_product = [];
				$meeting_wc_product['enable_wc_purchase'] 		= filter_input( INPUT_POST, 'enable_wc_purchase' );
				$meeting_wc_product['meeting_wc_product_price'] = sanitize_text_field( filter_input( INPUT_POST, 'meeting_wc_product_price' ) );
				$meeting_wc_product['meeting_wc_product_id'] 	= sanitize_text_field( filter_input( INPUT_POST, 'meeting_wc_product_id' ) );
				$meeting_wc_product['meeting_wc_product_show_ticket_buy_button'] 	= sanitize_text_field( filter_input( INPUT_POST, 'meeting_wc_product_show_ticket_buy_button' ) );

				if($meeting_wc_product['enable_wc_purchase'] && empty($meeting_wc_product['meeting_wc_product_id']))
				{
					$product_id = wp_insert_post( array(
								'post_type'     => 'product',
								'post_title'    => $post->post_title,
								'post_content'  => $post->post_content,
								'post_status'   => 'publish',
							) );	

					$meeting_wc_product['meeting_wc_product_id'] = $product_id;
				}			

				if($meeting_wc_product['enable_wc_purchase'] && !empty($meeting_wc_product['meeting_wc_product_id']))
				{
					$is_virtual = apply_filters('meeting_wc_is_virtual','yes');
					$sold_individually = apply_filters('meeting_wc_sold_individually','yes');

					update_post_meta($meeting_wc_product['meeting_wc_product_id'], '_regular_price', $meeting_wc_product['meeting_wc_product_price'] );
					update_post_meta($meeting_wc_product['meeting_wc_product_id'], '_price', $meeting_wc_product['meeting_wc_product_price'] );
					update_post_meta($meeting_wc_product['meeting_wc_product_id'], '_virtual', $is_virtual);
					update_post_meta($meeting_wc_product['meeting_wc_product_id'], '_sold_individually', $sold_individually );

					update_post_meta($meeting_wc_product['meeting_wc_product_id'], '_event_zoom_id', $post_id );

					$meeting_wc_product['meeting_wc_product_show_ticket_buy_button'] = !empty($meeting_wc_product['meeting_wc_product_show_ticket_buy_button']) ? $meeting_wc_product['meeting_wc_product_show_ticket_buy_button'] : '0';
					update_post_meta($post_id, '_meeting_wc_product', $meeting_wc_product );
				}
				else
				{
					update_post_meta($post_id, '_meeting_wc_product', '' );	
				}
				
			}

			//Create Zoom Meeting Now
			$meeting_id = get_post_meta( $post_id, '_meeting_zoom_meeting_id', true );

			if($params['meeting_type'] === 'webinar')
			{
				if ( empty( $meeting_id ) ) {
					//Create new Zoom Meeting
					$this->create_zoom_webinar( $post );
				} else {
					//Update Zoom Meeting
					$this->update_zoom_webinar( $post, $meeting_id );
				}
			}
			else
			{
				if ( empty( $meeting_id ) ) {
					//Create new Zoom Meeting
					$this->create_zoom_meeting( $post );
				} else {
					//Update Zoom Meeting
					$this->update_zoom_meeting( $post, $meeting_id );
				}
			}
		}


		/**
		 * create_zoom_meeting function.
		 * create zoom meeting
		 * @access private
		 * @param $post
		 * @return 
		 * @since 1.0.0
		 */
		private function create_zoom_meeting( $post ) {
			$pwd       = sanitize_text_field( filter_input( INPUT_POST, '_meeting_password' ) );
			$pwd       = !empty( $pwd ) ? $pwd : $post->ID;

			//timezone field if setting is site wise timezone
			$timezone_setting = get_option( 'event_manager_timezone_setting' ,'site_timezone' );
			if ( $timezone_setting != 'each_event' ) 
			{
				$timezone = WP_Event_Manager_Date_Time::get_current_site_timezone();
			}
			else
			{
				$timezone = sanitize_text_field( filter_input( INPUT_POST, '_meeting_timezone' ) );
			}

			//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
			$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
			
			//covert datepicker format  into php date() function date format
			$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

			$meeting_start_date = sanitize_text_field( filter_input( INPUT_POST, '_meeting_start_date' ) );
			$meeting_start_time = sanitize_text_field( filter_input( INPUT_POST, '_meeting_start_time' ) );

			$meeting_start_time = WP_Event_Manager_Date_Time::get_db_formatted_time($meeting_start_time);

			$date =  $meeting_start_date.' '.$meeting_start_time ;

			$meeting_start_date_time = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format . ' H:i:s', $date);
			$meeting_start_date_time = !empty($meeting_start_date_time) ? $meeting_start_date_time : $date;

			$params = array(
				'userId'                    => sanitize_text_field( filter_input( INPUT_POST, '_meeting_userId' ) ),
				'topic'              		=> $post->post_title,
				'start_date'                => $meeting_start_date_time,
				'timezone'                  => $timezone,
				'duration'                  => sanitize_text_field( filter_input( INPUT_POST, '_meeting_duration' ) ),
				'password'                  => $pwd,
				'option_meeting_authentication'	=> filter_input( INPUT_POST, '_meeting_option_authentication' ),
				'option_registration' 		=> filter_input( INPUT_POST, '_meeting_option_registration' ),
				'option_approval_type' 		=> filter_input( INPUT_POST, '_meeting_option_approval_type' ),
				'option_join_before_host'   => filter_input( INPUT_POST, '_meeting_option_join_before_host' ),
				'option_host_video'         => filter_input( INPUT_POST, '_meeting_option_host_video' ),
				'option_participants_video' => filter_input( INPUT_POST, '_meeting_option_participants_video' ),
				'option_mute_participants'  => filter_input( INPUT_POST, '_meeting_option_mute_participants' ),
				'option_auto_recording'     => filter_input( INPUT_POST, '_meeting_option_auto_recording' ),
				'alternative_host_ids'      => filter_input( INPUT_POST, '_meeting_alternative_host_ids', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY )
			);

			$meeting_created = json_decode( WPEM_Zoom_API()->createAMeeting( $params ) );

			if ( empty( $meeting_created->code ) ) {
				if ( !empty($meeting_created) && isset($meeting_created->id) && !empty($meeting_created->id) ) {
					update_post_meta( $post->ID, '_meeting_zoom_details', $meeting_created );
					update_post_meta( $post->ID, '_meeting_zoom_join_url', $meeting_created->join_url );
					update_post_meta( $post->ID, '_meeting_zoom_start_url', $meeting_created->start_url );
					update_post_meta( $post->ID, '_meeting_zoom_meeting_id', $meeting_created->id );
					update_post_meta( $post->ID, '_meeting_zoom_error', '' );
				}
			}
			else
			{
				update_post_meta( $post->ID, '_meeting_zoom_error', $meeting_created );
			}
		}

		/**
		 * update_zoom_meeting function.
		 * update zoom meeting
		 * @access private
		 * @param $post, $meeting_id
		 * @return 
		 * @since 1.0.0
		 */
		private function update_zoom_meeting( $post, $meeting_id ) {
			$pwd       = sanitize_text_field( filter_input( INPUT_POST, '_meeting_password' ) );
			$pwd       = !empty( $pwd ) ? $pwd : $post->ID;

			//timezone field if setting is site wise timezone
			$timezone_setting = get_option( 'event_manager_timezone_setting' ,'site_timezone' );
			if ( $timezone_setting != 'each_event' ) 
			{
				$timezone = WP_Event_Manager_Date_Time::get_current_site_timezone();
			}
			else
			{
				$timezone = sanitize_text_field( filter_input( INPUT_POST, '_meeting_timezone' ) );
			}

			//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
			$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
			
			//covert datepicker format  into php date() function date format
			$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

			$meeting_start_date = sanitize_text_field( filter_input( INPUT_POST, '_meeting_start_date' ) );
			$meeting_start_time = sanitize_text_field( filter_input( INPUT_POST, '_meeting_start_time' ) );

			$meeting_start_time = WP_Event_Manager_Date_Time::get_db_formatted_time($meeting_start_time);

			$date =  $meeting_start_date.' '.$meeting_start_time ;

			$meeting_start_date_time = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format . ' H:i:s', $date);
			$meeting_start_date_time = !empty($meeting_start_date_time) ? $meeting_start_date_time : $date;

			$params = array(
				'meeting_id'                => $meeting_id,
				'topic'                     => $post->post_title,
				'start_date'                => $meeting_start_date_time,
				'timezone'                  => $timezone,
				'duration'                  => sanitize_text_field( filter_input( INPUT_POST, '_meeting_duration' ) ),
				'password'                  => $pwd,
				'option_meeting_authentication'	=> filter_input( INPUT_POST, '_meeting_option_authentication' ),
				'option_registration'       => filter_input( INPUT_POST, '_meeting_option_registration' ),
				'option_approval_type' 		=> filter_input( INPUT_POST, '_meeting_option_approval_type' ),
				'option_join_before_host'   => filter_input( INPUT_POST, '_meeting_option_join_before_host' ),
				'option_host_video'         => filter_input( INPUT_POST, '_meeting_option_host_video' ),
				'option_participants_video' => filter_input( INPUT_POST, '_meeting_option_participants_video' ),
				'option_mute_participants'  => filter_input( INPUT_POST, '_meeting_option_mute_participants' ),
				'option_auto_recording'     => filter_input( INPUT_POST, '_meeting_option_auto_recording' ),
				'alternative_host_ids'      => filter_input( INPUT_POST, '_meeting_alternative_host_ids', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY )
			);

			$meeting_updated = json_decode( WPEM_Zoom_API()->updateMeetingInfo( $params ) );

			if ( empty( $meeting_updated->code ) ) {
				$meeting_info = json_decode( WPEM_Zoom_API()->getMeetingInfo( $meeting_id ) );
				if ( !empty($meeting_info) && isset($meeting_info->id) && !empty($meeting_info->id) ) {
					update_post_meta( $post->ID, '_meeting_zoom_details', $meeting_info );
					update_post_meta( $post->ID, '_meeting_zoom_join_url', $meeting_info->join_url );
					update_post_meta( $post->ID, '_meeting_zoom_start_url', $meeting_info->start_url );
					update_post_meta( $post->ID, '_meeting_zoom_meeting_id', $meeting_info->id );
					update_post_meta( $post->ID, '_meeting_zoom_error', '' );
				}
			}
			else
			{
				update_post_meta( $post->ID, '_meeting_zoom_error', $meeting_updated );
			}
		}

		/**
		 * create_zoom_webinar function.
		 * create zoom webinar
		 * @access private
		 * @param $post
		 * @return 
		 * @since 1.0.3
		 */
		private function create_zoom_webinar( $post ) {
			$pwd       = sanitize_text_field( filter_input( INPUT_POST, '_meeting_password' ) );
			$pwd       = !empty( $pwd ) ? $pwd : $post->ID;

			//timezone field if setting is site wise timezone
			$timezone_setting = get_option( 'event_manager_timezone_setting' ,'site_timezone' );
			if ( $timezone_setting != 'each_event' ) 
			{
				$timezone = WP_Event_Manager_Date_Time::get_current_site_timezone();
			}
			else
			{
				$timezone = sanitize_text_field( filter_input( INPUT_POST, '_meeting_timezone' ) );
			}

			//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
			$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
			
			//covert datepicker format  into php date() function date format
			$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

			$meeting_start_date = sanitize_text_field( filter_input( INPUT_POST, '_meeting_start_date' ) );
			$meeting_start_time = sanitize_text_field( filter_input( INPUT_POST, '_meeting_start_time' ) );

			$meeting_start_time = WP_Event_Manager_Date_Time::get_db_formatted_time($meeting_start_time);

			$date =  $meeting_start_date.' '.$meeting_start_time ;

			$meeting_start_date_time = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format . ' H:i:s', $date);
			$meeting_start_date_time = !empty($meeting_start_date_time) ? $meeting_start_date_time : $date;

			$params = array(
				'userId'                    => sanitize_text_field( filter_input( INPUT_POST, '_meeting_userId' ) ),
				'topic'              		=> $post->post_title,
				'start_date'                => $meeting_start_date_time,
				'timezone'                  => $timezone,
				'duration'                  => sanitize_text_field( filter_input( INPUT_POST, '_meeting_duration' ) ),
				'password'                  => $pwd,
				'option_meeting_authentication'	=> filter_input( INPUT_POST, '_meeting_option_authentication' ),
				'option_registration' 		=> filter_input( INPUT_POST, '_meeting_option_registration' ),
				'option_approval_type' 		=> filter_input( INPUT_POST, '_meeting_option_approval_type' ),
				'option_host_video'         => filter_input( INPUT_POST, '_meeting_option_host_video' ),
				'option_panelists_video'    => filter_input( INPUT_POST, '_meeting_option_panelists_video' ),
				'option_practice_session'   => filter_input( INPUT_POST, '_meeting_option_practice_session' ),
				'option_hd_video'         	=> filter_input( INPUT_POST, '_meeting_option_hd_video' ),
				'option_allow_multiple_devices'	=> filter_input( INPUT_POST, '_meeting_option_allow_multiple_devices' ),
				'option_auto_recording'     => filter_input( INPUT_POST, '_meeting_option_auto_recording' ),
				'alternative_host_ids'      => filter_input( INPUT_POST, '_meeting_alternative_host_ids', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY )
			);

			$webinar_created = json_decode( WPEM_Zoom_API()->createAWebinar( $params ) );

			if ( empty( $webinar_created->code ) ) {
				if ( !empty($webinar_created) && isset($webinar_created->id) && !empty($webinar_created->id) ) {
					update_post_meta( $post->ID, '_meeting_zoom_details', $webinar_created );
					update_post_meta( $post->ID, '_meeting_zoom_join_url', $webinar_created->join_url );
					update_post_meta( $post->ID, '_meeting_zoom_start_url', $webinar_created->start_url );
					update_post_meta( $post->ID, '_meeting_zoom_meeting_id', $webinar_created->id );
					update_post_meta( $post->ID, '_meeting_zoom_error', '' );
				}
			}
			else
			{
				update_post_meta( $post->ID, '_meeting_zoom_error', $webinar_created );
			}
		}

				/**
		 * update_zoom_meeting function.
		 * update zoom meeting
		 * @access private
		 * @param $post, $webinar_id
		 * @return 
		 * @since 1.0.0
		 */
		private function update_zoom_webinar( $post, $webinar_id ) {
			$pwd       = sanitize_text_field( filter_input( INPUT_POST, '_meeting_password' ) );
			$pwd       = !empty( $pwd ) ? $pwd : $post->ID;

			//timezone field if setting is site wise timezone
			$timezone_setting = get_option( 'event_manager_timezone_setting' ,'site_timezone' );
			if ( $timezone_setting != 'each_event' ) 
			{
				$timezone = WP_Event_Manager_Date_Time::get_current_site_timezone();
			}
			else
			{
				$timezone = sanitize_text_field( filter_input( INPUT_POST, '_meeting_timezone' ) );
			}

			//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
			$datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
			
			//covert datepicker format  into php date() function date format
			$php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );

			$meeting_start_date = sanitize_text_field( filter_input( INPUT_POST, '_meeting_start_date' ) );
			$meeting_start_time = sanitize_text_field( filter_input( INPUT_POST, '_meeting_start_time' ) );

			$meeting_start_time = WP_Event_Manager_Date_Time::get_db_formatted_time($meeting_start_time);

			$date =  $meeting_start_date.' '.$meeting_start_time ;

			$meeting_start_date_time = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format . ' H:i:s', $date);
			$meeting_start_date_time = !empty($meeting_start_date_time) ? $meeting_start_date_time : $date;

			$params = array(
				'webinar_id'                => $webinar_id,
				'topic'                     => $post->post_title,
				'start_date'                => $meeting_start_date_time,
				'timezone'                  => $timezone,
				'duration'                  => sanitize_text_field( filter_input( INPUT_POST, '_meeting_duration' ) ),
				'password'                  => $pwd,
				'option_meeting_authentication'	=> filter_input( INPUT_POST, '_meeting_option_authentication' ),
				'option_registration' 		=> filter_input( INPUT_POST, '_meeting_option_registration' ),
				'option_approval_type' 		=> filter_input( INPUT_POST, '_meeting_option_approval_type' ),
				'option_host_video'         => filter_input( INPUT_POST, '_meeting_option_host_video' ),
				'option_panelists_video'    => filter_input( INPUT_POST, '_meeting_option_panelists_video' ),
				'option_practice_session'   => filter_input( INPUT_POST, '_meeting_option_practice_session' ),
				'option_hd_video'         	=> filter_input( INPUT_POST, '_meeting_option_hd_video' ),
				'option_allow_multiple_devices'	=> filter_input( INPUT_POST, '_meeting_option_allow_multiple_devices' ),
				'option_auto_recording'     => filter_input( INPUT_POST, '_meeting_option_auto_recording' ),
				'alternative_host_ids'      => filter_input( INPUT_POST, '_meeting_alternative_host_ids', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY )
			);

			$webinar_updated = json_decode( WPEM_Zoom_API()->updateWebinar( $params ) );

			if ( empty( $webinar_updated->code ) ) {
				$webinar_info = json_decode( WPEM_Zoom_API()->getWebinarInfo( $webinar_id ) );
				if ( !empty($webinar_info) && isset($webinar_info->id) && !empty($webinar_info->id) ) {
					update_post_meta( $post->ID, '_meeting_zoom_details', $webinar_info );
					update_post_meta( $post->ID, '_meeting_zoom_join_url', $webinar_info->join_url );
					update_post_meta( $post->ID, '_meeting_zoom_start_url', $webinar_info->start_url );
					update_post_meta( $post->ID, '_meeting_zoom_meeting_id', $webinar_info->id );
					update_post_meta( $post->ID, '_meeting_zoom_error', '' );
				}
			}
			else
			{
				update_post_meta( $post->ID, '_meeting_zoom_error', $webinar_updated );
			}
		}

		/**
		 * delete function.
		 * delete meeting in zoom account and our database
		 * @access public
		 * @param $post_id
		 * @return 
		 * @since 1.0.0
		 */
		public function delete( $post_id ) 
		{
			if ( get_post_type( $post_id ) === $this->post_type ) 
			{
				$meeting_id = get_post_meta( $post_id, '_meeting_zoom_meeting_id', true );				
				$meeting_type = get_post_meta( $post_id, '_meeting_type', true );

				if ( !empty( $meeting_id ) ) 
				{
					if( $meeting_type === 'webinar' )
					{
						WPEM_Zoom_API()->deleteAWebinar( $meeting_id );
					}
					else
					{
						WPEM_Zoom_API()->deleteAMeeting( $meeting_id );	
					}					
				}
			}
		}

		/**
		 * add_columns function.
		 *
		 * @access public
		 * @param $columns
		 * @return 
		 * @since 1.0.0
		 */
		public function add_columns( $columns ) {

			$columns['zoom_meeting_id']        = __( 'Meeting ID', 'wp-event-manager-zoom' );
			$columns['zoom_meeting_type']      = __( 'Meeting Type', 'wp-event-manager-zoom' );
			$columns['zoom_meeting_startdate'] = __( 'Start Date & Time', 'wp-event-manager-zoom' );
			$columns['zoom_meeting_end']       = __( 'Status', 'wp-event-manager-zoom' );

			unset( $columns['author'] );

			return $columns;
		}

		/**
		 * render_data function.
		 *
		 * @access public
		 * @param $column, $post_id
		 * @return 
		 * @since 1.0.0
		 */
		public function render_data( $column, $post_id ) {

			wp_enqueue_style( 'wp-event-manager-zoom-backend' );
			wp_enqueue_script( 'wp-event-manager-zoom-admin-zoom' );
			
			$meeting = get_post_meta( $post_id, '_meeting_zoom_details', true );
			$meeting_type = get_post_meta( $post_id, '_meeting_type', true );
			$meeting_occurrence_id = get_post_meta( $post_id, '_meeting_occurrence_id', true );

			if( !empty($meeting) && !isset($meeting->state) )
			{
				$meeting->state = '';
			}

			switch ( $column ) {
				case 'zoom_meeting_startdate' :
					if ( !empty( $meeting ) && isset($meeting->type) && !empty( $meeting->start_time ) ) {
						echo event_manager_zoom_date_converter( $meeting->start_time, $meeting->timezone, 'F j, Y, g:i a' );
					} else {
						_e( ' - ', 'wp-event-manager-zoom' );
					}
					break;
				case 'zoom_meeting_type' :
					$meeting_type === 'webinar' ? _e( 'Webinar', 'wp-event-manager-zoom' ) : _e( 'Meeting', 'wp-event-manager-zoom' );
					if ( !empty( $meeting ) && isset($meeting->type) && in_array($meeting->type, [3, 8, 9]) ) {
						echo ' (' . __( 'Recurring', 'wp-event-manager-zoom' ) . ')';
					}
					break;
				case 'zoom_meeting_id' :
					if ( !empty( $meeting ) && isset($meeting->id) && !empty( $meeting->id ) ) {
						echo $meeting->id;
					} else {
						_e( ' - ', 'wp-event-manager-zoom' );
					}
					break;
				case 'zoom_meeting_end' :				
					if ( !empty( $meeting ) && !empty( $meeting->id ) ) {

						if ( isset($meeting->state) && $meeting->state=='started' ) : ?>
							<a href="javascript:void(0);" class="change-zoom-meeting-state button" data-type="post_type" data-state="end" data-postid="<?php echo $post_id; ?>" data-id="<?php echo isset($meeting->id) ? $meeting->id : ''; ?>"><?php _e( 'End', 'wp-event-manager-zoom' ); ?></a>
						<?php else : ?>
							<a href="<?php echo isset($meeting->start_url) ? $meeting->start_url : 'javascript:void(0)'; ?>" target="_blank" class="change-zoom-meeting-state button" data-type="post_type" data-state="start" data-postid="<?php echo $post_id; ?>" data-id="<?php echo isset($meeting->id) ? $meeting->id : ''; ?>"><?php _e( 'Start', 'wp-event-manager-zoom' ); ?></a>
						<?php endif;

					} 
					else {
						echo  __( 'Meeting not synced with Zoom', 'wp-event-manager-zoom' ).' <div class="wpem-tooltip wpem-tooltip-top wpem-icon-question"><span class="wpem-tooltiptext">'. __( 'Meeting created at local but not created at Zoom. After Syncing with Zoom, It will create at Zoom.', 'wp-event-manager-zoom' ) .'</span></div>';
					}
					break;
			}
		}

		/**
		 * add_zoom_meeting_tab function.
		 * add new tab in woocoomerce product in admin side
		 * @access public
		 * @param $tabs
		 * @return 
		 * @since 1.0.0
		 */
		public function add_zoom_meeting_tab( $tabs) 
		{
			$tabs['zoom_meeting'] = array(
				'label'		=> __( 'Zoom meeting', 'woocommerce' ),
				'target'	=> 'zoom_meeting',
				'class'		=> array( 'show_if_simple','show_if_event_ticket'  ),
			);

			return $tabs;
		}

		/**
		 * zoom_meeting_product_tab_content function.
		 * woocoomerce product Zoom meeting tab content in admin side
		 * @access public
		 * @param 
		 * @return 
		 * @since 1.0.0
		 */
		public function zoom_meeting_product_tab_content() 
		{
			global $post;

			wp_enqueue_style('wp-event-manager-zoom-backend');

			$result = get_event_manager_zoom_meeting_list();

			$event_meeting_list = [];

			if($result->found_posts > 0)
			{
				$event_meeting_list[''] =  __( 'Select Zoom Meeting / Webinar', 'wp-event-manager-zoom' );

				foreach ($result->posts as $event_zoom) 
				{
					$meeting_id = get_post_meta( $event_zoom->ID, '_meeting_zoom_meeting_id', true );

					if ( !empty( $meeting_id ) ) 
					{
						$event_meeting_list[$event_zoom->ID] = $event_zoom->post_title;
					}
				}
			}

			$event_zoom_id  = get_post_meta( $post->ID, '_event_zoom_id', true );
			
			?>
			<div id='zoom_meeting' class='panel woocommerce_options_panel'><?php

				?><div class='options_group'><?php

					woocommerce_wp_select( array(
				        'id'      => 'event_zoom_id',
				        'label'   => __( 'Select Zoom Meeting / Webinar ID', 'wp-event-manager-zoom' ),
				        'options' =>  $event_meeting_list, //this is where I am having trouble
				        'value'   => $event_zoom_id,
				    ));

				    if(!empty($event_zoom_id))
				    {
				    	echo do_shortcode( '[event_zoom_meeting_detail event_zoom_id="'. $event_zoom_id .'"]' );
				    }

				?></div>

			</div><?php
		}

		/**
		 * save_zoom_meeting_fields function.
		 * save zoom meeting while create and update product
		 * @access public
		 * @param $post_id
		 * @return 
		 * @since 1.0.0
		 */
		public function save_zoom_meeting_fields( $post_id ) 
		{	
			$event_zoom_id  = isset($_POST['event_zoom_id']) ? $_POST['event_zoom_id'] : '';

			update_post_meta( $post_id, '_event_zoom_id', $event_zoom_id );
		}
		
	}

	new WPEM_Zoom_Writepanels();
}