<?php
class WPEM_Zoom_Admin {

	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function __construct() {

		include_once( WPEM_ZOOM_PLUGIN_DIR . '/admin/wpem-zoom-setup.php' );
		include_once( WPEM_ZOOM_PLUGIN_DIR . '/admin/wpem-zoom-writepanels.php' );
		include_once (WPEM_ZOOM_PLUGIN_DIR . '/admin/wpem-zoom-reports.php' );
		include_once (WPEM_ZOOM_PLUGIN_DIR . '/admin/wpem-zoom-settings.php' );

		add_action( 'admin_menu', array( $this, 'admin_menu' ), 12 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );

		$this->user_page = new WPEM_Zoom_User();
		$this->reports_page = new WPEM_Zoom_Reports();
		$this->settings_page = new WPEM_Zoom_Settings();
	}

	/**
	 * admin_menu function.
	 * register menu in admin side
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function admin_menu() 
	{
		add_submenu_page( 'edit.php?post_type=event_zoom', __( 'WP Event Manager Zoom Users', 'wp-event-manager-zoom' ), __( 'Zoom Users', 'wp-event-manager-zoom' ), 'manage_options', 'event-manager-zoom-list-users', array($this->user_page, 'zoom_list_users') );

		add_submenu_page( 'edit.php?post_type=event_zoom', __( 'WP Event Manager Add Zoom User', 'wp-event-manager-zoom' ), __( 'Add User', 'wp-event-manager-zoom' ), 'manage_options', 'event-manager-zoom-add-user', array($this->user_page, 'zoom_add_user') );

		add_submenu_page( 'edit.php?post_type=event_zoom', __( 'WP Event Manager Zoom Reports', 'wp-event-manager-zoom' ), __( 'Reports', 'wp-event-manager-zoom' ) , 'manage_options', 'event-manager-zoom-reports', array( $this->reports_page, 'zoom_reports' ) );

		add_submenu_page( 'edit.php?post_type=event_zoom', __( 'WP Event Manager Zoom Settings', 'wp-event-manager-zoom' ), __( 'Settings', 'wp-event-manager-zoom' ) , 'manage_options', 'event-manager-zoom-settings', array( $this->settings_page, 'output' ) );
	}

	/**
	 * admin_enqueue_scripts function.
	 * enqueue style and script for admin
	 * @access public
	 * @param 
	 * @return 
	 * @since 1.0.0
	 */
	public function admin_enqueue_scripts() 
	{
		wp_register_style( 'jquery-ui',EVENT_MANAGER_PLUGIN_URL. '/assets/js/jquery-ui/jquery-ui.min.css' );			

		wp_register_style( 'wp-event-manager-zoom-backend', WPEM_ZOOM_PLUGIN_URL . '/assets/css/backend.min.css' );
		
		wp_register_script( 'wp-event-manager-zoom-admin-zoom', WPEM_ZOOM_PLUGIN_URL . '/assets/js/admin-zoom.min.js', array( 'jquery' ), WPEM_ZOOM_VERSION, true);

		wp_localize_script( 'wp-event-manager-zoom-admin-zoom', 'event_manager_zoom_admin_zoom', array( 
								'ajax_url' 	 => admin_url( 'admin-ajax.php' ),

								'i18n_datepicker_format' => WP_Event_Manager_Date_Time::get_datepicker_format(),
								'i18n_timepicker_format' => WP_Event_Manager_Date_Time::get_timepicker_format(),		
								'i18n_timepicker_step'	=> WP_Event_Manager_Date_Time::get_timepicker_step(),

								'event_manager_zoom_security'  => wp_create_nonce( "_nonce_event_manager_zoom_security" ),

								'confirm_end' => __( "Are you sure you want to end this meeting ?", 'wp-event-manager-zoom'),

								'sync_meeting_button_text'  	=> __( "Sync with Zoom Meetings", 'wp-event-manager-zoom'),
								'sync_meeting_confirmation_text'=> __( "Are you sure you want to synchronize Zoom Meetings", 'wp-event-manager-zoom'),
								'sync_meeting_before_send_text' => __( "Zoom Meetings are synchronizing now", 'wp-event-manager-zoom'),
								'sync_meeting_success_text'  	=> __( 'Zoom Meetings are synchronized successfully! Please <a href="javascript:window.location.href=window.location.href">reload</a> this page in order to see changes.', 'wp-event-manager-zoom'),
								'sync_meeting_error_text'  		=> __( "Zoom Meetings Synchronization Failed. Please try once again!", 'wp-event-manager-zoom'),

								'sync_user_confirmation_text'=> __( "Are you sure you want to synchronize Zoom Users", 'wp-event-manager-zoom'),
								'sync_user_before_send_text' => __( "Zoom Users are synchronizing now", 'wp-event-manager-zoom'),
								'sync_user_success_text'  	=> __( 'Zoom Users are synchronized successfully! Please <a href="javascript:window.location.href=window.location.href">reload</a> this page in order to see changes.', 'wp-event-manager-zoom'),
								'sync_user_error_text'  		=> __( "Zoom Users Synchronization Failed. Please try once again!", 'wp-event-manager-zoom'),

								'sync_webinar_button_text'  	=> __( "Sync with Zoom Webinars", 'wp-event-manager-zoom'),
								'sync_webinar_confirmation_text'=> __( "Are you sure you want to synchronize Zoom Webinars", 'wp-event-manager-zoom'),
								'sync_webinar_before_send_text' => __( "Zoom Webinars are synchronizing now", 'wp-event-manager-zoom'),
								'sync_webinar_success_text'  	=> __( 'Zoom Webinars are synchronized successfully! Please <a href="javascript:window.location.href=window.location.href">reload</a> this page in order to see changes.', 'wp-event-manager-zoom'),
								'sync_webinar_error_text'  		=> __( "Zoom Webinars Synchronization Failed. Please try once again!", 'wp-event-manager-zoom'),

							)
						);

		if(isset($_GET['post_type']) && $_GET['post_type'] == 'event_zoom')
		{
			wp_enqueue_script( 'wp-event-manager-zoom-admin-zoom' );
		}
	}
	
}

new WPEM_Zoom_Admin();

