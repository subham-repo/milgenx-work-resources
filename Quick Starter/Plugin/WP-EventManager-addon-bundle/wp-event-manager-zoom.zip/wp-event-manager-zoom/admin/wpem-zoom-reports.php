<?php
class WPEM_Zoom_Reports{

	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function zoom_reports() {

		wp_enqueue_style( 'jquery-ui' );
		wp_enqueue_style( 'wp-event-manager-zoom-backend' );

		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'wp-event-manager-zoom-admin-zoom' );

		$active_tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'zoom_daily_report';

		if($active_tab == 'zoom_daily_report')
		{
			$result = $this->get_daily_report_html();
			$template = 'zoom-daily-reports.php';
		}
		else if($active_tab == 'zoom_acount_report')
		{
			$result = $this->get_account_report_html();
			$template = 'zoom-account-reports.php';
		}

		get_event_manager_template( 
			$template, 
			array(
				'active_tab' => $active_tab,
				'result' => $result,
			), 
			'wp-event-manager-zoom', 
			WPEM_ZOOM_PLUGIN_DIR . '/templates/admin/'
		);
	}



	/**
	 * get_daily_report_html function.
	 * get daily report month wise in admin side
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	public function get_daily_report_html() {
		$return_result = false;
		$months        = array(
			1  => 'January',
			2  => 'February',
			3  => 'March',
			4  => 'April',
			5  => 'May',
			6  => 'June',
			7  => 'July',
			8  => 'August',
			9  => 'September',
			10 => 'October',
			11 => 'November',
			12 => 'December'
		);

		if ( isset( $_POST['zoom_check_month_year'] ) ) {
			$zoom_monthyear = $_POST['zoom_month_year'];
			if ( $zoom_monthyear == null || $zoom_monthyear == "" ) {
				$return_result = __( "Date field cannot be Empty !!", "wp-event-manager-zoom" );
			} else {
				$exploded_data = explode( ' ', $zoom_monthyear );
				foreach ( $months as $key => $month ) {
					if ( $exploded_data[0] == $month ) {
						$month_int = $key;
					}
				}
				$year          = $exploded_data[1];
				$result        = WPEM_Zoom_API()->getDailyReport( $month_int, $year );
				$return_result = json_decode( $result );
			}
		}

		return $return_result;
	}

	/**
	 * get_account_report_html function.
	 * get user account report with sub account
	 * @access public
	 * @param 
	 * @return array
	 * @since 1.0.0
	 */
	public function get_account_report_html() {
		$return_result = false;
		if ( isset( $_POST['zoom_account_from'] ) && isset( $_POST['zoom_account_to'] ) ) {
			$zoom_account_from = $_POST['zoom_account_from'];
			$zoom_account_to   = $_POST['zoom_account_to'];
			if ( $zoom_account_from == null || $zoom_account_to == null ) {
				$return_result = __( "The fields cannot be Empty !!", "wp-event-manager-zoom" );
			} else {
				$result        = WPEM_Zoom_API()->getAccountReport( $zoom_account_from, $zoom_account_to );
				$return_result = json_decode( $result );
			}
		}

		return $return_result;
	}

}

new WPEM_Zoom_Reports();