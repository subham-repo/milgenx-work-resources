<?php
/*
* From admin panel, setuping post event page, event dashboard page and event listings page.
*
*/

if ( ! defined( 'ABSPATH' ) ) {
    
	exit;
}

/**
 * WWPEM_Zoom_Setup class.
*/

class WWPEM_Zoom_Setup {

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */

	public function __construct() {

		add_action( 'admin_menu', array( $this, 'admin_menu' ), 12 );

		add_action( 'admin_head', array( $this, 'admin_head' ) );

		add_action( 'admin_init', array( $this, 'redirect' ) );

		if ( isset( $_GET['page'] ) && 'event-zoom-setup' === $_GET['page'] ) {
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ), 12 );
		}
	}

	/**
	 * admin_menu function.
	 *
	 * @access public
	 * @return void
	 */

	public function admin_menu() {

		add_dashboard_page( __( 'Setup', 'wp-event-manager-zoom' ), __( 'Setup', 'wp-event-manager-zoom' ), 'manage_options', 'event-zoom-setup', array( $this, 'output' ) );
	}

	/**
	 * Add styles just for this page, and remove dashboard page links.
	 *
	 * @access public
	 * @return void
	 */
	 
	public function admin_head() {

		remove_submenu_page( 'index.php', 'event-zoom-setup' );
	}

	/**
	 * Sends user to the setup page on first activation
	 */
	 
	public function redirect() {

		// Bail if no activation redirect transient is set

	    if ( ! get_transient( '_event_zoom_activation_redirect' ) ) {

			return;
	    }

	    if ( ! current_user_can( 'manage_options' ) ) {
	    	
	    	return;
	    }

		// Delete the redirect transient
		delete_transient( '_event_zoom_activation_redirect' );

		// Bail if activating from network, or bulk, or within an iFrame
		if ( is_network_admin() || isset( $_GET['activate-multi'] ) || defined( 'IFRAME_REQUEST' ) ) {

			return;
		}

		if ( ( isset( $_GET['action'] ) && 'upgrade-plugin' == $_GET['action'] ) && ( isset( $_GET['plugin'] ) && strstr( $_GET['plugin'], 'wp-event-manager.php' ) ) ) {

			return;
		}

		wp_redirect( admin_url( 'index.php?page=event-zoom-setup' ) );
		
		exit;
	}

	/**
	 * Enqueue scripts for setup page
	 */

	public function admin_enqueue_scripts() {
	    
		wp_enqueue_style( 'event_manager_setup_css', EVENT_MANAGER_PLUGIN_URL . '/assets/css/setup.css', array( 'dashicons' ) );
	}

	/**
	 * Create a page.
	 * @param  string $title
	 * @param  string $content
	 * @param  string $option
	 */
	 
	public function create_page( $title, $content, $option ) {

		$page_data = array(

			'post_status'    => 'publish',

			'post_type'      => 'page',

			'post_author'    => 1,

			'post_name'      => sanitize_title( $title ),

			'post_title'     => $title,

			'post_content'   => $content,

			'post_parent'    => 0,

			'comment_status' => 'closed'
		);

		$page_id = wp_insert_post( $page_data );

		if ( $option ) {

			update_option( $option, $page_id );
		}
	}

	/**
	 * Output addons page
	 */
	 
	public function output() {

		$step = ! empty( $_GET['step'] ) ? absint( $_GET['step'] ) : 1;

		if ( 3 === $step && ! empty( $_POST ) ) 
		{
			if ( false == wp_verify_nonce( $_REQUEST[ 'setup_wizard' ], 'step_3' ) )
				wp_die( __('Error in nonce. Try again.', 'wp-event-manager-zoom') );

			$create_pages    = isset( $_POST['wp-event-manager-zoom-create-page'] ) ? $_POST['wp-event-manager-zoom-create-page'] : array();

			$page_titles     = $_POST['wp-event-manager-page-title'];

			$pages_to_create = array(

				'zoom_submit_meeting_form' => '[submit_zoom_meeting_form]',

				'zoom_meeting_dashboard'   => '[zoom_meeting_dashboard]',
			);

			foreach ( $pages_to_create as $page => $content ) {

				if ( ! isset( $create_pages[ $page ] ) || empty( $page_titles[ $page ] ) ) {

					continue;
				}

				$this->create_page( sanitize_text_field( $page_titles[ $page ] ), $content, 'event_' . $page . '_page_id' );
			}
		}

		?>

		<div class="wrap wp_event_manager wp_event_manager_addons_wrap">
		
			<h2><?php _e( 'WP Event Manager Zoom Setup', 'wp-event-manager-zoom' ); ?></h2>

			<ul class="wp-event-manager-setup-steps wp-event-zoom-setup-steps">

				<li class="<?php if ( $step === 1 ) echo 'wp-event-manager-setup-active-step wp-event-zoom-setup-active-step'; ?>"><?php _e( '1. Introduction', 'wp-event-manager-zoom' ); ?></li>

				<li class="<?php if ( $step === 2 ) echo 'wp-event-manager-setup-active-step wp-event-zoom-setup-active-step'; ?>"><?php _e( '2. Page Setup', 'wp-event-manager-zoom' ); ?></li>

				<li class="<?php if ( $step === 3 ) echo 'wp-event-manager-setup-active-step wp-event-zoom-setup-active-step'; ?>"><?php _e( '3. Done', 'wp-event-manager-zoom' ); ?></li>

			</ul>

			<?php if ( 1 === $step ) : ?>

				<h3><?php _e( 'Setup Wizard Introduction', 'wp-event-manager-zoom' ); ?></h3>

				<p><?php _e( 'Thanks for installing <em>WP Event Manager Zoom</em>!', 'wp-event-manager-zoom' ); ?></p>

				<p><?php _e( 'This setup wizard will help you get started by creating the pages for event submission, event management, and listing your events.', 'wp-event-manager-zoom' ); ?></p>

				<p><?php printf( __( 'If you want to skip the wizard and setup the pages and shortcodes yourself manually, the process is still relatively simple. Refer to the %sdocumentation%s for help.', 'wp-event-manager-zoom' ), '<a href="https://wp-eventmanager.com/help-center/">', '</a>' ); ?></p>

				<p class="submit">

					<a href="<?php echo esc_url( add_query_arg( 'step', 2 ) ); ?>" class="button button-primary"><?php _e( 'Continue to page setup', 'wp-event-manager-zoom' ); ?></a>

					<a href="<?php echo esc_url( add_query_arg( 'skip-event-zoom-setup', 1, admin_url( 'index.php?page=event-zoom-setup&step=3' ) ) ); ?>" class="button"><?php _e( 'Skip setup. I will setup the plugin manually', 'wp-event-manager-zoom' ); ?></a>

				</p>
				
			<?php endif; ?>

			<?php if ( 2 === $step ) : ?>

				<h3><?php _e( 'Page Setup', 'wp-event-manager-zoom' ); ?></h3>

				<p><?php printf( __( '<em>WP Event Manager</em> includes %1$sshortcodes%2$s which can be used within your %3$spages%2$s to output content. These can be created for you below. For more information on the event shortcodes view the %4$sshortcode documentation%2$s.', 'wp-event-manager-zoom' ), '<a href="https://wp-eventmanager.com/knowledge-base/" title="What is a shortcode?" target="_blank" class="help-page-link">', '</a>', '<a href="https://wordpress.org/support/article/pages/" target="_blank" class="help-page-link">', '<a href="https://wp-eventmanager.com/knowledge-base/the-event-dashboard/" target="_blank" class="help-page-link">' ); ?></p>

				<form action="<?php echo esc_url( add_query_arg( 'step', 3 ) ); ?>" method="post">
					<?php wp_nonce_field( 'step_3', 'setup_wizard' ); ?>
					<table class="wp-event-manager-shortcodes widefat">
					
						<thead>
						
							<tr>		
								<th>&nbsp;</th>

								<th><?php _e( 'Page Title', 'wp-event-manager-zoom' ); ?></th>

								<th><?php _e( 'Page Description', 'wp-event-manager-zoom' ); ?></th>

								<th><?php _e( 'Content Shortcode', 'wp-event-manager-zoom' ); ?></th>
							</tr>

						</thead>

						<tbody>

							<tr>

								<td><input type="checkbox" checked="checked" name="wp-event-manager-zoom-create-page[zoom_submit_meeting_form]" /></td>

								<td><input type="text" value="<?php echo esc_attr( _x( 'Submit Zoom Meeting / Webinar Form', 'Default page title (wizard)', 'wp-event-manager-zoom' ) ); ?>" name="wp-event-manager-page-title[zoom_submit_meeting_form]" /></td>

								<td>
									<p><?php _e( 'This page allows peoples to Submit Zoom Meeting / Webinar to your website from the front-end.', 'wp-event-manager-zoom' ); ?></p>

									<p><?php _e( 'If you do not want to accept submissions from users in this way (for example you just want to Submit Zoom Meeting / Webinar from the admin dashboard) you can skip creating this page.', 'wp-event-manager-zoom' ); ?></p>
								</td>
								<td><code>[submit_zoom_meeting_form]</code></td>
							</tr>
							<tr>

								<td><input type="checkbox" checked="checked" name="wp-event-manager-zoom-create-page[zoom_meeting_dashboard]" /></td>

								<td><input type="text" value="<?php echo esc_attr( _x( 'Zoom Meeting / Webinar Dashboard', 'Default page title (wizard)', 'wp-event-manager-zoom' ) ); ?>" name="wp-event-manager-page-title[zoom_meeting_dashboard]" /></td>

								<td>

									<p><?php _e( 'This page allows peoples to manage and edit their own Zoom Meeting / Webinar from the front-end.', 'wp-event-manager-zoom' ); ?></p>

									<p><?php _e( 'If you plan on managing all Zoom Meeting / Webinar from the admin dashboard you can skip creating this page.', 'wp-event-manager-zoom' ); ?></p>
								</td>
								
								<td><code>[zoom_meeting_dashboard]</code></td>
							</tr>

						</tbody>

						<tfoot>

							<tr>
								<th colspan="4">
									<input type="submit" class="button button-primary" value="Create selected pages" />

									<a href="<?php echo esc_url( add_query_arg( 'step', 3 ) ); ?>" class="button"><?php _e( 'Skip this step', 'wp-event-manager-zoom' ); ?></a>
								</th>
							</tr>
						</tfoot>
					</table>
				</form>
				
			<?php endif; ?>

			<?php if ( 3 === $step ) : ?>

				<h3><?php _e( 'All Done!', 'wp-event-manager-zoom' ); ?></h3>
				
				<p><?php _e( 'Looks like you\'re all set to start using the plugin. In case you\'re wondering where to go next:', 'wp-event-manager-zoom' ); ?></p>

				<ul class="wp-event-manager-next-steps">

					<li><a href="<?php echo admin_url( 'edit.php?post_type=event_zoom&page=event-manager-zoom-settings' ); ?>"><?php _e( 'Tweak the plugin settings', 'wp-event-manager-zoom' ); ?></a></li>

					<li><a href="<?php echo admin_url( 'post-new.php?post_type=event_zoom' ); ?>"><?php _e( 'Add an Zoom Meeting / Webinar via the back-end', 'wp-event-manager-zoom' ); ?></a></li>

					<?php if ( $permalink = get_option( 'event_zoom_submit_meeting_form_page_id' ) ) : ?>

						<li><a href="<?php echo get_the_permalink( $permalink ); ?>"><?php _e( 'Add an event via the front-end', 'wp-event-manager-zoom' ); ?></a></li>

					<?php endif; ?>

					<?php if ( $permalink = get_option( 'event_zoom_meeting_dashboard_page_id' ) ) : ?>

						<li><a href="<?php echo get_the_permalink( $permalink ); ?>"><?php _e( 'Zoom Dashboard via the front-end', 'wp-event-manager-zoom' ); ?></a></li>

					<?php endif; ?>

				</ul>

				<p><?php printf( __( 'And don\'t forget, if you need any more help using <em>WP Event Manager</em> you can consult the %1$sdocumentation%2$s or %3$spost on the forums%2$s!', 'wp-event-manager-zoom' ), '<a href="https://wp-eventmanager.com/help-center/">', '</a>', '<a href="https://wordpress.org/support/plugin/wp-event-manager">' ); ?></p>

				<div class="wp-event-manager-support-the-plugin">

					<h3><?php _e( 'Support the Ongoing Development of this Plugin', 'wp-event-manager-zoom' ); ?></h3>

					<p><?php _e( 'There are many ways to support open-source projects such as WP Event Manager, for example code contribution, translation, or even telling your friends how awesome the plugin (hopefully) is. Thanks in advance for your support - it is much appreciated!', 'wp-event-manager-zoom' ); ?></p>

					<ul>

						<li class="icon-review"><a href="https://wordpress.org/support/plugin/wp-event-manager/reviews/#postform"><?php _e( 'Leave a positive review', 'wp-event-manager-zoom' ); ?></a></li>

						<li class="icon-localization"><a href="https://translate.wordpress.org/projects/wp-plugins/wp-event-manager"><?php _e( 'Contribute a localization', 'wp-event-manager-zoom' ); ?></a></li>

						<li class="icon-code"><a href="https://wp-eventmanager.com/help-center/"><?php _e( 'Contribute code or report a bug', 'wp-event-manager-zoom' ); ?></a></li>

						<li class="icon-forum"><a href="https://wordpress.org/support/plugin/wp-event-manager"><?php _e( 'Help other users on the forums', 'wp-event-manager-zoom' ); ?></a></li>

					</ul>

				</div>

			<?php endif; ?>

		</div>

		<?php
	}
}
new WWPEM_Zoom_Setup();
