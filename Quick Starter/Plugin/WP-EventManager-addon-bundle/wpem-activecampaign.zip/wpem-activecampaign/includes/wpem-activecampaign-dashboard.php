<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Activecampaign_Integration_Dashboard class.
 */
class WPEM_Activecampaign_Dashboard {

    /**
     * __construct function.
     */
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'frontend_scripts'));
        add_action('wp_loaded', array($this, 'edit_handler'));

        //wpem dashboard column and content
        add_filter('wpem_dashboard_menu', array($this, 'wpem_dashboard_menu_add'));
        add_action('event_manager_event_dashboard_content_wpem_activecampaign_settings', array($this, 'wpem_activecampaign_settings'));



        add_filter('event_manager_event_dashboard_columns', array($this, 'add_wpem_activecampaign_columns'));
        add_action('event_manager_event_dashboard_column_activecampaign', array($this, 'wpem_activecampaign_column'));

        // Ajax on event dashboard for perticular event activecampaign list selection
        add_action('wp_ajax_wpem_activecampaign_save_list_event', array($this, 'wpem_activecampaign_save_list_event'));

        // cron
        add_action('event_manager_auto_activecampaign_sync_attendees', array($this, 'wpem_auto_activecampaign_sync_attendees_callback'));
    }

    /**
     * frontend_scripts function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function frontend_scripts() {
        wp_register_script('wpem-activecampaign-dashboard', WPEM_ACTIVECAMPAIGN_PLUGIN_URL . '/assets/js/activecampaign-dashboard.js', array('jquery'), WPEM_ACTIVECAMPAIGN_VERSION, true);

        wp_localize_script('wpem-activecampaign-dashboard', 'wpem_activecampaign', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'wpem_activecampaign_dashboard_security' => wp_create_nonce("_nonce_wpem_activecampaign_dashboard_security"),
            'in_queue_icon' => EVENT_MANAGER_PLUGIN_URL . '/assets/images/ajax-loader.gif',
        ));

        wp_enqueue_style('wpem-activecampaign-frontend', WPEM_ACTIVECAMPAIGN_PLUGIN_URL . '/assets/css/frontend.css');
    }

    /**
     * add dashboard menu function.
     *
     * @access public
     * @return void
     */
    public function wpem_dashboard_menu_add($menus) {
        $menus['wpem_activecampaign'] = array(
            'title' => __('Activecampaign', 'wpem-activecampaign'),
            'icon' => 'wpem-icon-mail3',
            'submenu' => array('wpem_activecampaign_settings' => array(
                    'title' => __('Settings', 'wpem'),
                    'query_arg' => ['action' => 'wpem_activecampaign_settings'],
                ))
        );

        $enable_activecampaign_registration = get_option('enable_activecampaign_registration', true);
        $enable_activecampaign_guest_list = get_option('enable_activecampaign_guest_list', true);
        $enable_activecampaign_organizer = get_option('enable_activecampaign_organizer', true);
        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $sync_type = isset($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : 'auto';

        if (is_plugin_active('wp-event-manager-registrations/wp-event-manager-registrations.php') && $enable_activecampaign_registration == true && $sync_type == 'manual') {
            $menus['wpem_activecampaign']['submenu']['wpem_activecampaign_sync_registrations'] = array(
                'title' => __('Sync Registrations', 'wpem'),
                'query_arg' => ['action' => 'wpem_activecampaign_sync_registrations'],
            );
        }

        if (is_plugin_active('wpem-guests/wpem-guests.php') && $enable_activecampaign_guest_list == true && $sync_type == 'manual') {
            $menus['wpem_activecampaign']['submenu']['wpem_activecampaign_sync_guest_list'] = array(
                'title' => __('Sync Guests', 'wpem'),
                'query_arg' => ['action' => 'wpem_activecampaign_sync_guest_list'],
            );
        }
        
        return $menus;
    }

    /**
     * Export Event and Other Data
     */
    public function wpem_activecampaign_settings() {

        $user_id = get_current_user_id();

        wp_enqueue_script('wpem-activecampaign-dashboard');

        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        get_event_manager_template(
                'wpem-activecampaign-settings.php',
                array(
                    'user_id' => $user_id,
                    'activecampaign_account_url' => isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '',
                    'activecampaign_api_key' => isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '',
                    'activecampaign_list' => isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '',
                    'activecampaign_sync_type' => isset($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : 'auto',
                    'activecampaign_sync_via' => isset($activecampaign_settings['activecampaign_sync_via']) ? $activecampaign_settings['activecampaign_sync_via'] : 'cron_job',
                    'activecampaign_sync_schedule' => isset($activecampaign_settings['activecampaign_sync_schedule']) ? $activecampaign_settings['activecampaign_sync_schedule'] : 'weekly',
                ),
                'wpem-activecampaign',
                WPEM_ACTIVECAMPAIGN_PLUGIN_DIR . '/templates/'
        );
    }

    /**
     * edit_handler function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function edit_handler() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wp_event_manager_activecampaign']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_activecampaign')) {
            $activecampaign_account_url = !empty($_POST['activecampaign_account_url']) ? sanitize_text_field($_POST['activecampaign_account_url']) : '';
            $activecampaign_api_key = !empty($_POST['activecampaign_api_key']) ? sanitize_text_field($_POST['activecampaign_api_key']) : '';
            $activecampaign_list = !empty($_POST['activecampaign_list']) ? sanitize_text_field($_POST['activecampaign_list']) : '';
            $activecampaign_sync_type = !empty($_POST['activecampaign_sync_type']) ? sanitize_text_field($_POST['activecampaign_sync_type']) : 'auto';
            $activecampaign_sync_via = !empty($_POST['activecampaign_sync_via']) ? sanitize_text_field($_POST['activecampaign_sync_via']) : 'cron_job';
            $activecampaign_sync_schedule = !empty($_POST['activecampaign_sync_schedule']) ? sanitize_text_field($_POST['activecampaign_sync_schedule']) : 'weekly';

            $activecampaign_settings = [
                'activecampaign_account_url' => $activecampaign_account_url,
                'activecampaign_api_key' => $activecampaign_api_key,
                'activecampaign_list' => $activecampaign_list,
                'activecampaign_sync_type' => $activecampaign_sync_type,
                'activecampaign_sync_schedule' => $activecampaign_sync_schedule,
                'activecampaign_sync_via' => $activecampaign_sync_via,
            ];

            update_wpem_activecampaign_settings_by_user('activecampaign_settings', $activecampaign_settings);

            wp_clear_scheduled_hook('event_manager_auto_activecampaign_sync_attendees', array($user_id));
            if ($activecampaign_sync_type == 'auto' && $activecampaign_sync_via == 'cron_job') {
                switch ($activecampaign_sync_schedule) {
                    case '5min' :
                        $next = strtotime('+5 minutes');
                        break;
                    case 'daily' :
                        $next = strtotime('+1 day');
                        break;
                    case 'weekly' :
                        $next = strtotime('+1 week');
                        break;
                    case 'monthly' :
                        $next = strtotime('+1 month');
                        break;
                    case 'yearly' :
                        $next = strtotime('+1 year');
                        break;
                    default :
                        $next = strtotime('+1 week');
                        break;
                }

                // Create cron
                wp_schedule_event($next, $activecampaign_sync_schedule, 'event_manager_auto_activecampaign_sync_attendees', array($user_id));
            }
        }

        if (!empty($_POST['wp_event_manager_activecampaign_disconnect']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_activecampaign_disconnect')) {
            $arr_activecampaign_lists = get_sync_fields_by_user($user_id, 'activecampaign_lists');

            if (!empty($arr_activecampaign_lists)) {
                foreach ($arr_activecampaign_lists as $activecampaign_list => $activecampaign_name) {
                    delete_wpem_activecampaign_settings_by_user('activecampaign_list_dynamic_field_' . $activecampaign_list);
                }
            }

            wp_clear_scheduled_hook('event_manager_auto_activecampaign_sync_attendees', array($user_id));

            delete_wpem_activecampaign_settings_by_user('activecampaign_lists');
            delete_wpem_activecampaign_settings_by_user('activecampaign_settings');
        }
    }

    /**
     * add_wpem_activecampaign_columns function.
     *
     * @access public
     * @param $columns
     * @return void
     * @since 1.0.0
     */
    public function add_wpem_activecampaign_columns($columns) {
        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();
        $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : 0;
        //if user not set event based settings then do not add column
        if ($activecampaign_list != false)
            return $columns;


        $columns['activecampaign'] = __('Activecampaign', 'wpem-activecampaign');
        return $columns;
    }

    /**
     * wpem_activecampaign_column function.
     *
     * @access public
     * @param $event
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_column($event) {
        $user_id = get_current_user_id();
        $event_id = $event->ID;

        $event_activecampaign_list = get_post_meta($event_id, 'activecampaign_list', true);

        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
        $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
        $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : 0;

        if ($activecampaign_list != false)
            return;

        wp_enqueue_script('wpem-activecampaign-dashboard');

        $activecampaign_lists = get_wpem_activecampaign_lists($activecampaign_api_key,$activecampaign_account_url);

        if (count($activecampaign_lists) > 0) {
            if (isset($activecampaign_lists[0]))
                $activecampaign_lists[0] = __('Disable for this event', 'wpem-activecampaign');
            ?>
            <div class="wpem-form-wrapper wpem-activecampaign">
                <div class="wpem-form-group">
                    <select name="activecampaign_list" class="activecampaign-list" data-event-id="<?php echo $event->ID; ?>">
            <?php foreach ($activecampaign_lists as $id => $label) : ?>
                            <option value="<?php echo esc_attr($id); ?>" <?php selected($event_activecampaign_list, $id); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <?php
        } else {
            echo __('Please connect with Activecampaign.', 'wpem-activecampaign');
        }
    }

    public function wpem_activecampaign_save_list_event() {
        check_ajax_referer('_nonce_wpem_activecampaign_dashboard_security', 'security');

        $event_id = isset($_REQUEST['event_id']) ? absint($_REQUEST['event_id']) : '';
        $activecampaign_list = isset($_REQUEST['activecampaign_list']) ? $_REQUEST['activecampaign_list'] : 0;

        if (!empty($event_id)) {
            update_post_meta($event_id, 'activecampaign_list', $activecampaign_list);
            return wp_send_json(array(
                'message' => __('Updated sucessfully.', 'wpem-activecampaign')));
        }



        wp_die();
    }

    /**
     * wpem_auto_activecampaign_sync_attendees_callback function.
     *
     * @access public
     * @param $event_id
     * @return void
     * @since 1.0.0
     */
    public function wpem_auto_activecampaign_sync_attendees_callback($user_id) {
        $event_ids = get_event_by_user_id($user_id);

        if (!empty($event_ids)) {
            foreach ($event_ids as $event_id) {
                $registrations = get_registration_attendee_list(['event_id' => $event_id, 'posts_per_page' => -1]);

                $arr_attendees_id = [];

                if ($registrations->found_posts > 0) {
                    foreach ($registrations->posts as $registration) {
                        $arr_attendees_id[] = $registration->ID;
                    }

                    add_attendees_in_wpem_activecampaign_list($user_id, $arr_attendees_id);
                }
                wp_reset_postdata();
                $guests = get_guest_lists_guest_list(['event_id' => $event_id, 'posts_per_page' => -1]);

                $arr_guest_id = [];

                if ($guests->found_posts > 0) {
                    foreach ($guests->posts as $guest) {
                        $arr_guest_id[] = $guest->ID;
                    }

                    add_guests_in_wpem_activecampaign_list($user_id, $arr_guest_id);
                }
                wp_reset_postdata();
            }
        }
    }

}

new WPEM_Activecampaign_Dashboard();
