<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Activecampaignnblue_Registrations class.
 */
class WPEM_Activecampaignnblue_Registrations {

    /**
     * __construct function.
     */
    public function __construct() {
        add_action('wpem_activecampaign_dashboard_after', array($this, 'wpem_activecampaign_registrations_fields_mapping'), 10);

        add_action('wp_loaded', array($this, 'edit_handler'));

        // Insert New Registration
        add_action('wpem_create_event_registration_meta_update_end', array($this, 'wpem_activecampaign_sync_via_add_new_registration'), 10);

        add_action('event_manager_event_dashboard_content_wpem_activecampaign_sync_registrations', array($this, 'show_wpem_activecampaign_sync_attendees'));

        // Ajax
        add_action('wp_ajax_wpem_activecampaign_sync_attendees', array($this, 'wpem_activecampaign_sync_attendees'));
    }

    /**
     * wpem_activecampaign_registrations_fields_mapping function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_registrations_fields_mapping() {
        $user_id = get_current_user_id();

        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
        $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
        $check_wpem_activecampaign_key = check_wpem_activecampaign_key($activecampaign_api_key,$activecampaign_account_url);
        $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '';
        $enable_guest_list = get_option('enable_activecampaign_registration', true);
        if (isset($check_wpem_activecampaign_key['code']) && $check_wpem_activecampaign_key['code'] == "unauthorized")
            return;
        
        if ($enable_guest_list == false)
            return;

        if (!empty($activecampaign_api_key) && is_array($check_wpem_activecampaign_key) && !empty($activecampaign_account_url)) {
            $registration_field = get_sync_fields_by_user($user_id, 'registration_field');
            $registration_activecampaign_field = get_wpem_activecampaign_sync_fields_by_user($user_id, 'registration_activecampaign_field');

            $field_not_mapping_message = '';
            if (empty($registration_activecampaign_field)) {
                $registration_activecampaign_field = get_default_wpem_activecampaign_registration_matches_attribute();

                $field_not_mapping_message = __('Name and Email are compulsory fields for Activecampaignnblue synchronization.', 'wpem-activecampaign');
            }

            get_event_manager_template(
                    'wpem-activecampaign-registration-field-mapping.php',
                    array(
                        'user_id' => $user_id,
                        'activecampaign_account_url' => $activecampaign_account_url,
                        'activecampaign_api_key' => $activecampaign_api_key,
                        'activecampaign_list' => $activecampaign_list,
                        'registration_activecampaign_field' => $registration_activecampaign_field,
                        'field_not_mapping_message' => $field_not_mapping_message,
                    ),
                    'wpem-activecampaign',
                    WPEM_ACTIVECAMPAIGN_PLUGIN_DIR . '/templates/'
            );
        }
    }

    /**
     * edit_handler function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function edit_handler() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wp_event_manager_activecampaign_registration_matches_attribute']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_activecampaign_registration_matches_attribute')) {
            $registration_field = !empty($_POST['registration_field']) ? array_filter($_POST['registration_field']) : '';
            $registration_activecampaign_field = !empty($_POST['registration_activecampaign_field']) ? array_filter($_POST['registration_activecampaign_field']) : '';

            update_wpem_activecampaign_settings_by_user('registration_field', $registration_field);

            $new_activecampaign_field = [];

            if (!empty($registration_activecampaign_field)) {
                foreach ($registration_activecampaign_field as $key => $value) {
                    $new_activecampaign_field[$value] = $registration_field[$key];
                }
            }

            update_wpem_activecampaign_settings_by_user('registration_activecampaign_field', $new_activecampaign_field);
        }
    }

    /**
     * wpem_activecampaign_sync_via_add_new_registration function.
     *
     * @access public
     * @param $post_id
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_sync_via_add_new_registration($post_id) {
        //Check registration sync is enable
        $enable_registration = get_option('enable_activecampaign_registration', true);
        if ($enable_registration == false)
            return;

        $post = get_post($post_id);

        if ($post->post_type != 'event_registration')
            return;

        $event_id = $post->post_parent;
        $event = get_post($event_id);
        $user_id = $event->post_author;
        $arr_attendees_id = [$post_id];

        if (count($arr_attendees_id) > 0) {
            $activecampaign_settings = get_wpem_activecampaign_settings_by_user_id($user_id);

            $activecampaign_sync_type = isset($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : '';
            $activecampaign_sync_via = isset($activecampaign_settings['activecampaign_sync_via']) ? $activecampaign_settings['activecampaign_sync_via'] : '';

            if ($activecampaign_sync_type == 'auto' && $activecampaign_sync_via == 'when_created') {
                add_attendees_in_wpem_activecampaign_list($user_id, $arr_attendees_id);
            }
        }
    }

    /**
     * show_wpem_activecampaign_sync_attendees function.
     * List all the attendees on the activecampaign table
     *
     * @access public
     * @param $atts
     * @return void
     * @since 1.0.0
     */
    public function show_wpem_activecampaign_sync_attendees($atts) {
        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();
        $sync_type = isset($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : 'auto';
        if ($sync_type == 'manual') :

            $user_id = get_current_user_id();
            $event_id = isset($_REQUEST['event_id']) && !empty($_REQUEST['event_id']) ? absint($_REQUEST['event_id']) : '';

            $args = array(
                'post_type' => 'event_listing',
                'post_status' => array('publish', 'expired'),
                'posts_per_page' => -1,
                'author' => $user_id
            );

            $events = get_posts($args);

            $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
            $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
            $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '';

            $registration_activecampaign_field = get_wpem_activecampaign_sync_fields_by_user($user_id, 'registration_activecampaign_field');

            $sync_filter_field = !empty($_GET['sync_filter_field']) ? sanitize_text_field($_GET['sync_filter_field']) : '';
            $sync_filter_value = !empty($_GET['sync_filter_value']) ? sanitize_text_field($_GET['sync_filter_value']) : '';

            $event_activecampaign_list = get_post_meta($event_id, 'activecampaign_list', true);
            if (!empty($event_activecampaign_list)) {
                $activecampaign_list = $event_activecampaign_list;
            }

            if (empty($registration_activecampaign_field)) {
                $registration_activecampaign_field = get_default_wpem_activecampaign_registration_matches_attribute();
            }

            $registrations = get_registration_attendee_list(['event_id' => $event_id], [$sync_filter_field => $sync_filter_value]);

            wp_enqueue_script('wpem-activecampaign-dashboard');

            get_event_manager_template(
                    'wpem-activecampaign-sync-registrations.php',
                    array(
                        'event_id' => $event_id,
                        'events' => $events,
                        'activecampaign_account_url' => $activecampaign_account_url,
                        'activecampaign_api_key' => $activecampaign_api_key,
                        'activecampaign_list' => $activecampaign_list,
                        'registration_activecampaign_field' => $registration_activecampaign_field,
                        'total_registrations' => $registrations->found_posts,
                        'registrations' => $registrations->posts,
                        'max_num_pages' => $registrations->max_num_pages,
                        'sync_filter_field' => $sync_filter_field,
                        'sync_filter_value' => $sync_filter_value,
                    ),
                    'wpem-activecampaign',
                    WPEM_ACTIVECAMPAIGN_PLUGIN_DIR . '/templates/'
            );

        endif; //manual if condition
    }

    /**
     * wpem_activecampaign_sync_attendees function.
     *
     * @access public
     * @param 
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_sync_attendees() {
        check_ajax_referer('_nonce_wpem_activecampaign_dashboard_security', 'security');

        $params = $_POST['form_data'];
        $response = [];
        $user_id = get_current_user_id();
        $arr_attendees_id = $params['attendees_id'];

        if (count($arr_attendees_id) > 0) {
            $response = add_attendees_in_wpem_activecampaign_list($user_id, $arr_attendees_id);
        }

        wp_send_json($response);
        wp_die();
    }

}

new WPEM_Activecampaignnblue_Registrations();
