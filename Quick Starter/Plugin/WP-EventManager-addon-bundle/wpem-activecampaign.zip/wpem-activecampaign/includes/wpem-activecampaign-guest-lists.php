<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WPEM_Activecampaign_Integration_Guest_Lists class.
 */
class WPEM_Activecampaign_Guest_Lists {

    /**
     * __construct function.
     */
    public function __construct() {
        add_action('wpem_activecampaign_dashboard_after', array($this, 'wpem_activecampaign_guest_lists_fields_mapping'), 10);

        add_action('wp_loaded', array($this, 'edit_handler'));

        // Insert New Guest
        add_action('wpem_create_event_guests_meta_update_end', array($this, 'wpem_activecampaign_sync_via_add_new_guest_list'), 10);


        add_action('event_manager_event_dashboard_content_wpem_activecampaign_sync_guest_list', array($this, 'show_wpem_activecampaign_sync_guests'));

        // Ajax
        add_action('wp_ajax_wpem_activecampaign_sync_guests', array($this, 'wpem_activecampaign_sync_guests'));
    }

    /**
     * wpem_activecampaign_guest_lists_fields_mapping function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_guest_lists_fields_mapping() {
        $user_id = get_current_user_id();

        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
        $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
        
        $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '';
        $enable_guest_list = get_option('enable_activecampaign_guest_list', true);
        
        $check_wpem_activecampaign_key = check_wpem_activecampaign_key($activecampaign_api_key,$activecampaign_account_url);
        if (isset($check_wpem_activecampaign_key['code']) && $check_wpem_activecampaign_key['code'] == "unauthorized")
            return; 
        
        if ($enable_guest_list == false)
            return;

        if (!empty($activecampaign_api_key) && is_array($check_wpem_activecampaign_key) && !empty($activecampaign_account_url)) {
            $guest_list_field = get_sync_fields_by_user($user_id, 'guest_list_field');
            $guest_list_activecampaign_field = get_wpem_activecampaign_sync_fields_by_user($user_id, 'guest_list_activecampaign_field');

            $field_not_mapping_message = '';
            if (empty($guest_list_activecampaign_field)) {
                $guest_list_activecampaign_field = get_default_wpem_activecampaign_guest_list_matches_attribute();

                $field_not_mapping_message = __('Name and Email are compulsory fields for Activecampaign synchronization.', 'wpem-activecampaign');
            }

            get_event_manager_template(
                    'wpem-activecampaign-guest-lists-field-mapping.php',
                    array(
                        'user_id' => $user_id,
                        'activecampaign_account_url' => $activecampaign_account_url,
                        'activecampaign_api_key' => $activecampaign_api_key,
                        'activecampaign_list' => $activecampaign_list,
                        'guest_list_activecampaign_field' => $guest_list_activecampaign_field,
                        'field_not_mapping_message' => $field_not_mapping_message,
                    ),
                    'wpem-activecampaign',
                    WPEM_ACTIVECAMPAIGN_PLUGIN_DIR . '/templates/'
            );
        }
    }

    /**
     * edit_handler function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function edit_handler() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wp_event_manager_activecampaign_guest_list_matches_attribute']) && wp_verify_nonce($_POST['_wpnonce'], 'event_manager_activecampaign_guest_list_matches_attribute')) {
            $guest_list_field = !empty($_POST['guest_list_field']) ? array_filter($_POST['guest_list_field']) : '';
            $guest_list_activecampaign_field = !empty($_POST['guest_list_activecampaign_field']) ? array_filter($_POST['guest_list_activecampaign_field']) : '';

            update_wpem_activecampaign_settings_by_user('guest_list_field', $guest_list_field);

            $new_activecampaign_field = [];

            if (!empty($guest_list_activecampaign_field)) {
                foreach ($guest_list_activecampaign_field as $key => $value) {
                    $new_activecampaign_field[$value] = $guest_list_field[$key];
                }
            }

            update_wpem_activecampaign_settings_by_user('guest_list_activecampaign_field', $new_activecampaign_field);
        }
    }

    /**
     * wpem_activecampaign_sync_via_add_new_registration function.
     *
     * @access public
     * @param $post_id
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_sync_via_add_new_guest_list($post_id) {
        //Check registration sync is enable
        $enable_guest_list = get_option('enable_activecampaign_guest_list', true);
        if ($enable_guest_list == false)
            return;

        $post = get_post($post_id);

        if ($post->post_type != 'event_guests')
            return;

        $event_id = $post->post_parent;
        $event = get_post($event_id);
        $user_id = $event->post_author;
        $arr_guest_id = [$post_id];

        if (count($arr_guest_id) > 0) {
            $activecampaign_settings = get_wpem_activecampaign_settings_by_user_id($user_id);

            $activecampaign_sync_type = isset($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : '';
            $activecampaign_sync_via = isset($activecampaign_settings['activecampaign_sync_via']) ? $activecampaign_settings['activecampaign_sync_via'] : '';

            if ($activecampaign_sync_type == 'auto' && $activecampaign_sync_via == 'when_created') {
                add_guests_in_wpem_activecampaign_list($user_id, $arr_guest_id);
            }
        }
    }

    /**
     * show_wpem_activecampaign_sync_guests function.
     *
     * @access public
     * @param $atts
     * @return void
     * @since 1.0.0
     */
    public function show_wpem_activecampaign_sync_guests($atts) {
        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();
        $sync_type = isset($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : 'auto';
        if ($sync_type == 'manual') :

            $user_id = get_current_user_id();
            $event_id = isset($_REQUEST['event_id']) && !empty($_REQUEST['event_id']) ? absint($_REQUEST['event_id']) : '';

            $args = array(
                'post_type' => 'event_listing',
                'post_status' => array('publish', 'expired'),
                'posts_per_page' => -1,
                'author' => $user_id
            );

            $events = get_posts($args);

            $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

            $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
            $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
            $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '';

            $guest_list_activecampaign_field = get_wpem_activecampaign_sync_fields_by_user($user_id, 'guest_list_activecampaign_field');

            $sync_filter_field = !empty($_GET['sync_filter_field']) ? sanitize_text_field($_GET['sync_filter_field']) : '';
            $sync_filter_value = !empty($_GET['sync_filter_value']) ? sanitize_text_field($_GET['sync_filter_value']) : '';

            $event_activecampaign_list = get_post_meta($event_id, 'activecampaign_list', true);
            if (!empty($event_activecampaign_list)) {
                $activecampaign_list = $event_activecampaign_list;
            }

            if (empty($guest_list_activecampaign_field)) {
                $guest_list_activecampaign_field = get_default_wpem_activecampaign_guest_list_matches_attribute();
            }
            $guests = get_guest_lists_guest_list(['event_id' => $event_id], [$sync_filter_field => $sync_filter_value]);

            wp_enqueue_script('wpem-activecampaign-dashboard');

            get_event_manager_template(
                    'wpem-activecampaign-sync-guests.php',
                    array(
                        'event_id' => $event_id,
                        'events' => $events,
                        'activecampaign_account_url' => $activecampaign_account_url,
                        'activecampaign_api_key' => $activecampaign_api_key,
                        'activecampaign_list' => $activecampaign_list,
                        'guest_list_activecampaign_field' => $guest_list_activecampaign_field,
                        'total_guests' => $guests->found_posts,
                        'guests' => $guests->posts,
                        'max_num_pages' => $guests->max_num_pages,
                        'sync_filter_field' => $sync_filter_field,
                        'sync_filter_value' => $sync_filter_value,
                    ),
                    'wpem-activecampaign',
                    WPEM_ACTIVECAMPAIGN_PLUGIN_DIR . '/templates/'
            );

        endif; //manual if condition
    }

    /**
     * wpem_activecampaign_sync_guests function.
     *
     * @access public
     * @param 
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_sync_guests() {
        check_ajax_referer('_nonce_wpem_activecampaign_dashboard_security', 'security');

        $params = $_POST['form_data'];

        $response = [];
        $user_id = get_current_user_id();
        $arr_guests_id = $params['guests_id'];

        if (count($arr_guests_id) > 0) {
            $response = add_guests_in_wpem_activecampaign_list($user_id, $arr_guests_id);
        }

        wp_send_json($response);
        wp_die();
    }

}

new WPEM_Activecampaign_Guest_Lists();
