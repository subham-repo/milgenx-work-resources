<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

$options = array(
		'wpem_activecampaign_version',
		'organizer_field',
		'organizer_activecampaign_field',
		'registration_field',
		'registration_activecampaign_field',
		'activecampaign_list',
		'activecampaign_sync_type',
		'activecampaign_sync_via',
		'activecampaign_sync_schedule',
		'enable_activecampaign_organizer',
		'enable_activecampaign_registration',
		'guest_list_field',
		'guest_list_activecampaign_field',
		'enable_activecampaign_guest_list',
);

foreach ( $options as $option ) {
	delete_option( $option );
}
