<div class="wrap wp_event_manager wpem-activecampaign-admin-wrap">
    <h2><?php _e('WP Event Manager Activecampaign Settings', 'wpem-activecampaign'); ?></h2>

    <?php do_action('wpem_activecampaign_settings_before'); ?>

    <?php $activecampaign_lists = get_wpem_activecampaign_lists($activecampaign_api_key,$activecampaign_account_url);?>
    
    <div class="wpem-activecampaign-setting-wrapper">
        <div class="wpem-activecampaign-setting">
            <div class="wpem-activecampaign-image">
                <img src="<?php echo WPEM_ACTIVECAMPAIGN_PLUGIN_URL ?>/assets/images/activecampaign_logo_small.png" alt="activecampaign">
            </div>
            <div class="wpem-activecampaign-settings-container">
                
                <?php if (empty($activecampaign_lists) && $activecampaign_api_key != '') { ?>

                    <div class="error">
                        <p>
                            <?php echo __('The API key entered is invalid.', 'wpem-activecampaign'); ?>
                        </p>
                    </div>

                <?php } ?>
                <div class="wpem-activecampaign-info">
                    <h1><?php _e('Activecampaign Settings', 'wpem-activecampaign'); ?></h1>
                    <?php if (!empty($activecampaign_lists)) : ?>

                        <form method="post" class="wp-event-activecampaign-disconnect-settings">
                            <input type="submit" class="wpem-theme-button wpem-theme-button-disconnect" name="wpem_activecampaign_settings" value="<?php esc_attr_e('Disconnect', 'wpem-activecampaign'); ?>">

                            <?php wp_nonce_field('event_activecampaign_disconnect_settings'); ?>
                        </form>


                    <?php endif; ?>
                    <p><?php _e('Integrate Activecampaign with WP Event Manager', 'wpem-activecampaign'); ?></p>
                </div>

                <form method="post" class="wpem-activecampaign-form">
                    <div class="wpem-activecampaign-form-container">
                        <input type="text" class="activecampaign-account-url" name="activecampaign_account_url" placeholder="<?php _e('Activecampaign Account URL', 'wpem-activecampaign'); ?>" value="<?php echo $activecampaign_account_url; ?>">
                        <input type="text" class="activecampaign-api-key" name="activecampaign_api_key" placeholder="<?php _e('Activecampaign API Key', 'wpem-activecampaign'); ?>" value="<?php echo $activecampaign_api_key; ?>">

                        <?php if (empty($activecampaign_lists)) : ?>

                        <?php else : ?>
                            <?php if ($activecampaign_api_key != '' && !empty($activecampaign_lists)) : ?>
                                <select name="activecampaign_list" class="activecampaign-list">
                                    <?php foreach ($activecampaign_lists as $id => $label) : ?>
                                        <option value="<?php echo esc_attr($id); ?>" <?php selected($activecampaign_list, $id); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>

                            <?php if ($activecampaign_api_key != '' && !empty($activecampaign_lists)) : ?>
                                <select name="activecampaign_sync_type" class="activecampaign-sync-type" id="activecampaign-sync-type">
                                    <option value=""><?php _e('Select Activecampaign Sync Type', 'wpem-activecampaign'); ?></option>
                                    <?php foreach (get_wpem_activecampaign_sync_type() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($activecampaign_sync_type, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <?php
                                $style = '';
                                if ($activecampaign_sync_type == 'manual') {
                                    $style = 'style="display: none;"';
                                }
                                ?>
                                <select id="activecampaign-sync-via" <?php echo $style; ?> name="activecampaign_sync_via" class="activecampaign-sync-via">
                                    <option value=""><?php _e('Select Activecampaign Sync Via', 'wpem-activecampaign'); ?></option>
                                    <?php foreach (get_wpem_activecampaign_sync_via() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($activecampaign_sync_via, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <?php
                                $style = '';
                                if ($activecampaign_sync_type == 'manual' || $activecampaign_sync_via == 'when_created') {
                                    $style = 'style="display: none;"';
                                }
                                ?>
                                <select id="activecampaign_sync_schedule" <?php echo $style; ?> name="activecampaign_sync_schedule" class="activecampaign-sync-schedule">
                                    <?php foreach (get_wpem_activecampaign_sync_schedule() as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($activecampaign_sync_schedule, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>

                        <?php endif; ?>

                        <input type="submit" class="wpem-theme-button" name="wpem_activecampaign_settings" value="<?php esc_attr_e('Save Setting', 'wpem-activecampaign'); ?>" />

                        <?php wp_nonce_field('event_activecampaign_settings'); ?>

                    </div>
                </form>

            </div>
        </div>
    </div>

    <?php do_action('wpem_activecampaign_settings_after'); ?>

</div>
