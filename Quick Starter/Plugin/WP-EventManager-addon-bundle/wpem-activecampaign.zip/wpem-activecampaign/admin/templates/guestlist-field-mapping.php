<div class="white-background">
    <form method="post" class="wpem-activecampaign-guest-list-matches-attribute">
        <div class="wpem-activecampaign-settings-guest-list">

            <label><strong><?php _e('Sync Guest Lists', 'wpem-activecampaign'); ?></strong> <input id="setting-enable_activecampaign_guest_list" name="enable_activecampaign_guest_list" type="checkbox" <?php checked($enable_activecampaign_guest_list, true); ?> value="1"> <?php _e('Enable guest list sync with activecampaign.', 'wpem-activecampaign'); ?></label>
        </div>
        <h3><?php _e('Guest Field Mapping with Activecampaign', 'wpem-activecampaign'); ?></h3>
        <table class="widefat wpem-activecampaign-field-maping-table">
            <thead>
                <tr>
                    <th><?php _e('Guest List Field', 'wpem-activecampaign'); ?></th>
                    <th><?php _e('Activecampaign Field', 'wpem-activecampaign'); ?></th>
                    <th class="wpem-activecampaign-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>

            <tbody>
                <?php 
                $dynamic_fields = get_wpem_activecampaign_list_dynamic_field($activecampaign_api_key, $activecampaign_list,$activecampaign_account_url);
                $dynamic_fields_loop = $dynamic_fields;
                ?>
                <?php if (!empty($guest_list_activecampaign_field)) : ?>
                    <?php foreach ($guest_list_activecampaign_field as $sync_field => $form_field) : ?>
                        <tr>
                            <td>
                                <select name="guest_list_field[]" class="guest-list-field">
                                    <option value=""><?php _e('Select Field', 'wpem-activecampaign'); ?>...</option>
                                    <?php foreach (get_event_guests_form_fields() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="guest_list_activecampaign_field[]" class="activecampaign-guest-list-field">
                                    <option value=""><?php _e('Select Activecampaign Field', 'wpem-activecampaign'); ?>...</option>
                                    <?php
                                    if(array_key_exists("contact",$dynamic_fields_loop)){
                                        $dynamic_fields_loop = $dynamic_fields['contact'];
                                    }
                                     foreach ($dynamic_fields_loop as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wpem-activecampaign'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="guest_list_field[]" class="guest-list-field">
                                <option value=""><?php _e('Select Field', 'wpem-activecampaign'); ?>...</option>
                                <?php foreach (get_event_guests_form_fields() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="guest_list_activecampaign_field[]" class="activecampaign-guest-list-field">
                                <option value=""><?php _e('Select Activecampaign Field', 'wpem-activecampaign'); ?>...</option>
                                <?php foreach (get_wpem_activecampaign_list_dynamic_field($activecampaign_api_key, $activecampaign_list,$activecampaign_account_url) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">
                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wpem-activecampaign'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td>
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wpem-activecampaign'); ?></a>
                    </td>
                    <td colspan="2">
                        <?php wp_nonce_field('wpem_admin_activecampaign_guest_list_field_mapping'); ?>
                        <input type="submit" class="button-primary wpem-field-maping-save" name="submit_activecampaign_admin_guest_list_field_mapping" value="<?php esc_attr_e('Save', 'wpem-activecampaign'); ?>" />
                    </td>

                </tr>
            </tfoot>

        </table>
    </form>
</div>		
