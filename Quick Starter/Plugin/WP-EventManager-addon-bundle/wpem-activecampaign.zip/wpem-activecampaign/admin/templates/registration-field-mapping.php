<div class="white-background">
    <form method="post" class="wpem-activecampaign-registration-matches-attribute">
        <div class="wpem-activecampaign-settings-organizer">
            <label><strong>Sync Registrations</strong> <input id="setting-enable_activecampaign_registration" name="enable_activecampaign_registration" type="checkbox" <?php checked($enable_activecampaign_registration, true); ?> value="1"> <?php _e('Enable registration sync with activecampaign.', 'wpem-activecampaign'); ?></label>
        </div>
        <h3><?php _e('Registration Field Mapping with Activecampaign', 'wpem-activecampaign'); ?></h3>
        <table class="widefat wpem-activecampaign-field-maping-table">
            <thead>
                <tr>
                    <th ><?php _e('Registration Field', 'wpem-activecampaign'); ?></th>
                    <th ><?php _e('Activecampaign Field', 'wpem-activecampaign'); ?></th>
                    <th class="wpem-activecampaign-field-maping-actions">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $dynamic_fields = get_wpem_activecampaign_list_dynamic_field($activecampaign_api_key, $activecampaign_list,$activecampaign_account_url);
                $dynamic_fields_loop = $dynamic_fields;
                ?>
                <?php if (!empty($registration_activecampaign_field)) : ?>
                    <?php foreach ($registration_activecampaign_field as $sync_field => $form_field) : ?>
                        <tr>
                            <td>
                                <select name="registration_field[]" class="registration-field">
                                    <option value=""><?php _e('Select registration Field', 'wpem-activecampaign'); ?>...</option>
                                    <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($form_field, $name); ?>><?php echo esc_html($field['label']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="registration_activecampaign_field[]" class="activecampaign-registration-field">
                                    <option value=""><?php _e('Select Activecampaign Field', 'wpem-activecampaign'); ?>...</option>
                                    <?php
                                    if(array_key_exists("contact",$dynamic_fields_loop)){
                                        $dynamic_fields_loop = $dynamic_fields['contact'];
                                    }
                                     foreach ($dynamic_fields_loop as $name => $label) : ?>
                                        <option value="<?php echo esc_attr($name); ?>" <?php selected($sync_field, $name); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="field-actions">
                                <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wpem-activecampaign'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td>
                            <select name="registration_field[]" class="registration-field">
                                <option value=""><?php _e('Select registration Field', 'wpem-activecampaign'); ?>...</option>
                                <?php foreach (get_event_registration_form_fields() as $name => $field) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($field['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="registration_activecampaign_field[]" class="activecampaign-registration-field">
                                <option value=""><?php _e('Select Activecampaign Field', 'wpem-activecampaign'); ?>...</option>
                                <?php foreach (get_wpem_activecampaign_list_dynamic_field($activecampaign_api_key, $activecampaign_list,$activecampaign_account_url) as $name => $label) : ?>
                                    <option value="<?php echo esc_attr($name); ?>" <?php selected('', $name); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="field-actions">
                            <a href="javascript:void(0)" class="delete-field"><?php _e('Delete', 'wpem-activecampaign'); ?></a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <td >
                        <a class="button add-field" href="javascript:void(0)"><?php _e('Add field', 'wpem-activecampaign'); ?></a>
                    </td>
                    <td colspan="2">
                        <?php wp_nonce_field('wpem_activecampaign_admin_registration_field_mapping'); ?>
                        <input type="submit" class="button-primary wpem-field-maping-save" name="submit_activecampaign_admin_registration_mapping" value="<?php esc_attr_e('Save', 'wpem-activecampaign'); ?>" />
                    </td>
                </tr>
            </tfoot>
        </table>
    </form>	
</div>

