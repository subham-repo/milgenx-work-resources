<?php

/*
 * This file use for setings at admin site for event activecampaign integration settings.
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * WPEM_Activecampaign_Integration_Settings class.
 */
class WPEM_Activecampaign_Settings {

    /**
     * __construct function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function __construct() {
        
    }

    /**
     * wpem_activecampaign_settings function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_settings() {
        $user_id = get_current_user_id();

        if (!empty($_POST['wpem_activecampaign_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'event_activecampaign_disconnect_settings')) {
            $arr_activecampaign_lists = get_sync_fields_by_user($user_id, 'activecampaign_lists');

            if (!empty($arr_activecampaign_lists)) {
                foreach ($arr_activecampaign_lists as $activecampaign_list => $activecampaign_name) {
                    delete_wpem_activecampaign_settings_by_user('activecampaign_list_dynamic_field_' . $activecampaign_list);
                }
            }
            delete_wpem_activecampaign_settings_by_user('activecampaign_lists');
            delete_wpem_activecampaign_settings_by_user('activecampaign_settings');

            $arr_post_type = ['event_organizer', 'event_registration', 'event_guests'];
            wp_clear_scheduled_hook('auto_wpem_activecampaign_sync', array($arr_post_type));
        }

        if (!empty($_POST['wpem_activecampaign_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'event_activecampaign_settings')) {
            $activecampaign_account_url = !empty($_POST['activecampaign_account_url']) ? sanitize_text_field($_POST['activecampaign_account_url']) : '';
            $activecampaign_api_key = !empty($_POST['activecampaign_api_key']) ? sanitize_text_field($_POST['activecampaign_api_key']) : '';
            $activecampaign_list = !empty($_POST['activecampaign_list']) ? sanitize_text_field($_POST['activecampaign_list']) : '';
            $activecampaign_sync_type = !empty($_POST['activecampaign_sync_type']) ? sanitize_text_field($_POST['activecampaign_sync_type']) : 'auto';
            $activecampaign_sync_via = !empty($_POST['activecampaign_sync_via']) ? sanitize_text_field($_POST['activecampaign_sync_via']) : 'cron_job';
            $activecampaign_sync_schedule = !empty($_POST['activecampaign_sync_schedule']) ? sanitize_text_field($_POST['activecampaign_sync_schedule']) : 'weekly';

            $activecampaign_settings = [
                'activecampaign_account_url' => $activecampaign_account_url,
                'activecampaign_api_key' => $activecampaign_api_key,
                'activecampaign_list' => $activecampaign_list,
                'activecampaign_sync_type' => $activecampaign_sync_type,
                'activecampaign_sync_schedule' => $activecampaign_sync_schedule,
                'activecampaign_sync_via' => $activecampaign_sync_via,
            ];

            update_wpem_activecampaign_settings_by_user('activecampaign_settings', $activecampaign_settings);

            $arr_post_type = ['event_organizer', 'event_registration', 'event_guests'];
            wp_clear_scheduled_hook('auto_wpem_activecampaign_sync', array($arr_post_type));

            if ($activecampaign_sync_type == 'auto' && $activecampaign_sync_via == 'cron_job') {
                switch ($activecampaign_sync_schedule) {
                    case '5min':
                        $next = strtotime('+5 minutes');
                        break;
                    case 'daily':
                        $next = strtotime('+1 day');
                        break;
                    case 'weekly':
                        $next = strtotime('+1 week');
                        break;
                    case 'monthly':
                        $next = strtotime('+1 month');
                        break;
                    case 'yearly':
                        $next = strtotime('+1 year');
                        break;
                    default:
                        $next = strtotime('+1 week');
                        break;
                }

                // Create cron
                wp_schedule_event($next, $activecampaign_sync_schedule, 'auto_wpem_activecampaign_sync', array($arr_post_type));
            }
        }

        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
        $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
        $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '';
        $activecampaign_sync_type = isset($activecampaign_settings['activecampaign_sync_type']) && !empty($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : 'auto';
        $activecampaign_sync_via = isset($activecampaign_settings['activecampaign_sync_via']) && !empty($activecampaign_settings['activecampaign_sync_via']) ? $activecampaign_settings['activecampaign_sync_via'] : 'cron_job';
        $activecampaign_sync_schedule = isset($activecampaign_settings['activecampaign_sync_schedule']) ? $activecampaign_settings['activecampaign_sync_schedule'] : '';

        $check_wpem_activecampaign_key = check_wpem_activecampaign_key($activecampaign_api_key,$activecampaign_account_url);

        include('templates/activecampaign-settings.php');
    }

}
