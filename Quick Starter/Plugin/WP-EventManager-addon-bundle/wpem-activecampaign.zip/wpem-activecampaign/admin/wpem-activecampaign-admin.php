<?php

/*
 * This file use for setings at admin site for event activecampaign integration admin.
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * WPEM_Activecampaign_Integration_Admin class.
 */
class WPEM_Activecampaign_Admin {

    /**
     * The single instance of the class.
     *
     * @var self
     * @since  2.5
     */
    private static $_instance = null;

    /**
     * Main WP Event Manager Instance.
     *
     * Ensures only one instance of WP Event Manager is loaded or can be loaded.
     *
     * @since  2.5
     * @static
     * @see WP_Event_Manager()
     * @return self Main instance.
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * __construct function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function __construct() {
        include ('wpem-activecampaign-settings.php');
        $this->settings_class = new WPEM_Activecampaign_Settings();

        add_action('admin_menu', array($this, 'admin_menu'), 12);

        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));

        if (get_option('enable_event_organizer')) {
            //add_action('wpem_activecampaign_settings_after', array($this, 'wpem_activecampaign_organization_matches_attribute'));

            add_filter('manage_edit-event_organizer_columns', array($this, 'event_organizer_columns'), 12);
            add_action('manage_event_organizer_posts_custom_column', array($this, 'event_organizer_content'));
        }

        if (is_plugin_active('wp-event-manager-registrations/wp-event-manager-registrations.php')) {
            add_action('wpem_activecampaign_settings_after', array($this, 'wpem_activecampaign_admin_registration_field_mapping'));

            add_filter('manage_edit-event_registration_columns', array($this, 'event_registration_columns'), 12);
            add_action('manage_event_registration_posts_custom_column', array($this, 'event_registration_content'));

            //manual registration bulk action
            add_filter('bulk_actions-edit-event_registration', array($this, 'register_registration_bulk_actions'));
            add_filter('handle_bulk_actions-edit-event_registration', array($this, 'wpem_sync_attendee_bulk_handler'), 10, 3);
            add_action('admin_notices', array($this, 'registration_sync_bulk_action_admin_notice'));

            //manual Gust list bulk action
            add_filter('bulk_actions-edit-event_guests', array($this, 'register_guest_list_bulk_actions'));
            add_filter('handle_bulk_actions-edit-event_guests', array($this, 'wpem_sync_guest_bulk_handler'), 10, 3);
            add_action('admin_notices', array($this, 'guest_sync_bulk_action_admin_notice'));
        }

        if (is_plugin_active('wpem-guests/wpem-guests.php')) {
            add_action('wpem_activecampaign_settings_after', array($this, 'wpem_activecampaign_guest_lists_field_mapping'));

            add_filter('manage_edit-event_guest_list_columns', array($this, 'event_guest_list_columns'), 12);
            add_action('manage_event_guest_list_posts_custom_column', array($this, 'event_guest_list_content'));
        }

        // while new create
        add_action('wp_insert_post', array($this, 'wpem_activecampaign_sync_via_add_new_create'), 10, 3);
    }

    /**
     * admin_menu function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function admin_menu() {
        add_submenu_page('edit.php?post_type=event_listing', __('WP Event Manager Activecampaign Settings', 'wpem-activecampaign'), __('Activecampaign', 'wpem-activecampaign'), 'manage_options', 'event-manager-activecampaign-settings', array($this->settings_class, 'wpem_activecampaign_settings'), 7);
    }

    /**
     * admin_enqueue_scripts function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function admin_enqueue_scripts() {
        wp_enqueue_style('wpem-activecampaign-admin', WPEM_ACTIVECAMPAIGN_PLUGIN_URL . '/assets/css/admin.css', '', WPEM_ACTIVECAMPAIGN_VERSION);

        wp_register_script('wpem-activecampaign-admin', WPEM_ACTIVECAMPAIGN_PLUGIN_URL . '/assets/js/admin-activecampaign.js', array('jquery'), WPEM_ACTIVECAMPAIGN_VERSION, true);

        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
        $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
        $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '';
        $activecampaign_sync_type = isset($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : '';

        $add_sync_button = 'no';

        if ($activecampaign_sync_type === 'manual') {
            $check_wpem_activecampaign_key = check_wpem_activecampaign_key($activecampaign_api_key,$activecampaign_account_url);
            if ($activecampaign_list == '') {
                $add_sync_button = 'no';
            } else if ($activecampaign_api_key == '' || $activecampaign_list == '') {
                $add_sync_button = 'no';
            } else {
                $add_sync_button = 'yes';
            }
        }

        wp_localize_script('wpem-activecampaign-admin', 'wpem_activecampaign_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'wpem_activecampaign_admin_security' => wp_create_nonce('_nonce_wpem_activecampaign_admin_security'),
            'in_queue_icon' => EVENT_MANAGER_PLUGIN_URL . '/assets/images/ajax-loader.gif',
                //'sync_button_text' => __( 'Sync with Activecampaign', 'wpem-activecampaign'),
                //'add_sync_button' => $add_sync_button,
                )
        );

        wp_enqueue_script('wpem-activecampaign-admin');
    }

    /**
     * wpem_activecampaign_organization_matches_attribute function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_organization_matches_attribute() {


        if (!empty($_POST['wp_event_activecampaign_organizer_matches_attribute']) && wp_verify_nonce($_POST['_wpnonce'], 'event_activecampaign_organizer_matches_attribute')) {
            $organizer_field = !empty($_POST['organizer_field']) ? array_filter($_POST['organizer_field']) : '';

            $enable_activecampaign_organizer = isset($_POST['enable_activecampaign_organizer']) ? $_POST['enable_activecampaign_organizer'] : 0;
            $organizer_activecampaign_field = !empty($_POST['organizer_activecampaign_field']) ? array_filter($_POST['organizer_activecampaign_field']) : '';

            update_option('organizer_field', $organizer_field);

            $new_organizer_activecampaign_field = [];

            if (!empty($organizer_activecampaign_field)) {
                foreach ($organizer_activecampaign_field as $key => $value) {
                    if (isset($organizer_field[$key]))
                        $new_organizer_activecampaign_field[$value] = $organizer_field[$key];
                }
            }
            update_option('organizer_activecampaign_field', $new_organizer_activecampaign_field);

            update_option('enable_activecampaign_organizer', $enable_activecampaign_organizer);
        }

        $enable_activecampaign_organizer = get_option('enable_activecampaign_organizer', true);

        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
        $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
        $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '';
        $check_wpem_activecampaign_key = check_wpem_activecampaign_key($activecampaign_api_key,$activecampaign_account_url);

        $organizer_field = get_option('organizer_field');
        $organizer_activecampaign_field = get_option('organizer_activecampaign_field');

        if ($check_wpem_activecampaign_key == "")
            return;

        if ($activecampaign_api_key != '' && $activecampaign_account_url != '') :
            include('templates/organizer-field-mapping.php');
        endif;
    }

    /**
     * event_organizer_columns function.
     *
     * @access public
     * @param mixed $columns
     * @return void
     * @since 1.0.0
     */
    public function event_organizer_columns($columns) {
        foreach ($columns as $key => $column) {
            $new_columns[$key] = $column;

            if ('organizer_email' === $key) {
                $new_columns['_is_activecampaign_sync'] = '<span class="tips dashicons dashicons-email" data-tip="' . __("Activecampaign", 'wpem-activecampaign') . '">' . __("Activecampaign", 'wpem') . '</span>';
            }
        }

        return $new_columns;
    }

    /**
     * event_organizer_content function.
     *
     * @access public
     * @param mixed $column_name
     * @return void
     * @since 1.0.0
     */
    public function event_organizer_content($column_name) {
        global $post;

        if ($column_name == '_is_activecampaign_sync') {
            $_is_activecampaign_sync = get_post_meta($post->ID, '_is_activecampaign_sync', true);

            if ($_is_activecampaign_sync == '') {
                $_is_activecampaign_sync = __('-', 'wpem-activecampaign');
            }

            echo $_is_activecampaign_sync;
        }
    }

    /**
     * wpem_activecampaign_admin_registration_field_mapping function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_admin_registration_field_mapping() {
        if (!empty($_POST['submit_activecampaign_admin_registration_mapping']) && wp_verify_nonce($_POST['_wpnonce'], 'wpem_activecampaign_admin_registration_field_mapping')) {
            $registration_field = !empty($_POST['registration_field']) ? array_filter($_POST['registration_field']) : '';
            $registration_activecampaign_field = !empty($_POST['registration_activecampaign_field']) ? array_filter($_POST['registration_activecampaign_field']) : '';
            $enable_activecampaign_registration = isset($_POST['enable_activecampaign_registration']) ? $_POST['enable_activecampaign_registration'] : 0;


            update_option('registration_field', $registration_field);

            $new_registration_activecampaign_field = [];

            if (!empty($registration_activecampaign_field) > 0) {
                foreach ($registration_activecampaign_field as $key => $value) {
                    $new_registration_activecampaign_field[$value] = $registration_field[$key];
                }
            }
            update_option('registration_activecampaign_field', $new_registration_activecampaign_field);
            update_option('enable_activecampaign_registration', $enable_activecampaign_registration);
        }

        $enable_activecampaign_registration = get_option('enable_activecampaign_registration', true);
        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
        $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
        $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '';
        $check_wpem_activecampaign_key = check_wpem_activecampaign_key($activecampaign_api_key,$activecampaign_account_url);

        $registration_field = get_option('registration_field');
        $registration_activecampaign_field = get_option('registration_activecampaign_field');

        if (empty($registration_activecampaign_field)) {
            $registration_activecampaign_field = get_default_wpem_activecampaign_registration_matches_attribute();
        }
        if ($check_wpem_activecampaign_key == "")
            return;

        if ($activecampaign_api_key != '' && $activecampaign_account_url != '') :
            ?>
            <?php include('templates/registration-field-mapping.php'); ?>
        <?php endif; ?>

        <?php

    }

    /**
     * event_registration_columns function.
     *
     * @access public
     * @param mixed $columns
     * @return void
     * @since 1.0.0
     */
    public function event_registration_columns($columns) {
        foreach ($columns as $key => $column) {
            $new_columns[$key] = $column;

            if ('event_registration_posted' === $key) {
                $new_columns['_is_activecampaign_sync'] = '<span class="tips dashicons dashicons-email" data-tip="' . __("Activecampaign", 'wpem-activecampaign') . '">' . __("Activecampaign", 'wpem') . '</span>';
            }
        }

        return $new_columns;
    }

    /**
     * event_registration_content function.
     *
     * @access public
     * @param mixed $column_name
     * @return void
     * @since 1.0.0
     */
    public function event_registration_content($column_name) {
        global $post;

        if ($column_name == '_is_activecampaign_sync') {
            $_is_activecampaign_sync = get_post_meta($post->ID, '_is_activecampaign_sync', true);

            if ($_is_activecampaign_sync == '') {
                $_is_activecampaign_sync = __('-', 'wpem-activecampaign');
            }

            echo $_is_activecampaign_sync;
        }
    }

    /**
     * register_my_bulk_actions function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function register_registration_bulk_actions($bulk_actions) {
        $enable_registration = get_option('enable_activecampaign_registration', true);
        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $sync_type = isset($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : 'auto';

        if ($sync_type == 'manual' && $enable_registration == true)
            $bulk_actions['attendee_sync_activecampaign'] = __('Sync with activecampaign', 'wpem-activecampaign');

        return $bulk_actions;
    }

    /**
     * wpem_sync_attendee_bulk_handler function.
     *
     * @access public
     * @return String 
     * @since 1.0.0
     */
    public function wpem_sync_attendee_bulk_handler($redirect_to, $doaction, $post_ids) {
        if ($doaction !== 'attendee_sync_activecampaign')
            return $redirect_to;

        $response = $this->add_admin_data_in_wpem_activecampaign_list('event_registration', $post_ids);

        $redirect_to = add_query_arg('activecampaign_bulk_attendee_sync', count($post_ids), $redirect_to);
        return $redirect_to;
    }

    /**
     * registration_sync_bulk_action_admin_notice function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function registration_sync_bulk_action_admin_notice() {
        if (!empty($_REQUEST['activecampaign_bulk_attendee_sync'])) {
            $attendee_count = intval($_REQUEST['activecampaign_bulk_attendee_sync']);
            printf('<div class="updated"><p id="message" class="updated fade">' .
                    _n('%s Attendee syncronized to Activecampaign.',
                            '%s Attendee  syncronized to Activecampaign.',
                            $attendee_count,
                            'wpem-activecampaign'
                    ) . '</p></div>', $attendee_count);
        }
    }

    /**
     * register_guest_list_bulk_actions function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function register_guest_list_bulk_actions($bulk_actions) {
        $enable_guest_list = get_option('enable_activecampaign_registration', true);
        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $sync_type = isset($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : 'auto';

        if ($sync_type == 'manual' && $enable_guest_list == true)
            $bulk_actions['guest_sync_activecampaign'] = __('Sync with activecampaign', 'wpem-activecampaign');

        return $bulk_actions;
    }

    /**
     * wpem_sync_attendee_bulk_handler function.
     *
     * @access public
     * @return String 
     * @since 1.0.0
     */
    public function wpem_sync_guest_bulk_handler($redirect_to, $doaction, $post_ids) {
        if ($doaction !== 'guest_sync_activecampaign')
            return $redirect_to;

        $response = $this->add_admin_data_in_wpem_activecampaign_list('event_guests', $post_ids);
       
        $redirect_to = add_query_arg('activecampaign_bulk_guest_sync', count($post_ids), $redirect_to);
        return $redirect_to;
    }

    /**
     * registration_sync_bulk_action_admin_notice function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function guest_sync_bulk_action_admin_notice() {
        if (!empty($_REQUEST['activecampaign_bulk_guest_sync'])) {
            $guest_count = intval($_REQUEST['activecampaign_bulk_guest_sync']);
            printf('<div class="updated"><p id="message" class="updated fade">' .
                    _n('Guest %s syncronized to Activecampaign.',
                            'Guests %s syncronized to Activecampaign.',
                            $guest_count,
                            'wpem-activecampaign'
                    ) . '</p></div>', $guest_count);
        }
    }

    /**
     * wpem_activecampaign_guest_lists_field_mapping function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_guest_lists_field_mapping() {
        if (!empty($_POST['submit_activecampaign_admin_guest_list_field_mapping']) && wp_verify_nonce($_POST['_wpnonce'], 'wpem_admin_activecampaign_guest_list_field_mapping')) {
            $guest_list_field = !empty($_POST['guest_list_field']) ? array_filter($_POST['guest_list_field']) : '';
            $guest_list_activecampaign_field = !empty($_POST['guest_list_activecampaign_field']) ? array_filter($_POST['guest_list_activecampaign_field']) : '';
            $enable_activecampaign_guest_list = isset($_POST['enable_activecampaign_guest_list']) ? $_POST['enable_activecampaign_guest_list'] : 0;

            update_option('guest_list_field', $guest_list_field);

            $new_registration_activecampaign_field = [];

            if (!empty($guest_list_activecampaign_field) > 0) {
                foreach ($guest_list_activecampaign_field as $key => $value) {
                    $new_registration_activecampaign_field[$value] = $guest_list_field[$key];
                }
            }
            update_option('guest_list_activecampaign_field', $new_registration_activecampaign_field);
            update_option('enable_activecampaign_guest_list', $enable_activecampaign_guest_list);
        }
        $enable_activecampaign_guest_list = get_option('enable_activecampaign_guest_list', true);
        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
        $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
        $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '';
        $check_wpem_activecampaign_key = check_wpem_activecampaign_key($activecampaign_api_key,$activecampaign_account_url);

        $guest_list_field = get_option('guest_list_field');
        $guest_list_activecampaign_field = get_option('guest_list_activecampaign_field');

        if (empty($guest_list_activecampaign_field)) {
            $guest_list_activecampaign_field = get_default_wpem_activecampaign_guest_list_matches_attribute();
        }
        if ($check_wpem_activecampaign_key == "")
            return;

        if ($activecampaign_api_key != '' && $activecampaign_account_url != '') :
            include('templates/guestlist-field-mapping.php');
        endif;
    }

    /**
     * event_guest_list_columns function.
     *
     * @access public
     * @param mixed $columns
     * @return void
     * @since 1.0.0
     */
    public function event_guest_list_columns($columns) {
        foreach ($columns as $key => $column) {
            $new_columns[$key] = $column;

            if ('group_name' === $key) {
                $new_columns['_is_activecampaign_sync'] = '<span class="tips dashicons dashicons-email" data-tip="' . __("Activecampaign", 'wpem-activecampaign') . '">' . __("Activecampaign", 'wpem') . '</span>';
            }
        }

        return $new_columns;
    }

    /**
     * event_guest_list_content function.
     *
     * @access public
     * @param mixed $column_name
     * @return void
     * @since 1.0.0
     */
    public function event_guest_list_content($column_name) {
        global $post;

        if ($column_name == '_is_activecampaign_sync') {
            $_is_activecampaign_sync = get_post_meta($post->ID, '_is_activecampaign_sync', true);

            if ($_is_activecampaign_sync == '') {
                $_is_activecampaign_sync = __('-', 'wpem-activecampaign');
            }

            echo $_is_activecampaign_sync;
        }
    }

    /**
     * get_wpem_activecampaign_list function.
     *
     * @access public
     * @return void
     * @since 1.0.0
     */
    public function get_wpem_activecampaign_list() {
        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
        $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';

        $lists = [];

        if ($activecampaign_api_key != '' && $activecampaign_account_url != '') {
            $lists = get_wpem_activecampaign_lists($activecampaign_api_key,$activecampaign_account_url);
        }

        return $lists;
    }

    /**
     * wpem_activecampaign_sync_via_add_new_create function.
     *
     * @access public
     * @param mixed $post_id, $post, $update
     * @return void
     * @since 1.0.0
     */
    public function wpem_activecampaign_sync_via_add_new_create($post_id, $post, $update) {
        $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

        $activecampaign_sync_type = isset($activecampaign_settings['activecampaign_sync_type']) ? $activecampaign_settings['activecampaign_sync_type'] : '';
        $activecampaign_sync_via = isset($activecampaign_settings['activecampaign_sync_via']) ? $activecampaign_settings['activecampaign_sync_via'] : '';

        if ($activecampaign_sync_type == 'auto' && $activecampaign_sync_via == 'when_created') {
            if (!in_array($post->post_status, ['auto-draft']) && in_array($post->post_type, ['event_organizer', 'event_registration', 'event_guest_list'])) {
                $arr_post_id = [$post_id];
                $post_type = $post->post_type;

                if (count($arr_post_id) > 0) {
                    $response = $this->add_admin_data_in_wpem_activecampaign_list($post_type, $arr_post_id);
                }
            }
        }
    }

    /**
     * add_admin_data_in_wpem_activecampaign_list function.
     *
     * @access public
     * @param mixed $post_type, $arr_post_id
     * @return void
     * @since 1.0.0
     */
    public function add_admin_data_in_wpem_activecampaign_list($post_type = '', $arr_post_id = []) {
        $response = [];

        if (in_array($post_type, ['event_organizer', 'event_registration', 'event_guests']) != '' && !empty($arr_post_id)) {
            $activecampaign_settings = get_wpem_activecampaign_settings_by_user();

            $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
            $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
            $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : '';

            $organizer_activecampaign_field = get_option('organizer_activecampaign_field');
            $registration_activecampaign_field = get_option('registration_activecampaign_field');
            $guest_list_activecampaign_field = get_option('guest_list_activecampaign_field');

            if ($post_type == 'event_organizer') {
                $activecampaign_sync_field = $organizer_activecampaign_field;

                if (empty($activecampaign_sync_field)) {
                    $activecampaign_sync_field = get_default_wpem_activecampaign_organizer_matches_attribute();
                }

                $new_activecampaign_sync_field = [];

                foreach ($activecampaign_sync_field as $key => $value) {
                    $new_activecampaign_sync_field[$key] = '_' . $value;
                }

                $activecampaign_sync_field = $new_activecampaign_sync_field;
            } else if ($post_type == 'event_registration') {

                $activecampaign_sync_field = $registration_activecampaign_field;

                if (empty($activecampaign_sync_field)) {
                    $activecampaign_sync_field = get_default_wpem_activecampaign_registration_matches_attribute();
                }
            } else if ($post_type == 'event_guests') {

                $activecampaign_sync_field = $guest_list_activecampaign_field;

                if (empty($activecampaign_sync_field)) {

                    $activecampaign_sync_field = get_default_wpem_activecampaign_guest_list_matches_attribute();
                }
            }

            foreach ($arr_post_id as $post_id) {

                if (isset($activecampaign_settings['activecampaign_list']) && $activecampaign_settings['activecampaign_list'] == false) {
                    $event_id = wp_get_post_parent_id($post_id);

                    $event_activecampaign_list = get_post_meta($event_id, 'activecampaign_list', true);
                    if ($event_activecampaign_list == false) {
                        $response['message'] = __('Synchronization disabled for this event.', 'wpem-activecampaign');
                        continue;
                    }

                    if (!empty($event_activecampaign_list)) {
                        $activecampaign_list = $event_activecampaign_list;
                    }
                } 

                $_is_activecampaign_sync = get_post_meta($post_id, '_is_activecampaign_sync', true);
                
                if ($_is_activecampaign_sync != 'subscribed') {
                    $result = sync_data_in_wpem_activecampaign_list($activecampaign_api_key, $activecampaign_list, $activecampaign_sync_field, $post_id,$activecampaign_account_url);

                    if (isset($result['contact']['id']) && $result['contact']['id'] != '') {
                        update_post_meta($post_id, '_is_activecampaign_sync', 'subscribed');
                    }
                    if (isset($result['errors']) && ($result['errors'][0]['code'] == 'duplicate')) {
                        $response['code'] = 200;
                        $response['message'] = __('The contact already exists.', 'wpem-activecampaign');;
                    }
                    else if (isset($result['errors']) && ($result['errors'][0]['code'] )) {
                        $response['code'] = 400;
                        $response['message'] = $result['errors'][0]['code'];
                    } else if (isset($result['code']) && ($result['code'] == 'invalid_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else {
                        $response['code'] = 200;
                        $response['message'] = __('Subscribed', 'wpem-activecampaign');
                    }
                } else {
                    $response['code'] = 400;
                    $response['message'] = __('The contact already exists.', 'wpem-activecampaign');
                }
            }
        }
        
        return $response;
    }


}

new WPEM_Activecampaign_Admin();
