var AdminActivecampaignIntegration = function () {

    return {

        init: function ()
        {
            jQuery('select#activecampaign-sync-type').on('change', AdminActivecampaignIntegration.actions.syncType);
            jQuery('select#activecampaign-sync-via').on('change', AdminActivecampaignIntegration.actions.syncVia);

            jQuery('body').on('click', '.wpem-activecampaign-organizer-matches-attribute .add-field', AdminActivecampaignIntegration.actions.addFieldOrganization);
            jQuery('body').on('click', '.wpem-activecampaign-organizer-matches-attribute .delete-field', AdminActivecampaignIntegration.actions.deleteFieldOrganization);

            jQuery('body').on('click', '.wpem-activecampaign-registration-matches-attribute .add-field', AdminActivecampaignIntegration.actions.addFieldRegistration);
            jQuery('body').on('click', '.wpem-activecampaign-registration-matches-attribute .delete-field', AdminActivecampaignIntegration.actions.deleteFieldRegistration);

            jQuery('body').on('click', '.wpem-activecampaign-guest-list-matches-attribute .add-field', AdminActivecampaignIntegration.actions.addFieldGuest);
            jQuery('body').on('click', '.wpem-activecampaign-guest-list-matches-attribute .delete-field', AdminActivecampaignIntegration.actions.deleteFieldGuest);

        },

        actions:
                {

                    /**
                     * syncType function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    syncType: function (e)
                    {

                        var activecampaign_sync_type = jQuery(e.target).val();
                        if (activecampaign_sync_type === 'auto')
                        {
                            jQuery('#activecampaign-sync-via').show();

                            var activecampaign_sync_via = jQuery('#activecampaign-sync-via').val();
                            if (activecampaign_sync_via == 'when_created')
                            {
                                jQuery('#activecampaign_sync_schedule').hide();
                            } else
                            {
                                jQuery('#activecampaign_sync_schedule').show();
                            }
                        } else
                        {
                            jQuery('#activecampaign-sync-via').hide();
                            jQuery('#activecampaign_sync_schedule').hide();
                        }
                    },

                    /**
                     * syncVia function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    syncVia: function (e)
                    {
                        var activecampaign_sync_via = jQuery(e.target).val();
                        if (activecampaign_sync_via == 'cron_job')
                        {
                            jQuery('#activecampaign_sync_schedule').show();
                        } else
                        {
                            jQuery('#activecampaign_sync_schedule').hide();
                        }
                    },

                    /**
                     * addFieldOrganization function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    addFieldOrganization: function (e)
                    {
                        //var html = jQuery(e.target).closest('tr').html();
                        var html = jQuery('.wpem-activecampaign-organizer-matches-attribute tbody tr').last().html();
                        html = html.replace('selected="selected"', '');
                        html = html.replace('selected="selected"', '');
                        jQuery('.wpem-activecampaign-organizer-matches-attribute tbody').append('<tr>' + html + '</tr>');
                    },

                    /**
                     * deleteFieldOrganization function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    deleteFieldOrganization: function (e)
                    {
                        jQuery(e.target).closest('tr').remove();
                    },

                    /**
                     * addFieldRegistration function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    addFieldRegistration: function (e)
                    {
                        //var html = jQuery(e.target).closest('tr').html();
                        var html = jQuery('.wpem-activecampaign-registration-matches-attribute tbody tr').last().html();
                        html = html.replace('selected="selected"', '');
                        html = html.replace('selected="selected"', '');
                        jQuery('.wpem-activecampaign-registration-matches-attribute tbody').append('<tr>' + html + '</tr>');
                    },

                    /**
                     * deleteFieldRegistration function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    deleteFieldRegistration: function (e)
                    {
                        jQuery(e.target).closest('tr').remove();
                    },

                    /**
                     * addFieldGuest function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    addFieldGuest: function (e)
                    {
                        //var html = jQuery(e.target).closest('tr').html();
                        var html = jQuery('.wpem-activecampaign-guest-list-matches-attribute tbody tr').last().html();
                        html = html.replace('selected="selected"', '');
                        html = html.replace('selected="selected"', '');
                        jQuery('.wpem-activecampaign-guest-list-matches-attribute tbody').append('<tr>' + html + '</tr>');
                    },

                    /**
                     * deleteFieldGuest function.
                     *
                     * @access public
                     * @param 
                     * @return 
                     * @since 1.0
                     */
                    deleteFieldGuest: function (e)
                    {
                        jQuery(e.target).closest('tr').remove();
                    },

                } /* end of action */

    }; /* enf of return */

}; /* end of class */

AdminActivecampaignIntegration = AdminActivecampaignIntegration();

jQuery(document).ready(function ()
{
    AdminActivecampaignIntegration.init();
});
