<div id="wpem_activecampaign" class="wpem-activecampaign">

    <?php do_action('wpem_activecampaign_dashboard_before'); ?>

    <?php $check_wpem_activecampaign_key = check_wpem_activecampaign_key($activecampaign_api_key); ?>
    <?php $activecampaign_lists = get_wpem_activecampaign_lists($activecampaign_api_key,$activecampaign_account_url); ?>
    <?php if (empty($activecampaign_lists) && $activecampaign_api_key != '' ) { ?>

        <p class="event-manager-message wpem-alert wpem-alert-danger">
            <?php echo __('The API key entered is invalid.', 'wpem-activecampaign'); ?>
        </p>

    <?php } ?>

    <div class="wpem-main wpem-activecampaign-wrapper event-activecampaign">
        <div class="wpem-activecampaign-matches-attribute-header wpem-form-wrapper">
            <h3 class="wpem-form-title wpem-heading-text"><?php _e('Activecampaign Settings', 'wpem-activecampaign'); ?></h3>

            <?php
            if (!empty($activecampaign_lists)) :
                ?>
                <form class="wpem-activecampaign-disconnect wpem-form-wrapper" method="POST">

                    <input type="hidden" name="action" value="show_activecampaign" />
                    <?php if (!empty($_GET['page_id'])) : ?>
                        <input type="hidden" name="page_id" value="<?php echo absint($_GET['page_id']); ?>" />
                    <?php endif; ?>

                    <button type="submit" name="wp_event_manager_activecampaign_disconnect" class="wpem-theme-button wpem-theme-button-disconnect" value="<?php esc_attr_e('Disconnect', 'wpem-activecampaign'); ?>"><?php esc_attr_e('Disconnect', 'wpem-activecampaign'); ?></button>

                    <?php wp_nonce_field('event_manager_activecampaign_disconnect'); ?>

                </form>
            <?php endif; ?>
        </div>
        <div class="wpem-activecampaign-body">
            <form class="wpem-activecampaign wpem-form-wrapper" method="POST">
                <div class="wpem-activecampaign-field">
                    <div class="wpem-row">

                        <?php
                        $style = '';
                        if ($activecampaign_api_key != '' && $activecampaign_account_url != '') {
                            if (empty($activecampaign_lists)) {
                                $style = 'style="display: block;"';
                            } else {
                                $style = 'style="display: none;"';
                            }
                        }
                        ?>
                        <div class="wpem-col-md-6" <?php echo $style; ?>>
                            <div class="wpem-form-group">
                                <?php
                                $readonly = '';
                                if ($activecampaign_api_key != '' && $activecampaign_account_url != '' && !empty($activecampaign_lists)) {
                                        $readonly = 'readonly';
                                }
                                ?>
                                <input type="text" name="activecampaign_account_url" id="activecampaign-account-url" class="activecampaign-account-url" placeholder="<?php _e('Enter Activecampaign Account URL', 'wpem-activecampaign'); ?>" value="<?php echo $activecampaign_account_url; ?>" <?php echo $readonly; ?> />
                                
                            </div>
                        </div>
                        <div class="wpem-col-md-6" <?php echo $style; ?>>
                            <div class="wpem-form-group">
                                <?php
                                $readonly = '';
                                if ($activecampaign_api_key != '' && $activecampaign_account_url != '' && !empty($activecampaign_lists)) {
                                        $readonly = 'readonly';
                                }
                                ?>
                                
                                <input type="text" name="activecampaign_api_key" id="activecampaign-api-key" class="activecampaign-api-key" placeholder="<?php _e('Enter Activecampaign API Key', 'wpem-activecampaign'); ?>" value="<?php echo $activecampaign_api_key; ?>" <?php echo $readonly; ?> />
                            </div>
                        </div>

                        <?php if (empty($activecampaign_lists)) : ?>
                        <?php else : ?>
                            <?php if (!empty($activecampaign_api_key) && !empty($activecampaign_account_url)) : ?>
                                <div class="wpem-col-md-6">
                                    <div class="wpem-form-group">
                                        <select name="activecampaign_list" class="activecampaign-list" >
                                            <?php foreach (get_wpem_activecampaign_lists($activecampaign_api_key,$activecampaign_account_url) as $id => $label) : ?>
                                                <option value="<?php echo esc_attr($id); ?>" <?php selected($activecampaign_list, $id); ?>><?php echo esc_html($label); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if (!empty($activecampaign_api_key) && !empty($activecampaign_account_url)) : ?>
                                    <div class="wpem-col-md-6">
                                        <div class="wpem-form-group">
                                            <select required name="activecampaign_sync_type" class="activecampaign-sync-type" id="activecampaign-sync-type">
                                                <option value=""><?php _e('Select Activecampaign Sync Type', 'wpem-activecampaign'); ?>...</option>
                                                <?php foreach (get_wpem_activecampaign_sync_type() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($activecampaign_sync_type, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php
                                    $style = '';
                                    if ($activecampaign_sync_type == 'manual') {
                                        $style = 'style="display: none;"';
                                    }
                                    ?>
                                    <div class="wpem-col-md-6" id="activecampaign_sync_via" <?php echo $style; ?>>
                                        <div class="wpem-form-group">
                                            <select name="activecampaign_sync_via" class="activecampaign-sync-via" id="activecampaign-sync-via">
                                                <option value=""><?php _e('Select Activecampaign Sync Via', 'wpem-activecampaign'); ?>...</option>
                                                <?php foreach (get_wpem_activecampaign_sync_via() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($activecampaign_sync_via, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <?php
                                    $style = '';
                                    if ($activecampaign_sync_type == 'manual' || $activecampaign_sync_via == 'when_created') {
                                        $style = 'style="display: none;"';
                                    }
                                    ?>
                                    <div class="wpem-col-md-6" id="activecampaign_sync_schedule" <?php echo $style; ?>>
                                        <div class="wpem-form-group">
                                            <select name="activecampaign_sync_schedule" class="activecampaign-sync-schedule" id="activecampaign-sync-schedule">
                                                <option value=""><?php _e('Select Activecampaign Sync Schedule', 'wpem-activecampaign'); ?>...</option>
                                                <?php foreach (get_wpem_activecampaign_sync_schedule() as $name => $label) : ?>
                                                    <option value="<?php echo esc_attr($name); ?>" <?php selected($activecampaign_sync_schedule, $name); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                <?php endif; ?>
                            <?php endif; ?>

                        <?php endif; ?>

                        <div class="wpem-col-12">
                            <div class="wpem-form-group">
                                <input type="hidden" name="action" value="show_activecampaign" />
                                <button type="submit" name="wp_event_manager_activecampaign" class="wpem-theme-button" value="<?php esc_attr_e('Save Setting', 'wpem-activecampaign'); ?>"><?php esc_attr_e('Save Setting', 'wpem-activecampaign'); ?></button>

                                <?php wp_nonce_field('event_manager_activecampaign'); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>

    <?php do_action('wpem_activecampaign_dashboard_after'); ?>

</div>
