<?php

if (!function_exists('get_wpem_activecampaign_sync_type')) {

    /**
     * Event Activecampaign Sync Type
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_sync_type() {
        return apply_filters('activecampaign_sync_type', array(
            'auto' => __('Auto', 'wpem-activecampaign'),
            'manual' => __('Manual', 'wpem-activecampaign'),
        ));
    }

}

if (!function_exists('get_wpem_activecampaign_sync_schedule')) {

    /**
     * Event Activecampaign Sync Schedule
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_sync_schedule() {
        return apply_filters('activecampaign_sync_schedule', array(
            '5min' => __('5 Min', 'wpem-activecampaign'),
            'daily' => __('Daily', 'wpem-activecampaign'),
            'weekly' => __('Weekly', 'wpem-activecampaign'),
            'monthly' => __('Monthly', 'wpem-activecampaign'),
            'yearly' => __('Yearly', 'wpem-activecampaign'),
        ));
    }

}

if (!function_exists('get_wpem_activecampaign_sync_via')) {

    /**
     * Event Activecampaign Sync Type
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_sync_via() {
        return apply_filters('activecampaign_sync_via', array(
            'when_created' => __('When new created', 'wpem-activecampaign'),
            'cron_job' => __('Cron Job', 'wpem-activecampaign'),
        ));
    }

}

if (!function_exists('get_wpem_activecampaign_settings_by_user')) {

    /**
     * Get Activecampaign Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_settings_by_user() {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        $activecampaign_settings = [];

        if (current_user_can('manage_options')) {
            $activecampaign_settings = get_option('activecampaign_settings');
        } else {
            $activecampaign_settings = get_user_meta($user_id, 'activecampaign_settings', true);
        }

        return $activecampaign_settings;
    }

}

if (!function_exists('get_wpem_activecampaign_settings_by_user_id')) {

    /**
     * Get Activecampaign Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_settings_by_user_id($user_id = '') {

        $user_meta = get_userdata($user_id);

        $activecampaign_settings = [];

        if (isset($user_meta->roles) && in_array('administrator', $user_meta->roles)) {
            $activecampaign_settings = get_option('activecampaign_settings');
        } elseif (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $activecampaign_settings = get_option('activecampaign_settings');
        } else {
            $activecampaign_settings = get_user_meta($user_id, 'activecampaign_settings', true);
        }

        return $activecampaign_settings;
    }

}

if (!function_exists('update_wpem_activecampaign_settings_by_user')) {

    /**
     * update Activecampaign Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function update_wpem_activecampaign_settings_by_user($field_key = '', $field_value = '') {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        if (current_user_can('manage_options')) {
            update_option($field_key, $field_value);
        } else {
            update_user_meta($user_id, $field_key, $field_value);
        }
    }

}

if (!function_exists('delete_wpem_activecampaign_settings_by_user')) {

    /**
     * update Activecampaign Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function delete_wpem_activecampaign_settings_by_user($field_key = '') {
        if (!is_user_logged_in())
            return;

        $user_id = get_current_user_id();

        if (current_user_can('manage_options')) {
            delete_option($field_key);
        } else {
            delete_user_meta($user_id, $field_key);
        }
    }

}

if (!function_exists('get_sync_fields_by_user')) {

    /**
     * Get Activecampaign Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_sync_fields_by_user($user_id = '', $fields_key = '') {
        $sync_fields = [];

        $user_meta = get_userdata($user_id);

        if ((isset($user_meta->roles) && in_array('administrator', $user_meta->roles)) || current_user_can('manage_options')) {
            $sync_fields = get_option($fields_key);
        } else if (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $sync_fields = get_option($fields_key);
        } else {
            $sync_fields = get_user_meta($user_id, $fields_key, true);
        }

        return $sync_fields;
    }

}

if (!function_exists('get_wpem_activecampaign_sync_fields_by_user')) {

    /**
     * Get Activecampaign Settings
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_sync_fields_by_user($user_id = '', $fields_key = '') {
        $activecampaign_sync_fields = [];

        $user_meta = get_userdata($user_id);

        if ((isset($user_meta->roles) && in_array('administrator', $user_meta->roles)) || current_user_can('manage_options')) {
            $activecampaign_sync_fields = get_option($fields_key);
        } else if (isset($user_meta->roles) && in_array('editor', $user_meta->roles)) {
            $activecampaign_sync_fields = get_option($fields_key);
        } else {
            $activecampaign_sync_fields = get_user_meta($user_id, $fields_key, true);
        }

        return $activecampaign_sync_fields;
    }

}

if (!function_exists('wpem_activecampaign_request')) {

    /**
     * Activecampaign request
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function wpem_activecampaign_request($activecampaign_api_key = '', $end_point = '', $args = [],$activecampaign_account_url= '') {

        $response_body = '';

        if ($activecampaign_api_key != '' && $end_point != '') {
            $url = 'https://'.$activecampaign_account_url.'.api-us1.com/api/3/' . $end_point;

            $response = wp_remote_post($url, $args);

            $result = json_decode(wp_remote_retrieve_body($response), true);
        }

        return $result;
    }

}

if (!function_exists('check_wpem_activecampaign_key')) {

    /**
     * Check activecampaign key
     *
     * @access public
     * @param
     * @return bool
     * @since 1.0.0
     */
    function check_wpem_activecampaign_key($activecampaign_api_key = '',$activecampaign_account_url = '') {

        $response_body = [];

        if ($activecampaign_api_key != '') {
            $args = ['method' => 'GET', 'count' => '1', 'headers' => ['content-type' => 'application/json', 'Api-Token' => $activecampaign_api_key]];

            $end_point = 'lists/';

            $response_body = wpem_activecampaign_request($activecampaign_api_key, $end_point, $args,$activecampaign_account_url);
        }

        return $response_body;
    }

}

if (!function_exists('get_wpem_activecampaign_lists')) {

    /**
     * Get activecampaign list
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_lists($activecampaign_api_key = '',$activecampaign_account_url = '') {

        $user_id = get_current_user_id();

        $arr_activecampaign_lists = get_sync_fields_by_user($user_id, 'activecampaign_lists');

        $arr_activecampaign_lists = [];

        if ($activecampaign_api_key != '') {
            $args = ['method' => 'GET', 'count' => '20', 'headers' => ['content-type' => 'application/json', 'Api-Token' => $activecampaign_api_key]];

            $end_point = 'lists/';

            $response_body = wpem_activecampaign_request($activecampaign_api_key, $end_point, $args,$activecampaign_account_url);

            if (!empty($response_body['lists'])) {
                $arr_activecampaign_lists[] = __('Event based selection', 'wpem-activecampaign');

                foreach ($response_body['lists'] as $activecampaign_list) {
                    $arr_activecampaign_lists[$activecampaign_list['id']] = $activecampaign_list['name'];
                }
            }
        }

        update_wpem_activecampaign_settings_by_user('activecampaign_lists', $arr_activecampaign_lists);

        return $arr_activecampaign_lists;
    }

}

if (!function_exists('get_event_organization_form_field_lists')) {

    /**
     * Get event registration form fields
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_event_organization_form_field_lists() {

        // organizer fields
        $GLOBALS['event_manager']
                ->forms
                ->get_form('submit-organizer', array());
        $form_submit_organizer_instance = call_user_func(array(
            'WP_Event_Manager_Form_Submit_Organizer',
            'instance'
        ));
        $organizer_form_fields = $form_submit_organizer_instance->merge_with_custom_fields('frontend');

        $organizer_fields = $organizer_form_fields['organizer'];

        return $organizer_fields;
    }

}

if (!function_exists('get_wpem_activecampaign_list_static_field')) {

    /**
     * Event Activecampaign List Static Field
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_list_static_field() {
        $fields = array(
            'contact' => array(
                'email' => __('Email', 'wpem-activecampaign'),
                'firstName' => __('First Name', 'wpem-activecampaign'),
                'lastName' => __('Last Name', 'wpem-activecampaign'),
                'phone' => __('Phone', 'wpem-activecampaign'),
            ),
           
        );

        $fields = apply_filters('activecampaign_list_static_field', $fields);

        return $fields;
    }

}

if (!function_exists('get_wpem_activecampaign_list_dynamic_field')) {

    /**
     * Event Activecampaign List dynamin Field
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_list_dynamic_field($activecampaign_api_key = '', $activecampaign_list = '',$activecampaign_account_url = '') {
        $user_id = get_current_user_id();

        if ($activecampaign_api_key != '' && $activecampaign_list != '') {
            $fields = get_sync_fields_by_user($user_id, 'activecampaign_list_dynamic_field_' . $activecampaign_list);

            if (empty($fields)) {
                $args = ['method' => 'GET', 'headers' => ['content-type' => 'application/json', 'Api-Token' => $activecampaign_api_key]];

                $end_point = 'lists/';

                $response_body = wpem_activecampaign_request($activecampaign_api_key, $end_point, $args,$activecampaign_account_url);

                $fields = [
                    'email' => __('Email', 'wpem-activecampaign'),
                ];

                if (!empty($response_body['attributes'])) {
                    foreach ($response_body['attributes'] as $field) {

                        $fields[$field['tag']] = sprintf(__('%s', 'wpem-activecampaign'), $field['name']);
                    }
                }

                $fields['firstName'] = __('First Name', 'wpem-activecampaign');
                $fields['lastName'] = __('Last Name', 'wpem-activecampaign');
                $fields['phone'] = __('Phone', 'wpem-activecampaign');


                update_wpem_activecampaign_settings_by_user('activecampaign_list_dynamic_field_' . $activecampaign_list, $fields);
            }
        } else {
            $fields = get_wpem_activecampaign_list_static_field();
        }

        $fields = apply_filters('activecampaign_list_dynamic_field', $fields);

        return $fields;
    }

}

if (!function_exists('get_wpem_activecampaign_field_static_format')) {

    /**
     * Activecampaign List static Field format
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_field_static_format() {
        return apply_filters('activecampaign_field_static_format', array(
            'contact' => array(
                'email' => __('Email', 'wpem-activecampaign'),
                'firstName' => __('First Name', 'wpem-activecampaign'),
                'lastName' => __('Last Name', 'wpem-activecampaign'),
                'phone' => __('Phone', 'wpem-activecampaign'),
            ),
           
        ));
    }

}

if (!function_exists('get_wpem_activecampaign_field_dynamic_format')) {

    /**
     * Event Activecampaign List Field
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_wpem_activecampaign_field_dynamic_format($activecampaign_api_key = '', $activecampaign_list = '',$activecampaign_account_url = '') {
        if ($activecampaign_api_key != '' && $activecampaign_list != '') {
            $args = ['method' => 'GET', 'headers' => ['content-type' => 'application/json', 'Api-Token' => $activecampaign_api_key]];

            $end_point = 'lists/';

            $response_body = wpem_activecampaign_request($activecampaign_api_key, $end_point, $args,$activecampaign_account_url);

            $fields = [
                'contact' => array(
                    'email' => __('Email', 'wpem-activecampaign'),
                    'firstName' => __('First Name', 'wpem-activecampaign'),
                    'lastName' => __('Last Name', 'wpem-activecampaign'),
                    'phone' => __('Phone', 'wpem-activecampaign'),
                ),
                
            ];

            if (!empty($response_body['attributes'])) {
                foreach ($response_body['attributes'] as $field) {
                    $fields['attributes'][$field['tag']] = __($field['name'], 'wpem-activecampaign');
                }
            }
        } else {
            $fields = get_wpem_activecampaign_field_static_format();
        }

        return $fields;
    }

}

if (!function_exists('get_default_wpem_activecampaign_registration_matches_attribute')) {

    /**
     * Default Activecampaign Registration Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_wpem_activecampaign_registration_matches_attribute() {
        $registration_activecampaign_field = [];

        $registration_form_field = get_event_registration_form_fields();

        foreach ($registration_form_field as $key => $field) {
            if (in_array('from_email', $field['rules'])) {
                $registration_activecampaign_field['email'] = $key;
            } else if (in_array('from_name', $field['rules'])) {
                $registration_activecampaign_field['firstName'] = $key;
            }
        }

        return $registration_activecampaign_field;
    }

}

if (!function_exists('get_default_wpem_activecampaign_organizer_matches_attribute')) {

    /**
     * Default Activecampaign Organizer Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_wpem_activecampaign_organizer_matches_attribute() {
        $organizer_activecampaign_field = [];

        $organizer_activecampaign_field['email'] = 'organizer_email';
        $organizer_activecampaign_field['firstName'] = 'organizer_name';

        return $organizer_activecampaign_field;
    }

}

if (!function_exists('get_event_by_user_id')) {

    /**
     * Get event by user id
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_event_by_user_id($user_id = '') {
        return get_posts(array(
            'posts_per_page' => - 1,
            'post_type' => 'event_listing',
            'post_status' => 'publish',
            'suppress_filters' => 'false',
            'author' => $user_id,
            'fields' => 'ids',
        ));
    }

}

if (!function_exists('get_registration_attendee_list')) {

    /**
     * Get event registration attendee list
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_registration_attendee_list($atts = [], $filters = []) {
        $user_id = get_current_user_id();

        extract($atts = shortcode_atts(array(
            'event_id' => '',
            'posts_per_page' => 20,
            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                ), $atts));

        $registration_activecampaign_field = get_wpem_activecampaign_sync_fields_by_user($user_id, 'registration_activecampaign_field');
        if (empty($registration_activecampaign_field)) {
            $registration_activecampaign_field = get_default_wpem_activecampaign_registration_matches_attribute();
        }

        $args = array(
            'post_type' => 'event_registration',
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'post_parent' => $event_id,
            'author' => $user_id,
            'meta_query' => ['relation' => 'AND',
            ]
        );

        if (isset($registration_activecampaign_field['email']) && !empty($registration_activecampaign_field['email'])) {
            $args['meta_query'][] = ['key' => $registration_activecampaign_field['email'], 'value' => '', 'compare' => '!='];
        }

        if (!empty($filters)) {
            foreach ($filters as $key => $value) {
                if ($key != '' && $value != '') {
                    $args['meta_query'][] = ['key' => $key, 'value' => $value, 'compare' => 'LIKE',];
                }
            }
        }

        $registrations = new WP_Query($args);

        return $registrations;
    }

}

if (!function_exists('get_guest_lists_guest_list')) {

    /**
     * Get event registration attendee list
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_guest_lists_guest_list($atts = [], $filters = []) {
        $user_id = get_current_user_id();

        extract($atts = shortcode_atts(array(
            'event_id' => '',
            'posts_per_page' => 20,
            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
                ), $atts));

        $guest_list_activecampaign_field = get_wpem_activecampaign_sync_fields_by_user($user_id, 'guest_list_activecampaign_field');
        if (empty($guest_list_activecampaign_field)) {
            $guest_list_activecampaign_field = get_default_wpem_activecampaign_guest_list_matches_attribute();
        }

        $args = array(
            'post_type' => 'event_guests',
            'posts_per_page' => $posts_per_page,
            'paged' => $paged,
            'post_parent' => $event_id,
            'author' => $user_id,
            'meta_query' => [
                'relation' => 'AND',
            ]
        );

        if (isset($guest_list_activecampaign_field['email']) && !empty($guest_list_activecampaign_field['email'])) {
            $args['meta_query'][] = ['key' => $guest_list_activecampaign_field['email'], 'value' => '', 'compare' => '!='];
        }

        if (!empty($filters)) {
            foreach ($filters as $key => $value) {
                if ($key != '' && $value != '') {
                    $args['meta_query'][] = ['key' => $key, 'value' => $value, 'compare' => 'LIKE',];
                }
            }
        }

        $guests = new WP_Query($args);

        return $guests;
    }

}

if (!function_exists('sync_data_in_wpem_activecampaign_list')) {

    /**
     * Sync attendees in activecampaign
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function sync_data_in_wpem_activecampaign_list($activecampaign_api_key = '', $activecampaign_list = '', $registration_activecampaign_field = [], $post_id = '',$activecampaign_account_url = '') {
        $response_body = [];

        if ($activecampaign_api_key != '' && $activecampaign_list != '' && !empty($registration_activecampaign_field) && $post_id != '') {
            $params = [];
            $field_activecampaign = get_wpem_activecampaign_field_dynamic_format($activecampaign_api_key, $activecampaign_list,$activecampaign_account_url);
            foreach ($field_activecampaign as $field_name => $field_value) {
                if (is_array($field_value)) {
                    foreach ($field_value as $field_name2 => $field_value2) {
                        if (is_array($field_value2)) {
                            foreach ($field_value2 as $field_name3 => $field_value3) {
                                if (array_key_exists($field_name3, $registration_activecampaign_field)) {
                                    $params[$field_name][$field_name2][$field_name3] = get_post_meta($post_id, $registration_activecampaign_field[$field_name3], true);
                                }
                            }
                        } else {
                            if (array_key_exists($field_name2, $registration_activecampaign_field)) {
                                $params[$field_name][$field_name2] = get_post_meta($post_id, $registration_activecampaign_field[$field_name2], true);
                            }
                        }
                    }
                } else {
                    if (array_key_exists($field_name, $registration_activecampaign_field)) {
                        $params[$field_name] = get_post_meta($post_id, $registration_activecampaign_field[$field_name], true);
                    }
                }
            }

            $params['listIds'] = array_map('intval', array($activecampaign_list));

            $params['status'] = 'subscribed';
            
            $args = [
                'method' => 'POST',
                'headers' => [
                    'Accept' => 'application/json',
                    'content-type' => 'application/json',
                    'Api-Token' => $activecampaign_api_key
                ],
                'body' => json_encode($params)
            ];
            $end_point = 'contacts/';
            $response_body = wpem_activecampaign_request($activecampaign_api_key, $end_point, $args,$activecampaign_account_url);
            if(isset($response_body['errors'])){
                return $response_body;
            }
            // add contact into the list
            $contact_id = $response_body['contact']['id'];
            $list_params = array(
                'contactList' => array(
                    'list' => $activecampaign_list,
                    'contact' => $contact_id,
                    'status' => '1'
                )
            );
            $list_args = [
                'method' => 'POST',
                'headers' => [
                    'Accept' => 'application/json',
                    'content-type' => 'application/json',
                    'Api-Token' => $activecampaign_api_key
                ],
                'body' => json_encode($list_params)
            ];
             $end_point = 'contactLists/';
            $list_response_body = wpem_activecampaign_request($activecampaign_api_key, $end_point, $list_args,$activecampaign_account_url);

        }
        
        return $response_body;
    }

}

if (!function_exists('add_attendees_in_wpem_activecampaign_list')) {

    /**
     * Add attendees in activecampaign
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function add_attendees_in_wpem_activecampaign_list($user_id = '', $arr_attendees_id = []) {
        $response = [];

        if ($user_id != '' && !empty($arr_attendees_id)) {
            $activecampaign_settings = get_wpem_activecampaign_settings_by_user_id($user_id);

            $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
            $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
            $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : 0;

            $registration_field = get_sync_fields_by_user($user_id, 'registration_field');

            $registration_activecampaign_field = get_wpem_activecampaign_sync_fields_by_user($user_id, 'registration_activecampaign_field');

            if (empty($registration_activecampaign_field)) {
                $registration_activecampaign_field = get_default_wpem_activecampaign_registration_matches_attribute();
            }

            foreach ($arr_attendees_id as $attendees_id) {
                $_is_activecampaign_sync = get_post_meta($attendees_id, '_is_activecampaign_sync', true);

                $attendees = get_post($attendees_id);
                if (!empty($attendees)) {
                    if (isset($activecampaign_settings['activecampaign_list']) && $activecampaign_settings['activecampaign_list'] == false) {
                        $event_id = $attendees->post_parent;
                        $event_activecampaign_list = get_post_meta($event_id, 'activecampaign_list', true);
                        if ($event_activecampaign_list == false) {
                            $response['message'] = __('Synchronization disabled for this event.', 'wpem-activecampaign');
                            continue;
                        }

                        if (!empty($event_activecampaign_list)) {
                            $activecampaign_list = $event_activecampaign_list;
                        }
                    }
                }

                if ($_is_activecampaign_sync != 'subscribed') {

                    $result = sync_data_in_wpem_activecampaign_list($activecampaign_api_key, $activecampaign_list, $registration_activecampaign_field, $attendees_id,$activecampaign_account_url);

                    if (isset($result['contact']['id']) && $result['contact']['id'] != '') {
                        update_post_meta($attendees_id, '_is_activecampaign_sync', 'subscribed');
                    }
                    if (isset($result['errors']) && ($result['errors'][0]['code'] == 'duplicate')) {
                        $response['code'] = 200;
                        $response['message'] = __('The contact already exists.', 'wpem-activecampaign');;
                    }
                    else if (isset($result['errors']) && ($result['errors'][0]['code'] )) {
                        $response['code'] = 400;
                        $response['message'] = $result['errors'][0]['code'];
                    } else if (isset($result['code']) && ($result['code'] == 'invalid_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else {
                        $response['code'] = 200;
                        $response['message'] = __('Subscribed', 'wpem-activecampaign');
                    }
                } else {
                    $response['code'] = 400;
                    $response['message'] = __('The contact already exists.', 'wpem-activecampaign');
                }
            }
        }

        return $response;
    }

}

if (!function_exists('add_guests_in_wpem_activecampaign_list')) {

    /**
     * Add guests in activecampaign
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function add_guests_in_wpem_activecampaign_list($user_id = '', $arr_guests_id = []) {
        $response = [];

        if ($user_id != '' && !empty($arr_guests_id)) {
            $activecampaign_settings = get_wpem_activecampaign_settings_by_user_id($user_id);

            $activecampaign_api_key = isset($activecampaign_settings['activecampaign_api_key']) ? $activecampaign_settings['activecampaign_api_key'] : '';
            $activecampaign_account_url = isset($activecampaign_settings['activecampaign_account_url']) ? $activecampaign_settings['activecampaign_account_url'] : '';
            $activecampaign_list = isset($activecampaign_settings['activecampaign_list']) ? $activecampaign_settings['activecampaign_list'] : 0;

            $guest_list_field = get_sync_fields_by_user($user_id, 'guest_list_field');
            $guest_list_activecampaign_field = get_wpem_activecampaign_sync_fields_by_user($user_id, 'guest_list_activecampaign_field');

            if (empty($guest_list_activecampaign_field)) {
                $guest_list_activecampaign_field = get_default_wpem_activecampaign_guest_list_matches_attribute();
            }

            foreach ($arr_guests_id as $guest_id) {
                $_is_activecampaign_sync = get_post_meta($guest_id, '_is_activecampaign_sync', true);

                $guest = get_post($guest_id);
                if (!empty($guest)) {

                    if (isset($activecampaign_settings['activecampaign_list']) && $activecampaign_settings['activecampaign_list'] == false) {
                        $event_id = $guest->post_parent;
                        $event_activecampaign_list = get_post_meta($event_id, 'activecampaign_list', true);

                        if ($event_activecampaign_list == false) {
                            $response['message'] = __('Synchronization disabled for this event.', 'wpem-activecampaign');
                            continue;
                        }

                        if (!empty($event_activecampaign_list)) {
                            $activecampaign_list = $event_activecampaign_list;
                        }
                    }
                }

                if ($_is_activecampaign_sync != 'subscribed') {
                    $result = sync_data_in_wpem_activecampaign_list($activecampaign_api_key, $activecampaign_list, $guest_list_activecampaign_field, $guest_id,$activecampaign_account_url);

                    if (isset($result['contact']['id']) && $result['contact']['id'] != '') {
                        update_post_meta($guest_id, '_is_activecampaign_sync', 'subscribed');
                    }
                    if (isset($result['errors']) && ($result['errors'][0]['code'] == 'duplicate')) {
                        $response['code'] = 200;
                        $response['message'] = __('The contact already exists.', 'wpem-activecampaign');;
                    }
                    else if (isset($result['errors']) && ($result['errors'][0]['code'] )) {
                        $response['code'] = 400;
                        $response['message'] = $result['errors'][0]['code'];
                    } else if (isset($result['code']) && ($result['code'] == 'invalid_parameter')) {
                        $response['code'] = 400;
                        $response['message'] = $result['message'];
                    } else {
                        $response['code'] = 200;
                        $response['message'] = __('Subscribed', 'wpem-activecampaign');
                    }
                } else {
                    $response['code'] = 200;
                    $response['message'] = __('The contact already exists.', 'wpem-activecampaign');
                }
            }
        }

        return $response;
    }

}

if (!function_exists('sync_data_in_wpem_activecampaign_list_2')) {

    /**
     * Sync attendees in activecampaign
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function sync_data_in_wpem_activecampaign_list_2($activecampaign_api_key = '', $activecampaign_list = '', $registration_activecampaign_field = [], $data = [],$activecampaign_account_url = '') {
        $response_body = [];

        if ($activecampaign_api_key != '' && $activecampaign_list != '' && !empty($registration_activecampaign_field) && $data != '') {
            $params = [];
            $field_activecampaign = get_wpem_activecampaign_field_dynamic_format($activecampaign_api_key, $activecampaign_list,$activecampaign_account_url);

            foreach ($field_activecampaign as $field_name => $field_value) {
                if (is_array($field_value)) {
                    foreach ($field_value as $field_name2 => $field_value2) {
                        if (is_array($field_value2)) {
                            foreach ($field_value2 as $field_name3 => $field_value3) {
                                if (array_key_exists($field_name3, $registration_activecampaign_field)) {
                                    $params[$field_name][$field_name2][$field_name3] = $data[$registration_activecampaign_field[$field_name3]];
                                }
                            }
                        } else {
                            if (array_key_exists($field_name2, $registration_activecampaign_field)) {
                                $vdata = isset($data[$registration_activecampaign_field[$field_name2]]) ? $data[$registration_activecampaign_field[$field_name2]] : '' ;
                                $params[$field_name][$field_name2] = $vdata;
                            }
                        }
                    }
                } else {
                    if (array_key_exists($field_name, $registration_activecampaign_field)) {
                        $params[$field_name] = $data[$registration_activecampaign_field[$field_name]];
                    }
                }
            }

            $params['listIds'] = array_map('intval', array($activecampaign_list));

            $params['status'] = 'subscribed';

            $args = ['method' => 'POST', 'headers' => ['Accept' => 'application/json', 'content-type' => 'application/json', 'Api-Token' => $activecampaign_api_key], 'body' => json_encode($params)];

            $end_point = 'contacts/';

            $response_body = wpem_activecampaign_request($activecampaign_api_key, $end_point, $args,$activecampaign_account_url);
            
            // add contact into the list
            if(isset($response_body['errors'])){
                return $response_body;
            }
            $contact_id = $response_body['contact']['id'];
            $list_params = array(
                'contactList' => array(
                    'list' => $activecampaign_list,
                    'contact' => $contact_id,
                    'status' => '1'
                )
            );
            $list_args = [
                'method' => 'POST',
                'headers' => [
                    'Accept' => 'application/json',
                    'content-type' => 'application/json',
                    'Api-Token' => $activecampaign_api_key
                ],
                'body' => json_encode($list_params)
            ];
             $end_point = 'contactLists/';
            $list_response_body = wpem_activecampaign_request($activecampaign_api_key, $end_point, $list_args,$activecampaign_account_url);

        }
        return $response_body;
    }

}

/**
 * add activecampaign cron schedules
 *
 * @access public
 * @param
 * @return array
 * @since 1.0.0
 */
add_filter('cron_schedules', 'wpem_activecampaign_cron_schedules');

function wpem_activecampaign_cron_schedules($schedules) {
    if (!isset($schedules["5min"])) {
        $schedules["5min"] = array(
            'interval' => 5 * 60,
            'display' => __('5 Min', 'wpem-activecampaign')
        );
    }
    if (!isset($schedules["weekly"])) {
        $schedules["weekly"] = array(
            'interval' => 60 * 60 * 24 * 7,
            'display' => __('Once Weekly', 'wpem-activecampaign')
        );
    }
    if (!isset($schedules["monthly"])) {
        $schedules["monthly"] = array(
            'interval' => 60 * 60 * 24 * 30,
            'display' => __('Once Monthly', 'wpem-activecampaign')
        );
    }
    if (!isset($schedules["yearly"])) {
        $schedules["yearly"] = array(
            'interval' => 60 * 60 * 24 * 365,
            'display' => __('Once Yearly', 'wpem-activecampaign')
        );
    }
    return $schedules;
}

if (!function_exists('get_default_wpem_activecampaign_guest_list_matches_attribute')) {

    /**
     * Default Activecampaign guest_list Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_wpem_activecampaign_guest_list_matches_attribute() {
        $guest_list_activecampaign_field = [];

        $guest_list_form_field = get_event_guests_form_fields();

        foreach ($guest_list_form_field as $key => $field) {
            if (in_array('from_email', $field['rules'])) {
                $guest_list_activecampaign_field['email'] = $key;
            } else if (in_array('from_name', $field['rules'])) {
                $guest_list_activecampaign_field['firstName'] = $key;
            }
        }

        return $guest_list_activecampaign_field;
    }

}

if (!function_exists('get_default_wpem_activecampaign_contact_organizer_matches_attribute')) {

    /**
     * Default Activecampaign contact_organizer Matches Attribute
     *
     * @access public
     * @param
     * @return array
     * @since 1.0.0
     */
    function get_default_wpem_activecampaign_contact_organizer_matches_attribute() {
        $guest_list_activecampaign_field = [];

        $guest_list_form_field = get_contact_organizer_form_fields();

        foreach ($guest_list_form_field as $key => $field) {
            if (isset($field['rules']) && in_array('from_email', $field['rules'])) {
                $guest_list_activecampaign_field['email'] = $key;
            } else if (isset($field['rules']) && in_array('from_name', $field['rules'])) {
                $guest_list_activecampaign_field['firstName'] = $key;
            }
        }

        return $guest_list_activecampaign_field;
    }

}

/**
 * auto_wpem_activecampaign_sync_callback function.
 *
 * @access public
 * @param mixed $arr_post_type
 * @return void
 * @since 1.0.0
 */
function auto_wpem_activecampaign_sync_callback($arr_post_type = []) {
    $args = array(
        'post_type' => $arr_post_type,
        'posts_per_page' => - 1,
    );

    $result = new WP_Query($args);
    $response = [];

    if ($result->found_posts > 0) {
        $activecampaign_account_url = get_option('activecampaign_settings')['activecampaign_account_url'];
        $activecampaign_api_key = get_option('activecampaign_settings')['activecampaign_api_key'];
        $activecampaign_list = get_option('activecampaign_settings')['activecampaign_list'];
        $activecampaign_sync_type = get_option('activecampaign_settings')['activecampaign_sync_type'];

        $organizer_activecampaign_field = get_option('organizer_activecampaign_field');
        $registration_activecampaign_field = get_option('registration_activecampaign_field');
        $guest_list_activecampaign_field = get_option('guest_list_activecampaign_field');


        foreach ($result->posts as $result) {

            if (isset(get_option('activecampaign_settings')['activecampaign_list']) && get_option('activecampaign_settings')['activecampaign_list'] == false) {
                $event_id = $result->post_parent;
                $event_activecampaign_list = get_post_meta($event_id, 'activecampaign_list', true);
                if ($event_activecampaign_list == false) {
                    $response['message'] = __('Synchronization disabled for this event.', 'wpem-activecampaign');
                    continue;
                }

                if (!empty($event_activecampaign_list)) {
                    $activecampaign_list = $event_activecampaign_list;
                }
            }

            if ($result->post_type == 'event_organizer') {
                $activecampaign_sync_field = $organizer_activecampaign_field;

                if (empty($activecampaign_sync_field)) {
                    $activecampaign_sync_field = get_default_wpem_activecampaign_organizer_matches_attribute();
                }

            } else if ($result->post_type == 'event_registration') {

                $activecampaign_sync_field = $registration_activecampaign_field;

                if (empty($activecampaign_sync_field)) {
                    $activecampaign_sync_field = get_default_wpem_activecampaign_registration_matches_attribute();
                }
            } else if ($result->post_type == 'event_guests') {

                $activecampaign_sync_field = $guest_list_activecampaign_field;

                if (empty($activecampaign_sync_field)) {
                    $activecampaign_sync_field = get_default_wpem_activecampaign_guest_list_matches_attribute();
                }
            }

            $results = sync_data_in_wpem_activecampaign_list($activecampaign_api_key, $activecampaign_list, $activecampaign_sync_field, $result->ID,$activecampaign_account_url);
            if (isset($results['contact']['id']) && $results['contact']['id'] != '') {
                update_post_meta($result->ID, '_is_activecampaign_sync', 'subscribed');
            }
        }
    }
    wp_reset_postdata();
}
