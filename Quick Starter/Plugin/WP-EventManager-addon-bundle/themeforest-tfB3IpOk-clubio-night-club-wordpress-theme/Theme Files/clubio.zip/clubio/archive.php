<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Clubio
 */
get_header();
    get_template_part( 'template-parts/clubioblog/posts', 'template' );
get_footer();