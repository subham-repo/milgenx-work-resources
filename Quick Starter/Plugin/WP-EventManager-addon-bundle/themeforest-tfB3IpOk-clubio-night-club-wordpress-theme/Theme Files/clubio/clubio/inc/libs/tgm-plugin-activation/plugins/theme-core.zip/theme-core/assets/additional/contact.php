<p>[vc_row rsclass="clean" el_class="section-indent no-margin section-marker"][vc_column rsclass="clean"][vc_gmaps link="#E-8_JTNDaWZyYW1lJTIwY2xhc3MlM0QlMjJtb25vY2hyb21lLW1hcCUyMiUyMHNyYyUzRCUyMmh0dHBzJTNBJTJGJTJGd3d3Lmdvb2dsZS5jb20lMkZtYXBzJTJGZW1iZWQlM0ZwYiUzRCUyMTFtMTglMjExbTEyJTIxMW0zJTIxMWQ2MzA0LjgyOTk4NjEzMTI3MSUyMTJkLTEyMi40NzQ2OTY4MDMzMDkyJTIxM2QzNy44MDM3NDc1MjE2MDQ0MyUyMTJtMyUyMTFmMCUyMTJmMCUyMTNmMCUyMTNtMiUyMTFpMTAyNCUyMTJpNzY4JTIxNGYxMy4xJTIxM20zJTIxMW0yJTIxMXMweDgwODU4NmU2MzAyNjE1YTElMjUzQTB4ODZiZDEzMDI1MTc1N2MwMCUyMTJzU3RvcmV5JTJCQXZlJTI1MkMlMkJTYW4lMkJGcmFuY2lzY28lMjUyQyUyQkNBJTJCOTQxMjklMjE1ZTAlMjEzbTIlMjExc2VuJTIxMnN1cyUyMTR2MTQzNTgyNjQzMjA1MSUyMiUyMHdpZHRoJTNEJTIyNjAwJTIyJTIwaGVpZ2h0JTNEJTIyNDUwJTIyJTIwJTIwc3R5bGUlM0QlMjJib3JkZXIlM0EwJTIyJTIwYWxsb3dmdWxsc2NyZWVuJTNFJTNDJTJGaWZyYW1lJTNF" el_id="map" el_class="contact-map"][/vc_column][/vc_row][vc_row rsclass="clean" rsouter="section-indent no-margin"][vc_column rsclass="clean" el_class="contact-info-wrapper" css=".vc_custom_1596563181348{background-image: url(https://clubio.softali.net/wp/demo/wp-content/uploads/2020/08/contact-info-wrapper-scaled.jpg?id=2390) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}" rsinner="container"][vc_custom_heading text="Get in Touch with Us" font_container="tag:h3|text_align:center" use_theme_fonts="yes" el_class="contact-info__title text-center"][vc_row_inner rsclass="clean" el_class="row contact-info-list"][vc_column_inner el_class="col-md-6 col-lg-4" width="1/3" rsclass="clean" rsinner="contact-info"][vc_column_text rsclass="clean"][clubio_icon icon="icon-place" class="contact-info__icon"]</p>
<div class="contact-info__content">
    <div class="tt-title">VIP Clubio</div>
    <address>1035 N Sycamore<br />
        Avenue Hollywood, CA 90040</address>
</div>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-md-6 col-lg-4" width="1/3" rsclass="clean" rsinner="contact-info"][vc_column_text rsclass="clean"][clubio_icon icon="icon-phone" class="contact-info__icon"]</p>
<div class="contact-info__content">
    <div class="tt-title">Contact Phones</div>
    <address>1 (800) 765-43-21, 765-43-22<br class="ch" />1 (800) 765-43-23 (fax)</address>
</div>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-md-12 col-lg-4" width="1/3" rsclass="clean" rsinner="contact-info"][vc_column_text rsclass="clean"][clubio_icon icon="icon-clock" class="contact-info__icon"]</p>
<div class="contact-info__content">
    <div class="tt-title">Working Hours</div>
    <address>Mon-Fri: 9:00 am – 5:00 pm<br class="ch" />Sat-Sun: 11:00 am – 16:00 pm</address>
</div>
<p>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="section-indent05"][vc_column rsclass="clean" el_class="container"][vc_row_inner rsclass="clean" el_class="row"][vc_column_inner el_class="col-md-6" width="1/2" rsclass="clean"][vc_custom_heading text="Did You Know?" font_container="tag:h4|text_align:left" use_theme_fonts="yes" el_class="tt-subtitle"][vc_column_text rsclass="clean" el_class="tt-width-01"]</p>
<ul class="list-02-7">
    <li>For more information on corporate event services, please fill out the form located here or call 765-43-22. For press inquiries email: <a class="tt-link02" href="mailto:publicrelations@vipclubio.com">publicrelations@vipclubio.com</a></li>
    <li>If you are inquiring about your items lost during your time here, please provide any identifying information of your lost items such as name, brand, colour, etc and we'll be in touch if it turns up.</li>
    <li>The management reserves the right to change drink and admission prices from time to time. Please e mail <a class="tt-link02" href="info@vipclubio.com" target="_blank" rel="noopener noreferrer">info@vipclubio.com</a> for further information.</li>
</ul>
<p>[/vc_column_text][vc_custom_heading text="Newsletter" font_container="tag:h6|text_align:left" use_theme_fonts="yes" el_class="tt-subtitle tt-subtitle-top"][contact-form-7 id="2149"][/vc_column_inner][vc_column_inner el_class="divider d-block d-md-none" rsclass="clean"][/vc_column_inner][vc_column_inner el_class="col-md-6" width="1/2" rsclass="clean"][vc_custom_heading text="Contact Form" font_container="tag:h6|text_align:left" use_theme_fonts="yes" el_class="tt-subtitle"][contact-form-7 id="2151"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]</p>

<!--new code for the Contact us page: 09-12-2020-->

[vc_row rsclass="clean" el_class="section-indent no-margin section-marker"][vc_column rsclass="clean"][vc_gmaps link="#E-8_JTNDaWZyYW1lJTIwY2xhc3MlM0QlMjJtb25vY2hyb21lLW1hcCUyMiUyMHNyYyUzRCUyMmh0dHBzJTNBJTJGJTJGd3d3Lmdvb2dsZS5jb20lMkZtYXBzJTJGZW1iZWQlM0ZwYiUzRCUyMTFtMTglMjExbTEyJTIxMW0zJTIxMWQ2MzA0LjgyOTk4NjEzMTI3MSUyMTJkLTEyMi40NzQ2OTY4MDMzMDkyJTIxM2QzNy44MDM3NDc1MjE2MDQ0MyUyMTJtMyUyMTFmMCUyMTJmMCUyMTNmMCUyMTNtMiUyMTFpMTAyNCUyMTJpNzY4JTIxNGYxMy4xJTIxM20zJTIxMW0yJTIxMXMweDgwODU4NmU2MzAyNjE1YTElMjUzQTB4ODZiZDEzMDI1MTc1N2MwMCUyMTJzU3RvcmV5JTJCQXZlJTI1MkMlMkJTYW4lMkJGcmFuY2lzY28lMjUyQyUyQkNBJTJCOTQxMjklMjE1ZTAlMjEzbTIlMjExc2VuJTIxMnN1cyUyMTR2MTQzNTgyNjQzMjA1MSUyMiUyMHdpZHRoJTNEJTIyNjAwJTIyJTIwaGVpZ2h0JTNEJTIyNDUwJTIyJTIwJTIwc3R5bGUlM0QlMjJib3JkZXIlM0EwJTIyJTIwYWxsb3dmdWxsc2NyZWVuJTNFJTNDJTJGaWZyYW1lJTNF" el_id="map" el_class="contact-map"][/vc_column][/vc_row][vc_section rsclass="clean" css=".vc_custom_1607541680397{background-image: url(https://clubio.softali.net/wp/demo/wp-content/uploads/2020/12/contact-info-bg-02.jpg?id=2479) !important;background-position: 0 0 !important;background-repeat: no-repeat !important;}"][vc_row rsclass="clean" rsouter="section-indent no-margin"][vc_column rsclass="clean" el_class="contact-info-wrapper" css=".vc_custom_1607537960617{background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}" rsinner="container"][vc_custom_heading text="Get in Touch with Us" font_container="tag:h3|text_align:center" use_theme_fonts="yes" el_class="contact-info__title text-center"][vc_row_inner rsclass="clean" el_class="row contact-info-list"][vc_column_inner el_class="col-md-6 col-lg-4" width="1/3" rsclass="clean" rsinner="contact-info"][vc_column_text rsclass="clean"][clubio_icon icon="icon-place" class="contact-info__icon"]
<div class="contact-info__content">
    <div class="tt-title">VIP Clubio</div>
    <address>1035 N Sycamore
        Avenue Hollywood, CA 9004</address></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-md-6 col-lg-4" width="1/3" rsclass="clean" rsinner="contact-info"][vc_column_text rsclass="clean"][clubio_icon icon="icon-phone" class="contact-info__icon"]
<div class="contact-info__content">
    <div class="tt-title">Contact Phones</div>
    <address>1 (800) 765-43-21, 765-43-22<br class="ch" />1 (800) 765-43-23 (fax)</address></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-md-12 col-lg-4" width="1/3" rsclass="clean" rsinner="contact-info"][vc_column_text rsclass="clean"][clubio_icon icon="icon-clock" class="contact-info__icon"]
<div class="contact-info__content">
    <div class="tt-title">Working Hours</div>
    <address>Mon-Fri: 9:00 am – 5:00 pm<br class="ch" />Sat-Sun: 11:00 am – 4:00 pm</address></div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="section-indent05 section-margin"][vc_column rsclass="clean" el_class="container" rsinner="ch-outer-bg-top-minus"][vc_row_inner rsclass="clean" el_class="row"][vc_column_inner el_class="col-md-6" width="1/2" rsclass="clean" rsinner="ch-outer-bg-top-minus__inner left"][vc_custom_heading text="Did You Know?" font_container="tag:h4|text_align:left" use_theme_fonts="yes" el_class="tt-subtitle"][vc_column_text rsclass="clean" el_class="tt-width-01"]
<ul class="list-02-7 list-contact-form">
    <li>For more information on corporate event services, please fill out the form located here or call 765-43-22. For press inquiries email: <a class="tt-link02" href="mailto:publicrelations@vipclubio.com">publicrelations@vipclubio.com</a></li>
    <li>The management reserves the right to change drink and admission prices from time to time. Please e mail <a class="tt-link02" href="info@vipclubio.com" target="_blank" rel="noopener noreferrer">info@vipclubio.com</a> for further information.</li>
</ul>
[/vc_column_text][vc_custom_heading text="Newsletter" font_container="tag:h6|text_align:left" use_theme_fonts="yes" el_class="tt-subtitle tt-subtitle-top"][contact-form-7 id="2149"][/vc_column_inner][vc_column_inner el_class="col-md-6" width="1/2" rsclass="clean" rsinner="ch-outer-bg-top-minus__inner right"][vc_custom_heading text="Contact Form" font_container="tag:h6|text_align:left" use_theme_fonts="yes" el_class="tt-subtitle"][contact-form-7 id="2151"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][/vc_section]
