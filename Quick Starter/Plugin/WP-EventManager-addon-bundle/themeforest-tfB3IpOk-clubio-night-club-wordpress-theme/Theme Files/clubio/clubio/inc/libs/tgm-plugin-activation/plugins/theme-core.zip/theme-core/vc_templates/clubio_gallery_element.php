<?php
if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $source
 * @var $type
 * @var $onclick
 * @var $custom_links
 * @var $custom_links_target
 * @var $img_size
 * @var $external_img_size
 * @var $images
 * @var $custom_srcs
 * @var $el_class
 * @var $el_id
 * @var $interval
 * @var $css
 * @var $custom_titles
 * @var $custom_ttitles
 * @var $image_bind
 * @var $content
 */

$grids_links = $thumbnail = $video = $large_img_src = $source = $type = $onclick = $custom_links = $custom_links_target = $img_size = $external_img_size = $images = $custom_srcs = $custom_titles = $track_urls = $artists = $css_classes = $custom_ttitles = $image_bind = $el_class = $el_id = $interval = $css = $css_animation = '';

$attributes = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $attributes );

$default_src = vc_asset_url( 'vc/no_image.png' );

$gal_images = $link_start = $link_end = $el_start = $el_end = $slides_wrap_start = $slides_wrap_end = $rs_title = $rs_block = $artist = '';



$el_class = $this->getExtraClass( $el_class );


wp_enqueue_script( 'vc_grid-js-imagesloaded' );


$slides_wrap_start = '<div id="filter-layout" class="row no-gutters '.($type == 't1' ? 'gallery-innerlayout-wrapper' : 'gallery-externallayout-wrapper').'">';
$slides_wrap_end = '</div>';


if ( '' === $images ) {
    $images = '-1,-2,-3';
}


switch ( $source ) {
    case 'media_library':
        $images = explode( ',', $images );
        break;

    case 'external_link':
        $images = vc_value_from_safe( $custom_srcs );
        $images = explode( ',', $images );

        break;
}
foreach ( $images as $i => $image ) {
    switch ( $source ) {
        case 'media_library':
            if ( $image > 0 ) {
                $img = wpb_getImageBySize( array(
                    'attach_id' => $image,
                    'thumb_size' => $img_size,
                ) );
                $thumbnail = $img['thumbnail'];
                $large_img_src = $img['p_img_large'][0];
            } else {
                $large_img_src = $default_src;
                $thumbnail = '<div><img src="' . $default_src . '" /></div>';
            }
            break;

        case 'external_link':
            $image = esc_attr( $image );
            $dimensions = vc_extract_dimensions( $external_img_size );
            $hwstring = $dimensions ? image_hwstring( $dimensions[0], $dimensions[1] ) : '';
            $thumbnail = '<img ' . $hwstring . ' src="' . $image . '" />';
            $large_img_src = $image;
            break;
    }

    $link_start = $link_end = '';


    if ($type == 't1') {
        $link_start = '<div style="background-image: url('.$large_img_src.')" class="gallery__img">';
    } else {
        $link_start = '<div class="gallery__img">'.$thumbnail;
    }

    $link_end = '</div>';

    $rs_titles = vc_value_from_safe( $custom_titles );
    $rs_titles = explode( ',', $rs_titles );
    $rs_title = (!empty( $rs_titles[ $i ] ) ? '<div class="gallery__time">'.date('l, M d, Y', strtotime($rs_titles[ $i ])).'</div>' : '');


    $rs_artists = vc_value_from_safe($artists);
    $rs_artists = explode(',', $rs_artists );
    $artist = (!empty( $rs_artists[$i] ) ? '<div class="gallery__title">'.$rs_artists[ $i ].'</div>' : '');


    $image_bind_numbers = vc_value_from_safe($image_bind);
    $image_bind_numbers = explode( ',', $image_bind_numbers);


    $css_classes = vc_value_from_safe($css_classes);
    $css_class = explode(',', $css_classes );
    $css_class = (!empty( $css_class[$i] ) ? $css_class[$i] : 'col-sm-6 col-lg-4');

    $videos = vc_value_from_safe( $track_urls );
    $videos = explode( ',', $videos );
    $video = (!empty( $videos[ $i ] ) && $videos[ $i ] != '-' ? '<div class="gallery__video"></div>' : '');

    $elements_links = vc_value_from_safe( $grids_links );
    $elements_links = explode( ',', $elements_links );
    $grids_link = (!empty( $elements_links[ $i ] ) && $elements_links[ $i ] != '-' ? $elements_links[ $i ] : '#');




    if (!empty( $videos[ $i ] ) && $videos[ $i ] != '-') {
        $video = '<div class="gallery__video"></div>';
        $el_start = '<div class="'.$css_class.' '.(!empty( $image_bind_numbers[ $i ] ) ? $image_bind_numbers[$i] : '1').' videos all"><a href="'.$videos[ $i ].'" class="'.($type == 't1' ? 'gallery-innerlayout' : 'gallery-externallayout').' js-video-popup">';
    } else {

        $el_start = '<div class="'.$css_class.' '.(!empty( $image_bind_numbers[ $i ] ) ? $image_bind_numbers[$i] : '1').' photos all"><a href="'.$grids_link.'" class="'.($type == 't1' ? 'gallery-innerlayout' : 'gallery-externallayout').'">';
    }




    $el_end = '</a></div>';


    $gal_images .= $el_start.$link_start.$link_end.$video.$rs_title.$artist.$el_end;
}

$class_to_filter = '';

$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $el_class ) . $this->getCSSAnimation( $css_animation );
$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );
$wrapper_attributes = array();
if ( ! empty( $el_id ) ) {
    $wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}
$output = '';
$output .= '<div class="custom_css ' . $css_class . '" ' . implode( ' ', $wrapper_attributes ) . '>';

$rs_t_titles = vc_value_from_safe( $custom_ttitles );
$rs_t_titles = explode( ',', $rs_t_titles);

if (!empty($rs_t_titles)) {
    $output .= '<div id="filter-nav"><ul>';
    $output .= '<li><a class="gallery-navitem" href="all"><span>'.$rs_t_titles[0].'</span></a></li>';

    $rs_t_titles1 = array_shift($rs_t_titles);

    foreach ($rs_t_titles as $k => $rs_t_title) :
        $k = $k + 1;
        $output .= '<li class="'.($k == 1 ? 'active' : '').'"><a class="gallery-navitem" href="'.$k.'"><span>'.$rs_t_title.'</span></a></li>';
    endforeach;
    $output .= '</ul><div id="tt-filternav__line"></div></div>';
}
$output .= $slides_wrap_start . $gal_images . $slides_wrap_end;
$output .= '</div>';

$output .= wpb_js_remove_wpautop( $content, true );

echo $output;


wp_enqueue_script('clubio-gallery-element');
