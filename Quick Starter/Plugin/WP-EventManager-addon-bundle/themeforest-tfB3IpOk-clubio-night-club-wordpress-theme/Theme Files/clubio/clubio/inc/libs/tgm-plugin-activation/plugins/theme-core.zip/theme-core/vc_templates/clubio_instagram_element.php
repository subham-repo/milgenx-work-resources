<?php
if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $user_tag
 * @var $limit
 * @var $items_per_row
 * @var $margin
 * @var $user_name
 * @var $content
 * @var $el_id
 * @var $el_class
 */
$attributes = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $attributes );

$user_tag = ($user_tag != '' ? $user_tag : '');
$limit = ($limit != '' ? $limit : 9);
$items_per_row = ($items_per_row != '' ? $items_per_row : 8);
$margin = ($margin != '' ? $margin : 0);
$user_name = ($user_name != '' ? $user_name : '');

$ins_object = array(
    'user_tag' => esc_js($user_tag),
    'user_name' => esc_js($user_name),
    'el_id' => esc_js($el_id),
    'limit' => esc_js($limit),
    'items_per_row' => esc_js($items_per_row),
    'margin' => esc_js($margin),
);


wp_enqueue_script('rtext_element_inst');
//wp_add_inline_script('rtext_element_inst', 'el_id', $el_id);

wp_enqueue_script('clubio_insta_element_scr');
wp_localize_script('clubio_insta_element_scr', 'insObject', $ins_object);

echo '<div id="'.$el_id.'"  data-totalitem="'.esc_js($limit).'" class="items_'.$items_per_row.' '.$el_class.'"></div>';