<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $el_id
 * @var $css_animation
 * @var $css
 * @var $rsclass
 * @var $content - shortcode content
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Column_text
 */
$el_class = $el_id = $css = $css_animation = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
$cleanclass1 = $atts['el_class'];
$rsclass1 = $atts['rsclass'];

$output = '';
$class_to_filter = (($rsclass1 == 'clean') ? '' : 'wpb_text_column wpb_content_element ') . $this->getCSSAnimation( $css_animation );


$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $el_class );
$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );
$wrapper_attributes = array();
if ( ! empty( $el_id ) ) {
	$wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}

if ($rsclass1 == 'clean') {
    if ($cleanclass1 != '') {
        $output = '<div class="shortcode_vc_text ' . esc_attr( $css_class ) . '" ' . implode( ' ', $wrapper_attributes ) . '>'.wpb_js_remove_wpautop( $content, true ).'</div>';
    } else {
        $output = wpb_js_remove_wpautop( $content, true );
    }
} else {
    $output = '
	<div class="' . esc_attr( $css_class ) . '" ' . implode( ' ', $wrapper_attributes ) . '>
		<div class="tt_shortcode_vc_column_text wpb_wrapper">
			' . wpb_js_remove_wpautop( $content, true ) . '
		</div>
	</div>
';
}
echo $output;
