[vc_row rsclass="clean"][vc_column rsclass="clean"][clubio_rslider_element rs_num="3" rs_images="1871,1872,1873"]
<div class="tt-title-01">The Perfect Nightlife</div>
<div class="tt-title-02">FEEL THE NIGHT HERE
    With Friends</div>
<div class="tt-row-btn"><a class="tt-btn" href="events-tickets-1"><span class="ch">view tickets</span></a></div>
{slide}
<div class="tt-title-01">The Perfect Nightlife</div>
<div class="tt-title-02">FEEL THE NIGHT HERE
    With Friends</div>
<div class="tt-row-btn"><a class="tt-btn" href="events-tickets-1"><span class="ch">view tickets</span></a></div>
{slide}
<div class="tt-title-01">The Perfect Nightlife</div>
<div class="tt-title-02">FEEL THE NIGHT HERE
    With Friends</div>
<div class="tt-row-btn"><a class="tt-btn js-video-popup" href="https://www.youtube.com/watch?v=_sI_Ps7JSEk"><span class="ch">view tickets</span></a></div>
[/clubio_rslider_element][/vc_column][/vc_row]


<!--02-Upcoming Events--->
[vc_section rsclass="clean" el_id="ch-section-events" el_class="section-indent01"][vc_row rsclass="clean" el_class="container"][vc_column rsclass="clean" el_class="section-title section-title_bottom-none"][vc_custom_heading text="Upcoming Events" font_container="tag:h2|text_align:center" use_theme_fonts="yes" el_class="section-title__text"][vc_column_text rsclass="clean"]
<div class="section-title__text-under">Events</div>
<div class="section-title__link"><a class="link-01" href="events">view all events</a></div>
[/vc_column_text][/vc_column][/vc_row][vc_row rsclass="clean" el_class="container-fluid"][vc_column rsclass="clean" el_class="slick-indent"][vc_row_inner rsclass="clean" el_class="js-slick01 slick-dots01"][vc_column_inner el_class="ch" width="1/6" rsclass="clean" rsinner="event-item"][vc_column_text rsclass="clean"]
<div class="event-item__label">23<span class="ch">Jan</span></div>
[/vc_column_text][vc_single_image image="1960" img_size="full" rsclass="clean" el_class="event-item__img"][/vc_single_image][vc_column_text rsclass="clean"]
<div class="event-item__layout"><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalBayTickets"><span class="ch">buy tickets</span></a><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalVipTables"><span class="ch">VIP tables</span></a></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="ch" width="1/6" rsclass="clean" rsinner="event-item"][vc_column_text rsclass="clean"]
<div class="event-item__label">28<span class="ch">Jan</span></div>
[/vc_column_text][vc_single_image image="1961" img_size="full" rsclass="clean" el_class="event-item__img"][/vc_single_image][vc_column_text rsclass="clean"]
<div class="event-item__layout"><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalBayTickets"><span class="ch">buy tickets</span></a><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalVipTables"><span class="ch">VIP tables</span></a></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="ch" width="1/6" rsclass="clean" rsinner="event-item"][vc_column_text rsclass="clean"]
<div class="event-item__label">30<span class="ch">Jan</span></div>
[/vc_column_text][vc_single_image image="1962" img_size="full" rsclass="clean" el_class="event-item__img"][/vc_single_image][vc_column_text rsclass="clean"]
<div class="event-item__layout"><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalBayTickets"><span class="ch">buy tickets</span></a><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalVipTables"><span class="ch">VIP tables</span></a></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="ch" width="1/6" rsclass="clean" rsinner="event-item"][vc_column_text rsclass="clean"]
<div class="event-item__label">2<span class="ch">Feb</span></div>
[/vc_column_text][vc_single_image image="1963" img_size="full" rsclass="clean" el_class="event-item__img"][/vc_single_image][vc_column_text rsclass="clean"]
<div class="event-item__layout"><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalBayTickets"><span class="ch">buy tickets</span></a><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalVipTables"><span class="ch">VIP tables</span></a></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="ch" width="1/6" rsclass="clean" rsinner="event-item"][vc_column_text rsclass="clean"]
<div class="event-item__label">5<span class="ch">Feb</span></div>
[/vc_column_text][vc_single_image image="1964" img_size="full" rsclass="clean" el_class="event-item__img"][/vc_single_image][vc_column_text rsclass="clean"]
<div class="event-item__layout"><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalBayTickets"><span class="ch">buy tickets</span></a><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalVipTables"><span class="ch">VIP tables</span></a></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="ch" width="1/6" rsclass="clean" rsinner="event-item"][vc_column_text rsclass="clean"]
<div class="event-item__label">23<span class="ch">Jan</span></div>
[/vc_column_text][vc_single_image image="1961" img_size="full" rsclass="clean" el_class="event-item__img"][/vc_single_image][vc_column_text rsclass="clean"]
<div class="event-item__layout"><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalBayTickets"><span class="ch">buy tickets</span></a><a class="tt-btn" href="#" data-toggle="modal" data-target="#modalVipTables"><span class="ch">VIP tables</span></a></div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][/vc_section]




<!--03-ABOUT NIGHT CLUB--->
[vc_section rsclass="clean" el_class="section-indent02" el_id="ch-section-about"][vc_row rsclass="clean" el_class="container-fluid no-gutters section-marker"][vc_column rsclass="clean" el_class="events-wide-list"][vc_row_inner rsclass="clean" el_class="events-wide"][vc_column_inner el_class="events-wide__img" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]
<div class="ch"><a class="js-video-popup lazyload" href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" data-bg="wp-content/themes/clubio/images/events-wide01.jpg"><span class="tt-text tt-text__right">Night CLub</span> <span class="tt-icon"> </span></a></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="events-wide__content tt-color02" width="1/2" rsclass="clean" rsinner="events-wide_wrapper"][vc_column_text rsclass="clean"]
<div class="blocktitle_color-01 blocktitle">
    <div class="tt-caption">ABOUT NIGHT CLUB</div>
    <h4 class="tt-title">Old Space. New Stories</h4>
    <div class="tt-title-under">About</div>
</div>
<p class="ch">Our award-winning seasonal music series showcases the best in live and electronic music, becoming a vital part of the city’s vibrant cultural scene today and garnering global acclaim. Our Autumn/Winter 2019 Season features in excess of 250 artists, with over 30 shows taking place between September and January.</p>

<div class="ch"><a class="tt-btn tt-btn_color02" href="news"><span class="ch">know more</span></a></div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="events-wide tt-item__revers"][vc_column_inner el_class="events-wide__img" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]
<div class="ch"><a class="js-video-popup lazyload" href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" data-bg="wp-content/themes/clubio/images/events-wide02.jpg"><span class="tt-text tt-text__left">Day CLub</span><span class="tt-icon"> </span> </a></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="events-wide__content tt-color01" width="1/2" rsclass="clean" rsinner="events-wide_wrapper"][vc_column_text rsclass="clean"]
<div class="blocktitle">
    <div class="tt-caption">About Day Club</div>
    <h4 class="tt-title">Feel the Day Energy</h4>
    <div class="tt-title-under">About</div>
</div>
<p class="ch">VIP Clubio also features a dayclub that serves as an exclusive adult oasis by day and an extension of the nightclub in the evening. You can experience a vibrant beach club scene hosted by today’s most influential DJs while living it up in eight Grand Cabanas, each with its own private spa and infinity plunge pool.</p>

<div class="ch"><a class="tt-btn-default" href="news"><span class="ch">know more</span></a></div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][/vc_section]



<!--04-What We Offer-->
[vc_section rsclass="clean" el_class="section-indent03 section-marker section-marker__indent01" el_id="ch-section-offers"][vc_row rsclass="clean" el_class="container container-fluid-tablet"][vc_column rsclass="clean" el_class="section-title"][vc_custom_heading text="What We Offer" font_container="tag:h2|text_align:center" use_theme_fonts="yes" el_class="section-title__text"][vc_custom_heading text="Services" font_container="tag:div|text_align:left" use_theme_fonts="yes" el_class="section-title__text-under"][vc_custom_heading text="Experience the best nightlife option in with this escorted tour that includes 3 of the funnest bar/lounges/clubs each night has to offer" font_container="tag:div|text_align:center" use_theme_fonts="yes" el_class="title__text-description"][/vc_column][/vc_row][vc_row rsclass="clean" el_class="container container-fluid-tablet"][vc_column rsclass="clean" el_class="events-img-list"][vc_row_inner rsclass="clean" el_class="slick-dots02 js-slick02 event-item02-list row"][vc_column_inner el_class="col-md-4" width="1/3" rsclass="clean" rsinner="event-item02"][vc_single_image image="2435" img_size="full" ch_lazy="lazyloading" rsclass="clean" el_class="event-item02__img lazyload"][/vc_single_image][vc_column_text rsclass="clean"]
<div class="event-item02__border">
    <div class="event-item02__border-top"></div>
    <div class="event-item02__border-y"></div>
</div>
<div class="event-item02__content">
    <div class="event-item02__align">
        <h4 class="tt-title">Corporate Events</h4>
        <p class="ch">A friendly happy hour, a company holiday party, or an evening of entertainment for VIP.</p>

        <div class="ch"><a class="tt-btn" href="events-parties"><span class="ch">know more</span></a></div>
    </div>
</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-md-4" width="1/3" rsclass="clean" rsinner="event-item02"][vc_single_image image="2433" img_size="full" ch_lazy="lazyloading" rsclass="clean" el_class="event-item02__img lazyload"][/vc_single_image][vc_column_text rsclass="clean"]
<div class="event-item02__border">
    <div class="event-item02__border-top"></div>
    <div class="event-item02__border-y"></div>
</div>
<div class="event-item02__content">
    <div class="event-item02__align">
        <h4 class="tt-title">Birthday Parties</h4>
        <p class="ch">Spend your birthday with us, and enjoy a night you’ll remember forever.</p>

        <div class="ch"><a class="tt-btn" href="events-parties"><span class="ch">know more</span></a></div>
    </div>
</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="col-md-4" width="1/3" rsclass="clean" rsinner="event-item02"][vc_single_image image="1991" img_size="full" ch_lazy="lazyloading" rsclass="clean" el_class="event-item02__img lazyload"][/vc_single_image][vc_column_text rsclass="clean"]
<div class="event-item02__border">
    <div class="event-item02__border-top"></div>
    <div class="event-item02__border-y"></div>
</div>
<div class="event-item02__content">
    <div class="event-item02__align">
        <h4 class="tt-title">Bachelorette</h4>
        <p class="ch">VIP Night Club! End your single days in style with a VIP table reservation.</p>

        <div class="ch"><a class="tt-btn" href="events-parties"><span class="ch">know more</span></a></div>
    </div>
</div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][/vc_section]


<!--05-Additional Services-->
[vc_row rsclass="clean" el_class="section-indent04" el_id="ch-section-add-services"][vc_column rsclass="clean" el_class="promo-box-wide"][vc_row_inner rsclass="clean" el_class="tt-item"][vc_column_inner el_class="tt-item__img" width="1/2" css=".vc_custom_1591723022803{background-image: url(https://clubio.softali.net/wp/demo/wp-content/uploads/2020/06/promo-box-wide01.jpg?id=1925) !important;}" rsclass="clean"][/vc_column_inner][vc_column_inner el_class="tt-item__content" width="1/2" rsclass="clean"][vc_column_text rsclass="clean"]
<div class="tt-item__label">

    [clubio_icon icon="icon-cup" class="tt-item__label-icon"]
    <div class="tt-item__label-text-01">Best Night Club</div>
    <div class="tt-item__label-text-02">2020</div>
    <div class="tt-item__label-text-03">Awards</div>
</div>
<div class="blocktitle">
    <h4 class="tt-title">Additional Services</h4>
    <div class="tt-title-under">Additional</div>
</div>
<div class="tt-content-text">
    <p class="title__text-description">Enjoy a hassle-free night where all you have to worry about is enjoying yourself in company of friends. Our professional team will arrange the most convenient time for your group and personally escort you into the club.</p>

    <ul id="js-show-layout" class="list-01 list-text-top">
        <li><a href="#">Executive Event Production</a></li>
        <li><a href="#">Dancers &amp; Performance Artists</a></li>
        <li><a href="#">Celebrity Recruitment</a></li>
        <li><a href="#">PR Support</a></li>
        <li><a href="#">Photography</a></li>
        <li class="tt-table-hide"><a href="#">Event Conception Theme Decor</a></li>
        <li class="tt-table-hide"><a href="#">Custom Invite Creation</a></li>
        <li class="tt-table-hide"><a href="#">Creative Signage and Branding</a></li>
        <li class="tt-table-hide"><a href="#">Audience Procurement</a></li>
        <li class="tt-table-hide"><a href="#">Model Outreach</a></li>
    </ul>
    <div class="ch"><a id="js-show-btn" class="tt-link tt-link-top d-block d-lg-none" href="#">view more...</a></div>
</div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]







<!--06-Our Residents-->
[vc_section rsclass="clean" el_class="section-wrapper01" css=".vc_custom_1591792053837{background: #3c3b41 url(https://clubio.softali.net/wp/demo/wp-content/uploads/2020/06/promo02.jpg?id=1942) !important;}" el_id="ch-section-residents"][vc_row rsclass="clean"][vc_column rsclass="clean" el_class="promo02"][vc_column_text rsclass="clean"][clubio_icon icon="icon-cocktail" class="promo02__img"][/vc_column_text][vc_row_inner rsclass="clean" el_class="promo02__layout" rsouter="container"][vc_column_inner el_class="tt-col" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"]
<h6 class="promo02__title">Book Your <br class="ch" /><span class="tt-base-color">VIP Table</span> Now!</h6>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="tt-col promo02__content" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"]
<div class="ch">VIP Clubio offers private and semi-private nightclub tables coupled with VIP bottle service treatment. Please inquire here for availability and our VIP Reservations Manager will follow up in a timely manner.</div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="tt-col" width="1/3" rsclass="clean"][vc_column_text rsclass="clean"]
<div class="promo02_rowbtn"><a class="tt-btn tt-btn__wide" href="#" data-toggle="modal" data-target="#modalVipTables"><span class="ch">book VIP table</span></a></div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row rsclass="clean" el_class="section-inner section-marker"][vc_column rsclass="clean"][vc_column_text rsclass="clean"]
<div class="section-wrapper02"></div>
[/vc_column_text][vc_row_inner rsclass="clean" el_class="container container-fluid-tablet"][vc_column_inner el_class="section-title" rsclass="clean"][vc_column_text rsclass="clean"]
<h2 class="section-title__text">Our Residents</h2>
<div class="section-title__text-under">Residents</div>
<div class="title__text-description">We have great crowd motivating DJs who are night builders and can help to increase spend and dwell time in our club</div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner rsclass="clean" el_class="js-slick03 slick-dots01 tt-box01-wrapper" rsouter="container container-fluid-tablet"][vc_column_inner el_class="item" width="1/3" rsclass="clean" rsinner="tt-box01"][vc_hoverbox image="1947" shape="square" rsclass="clean" rsiclass="tt-box01__img" rstclass="tt-box01_layout"]
<div class="tt-col">
    <ul class="tt-box01__social">
        <li>[clubio_icon icon="icon-social-facebook" link="https://www.facebook.com/"]</li>
        <li>[clubio_icon icon="icon-social-instagram" link="https://www.instagram.com/"]</li>
    </ul>
</div>
<div class="tt-col">
    <div class="tt-box01__title">
        <div class="tt-title01"><a href="https://www.instagram.com/">Anthony Markus</a></div>
        <div class="tt-title02">House, Deep House</div>
    </div>
</div>
[/vc_hoverbox][/vc_column_inner][vc_column_inner el_class="item" width="1/3" rsclass="clean" rsinner="tt-box01"][vc_hoverbox image="1951" shape="square" rsclass="clean" rsiclass="tt-box01__img" rstclass="tt-box01_layout tt-box01_layout02"]
<div class="tt-col">
    <ul class="tt-box01__social">
        <li>[clubio_icon icon="icon-social-facebook" link="https://www.facebook.com/"]</li>
        <li>[clubio_icon icon="icon-social-instagram" link="https://www.instagram.com/"]</li>
    </ul>
</div>
<div class="tt-col">
    <div class="tt-box01__title">
        <div class="tt-title01"><a href="https://www.instagram.com/">Ann Sandoval</a></div>
        <div class="tt-title02">House, Deep House</div>
    </div>
</div>
[/vc_hoverbox][/vc_column_inner][vc_column_inner el_class="item" width="1/3" rsclass="clean" rsinner="tt-box01"][vc_hoverbox image="1953" shape="square" rsclass="clean" rsiclass="tt-box01__img" rstclass="tt-box01_layout"]
<div class="tt-col">
    <ul class="tt-box01__social">
        <li>[clubio_icon icon="icon-social-facebook" link="https://www.facebook.com/"]</li>
        <li>[clubio_icon icon="icon-social-instagram" link="https://www.instagram.com/"]</li>
    </ul>
</div>
<div class="tt-col">
    <div class="tt-box01__title">
        <div class="tt-title01"><a href="https://www.instagram.com/">Kenneth Pierce</a></div>
        <div class="tt-title02">Kenneth Piercee</div>
    </div>
</div>
[/vc_hoverbox][/vc_column_inner][vc_column_inner el_class="item" width="1/3" rsclass="clean" rsinner="tt-box01"][vc_hoverbox image="1947" shape="square" rsclass="clean" rsiclass="tt-box01__img" rstclass="tt-box01_layout"]
<div class="tt-col">
    <ul class="tt-box01__social">
        <li>[clubio_icon icon="icon-social-facebook" link="https://www.facebook.com/"]</li>
        <li>[clubio_icon icon="icon-social-instagram" link="https://www.instagram.com/"]</li>
    </ul>
</div>
<div class="tt-col">
    <div class="tt-box01__title">
        <div class="tt-title01"><a href="https://www.instagram.com/">Anthony Markus</a></div>
        <div class="tt-title02">House, Deep House</div>
    </div>
</div>
[/vc_hoverbox][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][/vc_section]





<!--07-Session-->


[vc_section rsclass="clean" el_class="section-marker section-marker__indent02"][vc_row rsclass="clean" el_class="section-parallax lazyload" rsouter="section-indent-minus01" css=".vc_custom_1591363421212{background-image: url(https://clubio.softali.net/wp/demo/wp-content/uploads/2020/06/section-parallax.jpg?id=1904) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column rsclass="clean" el_class="section-parallax-inner" rsinner="container container-fluid-tablet"][vc_column_text rsclass="clean"][clubio_icon link="#" icon="icon-arrow_left" class="parallax__navleft icon-arrow_left"][clubio_icon link="#" icon="icon-arrow_right" class="parallax__navright icon-arrow_right"][/vc_column_text][vc_row_inner el_class="section-parallax-border02" rsclass="clean" rsinner="js-init-slick04 slick-dots01 slick-arrows01" rsouter="section-parallax-border01"][vc_column_inner el_class="item" width="1/2" rsclass="clean" rsinner="tt-parallax01"][vc_column_text rsclass="clean" el_class="tt-parallax01__wrapper"]
<div class="tt-parallax01__data">Saturday, Jan 25, 2020</div>
<div class="tt-parallax01__title">Elevation: Season Opening Party</div>
<p class="ch">The season opening party is here. Super special debut of RSS Disco, the now legendary Mayan Warrior resident Peter Invasion who brought it top level to the City of Gods &amp; the debut of Savaggio &amp; ZERO!!!</p>

<div class="ch"><a class="tt-btn tt-btn__wide" href="news"><span class="ch">know more</span></a></div>
[/vc_column_text][/vc_column_inner][vc_column_inner el_class="item" width="1/2" rsclass="clean" rsinner="tt-parallax01"][vc_column_text rsclass="clean" el_class="tt-parallax01__wrapper"]
<div class="tt-parallax01__data">Saturday, Jan 25, 2020</div>
<div class="tt-parallax01__title">Elevation: Season Opening Party</div>
<p class="ch">The season opening party is here. Super special debut of RSS Disco, the now legendary Mayan Warrior resident Peter Invasion who brought it top level to the City of Gods &amp; the debut of Savaggio &amp; ZERO!!!</p>

<div class="ch"><a class="tt-btn tt-btn__wide" href="news"><span class="ch">know more</span></a></div>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][/vc_section]



<!--08-Instagram-->

[vc_row rsclass="clean" el_id="ch-section-instagram" el_class="section-marker section-marker__indent04"][vc_column rsclass="clean" el_class="section-indent06"][vc_column_text rsclass="clean" el_class="container"]
<div class="section-title section-title_01">
    <div class="section-title__label">YOU CAN AFFORD MORE HERE</div>
    <h2 class="section-title__text">Instagram <a class="tt-base-color" href="https://www.instagram.com/vipclubiodemo/">@VIPClubio</a></h2>
    <div class="section-title__text-under">Gallery</div>
</div>
[/vc_column_text][clubio_instagram_element limit="12" items_per_row="6"][/vc_column][/vc_row]


<!--09-Promo-->

[vc_row rsclass="clean" el_class="tt-promo01" el_id="ch-section-promo"][vc_column rsclass="clean" el_class="tt-promo01__layout"][vc_column_text rsclass="clean"]
<h5 class="tt-title"><span class="tt-base-color">Feel Free</span> and Enjoy<br class="ch" />in VIP Clubio with Joy</h5>
<p class="ch">We are very excited to have launched our brand new cocktail bar! Located on our ground floor. Come in, have a drink, some complimentary nibbles and relax.</p>

<div class="ch"><a class="tt-btn-default" href="events-parties"><span class="ch">explore all events</span></a></div>
[/vc_column_text][/vc_column][/vc_row]