(function ($) {
    "use strict";
        var obj = $("#instafeed");
        if(!obj.length && !obj.hasClass('activation')) return false;
        var initEvent = obj.attr('data-init');


    $(window).on('load', function () {
        //$(window).on(initEvent, function(){
            if(!obj.hasClass('activation')){
                obj.addClass('activation')
                $("#instafeed").each(function(){
                    var totalItem =  $(this).attr('data-totalitem');
                    $.instagramFeed({
                        'username': insObject['user_name'], //user name
                        'container': '#' + insObject['el_id'], //images container
                        'display_profile': false,
                        'display_biography': false,
                        'display_gallery': true,
                        'styling': false,
                        'items': totalItem,

                        'items_per_row': insObject['items_per_row'],
                        'margin': insObject['margin'],
                        'tag':insObject['user_tag']

                    });
                });
            };
        });

})(jQuery);
