<?php
if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $gm_marker
 * @var $el_id
 * @var $el_class
 * @var $content
 */
$default_src = vc_asset_url('vc/no_image.png');
$el_class = $el_id = $rs_num = $rs_img_size = $rs_loader = $arrows = $dots = $autoplay = $autoplayspeed = $fade = $speed = $output = '';

$attributes = vc_map_get_attributes($this->getShortcode(), $atts);
extract($attributes);
$rs_texts_output = explode('{slide}', $content );

$rs_num = ($rs_num =='' || $rs_num = 0 ? 2 : intval($rs_num));
$el_id = ($el_id != '' ? $el_id : 'mainSlider');


$rs_object = array(
    'el_id' => $el_id,
    'arrows' => $arrows,
    'dots' => $dots,
    'autoplay' => $autoplay,
    'autoplayspeed' => $autoplayspeed,
    'fade' => $fade,
    'speed' => $speed
);
$image_src = '';

$rs_images = explode( ',', $attributes['rs_images'] );


wp_enqueue_script('clubio-advslider-element');
wp_localize_script('clubio-advslider-element', 'rsObject', $rs_object);

$output = '';

?>
<div class="mainSliderWrapper">

    <div class="loader-wrapper">
        <div class="loader-container">
            <div class="rectangle-1">&nbsp;</div><div class="rectangle-2">&nbsp;</div><div class="rectangle-3">&nbsp;</div><div class="rectangle-4">&nbsp;</div><div class="rectangle-5">&nbsp;</div><div class="rectangle-6">&nbsp;</div><div class="rectangle-5">&nbsp;</div><div class="rectangle-4">&nbsp;</div><div class="rectangle-3">&nbsp;</div><div class="rectangle-2">&nbsp;</div><div class="rectangle-1">&nbsp;</div>
        </div>
    </div>


    <section id="<?php echo $el_id; ?>" class="mainSlider main-slider">

<?php
        $image_count = 0;

        for ($i = 0; $i < $attributes['rs_num']; $i++) :
        if (isset($rs_texts_output[$i])) :

            $output_slide_contents = explode('{text}', $rs_texts_output[$i] );

            $image_substr = '{image}';
            $video_substr = '{video}';
            $video_ytb_substr = '{youtube}';
            $video_vm_substr = '{vimeo}';

            $type_exists = '';
            $image_video_str = $output_slide_contents[0];

            if (strpos($image_video_str, $image_substr) !== false) {

                $type_exists = 'image';

                if (isset($rs_images[$image_count])) {
                    $img = wpb_getImageBySize( array(
                        'attach_id' => $rs_images[$image_count],
                        'thumb_size' => 'full',
                    ) );
                    $image_src = $img['p_img_large'][0];
                } else {
                    $image_src = $default_src;
                }
                $image_count ++;


            } elseif (strpos($image_video_str, $video_substr) !== false || strpos($image_video_str, $video_ytb_substr) !== false || strpos($image_video_str, $video_vm_substr) !== false) {
                $type_exists = 'video';
                if (strpos($image_video_str, $video_ytb_substr) !== false) {$type_exists = 'youtube';}
                if (strpos($image_video_str, $video_vm_substr) !== false) {$type_exists = 'vimeo';}

            }
?>

    <div class="item <?php echo $type_exists; ?>">
        <?php if ($type_exists != 'video') : echo '<figure>'; endif; ?>
        
        <?php if ($type_exists == 'image') { ?>

        <div class="slide-image image_num_<?php echo $image_count; ?> slide-media" style="background-image:url('<?php echo $image_src; ?>');"><img data-lazy="<?php echo $image_src; ?>" class="image-entity" /></div>
             <?php  }
        if (isset($output_slide_contents[0]) && $type_exists != 'image') :
            $pieces = explode("}", $output_slide_contents[0]);
            echo (isset($pieces[1]) ? $pieces[1] : '');
        endif;
        if (isset($output_slide_contents[1]) && $output_slide_contents[1] != '') : ?>
            <div class="slide-content center">
                <div class="vert-wrap container">
                    <div class="vert">
                        <div class="container">
                            <div class="slide-caption"><?php echo $output_slide_contents[1]; ?></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
            endif;
            if ($type_exists != 'video') :  echo '</figure>'; endif;
        ?>
    </div>
        <?php
        endif;
    endfor;
?>


</section>
</div>
