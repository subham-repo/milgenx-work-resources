<?php
add_action( 'vc_before_init', 'clubio_pre_init' );
function clubio_pre_init() {
    if( function_exists('vc_set_shortcodes_templates_dir') ){
        vc_set_shortcodes_templates_dir( plugin_dir_path( __FILE__ ).'vc_elements' );
    }
}
add_action( 'vc_after_init', 'clubio_post_init' );
function clubio_post_init() {
    $clubio_vc_column_new_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'clubio-layout' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Add Inner Block', 'theme-core' ),
            'param_name' => 'rsinner',
            'description' => esc_html__( 'Write some css style if you want to add innver block. If you left the field empty Inner Block will not be added', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 0,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),
    );
    $clubio_vc_row_new_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'theme-core' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),

        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Add Outer Block', 'theme-core' ),
            'param_name' => 'rsouter',
            'description' => esc_html__( 'Write some css style if you want to add outer block. If you left the field empty Outer Block will not be added', 'theme-shortcodes' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 0,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Add Inner Block', 'theme-core' ),
            'param_name' => 'rsinner',
            'description' => esc_html__( 'Write some css style if you want to add inner block. If you left the field empty Inner Block will not be added', 'theme-shortcodes' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 0,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),

    );
    $clubio_vc_column_inner_new_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'theme-core' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 2,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Add Inner Block', 'theme-core' ),
            'param_name' => 'rsinner',
            'description' => esc_html__( 'Write some css style if you want to add inner block. If you left the field empty Inner Block will not be added', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),
    );
    $clubio_vc_row_inner_new_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'theme-core' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Inner Block', 'theme-shortcodes' ),
            'param_name' => 'rsinner',
            'description' => esc_html__( 'Write some css style if you want to add the block. If you left the field empty the block will not be added', 'theme-shortcodes' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Outer Block', 'theme-shortcodes' ),
            'param_name' => 'rsouter',
            'description' => esc_html__( 'Write some css style if you want to add the block. If you left the field empty the block will not be added', 'theme-shortcodes' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 0,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),


    );
    $clubio_vc_column_text = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'theme-core' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),
    );
    $clubio_vc_section_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'theme-core' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),
    );
    $clubio_vc_single_image_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'theme-core' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Image loading', 'theme-core' ),
            'param_name' => 'ch_lazy',
            'value' => array( "default","lazyloading" ),
            'description' => esc_html__( '"Lazy Loading" is used if "Clean" class above is used', 'theme-core' ),
            'group' => esc_html__('Clubio Settings','theme-core'),
            'dependency' => array(
                'element' => 'rsclass',
                'value' => 'clean',
            ),

        ),
        array(
            'type' => 'textarea_html',
            'class' => 'class-name',
            'heading' => esc_html__( 'Additional html', 'theme-core' ),
            'param_name' => 'content',
            'description' => esc_html__( 'Write html which will comes in the inner part of common wrapper with Extra class name', 'theme-core' ),
            'admin_label' => true,
            'weight' => 0,
            'group' => esc_html__('Theme Options','theme-core'),
            'dependency' => array(
                'element' => 'rsclass',
                'value' => 'clean',
            ),

        ),




    );
    $clubio_vc_hoverbox_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'theme-core' ),
            'param_name' => 'rsclass',
            'description' => esc_html__( 'Write "clean" to remove some Hover Box default functionality: tab General - block width, block alignment, Reverse blocks, CSS Animation, tab Hover Block - Hover title, Hover title alignment, Background Color, Use custom font, Add button, all tab Design Options.', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core')
        ),



        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Extra class name for Image Wrapper', 'theme-core' ),
            'param_name' => 'rsiclass',
            'description' => esc_html__( 'Extra class name for Outer Image Wrapper', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => '',
            'group' => '',
        ),
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Extra class name for Text Wrapper', 'theme-core' ),
            'param_name' => 'rstclass',
            'description' => esc_html__( 'Extra class name for Outer Text Wrapper', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => '',
            'group' => '',
        ),
    );
    $clubio_vc_custom_heading_params = array(
        array(
            'type' => 'textfield',
            'class' => 'class-name',
            'heading' => esc_html__( 'Add Outer Wrapper Block', 'theme-core' ),
            'param_name' => 'rsouter',
            'description' => esc_html__( 'Write some css style if you want to add outer wrapper block. If you left the field empty Outer Block will not be added', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 0,
            'group' => '',
        ),
    );



    $clubio_vc_tta_global_params = array(
        array(
            'type' => 'dropdown',
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'theme-core' ),
            'param_name' => 'rsclass1',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core'),
            'value' => array( "default","clean","calendar" ),
        ),
    );

    //the Seciton under Tabs
    $clubio_vc_tta_pageable_section_params = array(
        array(
            'class' => 'class-name',
            'heading' => esc_html__( 'Clean Classes Box', 'theme-core' ),
            'param_name' => 'rsclass2',
            'description' => esc_html__( 'Write "clean" to remove all default classes', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core'),
            'value' => array( "default","clean","calendar" ),
            'type' => 'dropdown',
        ),
        array(
            'class' => 'class-name',
            'heading' => esc_html__( 'Day type: Empty or with Event', 'theme-core' ),
            'param_name' => 'c_day_type',
            'description' => wp_kses( __('<strong>active</strong> - Active day of a month: can have a holiday label or a product as event.<br> <strong>old</strong> - a day from the previous month (will be darken).', 'theme-core' ), array( 'strong' => array('class' => true), 'br' => array())),

            'admin_label' => false,
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core'),
            'value' => array( "active","old" ),
            'type' => 'dropdown',

            'dependency' => array(
                'element' => 'rsclass2',
                'value' => 'calendar',
            ),
        ),
    );

    $clubio_vc_tta_tabs_params = array(
        array(
            'heading' => esc_html__( 'Clean Classes Box', 'theme-core' ),
            'param_name' => 'rsclass3',
            'description' => esc_html__( 'Write "clean" to remove all default classes.', 'theme-core' ),
            'admin_label' => false,
            'dependency' => '',
            'weight' => 1,
            'group' => esc_html__('Clubio Settings','theme-core'),

            'type' => 'textfield',
            'class' => 'class-name',
            //'value' => array( "default","clean","calendar" ),

        ),
    );





    vc_add_params( 'vc_column', $clubio_vc_column_new_params );
    vc_add_params( 'vc_row', $clubio_vc_row_new_params );
    vc_add_params( 'vc_column_inner', $clubio_vc_column_inner_new_params );
    vc_add_params( 'vc_row_inner', $clubio_vc_row_inner_new_params );
    vc_add_params( 'vc_column_text', $clubio_vc_column_text );
    vc_add_params( 'vc_section', $clubio_vc_section_params );
    vc_add_params( 'vc_single_image', $clubio_vc_single_image_params );
    vc_add_params( 'vc_custom_heading', $clubio_vc_custom_heading_params );
    vc_add_params( 'vc_hoverbox', $clubio_vc_hoverbox_params );

    vc_add_params( 'vc_tta_pageable', $clubio_vc_tta_global_params );
    vc_add_params( 'vc_tta_section', $clubio_vc_tta_pageable_section_params );
    vc_add_params( 'vc_tta_tabs', $clubio_vc_tta_tabs_params );
}