<?php
if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $products_ids
 * @var $t_type
 * @var $btn_buy
 * @var $btn_tables
 * @var $content
 */
$ids = $products_ids = $t_image = $t_date = $t_title = $t_btn_table = $t_btn_buy = $t_sub = $btns_content = $t_label = $qty = $add_html = '';

//type 1 - wide/rows, type 2 - columns, 3 - calendar event

//css outer class for type 1: section-wrapper subpages-inner section-marker
//css outer class for type 2: subpages-inner section-marker container container-fluid-lg ticket-type-2
//html for btns:
/*
<div class="ch"><a class="tt-btn-default" href="#" data-toggle="modal" data-target="#modalBayTickets" tabindex="0"><span class="ch">buy tickets</span></a><br class="ch"><a class="tt-btn-default" href="#" data-toggle="modal" data-target="#modalVipTables" tabindex="0"><span class="ch">VIP tables</span></a></div>
*/

$t_type = $btn_buy = $btn_tables = $bl_date = 1;

$attributes = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $attributes );

$products_ids = explode( ',', $atts['ids'] );

$t_btn_table = ($btn_tables == 'true' ? '<a class="'.($t_type == 1 ? 'tt-btn-default '.($btn_buy == 'false' ? 'mt-0' : '') : 'tt-btn').'" href="#" data-toggle="modal" data-target="#modalVipTables" tabindex="0"><span class="ch">'.esc_html__('VIP tables', 'theme-core' ).'</span></a>' : '');

/*
 * type 1 date content:  <span class="ch">23</span>Jan
 * type 2 price content: From<br> <strong class="ch">$25</strong>
 */

$empty_text = esc_html__('Please, add existing product', 'theme-core' );

switch ($t_type) :

    case 1:
        //array of products

        if (isset($products_ids)) :
            foreach ($products_ids as $product_id) :
                $product = (clubio_plugin_detect('woo') ? wc_get_product( $product_id ) : '');

                if(!is_object($product)){
                    echo '<div class="tickets-wide"><div class="rs_inner_block tickets-wide__item" style="text-align:center;padding:50px 0"> <div class="shortcode_vc_text tickets-wide__description"> <div class="tickets-wide__title" style="font-size:15px;margin:auto">'.$empty_text.'</div> </div></div></div>';
                } else {

                    $qty = $product->get_stock_quantity();
                    $t_date = $product->get_meta( '_custom_field_two' );
                    $t_image = $product->get_image();
                    $t_title = $product->get_name();
                    $t_label = $product->get_meta( '_textarea' );
                    $t_btn_buy = ($btn_buy == 'true' ? '<a class="tt-btn-default" href="'.esc_url( $product->add_to_cart_url() ).'"><span class="ch">'.($product->get_manage_stock() == 1 && $qty == 0 ? esc_html__('sold out', 'theme-core' ) : esc_html__('buy tickets', 'theme-core' )).'</span></a>' : '');
                    $btns_content = '<div class="tickets-wide__btn">'.($content != '' && $add_html == 'true' ? wpb_js_remove_wpautop($content, true ) : $t_btn_buy.'<br>'.$t_btn_table).'</div>';

                    echo '
                        <div class="tickets-wide">
                            <div class="tickets-wide__item">
                                <div class="tickets-wide__img">'.$t_image.'</div>
                                <div class="tickets-wide__description">';
                                    echo ($t_label != '' && $t_label != '-' ? '<div class="tt-col"><div class="tickets-wide__label">'.$t_label.'</div></div>' : ($t_label == '' ? '<div class="tt-col"><div class="tickets-wide__label"><span class="ch">23</span>Jan</div></div>' : '')).
                                    '<div class="tt-col">';
                                        echo ($bl_date == 'true' ? '<div class="tickets-wide__data">'.($t_date != '' ? date('l, M j, Y', strtotime($t_date)) : date('l, M j, Y')).'</div>' : '');
                                        echo '<div class="tickets-wide__title">'.$t_title.'</div>
                                    </div>
                                </div>
                                '.$btns_content.'
                            </div>
                        </div>';
                }
            endforeach;
        endif;
    break;

    case 2:

        echo '
        <div class="row tickets-col-wrapper">';
        //array of products
        if (isset($products_ids)) :
            foreach ($products_ids as $product_id) :
                $product = (clubio_plugin_detect('woo') ? wc_get_product( $product_id ) : '');

                if(!is_object($product)){
                    echo '<div class="col-sm-6 col-md-4 "><div class="tickets-col"> <div class="tickets-col__img" style="position: relative;background: #eee;"> <img style="visibility:hidden" style="width: 100%; height: auto;" width="555" height="601" src="https://clubio.softali.net/wp/demo/wp-content/uploads/2020/07/tickets-col-01.jpg" class="vc_single_image-img attachment-full" alt="" /> </div> <div class="tickets-col__title" style="font-size:15px;text-align:center;position: absolute;padding-right: 30px; top: 50%; display: block; width: 100%;">'.$empty_text.'</div> </div></div>';
                } else {
                    $qty = $product->get_stock_quantity();
                    $t_date = $product->get_meta( '_custom_field_two' );
                    $t_image = $product->get_image();
                    $t_title = $product->get_name();
                    $t_sub = $product->get_meta( '_text_field' );
                    $t_label = $product->get_meta( '_textarea' );

                    $t_btn_buy = ($btn_buy == 'true' ? '<a class="tt-btn" href="'.esc_url( $product->add_to_cart_url() ).'"><span class="ch">'.($product->get_manage_stock() == 1 && $qty == 0 ? esc_html__('sold out', 'theme-core' ) : esc_html__('buy tickets', 'theme-core' )).'</span></a>' : '');
                    $btns_content = '<div class="tickets-wide__btn">'.($content != '' ? wpb_js_remove_wpautop($content, true ) : $t_btn_buy.'<br>'.$t_btn_table).'</div>';

                    echo '
                        <div class="col-sm-6 col-md-4">
                            <div class="tickets-col">
                                <div class="tickets-col__img">
                                    '.$t_image;
                                    echo ($t_label != '' && $t_label != '-' ? '<div class="tickets-col__label">'.$t_label.'</div>' : ($t_label == '' ? '<div class="tickets-col__label">From<br> <strong class="ch">$25</strong></div>' : ''));
                                    echo '<div class="tickets-col__btn">'.$t_btn_buy.'<br>'.$t_btn_table.'</div>
                                </div>
                                <div class="tickets-col__description">';
                                    echo ($bl_date == 'true' ? '<div class="tickets-col__data">'.($t_date != '' ? date('l, M j, Y', strtotime($t_date)) : date('l, M j, Y')).'</div>' : '');
                                    echo '<h3 class="tickets-col__title">'.$t_title.'</h3>
                                    '.($t_sub != '' && $t_sub != '-' ? $t_sub : '').'
                                </div>
                            </div>
                        </div>';
                }
            endforeach;
        else:
            echo 'Please add the products';
        endif;
        echo '</div>';

        break;

    case 3;
        if (isset($products_ids)) :
            foreach ($products_ids as $product_id) :
                $product = (clubio_plugin_detect('woo') ? wc_get_product( $product_id ) : '');

                if(!is_object($product)){
                    echo '<div style="font-size:15px;text-align:center;line-height: 20px;">'.$empty_text.'</div>';
                } else {
                    $qty = $product->get_stock_quantity();
                    $t_date = $product->get_meta( '_custom_field_two' );

                    //$datetime = new DateTime($t_date);

                    $t_image = wp_get_attachment_url( $product->get_image_id() );
                    $t_btn_buy = ($btn_buy == 'true' ? '<a class="tt-btn" href="'.esc_url( $product->add_to_cart_url() ).'"><span class="ch">'.($product->get_manage_stock() == 1 && $qty == 0 ? esc_html__('sold out', 'theme-core' ) : esc_html__('buy tickets', 'theme-core' )).'</span></a>' : '');
                    $btns_content = '<div class="ch-btns-wrapper">'.($content != '' && $add_html == 'true' ? wpb_js_remove_wpautop($content, true ) : $t_btn_buy.'<br>'.$t_btn_table).'</div>';

                    echo '
                    <div class="tt-day-event__bg" style="background-image: url('.$t_image.')">
                    '.$btns_content.'
                    </div>';

                    echo ($bl_date == 'true' ? ($t_date != '' ? '<div class="tt-day-event__time"><strong class="ch">'.date('j', strtotime($t_date)).'</strong>'.date('M', strtotime($t_date)).'</div>' : '') : '');
                }

            endforeach;
        endif;


        break;

endswitch;
