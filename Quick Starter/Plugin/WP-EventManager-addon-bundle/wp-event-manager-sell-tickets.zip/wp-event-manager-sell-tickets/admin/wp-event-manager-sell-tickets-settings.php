<?php
/*
* This file use for setings at admin site for sell tickets settings.
* This setting to show and hide registration form  at single event listing and free and paid tickets field at submit event page.
*/
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * WP_Event_Manager_Sell_Tickets_Settings class.
 */
class WP_Event_Manager_Sell_Tickets_Settings {

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() 
    {		
		add_filter( 'event_manager_settings', array( $this, 'sell_tickets_settings' ) ,99);
		add_action('wpem_admin_seting_side_box_start',array($this,'wpem_sell_ticket_ticket_shortcode_box'));

		

	}
	
	
	/**
	 * export settings function.
	 *
	 * @access public
	 * @return void
	 */
	public function sell_tickets_settings($settings) {

		$settings[ 'event_sell_tickets' ] =  array(
                        __( 'Sell Tickets', 'wp-event-manager-sell-tickets' ),
                        array(
                            	array(
									'name'       => 'event_manager_paid_tickets',
		
									'std'        => '1',
									
									'cb_label'   => __( 'You can show or hide Paid tickets field from [submit_event_form] page.', 'wp-event-manager-sell-tickets' ),
		
									'label'      => __( 'Show Paid tickets field', 'wp-event-manager-sell-tickets' ),
		
									'desc'       => '',
		
									'type'       => 'checkbox'
								),
								array(
									'name'       => 'event_manager_free_tickets',
		
									'std'        => '1',
									
									'cb_label'   => __( 'You can show or hide free tickets field from [submit_event_form] page.', 'wp-event-manager-sell-tickets' ),
		
									'label'      => __( 'Show Free tickets field', 'wp-event-manager-sell-tickets' ),
		
									'desc'       => '',
		
									'type'       => 'checkbox'
								),
	                            array(
	                                'name'       => 'event_manager_donation_tickets',
	                                
	                                'std'        => '1',
	                                
	                                'cb_label'   => __( 'You can show or hide donation tickets field from [submit_event_form] page.', 'wp-event-manager-sell-tickets' ),
	                                
	                                'label'      => __( 'Show Donation tickets field', 'wp-event-manager-sell-tickets' ),
	                                
	                                'desc'       => '',
	                                
	                                'type'       => 'checkbox'
	                            ),
								array(
									'name'       => 'event_manager_event_registration_addon_form',
		
									'std'        => '0',
									
									'cb_label'   => __( 'You can show or hide event registration addon form at single event page.', 'wp-event-manager-sell-tickets' ),
		
									'label'      => __( 'Show event registration addon form ', 'wp-event-manager-sell-tickets' ),
		
									'desc'       => '',
		
									'type'       => 'checkbox'
								),
								array(
									'name'       => 'wpem_sell_tickets_ticket_layout',
		
									'std'        => '0',
									
									'cb_label'   => __( 'Ticket layout used to generate pdf ticket.', 'wp-event-manager-sell-tickets' ),
		
									'label'      => __( 'Select ticket layout', 'wp-event-manager-sell-tickets' ),
		
									'desc'       => '',
		
									'type'       => 'radio',
									'options'	 => array(
										'0' => __('Default'),
										'1' => __('Style - 1','wp-event-manager-sell-tickets'),
										'2' => __('Style - 2','wp-event-manager-sell-tickets'),
										'3' => __('Custom','wp-event-manager-sell-tickets'),
										)
								),	

								array(
									'name'       => 'wpem_sell_tickets_ticket_content',
		
									'std'        => '',
									
									'cb_label'   => __( 'Ticket content used to generate pdf ticket.', 'wp-event-manager-sell-tickets' ),
		
									'label'      => __( 'Ticket PDF', 'wp-event-manager-sell-tickets' ),
		
									'desc'       => __('Add the ticket html with tags. ','wp-event-manager-sell-tickets'),
		
									'type'       => 'textarea',
									'row'		 => 20,
								),

								array(
									'name'       => 'wpem_sell_tickets_test_ticket_email',
		
									'std'        => '',
									
									'cb_label'   => __( 'Test email', 'wp-event-manager-sell-tickets' ),
		
									'label'      => __( 'Test email', 'wp-event-manager-sell-tickets' ),
		
									'desc'       => __('Email to test pdf ticket. ','wp-event-manager-sell-tickets'),
		
									'type'       => 'text',
									'row'		 => 20,
								),	

								array(
									'name'       => 'wpem_sell_tickets_test_now',
		
									//'std'        => '',
									
									'cb_label'   => __( 'Send now', 'wp-event-manager-sell-tickets' ),
		
									'label'      => '',
		
									'desc'       => '',
		
									'type'       => 'button',
								),

													
                        )

				);

		$event_submission_settings = [];
		if( isset($settings['event_submission'][1]) && !empty($settings['event_submission'][1]) )
		{
			foreach ($settings['event_submission'][1] as $key => $event_submission) 
			{
				if( !in_array($event_submission['name'], ['event_manager_enable_event_ticket_prices']) )
				{
					$event_submission_settings[] = $event_submission;
				}				
			}

			$settings['event_submission'][1] = 	$event_submission_settings;	
		}


		//if recurring addon active load the settings
		if(isset($settings['event-recurring'][1] )){
			$settings['event-recurring'][1][] = array(
		                'name' 		=> 'event_manager_duplicate_tickets',
		                'std' 		=> '1',
		                'label'      => __( 'Duplicate Tickets with Events', 'wp-event-manager-sell-tickets' ),
		                
		                'cb_label'   => __( 'Enable Duplicate Tickets for Recurring Events', 'wp-event-manager-sell-tickets' ),
		                
		                'desc'       => __( 'If enabled, recurring events creates duplicate tickets, else Use the parent event tickets and show at single event page.', 'wp-event-manager-sell-tickets' ),
		                
		                'type'       => 'checkbox',
		            );
		        
		}


		//Copatiblity with older version of WPEM. 
		//Need to remove PDF custom settings 
		if(version_compare(EVENT_MANAGER_VERSION,'3.1.21') <= 0){
					unset($settings[ 'event_sell_tickets' ][1][4]['options'][3]);
					unset($settings[ 'event_sell_tickets' ][1][5]);
					unset($settings[ 'event_sell_tickets' ][1][6]);
					unset($settings[ 'event_sell_tickets' ][1][7]);
		}
		
		
        return $settings;		                                                          
	}

    /**
    * @since 1.8.12
    * @param 
    * 
    * @return 
    */
    public function wpem_sell_ticket_ticket_shortcode_box(){
    	?>
    	<div class="box-info">
		   <div class="wp-event-sell_ticket-ticket-content-tags">
			<p><?php _e( 'The following tags can be used to add content dynamically:', 'wp-event-manager-sell-tickets' ); ?></p>
			<ul>
				<?php foreach ( get_wpem_sell_tickets_ticket_tags() as $tag => $name ) : ?>
					<li><code>[<?php echo esc_html( $tag ); ?>]</code> - <?php echo wp_kses_post( $name ); ?></li>
				<?php endforeach; ?>
			</ul>
			<p><?php _e( 'All tags can be passed a prefix and a suffix which is only output when the value is set e.g. <code>[event_title prefix="Event Title: " suffix="."]</code>', 'wp-event-manager-registrations' ); ?></p>
		   </div>
	    </div> <!--box-info--> 
    	<?php

    }

  
	
}
new WP_Event_Manager_Sell_Tickets_Settings();
