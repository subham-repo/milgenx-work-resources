<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP_Event_Manager_Sell_Tickets_Admin
 */
class WP_Event_Manager_Sell_Tickets_Admin {

	/** @var object Class Instance */
	private static $instance;

	/**
	 * Get the class instance
	 *
	 * @return static
	 */
	public static function get_instance() {
		return null === self::$instance ? ( self::$instance = new self ) : self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		add_filter( 'woocommerce_subscription_product_types', array( $this, 'woocommerce_subscription_product_types' ) );
		add_filter( 'product_type_selector', array( $this, 'product_type_selector' ) );
		add_action( 'woocommerce_process_product_meta_event_ticket', array( $this, 'save_event_ticket_data' ),99 );
		add_action( 'woocommerce_process_product_meta_event_ticket_subscription', array( $this, 'save_event_ticket_data' ),99 );
	
		add_action( 'woocommerce_product_options_general_product_data', array( $this, 'product_data' ) );
		add_filter( 'parse_query', array( $this, 'parse_query' ) );

		add_action( 'restrict_manage_posts', array( $this, 'restrict_manage_posts' ) );
	}



	/**
	 * Types for subscriptions
	 *
	 * @param  array $types
	 * @return array
	 */
	public function woocommerce_subscription_product_types( $types ) {
		$types[] = 'event_ticket_subscription';
		return $types;
	}

	/**
	 * Add the product type
	 *
	 * @param array $types
	 * @return array
	 */
	public function product_type_selector( $types ) {
		$types['event_ticket'] = __( 'Event Ticket', 'wp-event-manager-wc-paid-listings' );
		
		if ( class_exists( 'WC_Subscriptions' ) ) {
			$types['event_ticket_subscription'] = __( 'Event Ticket Subscription', 'wp-event-manager-wc-paid-listings' );
			
		}
		return $types;
	}

	/**
	 * Show the event package product options
	 */
	public function product_data() {
		global $post;
		$post_id = $post->ID;
		get_event_manager_template( 'html-event-ticket-data.php', array(), 'wp-event-manager-sell-tickets', EVENT_MANAGER_SELL_TICKETS_PLUGIN_DIR. '/templates/admin/' );

	}

	/**
	 * Save Event Package data for the product
	 *
	 * @param  int $post_id
	 */
	public function save_event_ticket_data( $post_id ) {

		$event_id = isset( $_POST['event_id'] ) ? sanitize_text_field($_POST['event_id']) : '';

		$event = get_post($event_id);

		if(!empty($event))
		{
			$args = [
				'ID' => $post_id,
				'post_author' => $event->post_author,
			];
			wp_update_post($args);
		}

		$show_ticket_description 	= isset( $_POST['_ticket_show_description'] ) ? $_POST['_ticket_show_description'] : '';
		$ticket_fee_pay_by 	        = isset( $_POST['_ticket_fee_pay_by'] ) ? $_POST['_ticket_fee_pay_by'] : '';
		$minimum_tickets 	        = isset( $_POST['minimum_order'] ) ? $_POST['minimum_order'] : '';
		$maximum_tickets 	        = isset( $_POST['maximum_order'] ) ? $_POST['maximum_order'] : '';
		$remaining_tickets 	        = isset( $_POST['_show_remaining_tickets'] ) ? $_POST['_show_remaining_tickets'] : '';
		$ticket_visibility 	        = isset( $_POST['ticket_visibility'] ) ? $_POST['ticket_visibility'] : '';
		$stock 	        			= isset( $_POST['_stock'] ) ? $_POST['_stock'] : '';
		$regular_price 	        	= isset( $_POST['_regular_price'] ) ? $_POST['_regular_price'] : '';
		$sold_individually 	        = isset( $_POST['_sold_individually'] ) ? $_POST['_sold_individually'] : '';
		$ticket_type 	        	= isset( $_POST['_ticket_type'] ) ? $_POST['_ticket_type'] : '';
		$ticket_sales_start_date 	= isset( $_POST['_ticket_sales_start_date'] ) ? $_POST['_ticket_sales_start_date'] : '';
		$sales_start_time 			= isset( $_POST['_ticket_sales_start_time'] ) ? $_POST['_ticket_sales_start_time'] : '';
		$ticket_sales_end_date   	= isset( $_POST['_ticket_sales_end_date'] ) ? $_POST['_ticket_sales_end_date'] : '';
		$sales_end_time 			= isset( $_POST['_ticket_sales_end_time'] ) ? $_POST['_ticket_sales_end_time'] : '';
		$ticket_priority 			= isset( $_POST['_ticket_priority'] ) ? $_POST['_ticket_priority'] : '';
		
		//check if method exists. this method is added in 3.1.10. After 3.2.0 we will remove this method condition
		if(method_exists('WP_Event_Manager_Date_Time','get_db_formatted_date_time'))
		{
			//get date and time setting defined in admin panel Event listing -> Settings -> Date & Time formatting
		    $datepicker_date_format 	= WP_Event_Manager_Date_Time::get_datepicker_format();
		    
		    //covert datepicker format  into php date() function date format
		    $php_date_format 		= WP_Event_Manager_Date_Time::get_view_date_format_from_datepicker_date_format( $datepicker_date_format );
    
			//Convert sales start date date and time value into DB formatted format and save eg. 1970-01-01 00:00:00
            $start_dbformatted_date     = WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format, $ticket_sales_start_date );
            $start_dbformatted_time     = WP_Event_Manager_Date_Time::get_db_formatted_time( $sales_start_time );
            $start_dbformatted_date     = isset($start_dbformatted_date,$start_dbformatted_time) ? $start_dbformatted_date.' '.$start_dbformatted_time : $ticket_sales_start_date;
             
            //Convert sales end date date and time value into DB formatted format and save eg. 1970-01-01 00:00:00
            $end_dbformatted_date 		= WP_Event_Manager_Date_Time::date_parse_from_format($php_date_format, $ticket_sales_end_date );
            $end_dbformatted_time 		= WP_Event_Manager_Date_Time::get_db_formatted_time( $sales_end_time );
            $end_dbformatted_date  		= isset($end_dbformatted_date,$end_dbformatted_time) ? $end_dbformatted_date.' '.$end_dbformatted_time : $ticket_sales_end_date;
		}
		
		 
		$paid_tickets       = get_post_meta($event_id,'_paid_tickets',true );
		$free_tickets       = get_post_meta($event_id,'_free_tickets',true);
		$donation_tickets   = get_post_meta($event_id,'_donation_tickets',true);

		//common ticket array
	  	$temp_ticket =  array();
	  	$temp_ticket['product_id']						  = $post_id;
	  	$temp_ticket['ticket_name']                       = get_the_title($post_id);
		$temp_ticket['ticket_visibility']                 = $ticket_visibility;
		$temp_ticket['ticket_quantity']                   = $stock;
		$temp_ticket['ticket_price']                      = $regular_price;
		$temp_ticket['ticket_sales_start_date']           = $start_dbformatted_date;
		$temp_ticket['ticket_sales_start_time']           = $sales_start_time;
		$temp_ticket['ticket_sales_end_date']             = $end_dbformatted_date;
		$temp_ticket['ticket_sales_end_time']             = $sales_end_time;
		$temp_ticket['ticket_description']                = get_post_field('post_content', $post_id);
		$temp_ticket['ticket_show_description']           = $show_ticket_description == 'yes' ? '1' : '0';
		$temp_ticket['ticket_minimum']                    = $minimum_tickets;
		$temp_ticket['ticket_maximum']                    = $maximum_tickets;
		$temp_ticket['show_remaining_tickets']            = $remaining_tickets == 'yes' ? '1' : '0';
		$temp_ticket['ticket_fee_pay_by']                 = $ticket_fee_pay_by;
		$temp_ticket['ticket_individually']               = $sold_individually;
		$temp_ticket['ticket_priority']               	  = $ticket_priority;

		/**
		 * Below three ticket type will be updated in event meta key
		 * for all three type of ticket (paid,free and donation ) it will fetch the current ticket details and update perticular ticket
		 * which is currently updating from admin side product.
		 *
		*/
		//paid ticket
		if($ticket_type ==  'paid'){
			if( !empty($paid_tickets) && is_array( $paid_tickets )  )
			{
				$updated_product = false;
				//check if product is exist or not.
				foreach ( $paid_tickets as $key => $ticket )
				{
					if(isset($ticket['product_id']) &&  $ticket['product_id'] == $post_id ){
						$updated_product = true;
						$paid_tickets[$key] = $temp_ticket;

					}
					
				}
				//if ticket is not found in existing paid ticket array then we have too add new ticket to paid ticket array.
				if(!$updated_product)
					$paid_tickets[] = $temp_ticket;
			}
			else{
				$paid_tickets = array();
				$paid_tickets[] = $temp_ticket;
			}

			//save event id in product and ticket inside event meta key
			update_post_meta($event_id, '_paid_tickets', $paid_tickets );
		}
		
		//free ticket
		if($ticket_type ==  'free'){
			if( !empty($free_tickets) && is_array( $free_tickets )  )
			{
				$updated_product = false;		
				foreach ( $free_tickets as $key => $ticket )
				{
					if(isset($ticket['product_id']) &&  $ticket['product_id'] == $post_id ){
						$updated_product = true;
						$free_tickets[$key] = $temp_ticket;
					}
				}
				if(!$updated_product)
					$free_tickets[] = $temp_ticket;
				
			}
			else{
				$free_tickets = array();
				$free_tickets[] = $temp_ticket;
			}
				
			update_post_meta($event_id, '_free_tickets', $free_tickets );
		}

		//donation ticket
		if($ticket_type ==  'donation'){
			if( !empty($donation_tickets) && is_array( $donation_tickets )  )
			{
				$updated_product = false;
				foreach ( $donation_tickets as $key => $ticket )
				{
					if(isset($ticket['product_id']) &&  $ticket['product_id'] == $post_id ){
						$updated_product = true;
						$donation_tickets[$key] = $temp_ticket;
					}
				}

				if(!$updated_product)
					$donation_tickets[] = $temp_ticket;
			}
			else{
				$donation_tickets = array();
				$donation_tickets[] = $temp_ticket;
			}

			//save event id in product and ticket inside event meta key
			update_post_meta($event_id, '_donation_tickets', $donation_tickets );
		}

		//save product meta keys
		update_post_meta($post_id, '_event_id', $event_id);
	    update_post_meta($post_id, '_ticket_type', esc_attr($ticket_type));
	    update_post_meta($post_id, '_ticket_show_description', esc_attr($show_ticket_description));
	    update_post_meta($post_id, '_ticket_fee_pay_by', esc_attr($ticket_fee_pay_by));
	    update_post_meta($post_id, '_show_remaining_tickets', esc_attr($remaining_tickets));
	    update_post_meta($post_id, '_ticket_sales_start_date', esc_attr($start_dbformatted_date));
	    update_post_meta($post_id, '_ticket_sales_start_time', esc_attr($start_dbformatted_time));
	    update_post_meta($post_id, '_ticket_sales_end_date', esc_attr($end_dbformatted_date));
	    update_post_meta($post_id, '_ticket_sales_end_time', esc_attr($end_dbformatted_time));
	    update_post_meta($post_id, 'minimum_order', esc_attr($minimum_tickets));
	    update_post_meta($post_id, 'maximum_order', esc_attr($maximum_tickets));
	    update_post_meta($post_id, '_ticket_priority', esc_attr($ticket_priority));
	}

	/**
	 * Add filter dropdown at woo order
	 *
	 * @param  
	 * @return 
	 */
	public function restrict_manage_posts(){
		global $typenow,$wpdb;
		if(isset($_GET['post_type']) && $_GET['post_type'] == 'shop_order'){
			?>
			<select name="_event_listing" id="_event_listing" class="">
				<option value=""><?php _e('Select event','wp-event-manager-sell-tickets');?></option>
				<?php
				$events_with_registrations = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'event_listing';" );
				$current                = isset( $_GET['_event_listing'] ) ? $_GET['_event_listing'] : 0;
				foreach ( $events_with_registrations as $event_id ) {
					if ( ( $title = get_the_title( $event_id ) ) && $event_id ) {
						
						if(get_post_status($event_id) == 'publish' || get_post_status($event_id) == 'expired' )
						echo '<option value="' . $event_id . '" ' . selected( $current, $event_id, false ) . '">' . $title . '</option>';
					}
				}
			?>
			</select>
			<?php
		} //end shop_order

	}


	/**
	 * Filters and sorting handler
	 *
	 * @param  WP_Query $query
	 * @return WP_Query
	 */
	public function parse_query( $query ) {
		global $typenow;
		

		if ( 'event_listing' === $typenow ) {
			if ( isset( $_GET['package'] ) ) {
				$query->query_vars['meta_key']   = '_user_package_id';
				$query->query_vars['meta_value'] = absint( $_GET['package'] );
			}
		}

		if ( 'shop_order' === $typenow ) {
			if ( isset( $_GET['_event_listing'] ) && !empty($_GET['_event_listing']) ) {
				$query->query_vars['meta_key']   = '_event_id';
				$query->query_vars['meta_value'] = absint( $_GET['_event_listing'] );
			}
		}



		return $query;
	}
}
WP_Event_Manager_Sell_Tickets_Admin::get_instance();
