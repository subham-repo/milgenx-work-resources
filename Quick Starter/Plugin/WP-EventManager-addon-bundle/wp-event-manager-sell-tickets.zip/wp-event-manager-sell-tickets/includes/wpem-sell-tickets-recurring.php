<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPEM_Sell_Tickets_Recurring
 * This will allow duplicate ticket with recurring event

 */
class WPEM_Sell_Tickets_Recurring {
	/**
	 * Constructor
	 *
	 * @param 
	 */
	public function __construct() {
		//Recurring cron 

		//Recurring with duplicate
		if(get_option('event_manager_duplicate_tickets',true)){
			add_action('event_manager_event_recurring_end',array($this,'wpem_sell_ticket_duplicate_tickets') ,20,2);
			//Delete duplicate ticket with recurring event
			add_action('wpem_before_deleting_recurring_event',array($this,'wpem_sell_ticket_delete_recurring_tickets'),20,2);
		}
	}

	/**
	* wpem_sell_ticket_duplicate_tickets
	* @param 
	* @return  
	* @since 
	*/
	public function wpem_sell_ticket_duplicate_tickets($event_id,$new_event_id){
		//$event = get_post($event_id);
    	$paid_tickets = get_post_meta( $event_id, '_paid_tickets',  true);
    	$free_tickets = get_post_meta( $event_id, '_free_tickets',  true);
    	$donation_tickets = get_post_meta( $event_id, '_donation_tickets', true);

    	//paid ticket foreach and remove the product id
    	 if( !empty($paid_tickets) && is_array( $paid_tickets )  ){ 
	    	foreach ( $paid_tickets as $key => $ticket ){ 
	    		//remove the ticket id from the paid ticket
	    		if(isset($ticket['product_id']))
	    		 $paid_tickets[$key]['product_id'] = '';
	    	}
		}
		update_post_meta($new_event_id, '_paid_tickets',$paid_tickets);
		
		//Free ticket foreach and remove the product id
    	 if( !empty($free_tickets) && is_array( $free_tickets )  ){ 
	    	foreach ( $free_tickets as $key => $ticket ){ 
	    		//remove the ticket id from the paid ticket
	    		if(isset($ticket['product_id']))
	    		 $free_tickets[$key]['product_id'] = '';
	    	}
		}
		update_post_meta($new_event_id, '_free_tickets',$free_tickets);

		//Donation ticket foreach and remove the product id
    	 if( !empty($donation_tickets) && is_array( $donation_tickets )  ){ 
	    	foreach ( $donation_tickets as $key => $ticket ){ 
	    		//remove the ticket id from the paid ticket
	    		if(isset($ticket['product_id']))
	    		 $donation_tickets[$key]['product_id'] = '';
	    	}
		}
		update_post_meta($new_event_id, '_donation_tickets',$donation_tickets);

		/**
		* Call the submit ticket with new event id
		* This will create new tickets inside the recurring event
		*/ 
		if(!empty($new_event_id) && $new_event_id > 0)
			submit_tickets( $new_event_id );

	}

	/**
	* wpem_sell_ticket_delete_recurring_tickets
	* @param 
	* @return  
	* @since 
	*/
	public function wpem_sell_ticket_delete_recurring_tickets($recurring_event_id,$event_id){
		$paid_tickets = get_post_meta( $recurring_event_id, '_paid_tickets',  true);
    	$free_tickets = get_post_meta( $recurring_event_id, '_free_tickets',  true);
    	$donation_tickets = get_post_meta( $recurring_event_id, '_donation_tickets', true);


    	//paid ticket foreach and remove the product id
    	 if( !empty($paid_tickets) && is_array( $paid_tickets )  ){ 
	    	foreach ( $paid_tickets as $key => $ticket ){ 
	    		//remove the ticket from the db
	    		if(isset($ticket['product_id']))
	    		 wp_delete_post($ticket['product_id'],true);
	    	}
		}
		
		//Free ticket foreach and remove the product id
    	 if( !empty($free_tickets) && is_array( $free_tickets )  ){ 
	    	foreach ( $free_tickets as $key => $ticket ){ 
	    		//remove the ticket from the db
	    		if(isset($ticket['product_id']))
	    		 wp_delete_post($ticket['product_id'],true);
	    	}
		}
		
		//Donation ticket foreach and remove the product id
    	 if( !empty($donation_tickets) && is_array( $donation_tickets )  ){ 
	    	foreach ( $donation_tickets as $key => $ticket ){ 
	    		//remove the ticket from the db
	    		if(isset($ticket['product_id']))
	    		 wp_delete_post($ticket['product_id'],true);
	    	}
		}
	}
}
new WPEM_Sell_Tickets_Recurring();
