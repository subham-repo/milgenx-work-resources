<?php
/**
 * REST API Sell Tickets controller
 *
 * Handles requests to the /products endpoint.
 *
 * @since    3.1.14
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}



/**
 * REST API Events controller class.
 *
 * @extends WPEM_REST_Events_Controller
 */
class WPEM_REST_Ticket_Controller  extends WPEM_REST_CRUD_Controller  {

	/**
	 * Endpoint namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'wpem';
	
	/**
	 * Route base.
	 *
	 * @var string
	 */
	protected $rest_base = 'events/(?P<event_id>[\d]+)/tickets';
	
	/**
	 * Post type.
	 *
	 * @var string
	 */
	protected $post_type = 'product';

	/**
	* 
	*/
	public function __construct(){
		add_action( 'rest_api_init', array( $this, 'register_routes' ), 10 );

		//add tickets details on each event
		add_filter( "wpem_rest_get_event_listing_data",array($this,'wpem_sell_tickets_add_data_to_listing'),10,3 );
	}

	/**
	 * Register the routes for event attendees.
	 */
	public function register_routes() {

		register_rest_route(
			$this->namespace, 
				'/' . $this->rest_base, 
				array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
					'args'                => $this->get_collection_params(),
				),
		
				'schema' => array( $this, 'get_public_item_schema' ),
			)
		);

		register_rest_route(
			$this->namespace, 
				'/' . $this->rest_base . '/(?P<id>[\d]+)', array(
				'args'   => array(
					'id' => array(
						'description' => __( 'Unique identifier for the ticket.', 'wp-event-manager-sell-tickets' ),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'context' => $this->get_context_param( array( 'default' => 'view' ) ),
					),
				),
				'schema' => array( $this, 'get_public_item_schema' ),
			)
		);
		

		register_rest_route(
			'wpem', 
				'/events/(?P<event_id>[\d]+)/attendees/(?P<attendee_id>[\d]+)/checkin', array(
				'args'   => array(
					'attendee_id' => array(
						'description' => __( 'Unique identifier for the resource.', 'wp-event-manager-sell-tickets' ),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'checkin_attendee' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
					'args'                => array(
						'force' => array(
							'default'     => false,
							'type'        => 'boolean',
							'description' => __( 'Whether to checkin or undo checkin.', 'wp-event-manager-sell-tickets' ),
						),
						'checkin_source' => array(
							'default'     => 'app',
							'type'        => 'string',
							'description' => __( 'Checkin platform details', 'wp-event-manager-sell-tickets' ),
						),
						'checkin_device_id' => array(
							'default'     => '',
							'type'        => 'string',
							'description' => __( 'Device id', 'wp-event-manager-sell-tickets' ),
						),
						'checkin_device_name' => array(
							'default'     => '',
							'type'        => 'string',
							'description' => __( 'Device name', 'wp-event-manager-sell-tickets' ),
						),
					),
				),
			)
		);


		register_rest_route(
			'wpem', 
				'/events/(?P<event_id>[\d]+)/attendees/(?P<attendee_id>[\d]+)/qrcode', array(
				'args'   => array(),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'qrcode_checkin_attendee' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'code' => array(
							'default'     => '',
							'type'        => 'string',
							'description' => __( 'Qrcode data taken from the ticket.', 'wp-event-manager-sell-tickets' ),
						),
						'checkin_source' => array(
							'default'     => 'app',
							'type'        => 'string',
							'description' => __( 'Checkin platform details', 'wp-event-manager-sell-tickets' ),
						),
						'checkin_device_id' => array(
							'default'     => '',
							'type'        => 'string',
							'description' => __( 'Device id', 'wp-event-manager-sell-tickets' ),
						),
						'checkin_device_name' => array(
							'default'     => '',
							'type'        => 'string',
							'description' => __( 'Device name', 'wp-event-manager-sell-tickets' ),
						),
					),
				),
			)
		);

	}


		/**
	 * Prepare objects query.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @since  3.0.0
	 * @return array
	 */
	protected function prepare_objects_query( $request ) {
		$args = parent::prepare_objects_query( $request );

		// Set post_status.
		$args['post_status'] = $request['status'];

		// Taxonomy query to filter products by type, category,
		// tag, shipping class, and attribute.
		$tax_query = array();

		// Map between taxonomy name and arg's key.
		$taxonomies = array(
			'product_cat'            => 'category',
			'product_tag'            => 'tag',
			'product_shipping_class' => 'shipping_class',
		);

		// Set tax_query for each passed arg.
		foreach ( $taxonomies as $taxonomy => $key ) {
			if ( ! empty( $request[ $key ] ) ) {
				$tax_query[] = array(
					'taxonomy' => $taxonomy,
					'field'    => 'term_id',
					'terms'    => $request[ $key ],
				);
			}
		}

		// Filter product type by slug.
		if ( ! empty( $request['type'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'product_type',
				'field'    => 'slug',
				'terms'    => $request['type'],
			);
		}

		// Filter by attribute and term.
		if ( ! empty( $request['attribute'] ) && ! empty( $request['attribute_term'] ) ) {
			if ( in_array( $request['attribute'], wc_get_attribute_taxonomy_names(), true ) ) {
				$tax_query[] = array(
					'taxonomy' => $request['attribute'],
					'field'    => 'term_id',
					'terms'    => $request['attribute_term'],
				);
			}
		}

		if ( ! empty( $tax_query ) ) {
			$args['tax_query'] = $tax_query; // WPCS: slow query ok.
		}

		// Filter featured.
		if ( is_bool( $request['featured'] ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'product_visibility',
				'field'    => 'name',
				'terms'    => 'featured',
				'operator' => true === $request['featured'] ? 'IN' : 'NOT IN',
			);
		}

		// Filter by sku.
		if ( ! empty( $request['sku'] ) ) {
			$skus = explode( ',', $request['sku'] );
			// Include the current string as a SKU too.
			if ( 1 < count( $skus ) ) {
				$skus[] = $request['sku'];
			}

			$args['meta_query'] = $this->add_meta_query( // WPCS: slow query ok.
				$args,
				array(
					'key'     => '_sku',
					'value'   => $skus,
					'compare' => 'IN',
				)
			);
		}

		// Filter by tax class.
		if ( ! empty( $request['tax_class'] ) ) {
			$args['meta_query'] = $this->add_meta_query( // WPCS: slow query ok.
				$args,
				array(
					'key'   => '_tax_class',
					'value' => 'standard' !== $request['tax_class'] ? $request['tax_class'] : '',
				)
			);
		}

		// Event filter.
		if ( isset($request['event_id']) && ! empty( $request['event_id'] ) ) {
			$args['meta_query'] = $this->add_meta_query( // WPCS: slow query ok.
				$args,
				array(
					'key'   => '_event_id',
					'value' => $request['event_id'],
				)
			);
		}


		// Price filter.
		if ( ! empty( $request['min_price'] ) || ! empty( $request['max_price'] ) ) {
			$args['meta_query'] = $this->add_meta_query( $args, wc_get_min_max_price_meta_query( $request ) );  // WPCS: slow query ok.
		}

		// Filter product in stock or out of stock.
		if ( is_bool( $request['in_stock'] ) ) {
			$args['meta_query'] = $this->add_meta_query( // WPCS: slow query ok.
				$args,
				array(
					'key'   => '_stock_status',
					'value' => true === $request['in_stock'] ? 'instock' : 'outofstock',
				)
			);
		}

		// Filter by on sale products.
		if ( is_bool( $request['on_sale'] ) ) {
			$on_sale_key = $request['on_sale'] ? 'post__in' : 'post__not_in';
			$on_sale_ids = wc_get_product_ids_on_sale();

			// Use 0 when there's no on sale products to avoid return all products.
			$on_sale_ids = empty( $on_sale_ids ) ? array( 0 ) : $on_sale_ids;

			$args[ $on_sale_key ] += $on_sale_ids;
		}

		// Force the post_type argument, since it's not a user input variable.
		if ( ! empty( $request['sku'] ) ) {
			$args['post_type'] = array( 'product', 'product_variation' );
		} else {
			$args['post_type'] = $this->post_type;
		}

		return $args;
	}

	/**
	 * Get object.
	 *
	 * @param int $id Object ID.
	 *
	 * @since  3.0.0
	 * @return WC_Data
	 */
	protected function get_object( $id ) {
		return wc_get_product( $id );
	}

	/**
	 * Prepare a single product output for response.
	 *
	 * @param WC_Data         $object  Object data.
	 * @param WP_REST_Request $request Request object.
	 *
	 * @since  3.0.0
	 * @return WP_REST_Response
	 */
	public function prepare_object_for_response( $object, $request ) {
		$context = ! empty( $request['context'] ) ? $request['context'] : 'view';
		$data    = $this->get_product_data( $object, $context );

		// Add variations to variable products.
		if ( $object->is_type( 'variable' ) && $object->has_child() ) {
			$data['variations'] = $object->get_children();
		}

		// Add grouped products data.
		if ( $object->is_type( 'grouped' ) && $object->has_child() ) {
			$data['grouped_products'] = $object->get_children();
		}

		$data     = $this->add_additional_fields_to_object( $data, $request );
		$data     = $this->filter_response_by_context( $data, $context );
		$response = rest_ensure_response( $data );
		$response->add_links( $this->prepare_links( $object, $request ) );

		/**
		 * Filter the data for a response.
		 *
		 * The dynamic portion of the hook name, $this->post_type,
		 * refers to object type being prepared for the response.
		 *
		 * @param WP_REST_Response $response The response object.
		 * @param WC_Data          $object   Object data.
		 * @param WP_REST_Request  $request  Request object.
		 */
		return apply_filters( "wpem_rest_prepare_{$this->post_type}_object", $response, $object, $request );
	}

	/**
	 * Get product data.
	 *
	 * @param WC_Product $product Product instance.
	 * @param string     $context Request context.
	 *                            Options: 'view' and 'edit'.
	 * @return array
	 */
	protected function get_product_data( $product, $context = 'view' ) {
		$data = array(
			'id'                    => $product->get_id(),
			'name'                  => $product->get_name( $context ),
			'slug'                  => $product->get_slug( $context ),
			'permalink'             => $product->get_permalink(),
			'date_created'          => wc_rest_prepare_date_response( $product->get_date_created( $context ), false ),
			'date_created_gmt'      => wc_rest_prepare_date_response( $product->get_date_created( $context ) ),
			'date_modified'         => wc_rest_prepare_date_response( $product->get_date_modified( $context ), false ),
			'date_modified_gmt'     => wc_rest_prepare_date_response( $product->get_date_modified( $context ) ),
			'type'                  => $product->get_type(),
			'status'                => $product->get_status( $context ),
			'featured'              => $product->is_featured(),
			'catalog_visibility'    => $product->get_catalog_visibility( $context ),
			'description'           => 'view' === $context ? wpautop( do_shortcode( $product->get_description() ) ) : $product->get_description( $context ),
			'short_description'     => 'view' === $context ? apply_filters( 'woocommerce_short_description', $product->get_short_description() ) : $product->get_short_description( $context ),
			'sku'                   => $product->get_sku( $context ),
			'price'                 => $product->get_price( $context ),
			'regular_price'         => $product->get_regular_price( $context ),
			'sale_price'            => $product->get_sale_price( $context ) ? $product->get_sale_price( $context ) : '',
			'date_on_sale_from'     => wc_rest_prepare_date_response( $product->get_date_on_sale_from( $context ), false ),
			'date_on_sale_from_gmt' => wc_rest_prepare_date_response( $product->get_date_on_sale_from( $context ) ),
			'date_on_sale_to'       => wc_rest_prepare_date_response( $product->get_date_on_sale_to( $context ), false ),
			'date_on_sale_to_gmt'   => wc_rest_prepare_date_response( $product->get_date_on_sale_to( $context ) ),
			'price_html'            => $product->get_price_html(),
			'on_sale'               => $product->is_on_sale( $context ),
			'purchasable'           => $product->is_purchasable(),
			'total_sales'           => $product->get_total_sales( $context ),
			'virtual'               => $product->is_virtual(),
	
		
			'tax_class'             => $product->get_tax_class( $context ),
			'manage_stock'          => $product->managing_stock(),
			'stock_quantity'        => $product->get_stock_quantity( $context ),
			'in_stock'              => $product->is_in_stock(),
		
			'sold_individually'     => $product->is_sold_individually(),
			'average_rating'        => 'view' === $context ? wc_format_decimal( $product->get_average_rating(), 2 ) : $product->get_average_rating( $context ),
			'rating_count'          => $product->get_rating_count(),
			'related_ids'           => array_map( 'absint', array_values( wc_get_related_products( $product->get_id() ) ) ),
			'upsell_ids'            => array_map( 'absint', $product->get_upsell_ids( $context ) ),
			'cross_sell_ids'        => array_map( 'absint', $product->get_cross_sell_ids( $context ) ),
			'parent_id'             => $product->get_parent_id( $context ),
			'purchase_note'         => 'view' === $context ? wpautop( do_shortcode( wp_kses_post( $product->get_purchase_note() ) ) ) : $product->get_purchase_note( $context ),
			
			'menu_order'            => $product->get_menu_order( $context ),
			'meta_data'             => $product->get_meta_data(),
		);


		// Replace in_stock with stock_status.
		$pos             = array_search( 'in_stock', array_keys( $data ), true );
		$array_section_1 = array_slice( $data, 0, $pos, true );
		$array_section_2 = array_slice( $data, $pos + 1, null, true );

		return $array_section_1 + array( 'stock_status' => $product->get_stock_status( $context ) ) + $array_section_2;
	}


	/**
	* wpem_sell_tickets_add_data_to_listing
	* 
	* @param $data, $event, $context
	* @since 1.8.8
	*/
	public function wpem_sell_tickets_add_data_to_listing($data, $event, $context){
		$data['sell_tickets'] 	= array();
		$total_sales 			= 0;
		$remaining_tickets 		= 0;
		$total_stock	 		= 0;
		$total_amount 			= 0;

		$tickets = wpem_sell_tickets_get_event_tickets( $event->ID, 'ID', 'ASC' );
		foreach ($tickets as $key => $value) {
		 if(isset($value->ID)){
		 	$ticket_sale 		= (int)get_post_meta($value->ID,'total_sales',true);
		 	$stock_quantity 	= (int)get_post_meta($value->ID,'_stock',true);
		 	$price 				= (int)get_post_meta($value->ID,'_price',true);
		 	$total_stock 		= $total_stock + $stock_quantity + $ticket_sale;
		 	$total_sales 		= $total_sales + $ticket_sale;
		 	$remaining_tickets 	= $remaining_tickets + $stock_quantity ;
		 	$total_amount 		= $total_amount  + ($ticket_sale*$price);
		 	
		 }
		}
		
		//get all tickets and send to the tickets array
		$data['sell_tickets']['tickets'] =  array(
												'total_sales' 		=> $total_sales,
												'remaining_tickets' => $remaining_tickets,
												'total_stock' 		=> $total_stock,
												'total_amount' 		=> get_woocommerce_currency_symbol().$total_amount,
											);

		return $data;
	}

	public function checkin_attendee($request){

		if(isset($request['attendee_id']) &&  $request['force'] ){
			$checkin = get_post_meta($attendee_id,'_check_in',true);
			if($checkin == 1){
				return array('message' => __('Already checkedin.','wp-event-manager-sell-tickets'));
			}

			
			$attendee_id 			= absint($request['attendee_id']);
			$checkin_source 		= isset($request['checkin_source']) ? $request['checkin_source'] : '';
			$checkin_device_id 		= isset($request['checkin_device_id']) ? $request['checkin_device_id'] : '';
			$checkin_device_name 	= isset($request['checkin_device_name']) ? $request['checkin_device_name'] : '';

			update_post_meta($attendee_id,'_check_in',1);
			update_post_meta($attendee_id,'_checkin_source',$checkin_source);
			update_post_meta($attendee_id,'_checkin_device_id',$checkin_device_id);
			update_post_meta($attendee_id,'_checkin_device_name',$checkin_device_name);
			update_post_meta($attendee_id,'_checkin_time',current_time( 'mysql' ));
			return array('message' => __('Checkin successfull','wp-event-manager-sell-tickets'));
		}
		elseif(isset($request['attendee_id']) && isset($request['force']) && $request['force'] == false){
			$attendee_id = absint($request['attendee_id']);
			 update_post_meta($attendee_id,'_check_in',0);
			return array(	'message' => __('Uncheckin successfull','wp-event-manager-sell-tickets')	);
		}
		else
			return array('message' => __('There was some error while checkin','wp-event-manager-sell-tickets') );		
	}


	/**
	 * qrcode_checkin_attendee
	 * 
	 * @since 1.8.8
	 * @param Array 
	 */
	public function qrcode_checkin_attendee($request){

		if(isset($request['attendee_id']) &&  $request['code'] ){

			//check weather code is correct
			$code 					= $request['code'];
			$attendee_id 			= absint($request['attendee_id']);
			$order_id 				= get_post_meta($attendee_id,'_order_id',true);
			$event_id 				= wp_get_post_parent_id( $attendee_id );

			$qrcode					= apply_filters('event_manager_sell_tickets_qrcode', $event_id.'-'.$order_id.'-'.$attendee_id);

			$attendee_name = get_the_title($attendee_id);
			$event_title = get_the_title($event_id);

			$checkin = get_post_meta($attendee_id,'_check_in',true);
			if($checkin == 1){
				return array('message' => __('Already checkedin.','wp-event-manager-sell-tickets') );
			}

			if($qrcode	== $code ){
				$checkin_source 		= isset($request['checkin_source']) ? $request['checkin_source'] : '';
				$checkin_device_id 		= isset($request['checkin_device_id']) ? $request['checkin_device_id'] : '';
				$checkin_device_name 	= isset($request['checkin_device_name']) ? $request['checkin_device_name'] : '';

				update_post_meta($attendee_id,'_check_in',1);
				update_post_meta($attendee_id,'_checkin_source',$checkin_source);
				update_post_meta($attendee_id,'_checkin_device_id',$checkin_device_id);
				update_post_meta($attendee_id,'_checkin_device_name',$checkin_device_name);
				update_post_meta($attendee_id,'_checkin_time',current_time( 'mysql' ));
				
				return array('message' => __('Checkin successfull','wp-event-manager-sell-tickets'),'event_title' =>  $event_title , 'attendee_name' => $attendee_name);
			}
		}
		else
			return array('message' => __('There was some error while checkin','wp-event-manager-sell-tickets') );		
	}
}
new WPEM_REST_Ticket_Controller();
