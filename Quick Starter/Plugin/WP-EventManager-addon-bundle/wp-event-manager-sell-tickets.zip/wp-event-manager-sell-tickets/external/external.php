<?php
/**
 * Load external compatibility tweaks.
 */

//check Elementor Plugin istallation
if ( ! function_exists( '_is_elementor_installed' ) ) {

	function _is_elementor_installed() {
		$file_path = 'elementor/elementor.php';
		$installed_plugins = get_plugins();

		return isset( $installed_plugins[ $file_path ] );
	}
}

if(!function_exists('is_plugin_active')){
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

require_once( 'elementor.php' );




//WPML AND POLYLANG 
if(!function_exists('wpem_get_original_event_id')){

	function wpem_get_original_event_id($event_id)
    {
        // WPML
        if(class_exists('SitePress'))
        {
            $trid = apply_filters('wpml_element_trid', NULL, $event_id, 'post_mec-events');
            $translations = apply_filters('wpml_get_element_translations', NULL, $trid, 'post_mec-events');

            if(!is_array($translations) or (is_array($translations) and !count($translations))) return $event_id;

            $original_id = $event_id;
            foreach($translations as $translation)
            {
                if(isset($translation->original) and $translation->original)
                {
                    $original_id = $translation->element_id;
                    break;
                }
            }

            return $original_id;
        }
        // PolyLang
        elseif(function_exists('pll_default_language'))
        {
            $pll_lang = pll_default_language();

            $translations = pll_get_post_translations($event_id);
            if(!is_array($translations) or (is_array($translations) and !count($translations))) return $event_id;

            if(isset($translations[$pll_lang]) and is_numeric($translations[$pll_lang])) return $translations[$pll_lang];
        }
        else return $event_id;
    }
}
