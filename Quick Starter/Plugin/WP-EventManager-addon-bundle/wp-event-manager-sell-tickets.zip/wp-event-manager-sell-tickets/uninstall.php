<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}


$options = array('wc_settings_fees_enable',
                'wc_settings_fee_value',
                'wc_settings_fee_label',
                'wc_settings_fee_modes',
                'wc_settings_fee_types',
                'fee_settings_rules',
                'event_manager_paid_tickets',
                'event_manager_free_tickets',
                'event_manager_donation_tickets',
                'event_manager_event_registration_addon_form',
                'wpem_sell_tickets_ticket_content',
                'wpem_sell_tickets_ticket_layout',

            );

foreach ( $options as $option ) {
	delete_option( $option );
}

$all_fields = get_option( 'event_manager_form_fields', true );
if(is_array($all_fields)){
	$sell_tickets_fields = array('paid_tickets','free_tickets','donation_tickets');
	foreach ($sell_tickets_fields as $key => $value) {
		if(isset($all_fields['event'][$value]))
			unset($all_fields['event'][$value]);
	}
}
update_option('event_manager_form_fields', $all_fields);
