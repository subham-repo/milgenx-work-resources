=== WP Event Manager - Sell Tickets ===

Contributors: wpeventmanager
Requires at least: 4.1
Tested up to: 5.7
Stable tag: 1.8.14
License: GNU General Public License v3.0

Sell tickets for your events and keep track of them. Sell Tickets addon runs on the most popular eCommerce system - Woo commerce for the WordPress & support many payment gateways.

= Support Policy =

I will happily patch any confirmed bugs with this plugin, however, I will not offer support for:

1. Customisations of this plugin or any plugins it relies upon
2. Conflicts with "premium" themes from ThemeForest and similar marketplaces (due to bad practice and not being readily available to test)
3. CSS Styling (this is customisation work)

If you need help with customisation you will need to find and hire a developer capable of making the changes.

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Changelog ==

= 1.8.14 [ 20th Jul 2021 ]  = 

* Fixed - Multiple pdf ticket issue.
* Fixed - WC order search.
* Fixed - Ticket stock sync with edit field.
* Fixed - Some js and css tweaks.


= 1.8.13 [ 22nd Jun 2021 ]  = 

* Added - Woocommerce subscription.
* Added - Tax settings with woo.
* Fixed - Ticket pdf improvements.
* Fixed - Some js and css tweaks.


= 1.8.12 [ 22nd Apr 2021 ]  = 

* Fixed - Date conflict.
* Fixed - Multiple registration with sell ticket.

= 1.8.11 [ 8th Apr 2021 ]  = 

* Fixed - Qrcode conflict.
* Fixed - Ticket fee value in floating point.


= 1.8.10 [ 8 Dec 2020 ]  = 

* Added - Ticket layout.
* Fixed - Failed Order with registration status.
* Fixed - Dompdf version updated.
* Fixed - Fee settings improved.
* Fixed - Duplicate ticket feature with recurring.


= 1.8.9 [ 8 Dec 2020 ]  = 

* Fixed - Ticket priority improved.
* Fixed - Dashboard design improved.
* Fixed - Ticket snyc with admin improved.
* Fixed - Timezone improved with WPEM settings.
* Fixed - Ticket PDF improved.



= 1.8.8 [ 30th Sep 2020 ]  = 

* Added - Ticket order by priority.
* Fixed - Ticket sync with frontend and backend.
* Fixed - Currency switcher compatiblity.
* Fixed - Fee settings improved.
* Fixed - Ticket sales date must be sync with event start and end date.
* Fixed - Checkin with extra details like source and datetime.
* Fixed - Elementor shortcode improved.
* Fixed - Min and max ticket validation improved.
* Fixed - Show/hide ticket description.
* Fixed - Show event details on order page.


= 1.8.7 = 

* Added - Event description.
* Fixed - Event ticket edit improved.
* Fixed - JS conflict with $ improved.

= 1.8.6 = 

* Fixed - Event title added in admin and frontend order details.
* Fixed - Event title added in Email
* Fixed - Product min and max order issue fixed.


= 1.8.5 = 

* Fixed - Virtual product type added in each new product.
* Fixed - Fee settings improved.
* Fixed - Registration disabled by default with sell ticket.


= 1.8.4 = 

* Fixed - Admin updating ticket issue.
* Fixed - from_name and from_email improved with registration
* Fixed - Some js and css tweaks.


= 1.8.3 = 

* Added - New design responsive structure
* Added - Layout type attribute in events shortcode
* Added - CSS Improved
* Added - All Templates Improved
* Fixed - Minor Bugs


= 1.8.2 = 

* Fixed - Woo event ticket type product issue fixed 
* Added - Elementor compitible Custom widget for shortcode added


= 1.8.1 = 

* Fixed - Each attendee not working properly.
* Fixed - Product total sales is not updating after registration.
* Fixed - if payment failed then do not allow registration entry in db.
* Added - Generate QRCode in ticket pdf

= 1.8 =

* Fixed - js conflict with minified version .

= 1.7 =

* Fixed - sold individually issue fixed.

= 1.6 =

* Fixed - WP Event Manager 3.0 version compatiblity
* Fixed - Template improved with date and time features
* Fixed - custom produt type improved.

= 1.5 =

* Added - PDF ticket attachment and download option
* Added - Custom product type event_ticket
* Fixed - Fee settings moved from each ticket to central fee setting will apply on all ticket


= 1.4 =

* Fixed - field editor compatibility

= 1.3 =

* Fixed - single event ticket block showing time error.


= 1.2 =

* Fixed - table column is fixed if fee is enable or not.
* Fixed - registration fields empty issue.

= 1.1 =

* Fixed - Woocommerce 3.0 Update compatibility errors.
* Fixed - Ticket fee must have to calculate after discounted price.
* Fixed - Apply fee setting on cart according to the admin.
* Fixed - Fee apply by country code not working after change product fee settings to admin fee settings.
* Fixed - Repeatedly adding tickets in event.

= 1.0.0 =
* First release.

