<div class="download action-btn">
	<a href="?action=show_registrations&event_id=<?php echo $event_id;?>&download_ticket=true&order_id=<?php echo $order_id;?>" title="<?php _e( 'Download', 'wp-event-manager-sell-tickets' ); ?>" class="event-ticket-download"><?php _e( 'Download', 'wp-event-manager-sell-tickets' ); ?></a>
</div>