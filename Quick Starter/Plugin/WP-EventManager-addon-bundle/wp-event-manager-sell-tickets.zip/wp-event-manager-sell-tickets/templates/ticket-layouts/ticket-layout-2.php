<div></div>
<!DOCTYPE html>
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <title><?php _e('Event Ticket','wp-event-manager-sell-tickets'); ?></title>
</head>
<body>
   <?php
   $event = get_post($event_id);
   $order = wc_get_order($order_id);
   $registration_id = $registration->ID;
   ?>
   <table width="70%" border="0" align="center" cellpadding="0" cellspacing="0" style="border:3px solid #000;">
      <tr>
         <td width="60%">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding:15px">

               <tr>
                  <td style="padding:15px 10px 10px 5px;;font-family:Arial, Helvetica, sans-serif; font-weight:bold;  font-size:20px; color:#000;"><?php echo $event->post_title; ?></td>
               </tr>
               <tr>
                  <td style="padding:5px;font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#000;"><span style="font-size:12px"><?php _e('Organizer:', 'wp-event-manager-sell-tickets'); ?></span><br><strong><?php echo get_bloginfo('name'); ?></strong></td>
               </tr>
               <tr>
                  <td style="font-family:Arial, Helvetica, sans-serif; font-size:14px; padding:5px; color:#000;"><span style="font-size:12px"><?php _e('Date and Time:', 'wp-event-manager-sell-tickets'); ?></span><br><strong><?php display_event_start_date('', '',  true, $event); ?> / <?php display_event_start_time('', '',  true, $event); ?></td>
               </tr>
               <tr>
                  <td style="padding:5px;font-family:Arial, Helvetica, sans-serif;  font-size:14px; padding:5px; color:#000;"><span style="font-size:12px"><?php _e('Location:', 'wp-event-manager-sell-tickets'); ?></span><br><strong><?php display_event_venue_name('', '', true, $event); ?></strong></td>
               </tr>
               <tr>
                  <td style="padding:5px;font-family:Arial, Helvetica, sans-serif; color:#000;font-size:14px; "><span style="font-size:12px"><?php _e('Order ID:', 'wp-event-manager-sell-tickets'); ?></span><br><strong> #<?php echo $order_id; ?></strong></td>
               </tr>
               <tr>
                  <td style="padding:5px;font-family:Arial, Helvetica, sans-serif; color:#000;font-size:14px; "><span style="font-size:12px"><?php _e('Order By:', 'wp-event-manager-sell-tickets'); ?></span><br><strong><?php echo $registration->post_title; ?></strong></td>
               </tr>
            </table>
         </td>
         <td style="padding: 20px;text-align:center;" width="40%">
            <table border="0" style="text-align:center;" cellpadding="0" cellspacing="0">
               <tr>
                  <td><img src="<?php echo $qrcode_directory_new . '/' . $event_id . '-' . $order_id . '-' . $registration_id; ?>.png" title="Link to Google.com" />
               </tr>
               <tr>
                  <td style="font-family:Arial, Helvetica, sans-serif; font-size:14px; padding:5px;  color:#000;"><span style="font-size:12px"><?php _e('Ticket Name:', 'wp-event-manager-sell-tickets'); ?></span><br><strong><?php echo $product->get_name(); ?> </strong></td>
               </tr>

               <tr>
                  <td style="font-family:Arial, Helvetica, sans-serif; font-size:14px; padding:5px;  color:#000;"><span style="font-size:12px"><?php _e('Ticket Price:', 'wp-event-manager-sell-tickets'); ?></span><br><strong><span style="font-family: DejaVu Sans;"><?php echo $product->get_price_html(); ?></span> <?php _e('PAID', 'wp-event-manager-sell-tickets'); ?></strong></td>
               </tr>
            </table>
         </td>
      </tr>
   </table>
</body>

</html>
<?php
if ($page_break_count == 1) { ?>
   <div style="page-break-before: always;" class="page_break"></div>
<?php $page_break_count++;
} else {
   $page_break_count == 0;
   echo '<br>';
} ?>