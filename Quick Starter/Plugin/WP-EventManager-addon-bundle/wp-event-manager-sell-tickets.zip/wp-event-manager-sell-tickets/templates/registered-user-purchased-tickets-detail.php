<?php if(!empty($tickets_type)) { ?>
<div><?php _e('Ticket Type : ','wp-event-manager-sell-tickets'); _e($tickets_type,'wp-event-manager-sell-tickets');?></div>
<?php 
    }
if(!empty($ticket_price)) { ?>
<div><?php _e('Ticket Price : ','wp-event-manager-sell-tickets'); _e($ticket_price,'wp-event-manager-sell-tickets');?></div>
<?php } 
if(!empty($ticket_names) ) { ?>
<div><?php _e('Ticket Name : ','wp-event-manager-sell-tickets'); echo $ticket_names;?></div>
<?php } ?>
