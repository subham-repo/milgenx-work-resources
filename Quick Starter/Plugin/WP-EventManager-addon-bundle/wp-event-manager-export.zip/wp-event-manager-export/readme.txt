=== WP Event Manager - Export  ===

Contributors: WP Event Manager

Requires at least: 4.1
Tested up to: 5.8
Stable tag: 1.3.3
Copyright: 2021 WP Event Manager
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Generate csv file of all events.

= Support Policy =

I will happily patch any confirmed bugs with this plugin, however, I will not offer support for:

1. Customisations of this plugin or any plugins it relies upon
2. Conflicts with "premium" themes from ThemeForest and similar marketplaces (due to bad practice and not being readily available to test)
3. CSS Styling (this is customisation work)

If you need help with customisation you will need to find and hire a developer or you can hire our developers or team for making the changes.

Hire Us : http://www.wp-eventmanager.com

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Changelog ==

= 1.3.3 [ 23 Aug 2021 ]  =

* Added - Organizer and venue custom field selection.
* Fixed - Event category,type and description field.
* Fixed - Some string,css and js tweaks.


= 1.3.2 =

* Fixed - Author issue in query improved.

= 1.3.1 =

* Added - New design responsive structure
* Added - Layout type attribute in events shortcode
* Added - CSS Improved
* Added - All Templates Improved
* Fixed - Minor Bugs

= 1.3 =
* Fixed  - Update restriction issue fixed.

= 1.2=
* Added  - Admin all event export.

= 1.1=
* Fixed - Admin setting issue.
= 1.0=
* Fixed - Admin settings.

= 1.0=
* First release.
