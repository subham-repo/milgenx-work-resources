<div class="">
<button id="event-export-button" data-modal-id="wpem-export-modal-popup-organizer" class="wpem-theme-button wpem-modal-button"> <?php _e('Download Organizers CSV File','wp-event-manager-export') ?></button>
</div> 

<div id="wpem-export-modal-popup-organizer" class="wpem-modal" role="dialog" aria-labelledby="<?php _e('Organizer Export','wp-event-manager-export');?>">
	<div class="wpem-modal-content-wrapper">
		<div class="wpem-modal-header">
			<div class="wpem-modal-header-title"><h3 class="wpem-modal-header-title-text"><?php _e('Organizer Export','wp-event-manager-export');?></h3></div>
			<div class="wpem-modal-header-close"><a href="javascript:void(0);" class="wpem-modal-close">x</a></div>
		</div>

		<div class="wpem-modal-content">
			<a id="event_csv_default" href="?download_ornagizers_default&user_id=<?php echo get_current_user_id(); ?>" class="wpem-theme-button"><span><i class="wpem-icon-download3"></i> <?php _e( 'Organizer CSV Default', 'wp-event-manager-export' ); ?></span></a>
	 		
	 		<a id="custom_organizer_csv" href="#" class="wpem-theme-button"><span><?php _e( 'Organizer CSV Custom', 'wp-event-manager-export' ); ?> <i class="wpem-icon-arrow-down "></i></span></a>


			<form action="" method="post" class="wpem-form-wrapper" id="custom_organizer_form">
				<div class="wpem-form-group">

				 	<fieldset class="wpem-form-group fieldset-organizer_fields">

						<label for="event_title"><?php _e('Ornagizer Fields','wp-event-manager-export');?><span class="require-field">*</span></label>

						<div class="field">
							<select class="event-manager-select-chosen" id="event_manager_export_organizer_fields" name="event_manager_export_organizer_fields[]" multiple="multiple" required="true">
					 			<?php
					 			foreach($organizer_fields as $form_guoups => $form_fields)
								{
									foreach ($form_fields as $key => $field) 
									{
										if( in_array($key, $default_csv_fields) )
						 				{
						 					echo '<option selected value="'.esc_attr($key).'" >'. $field['label'] . '</option>';	
						 				}
						 				else
						 				{
						 					echo '<option value="'.esc_attr($key).'" >'. $field['label'] . '</option>';
						 				}
									}			
								}
					 			?>
					 		</select>
						</div>
					</fieldset>
				</div>

			 	<div class="wpem-form-footer">
					<button type="submit" id ="download_ornagizers_custom" name="download_ornagizers_custom" value="<?php echo get_current_user_id();?>" class="wpem-theme-button"><i class="wpem-icon-download3"></i> <?php _e( 'Download Custom Csv', 'wp-event-manager-export' ); ?></button>
				</div>
			</form>
			</div>
	</div>

	<a href="javascript:void(0);"><div class="wpem-modal-overlay"></div></a>	

</div>
