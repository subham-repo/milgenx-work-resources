var EventExport= function () {
    /// <summary>Constructor function of the contact to the organizer class.</summary>
    /// <since>1.0.0</since>
    /// <returns type="EventExport" /> 

    return {
	    /// <summary>
        /// Initializes the EventExport.       
        /// </summary>                 
        /// <returns type="initialization settings" />     
        /// <since>1.0.0</since>  
        init: function() 
        {           
              Common.logInfo("EventExport.init...");           
      			  jQuery("#event_csv_custome").click(function(){
        				  jQuery('#custom_events_form').slideToggle("slow");
        				  jQuery(this).toggleClass('wpem-active-button');
        				  
        				jQuery("#event_csv_custome").find('i').toggleClass('wpem-icon-arrow-up').toggleClass('wpem-icon-arrow-down');

                if (jQuery(".event-manager-select-chosen").length > 0)
                {
                    jQuery(".event-manager-select-chosen").chosen();
                }
			       });

              //organizer
              jQuery("#custom_organizer_csv").click(function(){
                  jQuery('#custom_organizer_form').slideToggle("slow");
                  jQuery(this).toggleClass('wpem-active-button');
                  
                jQuery("#custom_organizer_csv").find('i').toggleClass('wpem-icon-arrow-up').toggleClass('wpem-icon-arrow-down');

                if (jQuery(".event-manager-select-chosen").length > 0)
                {
                    jQuery(".event-manager-select-chosen").chosen();
                }
             });

              //venue
              jQuery("#custom_venue_csv").click(function(){
                  jQuery('#custom_venue_form').slideToggle("slow");
                  jQuery(this).toggleClass('wpem-active-button');
                  
                jQuery("#custom_venue_csv").find('i').toggleClass('wpem-icon-arrow-up').toggleClass('wpem-icon-arrow-down');

                if (jQuery(".event-manager-select-chosen").length > 0)
                {
                    jQuery(".event-manager-select-chosen").chosen();
                }
             });
			  
		},
	
	     actions:
         {} //end of the actions       

    } //end of the return
};

EventExport= EventExport();
jQuery(document).ready(function($) 
{
   EventExport.init();  
});
