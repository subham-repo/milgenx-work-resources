<?php
/*
Plugin Name: WP Event Manager - Export
Plugin URI: http://www.wp-eventmanager.com/
Description: Generate csv file of all events.

Author: WP Event Manager
Author URI: http://www.wp-eventmanager.com/
Text Domain: wp-event-manager-export
Domain Path: /languages
Version: 1.3.3
Since: 1.0

Requires WordPress Version at least: 4.1

Copyright: 2017 WP Event Manager
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) )
    exit;
	
if ( ! class_exists( 'WPEM_Updater' ) ) {
	include( 'autoupdater/wpem-updater.php' );
}
include_once(ABSPATH.'wp-admin/includes/plugin.php');

function pre_check_before_installing_export() 
{
    /*
    * Check weather WP Event Manager is installed or not
    */
    if ( !is_plugin_active( 'wp-event-manager/wp-event-manager.php' ) ) 
    {
            global $pagenow;
        	if( $pagenow == 'plugins.php' )
        	{
                echo '<div id="error" class="error notice is-dismissible"><p>';
                echo __( 'WP Event Manager is require to use WP Event Manager - Export' , 'wp-event-manager-export');
                echo '</p></div>';		
        	}          		
    }
}
add_action( 'admin_notices', 'pre_check_before_installing_export' );	

/**
 * WP_Event_Manager_Bookmarks class.
 */
class WP_Event_Manager_Export extends WPEM_Updater {

	/**
	 * Constructor
	 */
	public function __construct() {

		//if wp event manager not active return from the plugin
		if (! is_plugin_active('wp-event-manager/wp-event-manager.php') )
			return;
		
		// Define constants
		define( 'EVENT_MANAGER_EXPORT_VERSION', '1.3.3' );
		define( 'EVENT_MANAGER_EXPORT_PLUGIN_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
		define( 'EVENT_MANAGER_EXPORT_PLUGIN_URL', untrailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) ) );
		
		// Add actions
		add_action( 'init', array( $this, 'load_plugin_textdomain' ) );

		//add_action('event_manager_event_dashboard_before',array($this,'add_event_download_link') );
		//add_action('event_manager_organizer_dashboard_before',array($this,'add_organizer_download_link') );
		//add_action('event_manager_venue_dashboard_before',array($this,'add_venue_download_link') );

		add_filter( 'wpem_dashboard_menu', array($this,'wpem_dashboard_menu_add') );
		add_action( 'event_manager_event_dashboard_content_wpem_exports', array($this,'wpem_exports_link') );

		add_action( 'wp_loaded', array( $this, 'csv_handler' ) );		
		add_action( 'in_admin_footer',array($this, 'admin_export_setting_js') );
		add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
		
		//include
		include('admin/wpem-export-settings.php');
		include('admin/wpem-export-writepanels.php');
		
		// Init updates
		$this->init_updates( __FILE__ );
	}
	
	/**
	 * Localisation
	 */
	public function load_plugin_textdomain() {
		$domain = 'wp-event-manager-export';       
        $locale = apply_filters('plugin_locale', get_locale(), $domain);
		load_textdomain( $domain, WP_LANG_DIR . "/wp-event-manager-export/".$domain."-" .$locale. ".mo" );
		load_plugin_textdomain($domain, false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}
	
	
	/**
	 * frontend_scripts function.
	 *
	 * @access public
	 * @return void
	 */
	public function frontend_scripts() {   
	    
	    wp_register_style( 'wp-event-manager-export-frontend', EVENT_MANAGER_EXPORT_PLUGIN_URL.'/assets/css/frontend.css');
	    wp_enqueue_style( 'wp-event-manager-export-frontend');

	    wp_register_style( 'chosen', EVENT_MANAGER_PLUGIN_URL . '/assets/css/chosen.css' );
	    wp_register_script( 'chosen', EVENT_MANAGER_PLUGIN_URL . '/assets/js/jquery-chosen/chosen.jquery.min.js', array( 'jquery' ), '1.1.0', true );

		wp_register_script('event-export-min-js',EVENT_MANAGER_EXPORT_PLUGIN_URL . '/assets/js/export.min.js', array('jquery'), EVENT_MANAGER_EXPORT_VERSION, true ); 		
	}

	/**
	 * add dashboard menu function.
	 *
	 * @access public
	 * @return void
	 */
	public function wpem_dashboard_menu_add($menus) 
	{
		$menus['wpem_exports'] = [
						'title' => __('Exports', 'wp-event-manager-export'),
						'icon' => 'wpem-icon-download3',
						'query_arg' => ['action' => 'wpem_exports'],
					];

		return $menus;
	}

	/**
	 * Export Event and Other Data
	 */
	public function wpem_exports_link(){
	    
    	wp_enqueue_style('chosen');

    	wp_enqueue_script('chosen');
		wp_enqueue_script('event-export-min-js');

		/* For Event */
		$default_csv_fields = [
			'event_title',
			'event_description',
			'event_location',
			'event_start_date',
			'event_end_date',
			'view_count',
		];
		$default_csv_fields = apply_filters('event_manager_export_event_default_fields', $default_csv_fields);

		$GLOBALS['event_manager']->forms->get_form( 'submit-event', array() );
		$form_submit_event_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Event', 'instance' ) );
		$event_form_fields = $form_submit_event_instance->merge_with_custom_fields('frontend');
		$event_form_fields = apply_filters('event_manager_export_event_form_fields', $event_form_fields);

		get_event_manager_template( 'event-export.php',array('event_fields' => $event_form_fields, 'default_csv_fields' => $default_csv_fields),'wp-event-manager-export',EVENT_MANAGER_EXPORT_PLUGIN_DIR . '/templates/' );


		/* For Organizer */
		$default_csv_fields = [
			'organizer_name',
			'organizer_logo',
			'organizer_description',
			'organizer_email',
			'organizer_website',
		];
		$default_csv_fields = apply_filters('event_manager_export_organizer_default_fields', $default_csv_fields);

		$GLOBALS['event_manager']->forms->get_form( 'submit-organizer', array() );
		$form_submit_organizer_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Organizer', 'instance' ) );
		$organizer_form_fields = $form_submit_organizer_instance->merge_with_custom_fields('frontend');
		$organizer_form_fields = apply_filters('event_manager_export_organizer_form_fields', $organizer_form_fields);

		get_event_manager_template( 'organizer-export.php',array('organizer_fields' => $organizer_form_fields, 'default_csv_fields' => $default_csv_fields),'wp-event-manager-export',EVENT_MANAGER_EXPORT_PLUGIN_DIR . '/templates/' );


		/* For Venue */
		$default_csv_fields = [
			'venue_name',
			'venue_description',
			'venue_logo',
			'venue_website',
		];
		$default_csv_fields = apply_filters('event_manager_export_venue_form_fields', $default_csv_fields);

		$GLOBALS['event_manager']->forms->get_form( 'submit-venue', array() );
		$form_submit_venue_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Venue', 'instance' ) );
		$venue_form_fields = $form_submit_venue_instance->merge_with_custom_fields('frontend');
		$venue_form_fields = apply_filters('event_manager_export_venue_form_fields', $venue_form_fields);

		get_event_manager_template( 'venue-export.php',array('venue_fields' => $venue_form_fields, 'default_csv_fields' => $default_csv_fields),'wp-event-manager-export',EVENT_MANAGER_EXPORT_PLUGIN_DIR . '/templates/' );
	}
	
	/**
	 * Add event download link
	 */
	public function add_event_download_link(){
	    
    	ob_start();

    	wp_enqueue_style('chosen');

    	wp_enqueue_script('chosen');
		wp_enqueue_script('event-export-min-js');

		$default_csv_fields = [
			'event_title',
			'event_description',
			'event_location',
			'event_start_date',
			'event_end_date',
			'view_count',
		];
		$default_csv_fields = apply_filters('event_manager_export_event_default_fields', $default_csv_fields);

		$GLOBALS['event_manager']->forms->get_form( 'submit-event', array() );
		$form_submit_event_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Event', 'instance' ) );
		$event_form_fields = $form_submit_event_instance->merge_with_custom_fields('frontend');
		$event_form_fields = apply_filters('event_manager_export_event_form_fields', $event_form_fields);

		get_event_manager_template( 'event-export.php',array('event_fields' => $event_form_fields, 'default_csv_fields' => $default_csv_fields),'wp-event-manager-export',EVENT_MANAGER_EXPORT_PLUGIN_DIR . '/templates/' );
	}

	/**
	 * Add organizer download link
	 */
	public function add_organizer_download_link(){
	    
    	ob_start();

    	wp_enqueue_style('chosen');

    	wp_enqueue_script('chosen');
		wp_enqueue_script('event-export-min-js');

		$default_csv_fields = [
			'organizer_name',
			'organizer_logo',
			'organizer_description',
			'organizer_email',
			'organizer_website',
		];
		$default_csv_fields = apply_filters('event_manager_export_organizer_default_fields', $default_csv_fields);

		$GLOBALS['event_manager']->forms->get_form( 'submit-organizer', array() );
		$form_submit_organizer_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Organizer', 'instance' ) );
		$organizer_form_fields = $form_submit_organizer_instance->merge_with_custom_fields('frontend');
		$organizer_form_fields = apply_filters('event_manager_export_organizer_form_fields', $organizer_form_fields);

		get_event_manager_template( 'organizer-export.php',array('organizer_fields' => $organizer_form_fields, 'default_csv_fields' => $default_csv_fields),'wp-event-manager-export',EVENT_MANAGER_EXPORT_PLUGIN_DIR . '/templates/' );
	}

	/**
	 * Add venue download link
	 */
	public function add_venue_download_link(){
	    
    	ob_start();

    	wp_enqueue_style('chosen');

    	wp_enqueue_script('chosen');
		wp_enqueue_script('event-export-min-js');

		$default_csv_fields = [
			'venue_name',
			'venue_description',
			'venue_logo',
			'venue_website',
		];
		$default_csv_fields = apply_filters('event_manager_export_venue_form_fields', $default_csv_fields);

		$GLOBALS['event_manager']->forms->get_form( 'submit-venue', array() );
		$form_submit_venue_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Venue', 'instance' ) );
		$venue_form_fields = $form_submit_venue_instance->merge_with_custom_fields('frontend');
		$venue_form_fields = apply_filters('event_manager_export_venue_form_fields', $venue_form_fields);

		get_event_manager_template( 'venue-export.php',array('venue_fields' => $venue_form_fields, 'default_csv_fields' => $default_csv_fields),'wp-event-manager-export',EVENT_MANAGER_EXPORT_PLUGIN_DIR . '/templates/' );
	}
	
    /**
     * Download a CSV
     * This function genrate CSV file.
     * This will write content from the database in to csv file.
     * All the event will added in to csv file
     * There is two type of csv file one is with meta key and value.
     * Second is Custom value is selected from the admin panel export tab.
     */
	 public function csv_handler() { 

	 	if (  isset($_GET['download_events_default']) ) 
		{
			$auther_id = $_GET['user_id'];	
			
			$events = $this->get_event_posts('event_listing', $auther_id ); 
				
			 foreach ( $events as $event ) {
				$custom_fields =  array_keys( get_post_custom( $event->ID ) );
			 }
			
			 $custom_fields = array_unique( $custom_fields );
			 foreach ( $custom_fields as $custom_field ) {
				$row[] = $custom_field;
			 }
			$this->csv_generate('events', $row, $events, $custom_fields);
			
		}
		else if (isset($_POST['download_events_custom']))
		{
			$auther_id = $_POST['download_events_custom'];	
			$events = $this->get_event_posts('event_listing', $auther_id );

			// custom fields
			$custom_fields = array();
			$row_heading = array();

			$GLOBALS['event_manager']->forms->get_form( 'submit-event', array() );
			$form_submit_event_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Event', 'instance' ) );
			$event_form_fields =	$form_submit_event_instance->merge_with_custom_fields('frontend');

			if( !empty($_POST['event_manager_export_event_fields']) )
			{
				foreach ($_POST['event_manager_export_event_fields'] as $key => $field) 
				{
					if(isset($event_form_fields['event'][$field]['label']))
					{
						$row_heading[] = $event_form_fields['event'][$field]['label'];	
					}
					else
					{
						$row_heading[] = $field;	
					}
					
					$custom_fields[] = '_'.$field;
				}
			}
			 
		 	$row = array_map( __CLASS__ . '::wrap_column', $row_heading );
		 	$this->csv_generate('events', $row, $events, $custom_fields);
		}
		else if ( isset($_GET['download_ornagizers_default']) )
		{
			$auther_id = $_GET['user_id'];	
			
			$ornagizers = $this->get_event_posts('event_organizer', $auther_id ); 
				
			 foreach ( $ornagizers as $ornagizer ) {
				$custom_fields =  array_keys( get_post_custom( $ornagizer->ID ) );
			 }
			
			 $custom_fields = array_unique( $custom_fields );
			 foreach ( $custom_fields as $custom_field ) {
				$row[] = $custom_field;
			 }
			$this->csv_generate('organizers', $row, $ornagizers, $custom_fields);			
		}
		else if (isset($_POST['download_ornagizers_custom']))
		{
			$auther_id = $_POST['download_ornagizers_custom'];	
			$ornagizers = $this->get_event_posts('event_organizer', $auther_id );

			// custom fields
			$custom_fields = array();
			$row_heading = array();

			$GLOBALS['event_manager']->forms->get_form( 'submit-organizer', array() );
			$form_submit_organizer_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Organizer', 'instance' ) );
			$organizer_form_fields =	$form_submit_organizer_instance->merge_with_custom_fields('frontend');

			if( !empty($_POST['event_manager_export_organizer_fields']) )
			{
				foreach ($_POST['event_manager_export_organizer_fields'] as $key => $field) 
				{
					if(isset($organizer_form_fields['organizer'][$field]['label']))
					{
						$row_heading[] = $organizer_form_fields['organizer'][$field]['label'];	
					}
					else
					{
						$row_heading[] = $field;	
					}
					
					$custom_fields[] = '_'.$field;
				}
			}
			 
		 	$row = array_map( __CLASS__ . '::wrap_column', $row_heading );
		 	$this->csv_generate('organizers', $row, $ornagizers, $custom_fields);
		}
		else if ( isset($_GET['download_venues_default']) )
		{
			$auther_id = $_GET['user_id'];	
			
			$ornagizers = $this->get_event_posts('event_venue', $auther_id ); 
				
			 foreach ( $ornagizers as $ornagizer ) {
				$custom_fields =  array_keys( get_post_custom( $ornagizer->ID ) );
			 }
			
			 $custom_fields = array_unique( $custom_fields );
			 foreach ( $custom_fields as $custom_field ) {
				$row[] = $custom_field;
			 }
			$this->csv_generate('venues', $row, $ornagizers, $custom_fields);			
		}
		else if (isset($_POST['download_venues_custom']))
		{
			$auther_id = $_POST['download_venues_custom'];	
			$venues = $this->get_event_posts('event_venue', $auther_id );

			// custom fields
			$custom_fields = array();
			$row_heading = array();

			$GLOBALS['event_manager']->forms->get_form( 'submit-venue', array() );
			$form_submit_venue_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Venue', 'instance' ) );
			$venue_form_fields =	$form_submit_venue_instance->merge_with_custom_fields('frontend');

			if( !empty($_POST['event_manager_export_venue_fields']) )
			{
				foreach ($_POST['event_manager_export_venue_fields'] as $key => $field) 
				{
					if(isset($venue_form_fields['venue'][$field]['label']))
					{
						$row_heading[] = $venue_form_fields['venue'][$field]['label'];	
					}
					else
					{
						$row_heading[] = $field;	
					}
					
					$custom_fields[] = '_'.$field;
				}
			}
			 
		 	$row = array_map( __CLASS__ . '::wrap_column', $row_heading );
		 	$this->csv_generate('venues', $row, $venues, $custom_fields);
		}



		if(is_admin() && isset( $_GET['exportAllEvents'] ) && $_GET['exportAllEvents'] == true )
		{
			$row = [];
			$custom_fields = [];
			
			$events = $this->get_event_posts('event_listing');

			$export_type = get_option('event_manager_export_type');

			if($export_type === 'event_csv_custome')
			{
				$GLOBALS['event_manager']->forms->get_form( 'submit-event', array() );
				$form_submit_event_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Event', 'instance' ) );
				$event_form_fields =	$form_submit_event_instance->merge_with_custom_fields('frontend');
				$event_form_fields = apply_filters('event_manager_export_event_form_fields', $event_form_fields);

				$export_event_fields = get_option('event_manager_export_event_fields');

				if( !empty($export_event_fields) )
				{
					foreach ($export_event_fields as $key => $field) 
					{
						$field = ltrim($field, '_');

						if(isset($event_form_fields['event'][$field]['label']))
						{
							$row[] = $event_form_fields['event'][$field]['label'];	
						}
						else
						{
							$row[] = $field;	
						}
						
						$custom_fields[] = '_'.$field;
					}
				}
			}
			else
			{
				foreach ( $events as $event ) {
					$custom_fields =  array_keys( get_post_custom( $event->ID ) );
				}
				
				$custom_fields = array_unique( $custom_fields );
				foreach ( $custom_fields as $custom_field ) {
					$row[] = $custom_field;
				}	
			}
			$row   = array_map( __CLASS__ . '::wrap_column', $row );
			$this->csv_generate('events', $row, $events, $custom_fields);
		}
		else if(is_admin() && isset( $_GET['exportAllOrganizers'] ) && $_GET['exportAllOrganizers'] == true )
		{
			$row = [];
			$custom_fields = [];
			
			$organizers = $this->get_event_posts('event_organizer');

			$export_type = get_option('event_manager_export_type');

			if($export_type === 'event_csv_custome')
			{
				$GLOBALS['event_manager']->forms->get_form( 'submit-organizer', array() );
				$form_submit_organizer_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Organizer', 'instance' ) );
				$organizer_form_fields = $form_submit_organizer_instance->merge_with_custom_fields('frontend');
				$organizer_form_fields = apply_filters('event_manager_export_organizer_form_fields', $organizer_form_fields);

				$export_organizer_fields = get_option('event_manager_export_organizer_fields');

				if( !empty($export_organizer_fields) )
				{
					foreach ($export_organizer_fields as $key => $field) 
					{
						$field = ltrim($field, '_');

						if(isset($organizer_form_fields['organizer'][$field]['label']))
						{
							$row[] = $organizer_form_fields['organizer'][$field]['label'];	
						}
						else
						{
							$row[] = $field;	
						}
						
						$custom_fields[] = '_'.$field;
					}
				}
			}
			else
			{
				foreach ( $organizers as $organizer ) {
					$custom_fields =  array_keys( get_post_custom( $organizer->ID ) );
				}
				
				$custom_fields = array_unique( $custom_fields );
				foreach ( $custom_fields as $custom_field ) {
					$row[] = $custom_field;
				}	
			}
			
			$this->csv_generate('organizers', $row, $organizers, $custom_fields);
		}
		else if(is_admin() && isset( $_GET['exportAllVenues'] ) && $_GET['exportAllVenues'] == true )
		{
			$row = [];
			$custom_fields = [];
			
			$venues = $this->get_event_posts('event_venue');

			$export_type = get_option('event_manager_export_type');

			if($export_type === 'event_csv_custome')
			{
				// venue fields
				$GLOBALS['event_manager']->forms->get_form( 'submit-venue', array() );
				$form_submit_venue_instance = call_user_func( array( 'WP_Event_Manager_Form_Submit_Venue', 'instance' ) );
				$venue_form_fields = $form_submit_venue_instance->merge_with_custom_fields('frontend');
				$venue_form_fields = apply_filters('event_manager_export_venue_form_fields', $venue_form_fields);

				$export_venue_fields = get_option('event_manager_export_venue_fields');

				if( !empty($export_venue_fields) )
				{
					foreach ($export_venue_fields as $key => $field) 
					{
						$field = ltrim($field, '_');

						if(isset($venue_form_fields['venue'][$field]['label']))
						{
							$row[] = $venue_form_fields['venue'][$field]['label'];	
						}
						else
						{
							$row[] = $field;	
						}
						
						$custom_fields[] = '_'.$field;
					}
				}
			}
			else
			{
				foreach ( $venues as $venue ) {
					$custom_fields =  array_keys( get_post_custom( $venue->ID ) );
				}
				
				$custom_fields = array_unique( $custom_fields );
				foreach ( $custom_fields as $custom_field ) {
					$row[] = $custom_field;
				}	
			}
			
			$this->csv_generate('venues', $row, $venues, $custom_fields);
		}

	}

	/**
	 * Get all events by user id.
	 * @return $events
	 */
	 public function get_event_posts($post_type = 'event_listing', $auther_id = '') {

			$args = array(
						'post_type'         => $post_type,
			            'post_status'       =>  array('publish', 'draft', 'expired') ,
						'posts_per_page'	=> -1,
					) ;

			if( !empty($auther_id) )
			{
				$args['author__in'] = array($auther_id);
			}

			$events = get_posts( $args );

			return $events;
	 }
	 
	 /**
	 * Create csv file and put data in to the csv file.
	 */
	  public function csv_generate($file_name='events', $row = [], $events = [], $custom_fields = []) {
	
			@set_time_limit(0);
			if ( function_exists( 'apache_setenv' ) ) {
				@apache_setenv( 'no-gzip', 1 );
			}
			@ini_set('zlib.output_compression', 0);
			//@ob_clean();

			header( 'Content-Type: text/csv; charset=UTF-8' );
			header( 'Content-Disposition: attachment; filename=' . $file_name . '.csv' );
			header( 'Pragma: no-cache' );
			header( 'Expires: 0' );
	
			$fp  = fopen('php://output', 'w');
			
			fwrite( $fp, implode( ',', $row ) . "\n" );
	  
			foreach ( $events as $event ) {
				$row   = array();
				foreach ( $custom_fields as $custom_field ) {
					if($custom_field == '_event_title'){
						$row[] = $event->post_title;
					}
					elseif($custom_field == '_event_description'){
						$row[] = $event->post_content;
					}
					elseif($custom_field =='_event_category'){
						$categories = get_the_terms( $event->ID, 'event_listing_category' );
						$cat = [];
						if(isset($categories) && !empty($categories))
							foreach ( $categories as $term ) {
							        $cat[] = $term->name;
							}
						$row[] = $cat;
					}
					elseif($custom_field =='_event_type'){
						$categories = get_the_terms( $event->ID, 'event_listing_type' );
						$cat = [];
						if(isset($categories) && !empty($categories))
							foreach ( $categories as $term ) {
							        $cat[] = $term->name;
							}
						$row[] = $cat;

					}

					elseif($custom_field =='_organizer_logo' || $custom_field =='_venue_logo' ){
						
						$row[] = get_the_post_thumbnail_url($event->ID,'full'); ;

					}
					else{
						$row[] = get_post_meta( $event->ID, $custom_field, true );
					}
				}				
				$row   = array_map( __CLASS__ . '::wrap_column', $row );
				fwrite( $fp, implode( ',', $row ) . "\n" );
			}
			fclose( $fp );
			exit;
	  }
	
	/**
	 * Wrap a column in quotes for the CSV
	 * @param  string data to wrap
	 * @return string wrapped data
	 */
	public static function wrap_column( $data ) {
		$data = is_array( $data ) ? json_encode( $data ) : $data;
		return '"' . str_replace( '"', '""', $data ) . '"';
	}
	
    /**
	* Admin script for hide and show event export tab setting fields.
	*/
	public function admin_export_setting_js(){
		echo '<script>
		jQuery("#settings-event_export").find("tr").not("#setting-event_manager_export_type").hide();
		jQuery("#settings-event_export").find("tr:first").show();
		var export_type = jQuery("#setting-event_manager_export_type").val();
		if ( export_type == "event_csv_custome" ) {
				jQuery("#settings-event_export").find("tr").show();
			}
		jQuery("#setting-event_manager_export_type").change(function(){
			var option_export = jQuery(this).val();
			if ( option_export == "event_csv_custome" ) {
				jQuery("#settings-event_export").find("tr").show();	 
				
				jQuery("select").chosen("destroy")
				jQuery("select[data-multiple=\'multiple\']").chosen();
			}
			else{
			  jQuery("#settings-event_export").find("tr").not("#setting-event_manager_export_type").hide();
			  jQuery("#settings-event_export").find("tr:first").show();
			}
		});
		</script>';
	}

}
$GLOBALS['event_manager_export'] =  new WP_Event_Manager_Export();
