<?php
/*
* This file is use to create a shortcode of gam event manager bookmarks plugin. 
* Attendees/User can bookmark events and organizer can bookmark attendees/user using the shortcode [event_manager_my_bookmarks]. Only logged in users can bookmarks.
*/
?>
<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * WP_Event_Manager_Bookmarks_Shortcodes class.
 */
class WP_Event_Manager_Bookmarks_Shortcodes {	

	/**
	 * Constructor
	 */
	public function __construct() {			
			
		add_shortcode( 'event_manager_my_bookmarks', array( $this, 'event_manager_my_bookmarks' ) );  
        		
	}
    
    /**
	 * User bookmarks shortcode
	 */
	public function event_manager_my_bookmarks() 
    {
		if ( ! is_user_logged_in() ) {
			return __( 'You need to be signed in to manage your bookmarks.', 'wp-event-manager-bookmarks' );
		}

		ob_start();

		wp_enqueue_script( 'wp-event-manager-bookmarks-bookmark' );

		$bookmarks = $this->get_user_bookmarks();

		get_event_manager_template( 'my-bookmarks.php', array(
			'bookmarks'     => $bookmarks
		), 'wp-event-manager-bookmarks', EVENT_MANAGER_BOOKMARKS_PLUGIN_DIR . '/templates/' );

		return ob_get_clean();
	}
	
	   /**
	 * Get a user's bookmarks
	 * @param  integer $user_id
	 * @return array
	 */
	public function get_user_bookmarks( $user_id = 0 ) {
		if ( ! $user_id && is_user_logged_in() ) {
			$user_id = get_current_user_id();
		} elseif ( ! $user_id ) {
			return false;
		}

		global $wpdb;

		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}event_manager_bookmarks WHERE user_id = %d ORDER BY date_created;", $user_id ) );
	}


}
new WP_Event_Manager_Bookmarks_Shortcodes();