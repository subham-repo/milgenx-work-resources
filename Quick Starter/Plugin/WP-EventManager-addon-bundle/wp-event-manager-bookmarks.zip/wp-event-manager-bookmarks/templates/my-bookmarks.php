<div id="event-manager-bookmarks">
	<table class="wpem-main wpem-responsive-table-wrapper event-manager-bookmarks table table-bordered event-manager-events table-striped">
		<thead>
			<tr>
				<th class="wpem-heading-text"><?php _e( 'Bookmark', 'wp-event-manager-bookmarks' ); ?></th>
				<th class="wpem-heading-text"><?php _e( 'Notes', 'wp-event-manager-bookmarks' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php 
			foreach ( $bookmarks as $bookmark ) : 
				if ( get_post_status( $bookmark->post_id ) !== 'publish' ) {
					continue;
				}
				$has_bookmark = true;
				?>
				<tr>
					<td width="50%">
						<?php echo '<a href="' . get_permalink( $bookmark->post_id ) . '">' . get_the_title( $bookmark->post_id ) . '</a>'; ?>
						<ul class="event-manager-bookmark-actions">
							<?php
								$actions = apply_filters( 'event_manager_bookmark_actions', array(
									'delete' => array(
										'label' => __( 'Delete', 'wp-event-manager-bookmarks' ),
										'url'   =>  wp_nonce_url( add_query_arg( 'remove_bookmark', $bookmark->post_id ), 'remove_bookmark' )
									)
								), $bookmark );

								foreach ( $actions as $action => $value ) {
									echo '<li><a href="' . esc_url( $value['url'] ) . '" class="event-manager-bookmark-action-' . $action . '">' . $value['label'] . '</a></li>';
								}
							?>
						</ul>
					</td>
					<td width="50%">
						<?php echo wpautop( wp_kses_post( $bookmark->bookmark_note ) ); ?>
					</td>
				</tr>
			<?php endforeach; ?> 

			<?php if ( empty( $has_bookmark ) ) : ?>
				<tr>
					<td colspan="2"><?php _e( 'You currently have no bookmarks', 'wp-event-manager-bookmarks' ); ?></td>
				</tr>
			<?php endif; ?>
		</tbody>
	</table>
</div>