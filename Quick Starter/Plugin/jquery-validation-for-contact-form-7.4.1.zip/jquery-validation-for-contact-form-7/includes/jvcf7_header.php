<div class="wrap">
<h2>Jquery Validation For Contact Form 7</h2>
<table width="100%">
	<tr>
    	<td valign="top">
            