<?php
namespace Ari\Views;

defined( 'ABSPATH' ) or die( 'Access forbidden!' );

use Ari\Utils\Options as Options;

class View_Options extends Options {
    public $domain = '';
}
