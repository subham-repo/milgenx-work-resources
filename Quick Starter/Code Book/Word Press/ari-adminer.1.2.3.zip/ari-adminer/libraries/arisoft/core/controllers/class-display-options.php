<?php
namespace Ari\Controllers;

defined( 'ABSPATH' ) or die( 'Access forbidden!' );

class Display_Options extends Controller_Options {
    public $view_path = '';
}
