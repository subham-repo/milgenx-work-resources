<?php
defined( 'ABSPATH' ) or die( 'Access forbidden!' );

define( 'ARIADMINER_VERSION', '1.2.3' );
define( 'ARIADMINER_SLUG', 'ari-adminer' );
define( 'ARIADMINER_ASSETS_URL', ARIADMINER_URL . 'assets/' );
define( 'ARIADMINER_VERSION_OPTION', 'ari_adminer' );
define( 'ARIADMINER_DEFAULT_CONN_OPTION', 'ari_adminer_default_conn' );
define( 'ARIADMINER_INSTALL_PATH', ARIADMINER_PATH . 'install/' );
define( 'ARIADMINER_CAPABILITY_RUN', 'run_adminer' );

define( 'ARIADMINER_CONFIG_PATH', WP_CONTENT_DIR . '/ari-adminer-config.php' );
define( 'ARIADMINER_CONFIG_TMPL', "<?php\r\ndefined( 'ABSPATH' ) or die( 'Access forbidden!' );\r\ndefine( 'ARIADMINER_CRYPT_KEY', '%1\$s' );" );

define( 'ARIADMINER_THEMES_PATH', ARIADMINER_PATH . 'assets/themes/' );
define( 'ARIADMINER_THEMES_URL', ARIADMINER_URL . 'assets/themes/' );
define( 'ARIADMINER_THEME_DEFAULT', 'flat' );

define( 'ARIADMINER_MESSAGETYPE_SUCCESS', 'success' );
define( 'ARIADMINER_MESSAGETYPE_NOTICE', 'notice' );
define( 'ARIADMINER_MESSAGETYPE_ERROR', 'error' );
define( 'ARIADMINER_MESSAGETYPE_WARNING', 'warning' );

define( 'ARIADMINER_NONCE', 'ariadminer' );
define( 'ARIADMINER_RUN_NONCE', 'ariadminer_run' );
