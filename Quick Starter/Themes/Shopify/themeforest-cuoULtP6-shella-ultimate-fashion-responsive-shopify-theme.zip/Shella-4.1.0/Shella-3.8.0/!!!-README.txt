
===>>> How to install theme

Check this video for more details - https://www.youtube.com/watch?v=Rt1Frbom8bw



===>>> FAQ

Q) Logo doesn't changed.
A) Untick "SVG logo" at Sections -> Header

Q) How to disable "gear" popup at the right?
A) Theme settings -> Layout -> Enable presentation.

Other FAQ - https://mpithemes.ticksy.com/article/14827



===>>> How to update theme and save theme settings.

1) Upload new theme version as unpublished theme.
2) Copy current theme settings.
- open online editor at Theme -> Actions -> Edit code
- open file config/settings_data.json
- copy file content to clipboard
3) Save settings to new theme
- open online editor at Theme -> Actions -> Edit code
- open file config/settings_data.json
- paste data from clipboard
- save file
4) Check apps configuration.
5) Reapply custom code changes.


Check this video for more details - https://www.youtube.com/watch?v=8wuBCwFY4xo


!!!
!!! Important. If you update from version 1 or version 2.
!!!

Version 3.x included significant changes and may need additional configuration.
Test your store with new theme version carefully before go live.



! Backup your current theme. (Actions -> Duplicate)
