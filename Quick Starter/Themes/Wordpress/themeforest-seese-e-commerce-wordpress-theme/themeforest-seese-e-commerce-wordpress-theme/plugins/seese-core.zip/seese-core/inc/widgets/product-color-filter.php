<?php
/*
 * Product Color Filter Widget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

  class seese_product_color extends WP_Widget {

    /**
     * Specifies the widget name, description, class name and instatiates it
     */
    public function __construct() {
      parent::__construct(
        'seese-product-color-filter',
        VTHEME_NAME_P . esc_html__( ' : Product Color Filter', 'seese' ),
        array(
          'classname'   => 'seese-product-color-filter seese-filter-column',
          'description' => VTHEME_NAME_P . esc_html__( ' widget that works for product color filtering.', 'seese' )
        )
      );
    }

    /**
     * Generates the back-end layout for the widget
     */
    public function form( $instance ) {

      // Default Values
      $instance      = wp_parse_args( $instance, array(
        'title'      => esc_html__( 'Choose Color', 'seese' ),
        'query_type' => 'and',
        'hide' 	     => '',
        'colors' 	   => '',
        'collapse'   => 'false',
      ));

      // Title
      $title_value   = esc_attr( $instance['title'] );
      $title_field   = array(
        'id'         => $this->get_field_name('title'),
        'name'       => $this->get_field_name('title'),
        'type'       => 'text',
        'title'      => esc_html__( 'Title ', 'seese' ),
        'wrap_class' => 'seese-cs-widget-fields',
      );
      echo cs_add_element( $title_field, $title_value );

      // Query Type
      $query_type_value = esc_attr( $instance['query_type'] );
      $query_type_field = array(
        'id'            => $this->get_field_name('query_type'),
        'name'          => $this->get_field_name('query_type'),
        'type'          => 'select',
        'options'       => array(
          'and'         => esc_html__( 'AND', 'seese' ),
          'or'          => esc_html__( 'OR', 'seese' ),
        ),
        'title'         => esc_html__( 'Query type ', 'seese' ),
      );
      echo cs_add_element( $query_type_field, $query_type_value );

      $color_attribute_slug = apply_filters( 'color_filter_slug', 'color' ); ?>

      <div class="cs-element cs-element-color">
  	    <div class="seese-widget-color-table">
          <?php
          $terms = get_terms('pa_'.$color_attribute_slug, array('hide_empty' => '0'));

          if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {

            $id     = 'widget-'.$this->id.'-';
            $name   = 'widget-'.$this->id_base.'['.$this->number.']';
            $hide   = $instance['hide'];
            $values = json_decode(json_encode($instance['colors']), true);

            $output = sprintf( '<table><tr><td><h4>%s</h4></td><td><h4>%s</h4></td><td><h4>%s</h4></td></tr>', esc_html__( 'Hide', 'seese' ), esc_html__( 'Name', 'seese' ), esc_html__( 'Color', 'seese' ) );
            
            foreach ( $terms as $term ) {
          	  $id = $id.$term->term_id;
              $hideValue = isset($hide[$term->term_id]) ? 'true' : 'false';

              $hideOn  = ($hideValue == 'true') ? 'checked="checked"' : '';
              $output .= '<tr><td><input type="checkbox" name="'.esc_attr($name).'[hide]['.esc_attr($term->term_id).']" '.$hideOn.' /></td>';

              $output .= '<td><label for="'.esc_attr($id).'">'.esc_attr($term->name).'</label></td>';
              $output .= '<td><input type="text" id="'.esc_attr($id).'" name="'.esc_attr($name).'[colors]['.esc_attr($term->term_id).']" value="'.(isset($values[$term->term_id]) ? esc_attr($values[$term->term_id]) : '').'" size="3" class="seese-widget-color-picker" /></td></tr>';
            }

            $output .= '</table>';
            $output .= '<input type="hidden" name="'.esc_attr($name).'[labels]" value="" />';

          } else {
            $output = '<span>No product attribute saved with the <strong>"'.$color_attribute_slug.'"</strong> slug yet.';
          }

          echo $output; ?>
  	    </div>
        <div class="clear"></div>
      </div>

    <?php
      // Collapsible
      $collapse_value = $instance['collapse'];
      $collapse_field = array(
        'id'          => $this->get_field_name('collapse'),
        'name'        => $this->get_field_name('collapse'),
        'type'        => 'checkbox',
        'title'       => esc_html__( 'Collapsible', 'seese' ),
        'default'     => false,
        'wrap_class'  => 'seese-cs-widget-fields',
      );
      echo cs_add_element( $collapse_field, $collapse_value );
    }

    /**
    * Processes the widget's values
    */
    public function update( $new_instance, $old_instance ) {
      $instance = $old_instance;

      // Update values
      $instance['title']      = strip_tags( stripslashes( $new_instance['title'] ) );
      $instance['query_type'] = strip_tags( stripslashes( $new_instance['query_type'] ) );
      $instance['hide']       = $new_instance['hide'];
      $instance['colors']     = $new_instance['colors'];
      $instance['collapse']   = $new_instance['collapse'];

      return $instance;
    }

    /**
    * Output the contents of the widget
    */
    public function widget( $args, $instance ) {

      // Extract the arguments
      extract( $args );

      $title       = apply_filters('widget_title', $instance['title']);
      $query_type  = $instance['query_type'];
      $collapse    = $instance['collapse'];
      $color_slug  = apply_filters('color_filter_slug', 'color');
      $taxonomy    = wc_attribute_taxonomy_name($color_slug);
      
      $seese_args['colors']  = json_decode( json_encode($instance['colors'] ), true );

      $seese_args['columns'] = '1';
      $seese_args['hide']    = $instance['hide'];

      $output = '';

      $e_uniqid    = uniqid();
      $unique_name = 'seese-filterColor-'. $e_uniqid;

      if ( ! taxonomy_exists( $taxonomy ) ) {
        return;
  	  }

      $get_terms_args = array( 'hide_empty' => '1' );
      $orderby        = wc_attribute_orderby($taxonomy);

      switch ( $orderby ) {
        case 'name' :
          $get_terms_args['orderby']    = 'name';
          $get_terms_args['menu_order'] = false;
        break;
        case 'id' :
          $get_terms_args['orderby']    = 'id';
          $get_terms_args['order']      = 'ASC';
          $get_terms_args['menu_order'] = false;
        break;
        case 'menu_order' :
          $get_terms_args['menu_order'] = 'ASC';
        break;
      }

      $terms = get_terms( $taxonomy, $get_terms_args );

      if ( 0 === sizeof( $terms ) ) {
  	    return;
  	  }

    	switch ( $orderby ) {
    	  case 'name_num' :
    	    usort( $terms, '_wc_get_product_terms_name_num_usort_callback' );
    	  break;
    	  case 'parent' :
    	    usort( $terms, '_wc_get_product_terms_parent_usort_callback' );
    	  break;
    	}

      echo $before_widget;

      $output.= $before_title;

      if ( $title ) {
        if ( $collapse ) {
          $output.= '<a role="button" data-toggle="collapse" href=".'.esc_attr($unique_name).'" aria-expanded="false" aria-controls="'.esc_attr($unique_name).'" class="seese-collapse">'.$title.'</a>';
        } else {
          $output.= '<a href="javascript:void(0);" class="seese-nocollapse">'.$title.'</a>';
        }
      }

      $output.= $after_title;

      if ( $collapse ) {
        $collapse_class = 'collapse in';
      } else {
        $collapse_class = 'no-collapse';
      }

      $output.= '<div class="'.esc_attr($collapse_class.' '.$unique_name).' seese-filter-content" id="seese-filterColor">';
      $output.= '<ul id="seese-color-filter" class="seese-color-filter">';

      $term_counts = $this->get_filtered_term_product_counts(wp_list_pluck($terms, 'term_id'), $taxonomy, $query_type);
      $filter_name = sanitize_title( str_replace( 'pa_', '', $taxonomy ) );

      foreach ($terms as $term) {
        if ( $this->get_current_term_id() === $term->term_id ) {
          continue;
        }
        $product_count = isset($term_counts[$term->term_id]) ? $term_counts[$term->term_id] : 0;
        $hideItem = isset($seese_args['hide'][$term->term_id]) ? 'true' : 'false';
        if ($hideItem == 'false') {
          $output.= '<li>';
          $output.= ($product_count > 0) ? '<a href="javascript:void(0);" data-color="'.esc_attr($term->slug).'" data-attrname="'.esc_attr($filter_name).'">' : '<span>';
          $color_val = isset($seese_args['colors'][$term->term_id]) ? $seese_args['colors'][$term->term_id] : '#e0e0e0';
          $output.= '<i style="background-color:'.esc_attr($color_val).';" class="seese-filter-color-item seese-filter-color-'.esc_attr(strtolower($term->slug)).'"></i>';
          $output.= esc_attr($term->name);
          $output.= ($product_count > 0) ? '</a> ' : '</span> ';
          $output.= '</li>';
        }
      }

      $output .= '</ul>';
      $output .= '</div>';

      echo $output . $after_widget;
    }

    /**
    * Return the currently viewed term ID.
    */
    protected function get_current_term_id() {
      return absint( is_tax() ? get_queried_object()->term_id : 0 );
    }

    /**
    * Return the currently viewed term slug.
    */
    protected function get_current_term_slug() {
      return absint( is_tax() ? get_queried_object()->slug : 0 );
    }

    /**
    * Count products within certain terms, taking the main WP query into consideration.
    */
    protected function get_filtered_term_product_counts( $term_ids, $taxonomy, $query_type ) {
      global $wpdb;

      $tax_query  = WC_Query::get_main_tax_query();
      $meta_query = WC_Query::get_main_meta_query();

      if ( 'or' === $query_type ) {
        foreach ( $tax_query as $key => $query ) {
          if ( $taxonomy === $query['taxonomy'] ) {
            unset( $tax_query[ $key ] );
          }
        }
      }

      $meta_query      = new WP_Meta_Query( $meta_query );
      $tax_query       = new WP_Tax_Query( $tax_query );
      $meta_query_sql  = $meta_query->get_sql( 'post', $wpdb->posts, 'ID' );
      $tax_query_sql   = $tax_query->get_sql( $wpdb->posts, 'ID' );

      $query           = array();
      $query['select'] = "SELECT COUNT( DISTINCT {$wpdb->posts}.ID ) as term_count, terms.term_id as term_count_id";
      $query['from']   = "FROM {$wpdb->posts}";
      $query['join']   = "INNER JOIN {$wpdb->term_relationships} AS term_relationships ON {$wpdb->posts}.ID = term_relationships.object_id
      INNER JOIN {$wpdb->term_taxonomy} AS term_taxonomy USING( term_taxonomy_id )
      INNER JOIN {$wpdb->terms} AS terms USING( term_id )" . $tax_query_sql['join'] . $meta_query_sql['join'];

      $query['where']   = "WHERE {$wpdb->posts}.post_type IN ( 'product' )
      AND {$wpdb->posts}.post_status = 'publish' " . $tax_query_sql['where'] . $meta_query_sql['where'] . "
      AND terms.term_id IN (" . implode( ',', array_map( 'absint', $term_ids ) ) . ")";

      if ( $search = WC_Query::get_main_search_query_sql() ) {
        $query['where'] .= ' AND ' . $search;
      }

      $query['group_by'] = "GROUP BY terms.term_id";
      $query             = apply_filters( 'woocommerce_get_filtered_term_product_counts_query', $query );
      $query             = implode( ' ', $query );
      $results           = $wpdb->get_results( $query );

      return wp_list_pluck( $results, 'term_count', 'term_count_id' );
    }

  }

  // Register the widget using an annonymous function
  add_action( 'widgets_init', create_function( '', 'register_widget( "seese_product_color" );' ) );

}
