<?php
/*
 * Product Sort Filter Widget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

  class seese_product_sort_filter extends WP_Widget {

    /**
     * Specifies the widget name, description, class name and instatiates it
     */
    public function __construct() {
      parent::__construct(
        'seese-product-sort-filter',
        VTHEME_NAME_P . esc_html__( ' : Product Sorting Filter', 'seese' ),
        array(
          'classname'   => 'seese-product-sort-filter seese-filter-column',
          'description' => VTHEME_NAME_P . esc_html__( ' widget that works for product sort filtering.', 'seese' )
        )
      );
    }

    /**
     * Generates the back-end layout for the widget
     */
    public function form( $instance ) {
      // Default Values
      $instance    = wp_parse_args( $instance, array(
        'title'    => esc_html__( 'Sort By', 'seese' ),
        'collapse' => 'false',
      ));

      // Title
      $title_value = esc_attr( $instance['title'] );
      $title_field = array(
        'id'         => $this->get_field_name('title'),
        'name'       => $this->get_field_name('title'),
        'type'       => 'text',
        'title'      => esc_html__( 'Title', 'seese' ),
        'wrap_class' => 'seese-cs-widget-fields',
      );
      echo cs_add_element( $title_field, $title_value );

      // Collapsible
      $collapse_value = $instance['collapse'];
      $collapse_field = array(
        'id'         => $this->get_field_name('collapse'),
        'name'       => $this->get_field_name('collapse'),
        'type'       => 'checkbox',
        'title'      => esc_html__( 'Collapsible', 'seese' ),
        'default'    => false,
        'wrap_class' => 'seese-cs-widget-fields',
      );
      echo cs_add_element( $collapse_field, $collapse_value );
    }

    /**
     * Processes the widget's values
     */
    public function update( $new_instance, $old_instance ) {
      $instance = $old_instance;

      // Update values
      $instance['title']    = strip_tags( stripslashes( $new_instance['title'] ) );
      $instance['collapse'] = $new_instance['collapse'];

      return $instance;
    }

    /**
     * Output the contents of the widget
     */
    public function widget( $args, $instance ) {
      global $wp_query;

      // Extract the arguments
      extract( $args );

      $title    = apply_filters( 'widget_title', $instance['title'] );
      $collapse = $instance['collapse'];

      $e_uniqid    = uniqid();
      $unique_name = 'seese-filter-sorting-'. $e_uniqid;

      $output = '';

      // Display the markup before the widget
      echo $before_widget;

      $output.= $before_title;

      if ( $title ) {
        if ( $collapse ) {
          $output.= '<a role="button" data-toggle="collapse" href=".'.esc_attr($unique_name).'" aria-expanded="false" aria-controls="'.esc_attr($unique_name).'" class="seese-collapse">'.$title.'</a>';
        } else {
          $output.= '<a href="javascript:void(0);" class="seese-nocollapse">'.$title.'</a>';
        }
      }

      $output.= $after_title;

      if ( $collapse ) {
        $collapse_class = 'collapse in';
      } else {
        $collapse_class = 'no-collapse';
      }

      $output.= '<div class="'.esc_attr($collapse_class.' '.$unique_name).' seese-filter-content" id="seese-filter-sorting">';
      $output.= '<ul id="seese-product-sorting" class="seese-product-sorting">';

      $orderby = 'all';

      $catalog_orderby_options = array(
        'all'           => esc_html__( 'Show All', 'seese' ),
        'date'       	  => esc_html__( 'Newest', 'seese' ),
        'popularity' 	  => esc_html__( 'Popularity', 'seese' ),
        'rating'     	  => esc_html__( 'Average rating', 'seese' ),
        'price'      	  => esc_html__( 'Price: Low to High', 'seese' ),
        'price-desc'	  => esc_html__( 'Price: High to Low', 'seese' )
      );

    	if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' ) {
        unset( $catalog_orderby_options['rating'] );
    	}

      global $wp;
      $home_url  = home_url($wp->request);
      $curr_url  = home_url(add_query_arg(array(), $wp->request));
      $shop_url  = get_permalink(wc_get_page_id('shop'));

      foreach ( $catalog_orderby_options as $id => $name ) {
    	  if ( $orderby == $id ) {
          $output.= '<li class="active seese-sort-item-all"><a href="javascript:void(0);" data-sort="'.esc_attr($id).'">'.esc_attr($name).'</a></li>';
    	  } else {
    		  $output.= '<li><a href="javascript:void(0);" data-sort="'.esc_attr($id).'">'.esc_attr($name).'</a></li>';
    	  }
      }

     	$output .= '</ul>';
  	  $output .= '</div>';

      echo $output;

      // Display the markup after the widget
      echo $after_widget;
    }
  }

  // Register the widget using an annonymous function
  add_action( 'widgets_init', create_function( '', 'register_widget("seese_product_sort_filter");' ) );

}
