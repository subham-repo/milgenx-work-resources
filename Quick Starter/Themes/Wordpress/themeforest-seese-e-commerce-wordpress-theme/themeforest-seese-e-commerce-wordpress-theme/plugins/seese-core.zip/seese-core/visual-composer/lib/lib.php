<?php
/**
 * Visual Composer Library
 * Common Fields
 */
class VictorLib {

	// Get Theme Name
	public static function vcts_cat_name() {
		return esc_html__( "by VictorThemes", 'seese-core' );
	}

	// Notice
	public static function seese_notice_field($heading, $param, $class, $group) {
		return array(
			"type"        => "notice",
			"heading"     => $heading,
			"param_name"  => $param,
			'class'       => $class,
			'value'       => '',
			"group"       => $group,
		);
	}

	// Extra Class
	public static function seese_class_option() {
		return array(
		  "type"        => "textfield",
		  "heading"     => esc_html__( "Extra class name", 'seese-core' ),
		  "param_name"  => "class",
		  'value'       => '',
		  "description" => esc_html__( "Custom styled class name.", 'seese-core')
		);
	}

	// ID
	public static function seese_id_option() {
		return array(
		  "type"        => "textfield",
		  "heading"     => esc_html__( "Element ID", 'seese-core' ),
		  "param_name"  => "id",
		  'value'       => '',
		  "description" => esc_html__( "Enter your ID for this element. If you want.", 'seese-core')
		);
	}

	// Open Link in New Tab
	public static function seese_open_link_tab() {
		return array(
			"type"       => "switcher",
			"heading"    => esc_html__( "Open New Tab? (Links)", 'seese-core' ),
			"param_name" => "open_link",
			"std"        => true,
			'value'      => '',
			"on_text"    => esc_html__( "Yes", 'seese-core' ),
			"off_text"   => esc_html__( "No", 'seese-core' ),
		);
	}

}

/*
 * Load All Shortcodes within a directory of visual-composer/shortcodes
 */
function vcts_all_shortcodes() {
	$dirs = glob( VCTS_SHORTCODE_PATH . '*', GLOB_ONLYDIR );
	if ( !$dirs ) return;
	foreach ($dirs as $dir) {
		$dirname = basename( $dir );

		/* Include all shortcodes backend options file */
		$options_file = $dir . DS . $dirname . '-options.php';
		$options = array();
		if ( file_exists( $options_file ) ) {
			include_once( $options_file );
		} else {
			continue;
		}

		/* Include all shortcodes frondend options file */
		$shortcode_class_file = $dir . DS . $dirname .'.php';
		if ( file_exists( $shortcode_class_file ) ) {
			include_once( $shortcode_class_file );
		}
	}
}
vcts_all_shortcodes();

if( ! function_exists( 'vc_add_shortcode_param' ) && function_exists( 'add_shortcode_param' ) ) {
  function vc_add_shortcode_param( $name, $form_field_callback, $script_url = null ) {
    return add_shortcode_param( $name, $form_field_callback, $script_url );
  }
}

/* Inline Style */
global $all_inline_styles;
$all_inline_styles = array();
if( ! function_exists( 'seese_add_inline_style' ) ) {
  function seese_add_inline_style( $style ) {
    global $all_inline_styles;
    array_push( $all_inline_styles, $style );
  }
}

/* Enqueue Inline Styles */
if ( ! function_exists( 'seese_enqueue_inline_styles' ) ) {
  function seese_enqueue_inline_styles() {

    global $all_inline_styles;

    if ( ! empty( $all_inline_styles ) ) {
      echo '<style id="seese-inline-style" type="text/css">'. seese_compress_css_lines( join( '', $all_inline_styles ) ) .'</style>';
    }

  }
  add_action( 'wp_footer', 'seese_enqueue_inline_styles' );
}

/* Validate px entered in field */
if( ! function_exists( 'seese_check_px' ) ) {
  function seese_check_px( $num ) {
    return ( is_numeric( $num ) ) ? $num . 'px' : $num;
  }
}
