<?php
/**
 * Blog - Shortcode Options
 */
add_action( "init", "vcts_blog_vc_map" );

if ( ! function_exists( "vcts_blog_vc_map" ) ) {

  function vcts_blog_vc_map() {

    vc_map( array(
      "name"        => esc_html__( "Blog", "seese-core"),
      "base"        => "vcts_blog",
      "description" => esc_html__( "Blog Styles", "seese-core"),
      "icon"        => "fa fa-newspaper-o color-red",
      "category"    => VictorLib::vcts_cat_name(),
      "params"      => array(

        array(
          "type"             => "dropdown",
          "heading"          => esc_html__( "Blog Style", "seese-core" ),
          "value"            => array(
            esc_html__( "Standard", "seese-core" ) => "seese-blog-one",
            esc_html__( "Masonry", "seese-core" )  => "seese-blog-two",
          ),
          "admin_label"      => true,
          "param_name"       => "blog_style",
          "description"      => esc_html__( "Select your blog style.", "seese-core" ),
        ),
        array(
          "type"             => "dropdown",
          "heading"          => esc_html__( "Columns", "seese-core" ),
          "value"            => array(
            esc_html__( "Column One", "seese-core" )   => "seese-blog-col-1",
            esc_html__( "Column Two", "seese-core" )   => "seese-blog-col-2",
            esc_html__( "Column Three", "seese-core" ) => "seese-blog-col-3",
          ),
          "admin_label"      => true,
          "param_name"       => "blog_columns",
          "description"      => esc_html__( "Select your blog column.", "seese-core" ),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          "type"             => "textfield",
          "heading"          => esc_html__("Limit", "seese-core"),
          "param_name"       => "blog_limit",
          "value"            => "",
          "admin_label"      => true,
          "description"      => esc_html__( "Enter the number of items to show.", "seese-core"),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),

        array(
          "type"             => "notice",
          "heading"          => esc_html__( "Enable/Disable", "seese-core" ),
          "param_name"       => "ed_opt",
          "class"            => "cs-info",
          "value"            => "",
		),
        array(
          "type"             => 'switcher',
          "heading"          => esc_html__('Category', 'seese-core'),
          "param_name"       => "blog_category",
          "value"            => "",
          "std"              => true,
          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
        ),
        array(
          "type"             => "switcher",
          "heading"          => esc_html__("Date", "seese-core"),
          "param_name"       => "blog_date",
          "value"            => "",
          "std"              => true,
          "edit_field_class" => "vc_col-md-3 vc_column seese_field_space",
        ),
        array(
          "type"             => "switcher",
          "heading"          => esc_html__("Author", "seese-core"),
          "param_name"       => "blog_author",
          "value"            => "",
          "std"              => true,
          "edit_field_class" => "vc_col-md-3 vc_column seese_field_space",
        ),
        array(
          "type"             => "switcher",
          "heading"          => esc_html__("Image Popup", "seese-core"),
          "param_name"       => "blog_popup",
          "value"            => "",
          "std"              => true,
          "edit_field_class" => "vc_col-md-3 vc_column seese_field_space",
        ),
        array(
          "type"             => "switcher",
          "heading"          => esc_html__("Excerpt", "seese-core"),
          "param_name"       => "blog_excerpt",
          "value"            => "",
          "std"              => true,
          "edit_field_class" => "vc_col-md-3 vc_column seese_field_space",
        ),
        array(
          "type"             => "switcher",
          "heading"          => esc_html__("Read More", "seese-core"),
          "param_name"       => "blog_read_more",
          "value"            => "",
          "std"              => true,
          "edit_field_class" => "vc_col-md-3 vc_column seese_field_space",
        ),
        array(
          "type"             => "switcher",
          "heading"          => esc_html__("Pagination", "seese-core"),
          "param_name"       => "blog_pagination",
          "value"            => "",
          "std"              => true,
          "edit_field_class" => "vc_col-md-3 vc_column seese_field_space",
        ),

        array(
          "type"             => "textfield",
          "heading"          => esc_html__("Excerpt Length", "seese-core"),
          "param_name"       => "blog_excerpt_length",
          "value"            => "",
          "description"      => esc_html__( "Enter blog short content length.", "seese-core"),
          "dependency"       => array(
            "element"        => "blog_excerpt",
            "value"          => array("true"),
          ),
          "edit_field_class" => "vc_col-md-4 vc_column seese_field_space",
        ),
        array(
          "type"             => "textfield",
          "heading"          => esc_html__("Read More Button Text", "seese-core"),
          "param_name"       => "read_more_text",
          "value"            => "",
          "description"      => esc_html__( "Enter read more button text.", "seese-core"),
          "dependency"       => array(
            "element"        => "blog_read_more",
            "value"          => array("true"),
          ),
          "edit_field_class" => "vc_col-md-4 vc_column seese_field_space",
        ),
        array(
          "type"             => "dropdown",
          "heading"          => esc_html__("Pagination Style", "seese-core"),
          "value"            => array(
            esc_html__( "Page Numbers", "seese-core" )  => "seese-pagination-one",
            esc_html__( "Previous/Next", "seese-core" ) => "seese-pagination-two",
            esc_html__( "Load More", "seese-core" )     => "seese-pagination-three",
          ),
          "param_name"       => "blog_pagination_style",
          "description"      => esc_html__( "Select blog pagination style.", "seese-core" ),
          "dependency"       => array(
            "element"        => "blog_pagination",
            "value"          => array("true"),
          ),
          "edit_field_class" => "vc_col-md-4 vc_column seese_field_space",
        ),

        array(
          "type"             => "notice",
          "heading"          => esc_html__( "Listing", "seese-core" ),
          "param_name"       => "lsng_opt",
          "class"            => "cs-info",
          "value"            => "",
		),
        array(
          "type"             => "dropdown",
          "heading"          => esc_html__( "Order", "seese-core" ),
          "value"            => array(
            esc_html__( "Select Blog Order", "seese-core" ) => "",
            esc_html__("Asending", "seese-core")            => "ASC",
            esc_html__("Desending", "seese-core")           => "DESC",
          ),
          "param_name"       => "blog_order",
          "edit_field_class" => "vc_col-md-6 vc_column seese_field_space",
        ),
        array(
          "type"             => "dropdown",
          "heading"          => esc_html__( "Order By", "seese-core" ),
          "value"            => array(
            esc_html__("None", "seese-core")   => "none",
            esc_html__("ID", "seese-core")     => "ID",
            esc_html__("Author", "seese-core") => "author",
            esc_html__("Title", "seese-core")  => "title",
            esc_html__("Date", "seese-core")   => "date",
          ),
          "param_name"       => "blog_orderby",
          "edit_field_class" => "vc_col-md-6 vc_column seese_field_space",
        ),
        array(
          "type"             => "textfield",
          "heading"          => esc_html__("Show only certain categories?", "seese-core"),
          "param_name"       => "blog_category_slugs",
          "value"            => "",
          "description"      => esc_html__( "Enter category SLUGS (comma separated) you want to display.", "seese-core")
        ),

        VictorLib::seese_class_option(),

      )
    ) );
  }
}
