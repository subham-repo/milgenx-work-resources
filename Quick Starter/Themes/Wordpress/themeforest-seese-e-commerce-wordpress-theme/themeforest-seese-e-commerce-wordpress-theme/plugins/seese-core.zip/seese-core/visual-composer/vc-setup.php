<?php
/**
 * Visual Composer Related Functions
 */

// Init Visual Composer
function vcts_init_vc_shortcodes() {
  if ( defined( 'WPB_VC_VERSION' ) ) {

    /* Visual Composer - Setup */
    require_once( VCTS_SHORTCODE_BASE_PATH . '/lib/lib.php' );
    require_once( VCTS_SHORTCODE_BASE_PATH . '/lib/add-params.php' );
    require_once( VCTS_SHORTCODE_BASE_PATH . '/pre_pages/pre-pages.php' );

    /* All Shortcodes */
    if (class_exists('WPBakeryVisualComposerAbstract')) {

      // Templates
      $dir = VCTS_SHORTCODE_BASE_PATH . '/vc_templates';
      vc_set_shortcodes_templates_dir( $dir );

      /* Set VC editor as default in following post types */
      $list = array(
        'post',
        'page',
        'team',
        'testimonial'
      );
      vc_set_default_editor_post_types( $list );

    } // class_exists
  }
}
add_action( 'vc_before_init', 'vcts_init_vc_shortcodes' );

/* Remove VC Teaser metabox */
if ( is_admin() ) {
  if ( ! function_exists('seese_framework_remove_vc_boxes') ) {
    function seese_framework_remove_vc_boxes(){
      $post_types = get_post_types( '', 'names' );
      foreach ( $post_types as $post_type ) {
        remove_meta_box('vc_teaser',  $post_type, 'side');
      }
    } // End function
  } // End if
  add_action('do_meta_boxes', 'seese_framework_remove_vc_boxes');
}
