<?php
/* ==========================================================
  Team
=========================================================== */
if ( !function_exists('vcts_team_function')) {
  function vcts_team_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'team_columns'        => '',
      'team_limit'          => '',
      'team_member_details' => '',
      'team_member_job'     => '',
      'team_order'          => '',
      'team_orderby'        => '',
      'class'               => '',
    ), $atts));

    // Column Style
    if($team_columns === 'seese-team-col-2') {
      $grid_number = 2;
      $team_column_class = 'col-lg-6 col-md-6 col-sm-6 col-xs-12';
    } else if($team_columns === 'seese-team-col-3') {
      $grid_number = 3;
      $team_column_class = 'col-lg-4 col-md-4 col-sm-4 col-xs-12';
    } else {
      $grid_number = 1;
      $team_column_class = '';
    }

    // Turn output buffer on
    ob_start();

    $args = array(
      // other query params here,
      'post_type'      => 'team',
      'posts_per_page' => (int)$team_limit,
      'orderby'        => $team_orderby,
      'order'          => $team_order
    );

    $vcts_post = new WP_Query( $args );
?>
    <!-- Team Start -->
    <div class="seese-team <?php echo esc_attr($team_columns . ' ' . $class); ?>">

    <?php
    if ($vcts_post->have_posts()) :
      $count_all_post = $vcts_post->post_count;
      $count = 0;

      while ($vcts_post->have_posts()) : $vcts_post->the_post();
        $count++;
        if ( $grid_number != 1) {
          if( $count === 1 ) {
            echo '<div class="row">';
          } else if(( $count % $grid_number ) === 1 ) {
            echo '<div class="row">';
          }
          echo '<div class="'. esc_attr($team_column_class) .'">';
        }
    ?>
        <div class="seese-team-box">
          <?php
          $large_image  = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
          $large_image  = $large_image[0];
          $team_options = get_post_meta( get_the_ID(), 'team_options', true );
          $member_link  = isset($team_options['team_custom_link']) ? $team_options['team_custom_link'] : get_the_permalink();
          $member_job   = isset($team_options['team_job_position']) ? $team_options['team_job_position'] : '';

          if ($large_image) {
            if($team_columns === 'seese-team-col-3') {
              if(class_exists('Aq_Resize')) {
                $team_img = aq_resize( $large_image, '385', '420', true );
                $team_img = ($team_img) ? $team_img : $large_image;
              } else {
                $team_img = $large_image;
              }
            } else if($team_columns === 'seese-team-col-2') {
              if(class_exists('Aq_Resize')) {
                $team_img = aq_resize( $large_image, '555', '590', true );
                $team_img = ($team_img) ? $team_img : $large_image;
              } else {
                $team_img = $large_image;
              }
            } else {
              $team_img = $large_image;
            } ?>
            <div class="seese-team-img">
              <img src="<?php echo esc_url($team_img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"/>
            </div>
       	  <?php
          } else {
            if($team_columns === 'seese-team-col-3') {
              $team_img = VCTS_PLUGIN_ASTS . '/images/385x420.jpg';
            } else if($team_columns === 'seese-team-col-2') {
              $team_img = VCTS_PLUGIN_ASTS . '/images/555x590.jpg';
            } else {
              $team_img = VCTS_PLUGIN_ASTS . '/images/1170x705.jpg';
            }
            ?>
            <div class="seese-team-img">
              <img src="<?php echo esc_url($team_img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"/>
            </div>
          <?php } // Featured Image ?>

          <?php if($team_member_details) { ?>
          <div class="seese-team-text">
            <?php the_content(get_the_ID()); ?>
          </div>
          <?php } ?>

          <div class="seese-team-info">
            <div class="seese-lift-up">
              <div class="member-name">
                <a href="<?php echo esc_url($member_link) ?>">
                  <?php the_title(); ?>
                </a>
              </div>
              <?php if($team_member_job) { ?>
              <div class="member-job">
                <?php echo esc_attr($member_job); ?>
              </div>
              <?php } ?>
            </div>
          </div>

        </div>
        <?php
        if ( $grid_number != 1) {
          echo '</div>';
          if((($count % $grid_number) === 0) || ($count === ($count_all_post))) {
            echo '</div>';
          }
        }
      endwhile;
      endif;
      ?>
    </div>
    <!-- Team End -->
<?php
    wp_reset_postdata();  // avoid errors further down the page

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'vcts_team', 'vcts_team_function' );
