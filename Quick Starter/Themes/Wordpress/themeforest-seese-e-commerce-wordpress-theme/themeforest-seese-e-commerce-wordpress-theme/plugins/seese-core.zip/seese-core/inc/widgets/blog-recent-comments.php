<?php
/*
 * Recent Comment Widget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

class seese_recent_comments extends WP_Widget {

  /**
   * Specifies the widget name, description, class name and instatiates it
   */
  public function __construct() {
    parent::__construct(
      'seese-recent-comments',
      VTHEME_NAME_P . esc_html__( ' : Recent Comments', 'seese' ),
      array(
        'classname'   => 'seese-recent-comments',
        'description' => VTHEME_NAME_P . esc_html__( ' widget that displays recent comments.', 'seese' )
      )
    );
  }

  /**
   * Generates the back-end layout for the widget
   */
  public function form( $instance ) {
    // Default Values
    $instance   = wp_parse_args( $instance, array(
      'title'   => esc_html__( 'Recent Comments', 'seese' ),
      'ptypes'  => 'post',
      'limit'   => '3',
      'date'    => true,
    ));

    // Title
    $title_value = esc_attr( $instance['title'] );
    $title_field = array(
      'id'    => $this->get_field_name('title'),
      'name'  => $this->get_field_name('title'),
      'type'  => 'text',
      'title' => esc_html__( 'Title :', 'seese' ),
      'wrap_class' => 'seese-cs-widget-fields',
    );
    echo cs_add_element( $title_field, $title_value );

    // Post Type
    $ptypes_value = esc_attr( $instance['ptypes'] );
    $ptypes_field = array(
      'id'      => $this->get_field_name('ptypes'),
      'name'    => $this->get_field_name('ptypes'),
      'type'    => 'select',
      'options' => 'post_types',
      'default_option' => esc_html__( 'Select Post Type', 'seese' ),
      'title'   => esc_html__( 'Post Type :', 'seese' ),
    );
    echo cs_add_element( $ptypes_field, $ptypes_value );

    // Limit
    $limit_value = esc_attr( $instance['limit'] );
    $limit_field = array(
      'id'    => $this->get_field_name('limit'),
      'name'  => $this->get_field_name('limit'),
      'type'  => 'text',
      'title' => esc_html__( 'Limit :', 'seese' ),
      'help' => esc_html__( 'How many comments want to show?', 'seese' ),
    );
    echo cs_add_element( $limit_field, $limit_value );

    // Date
    $date_value = esc_attr( $instance['date'] );
    $date_field = array(
      'id'    => $this->get_field_name('date'),
      'name'  => $this->get_field_name('date'),
      'type'  => 'switcher',
      'on_text'  => esc_html__( 'Yes', 'seese' ),
      'off_text'  => esc_html__( 'No', 'seese' ),
      'title' => esc_html__( 'Display Date :', 'seese' ),
    );
    echo cs_add_element( $date_field, $date_value );

  }

  /**
   * Processes the widget's values
   */
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;

    // Update values
    $instance['title']        = strip_tags( stripslashes( $new_instance['title'] ) );
    $instance['ptypes']       = strip_tags( stripslashes( $new_instance['ptypes'] ) );
    $instance['limit']        = strip_tags( stripslashes( $new_instance['limit'] ) );
    $instance['date']         = strip_tags( stripslashes( $new_instance['date'] ) );

    return $instance;
  }

  /**
   * Output the contents of the widget
   */
  public function widget( $args, $instance ) {
    // Extract the arguments
    extract( $args );

    $title             = apply_filters( 'widget_title', $instance['title'] );
    $ptypes            = $instance['ptypes'];
    $limit             = $instance['limit'];
    $display_date      = $instance['date'];

    $args = array(
      // other query params here,
      'post_type' => esc_attr($ptypes),
      'status'    => 'approve',
      'number'    => (int)$limit,
      'orderby'   => 'date',
      'order'     => 'DESC',
     );

    $seese_rcw = new WP_Comment_Query;
    $comments   = $seese_rcw->query( $args );

    // Display the markup before the widget
    echo $before_widget;

    if ( $title ) {
      echo $before_title . $title . $after_title;
    }

    if ($comments) {
      foreach ($comments as $comment) {
  ?>
      <div class="comment-box">
        <div class="comment-text">
        <?php
          $words = explode(' ', $comment->comment_content, 10);
          if (count($words)> 9) {
            array_pop($words);
            echo $text = implode(' ', $words);
          } else {
            echo $comment->comment_content;
          }
        ?>
        </div>
        <div class="comment-publish">
          <span><?php echo esc_html__( 'by ', 'seese' ); ?></span>
          <label><?php echo esc_attr($comment->comment_author); ?></label>
          <?php if ($display_date === '1') { ?>
          <span>
          <?php
            echo esc_html__( ' - ', 'seese' );
            $time = strtotime($comment->comment_date);
            $newformat = date('d F, Y', $time);
            echo $newformat;
          ?>
          </span>
          <?php } ?>
        </div>
      </div>
  <?php
      }
    } else {

    }
    // Display the markup after the widget
    echo $after_widget;
  }
}

// Register the widget using an annonymous function
add_action( 'widgets_init', create_function( '', 'register_widget( "seese_recent_comments" );' ) );
