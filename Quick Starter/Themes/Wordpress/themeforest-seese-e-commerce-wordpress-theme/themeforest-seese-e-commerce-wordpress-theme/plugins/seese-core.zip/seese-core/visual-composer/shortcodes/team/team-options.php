<?php
/**
 * Team - Shortcode Options
 */
add_action( 'init', 'vcts_team_vc_map' );

if ( ! function_exists( 'vcts_team_vc_map' ) ) {

  function vcts_team_vc_map() {

    vc_map( array(
      'name'        => esc_html__( 'Team', 'seese-core'),
      'base'        => 'vcts_team',
      'description' => esc_html__( 'Team Styles', 'seese-core'),
      'icon'        => 'fa fa-users color-orange',
      'category'    => VictorLib::vcts_cat_name(),
      'params'      => array(

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Layout', 'seese-core' ),
          'param_name'       => 'lt_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'dropdown',
          'heading'          => esc_html__( 'Columns', 'seese-core' ),
          'value'            => array(
            esc_html__( 'Column One', 'seese-core' )   => 'seese-team-col-1',
            esc_html__( 'Column Two', 'seese-core' )   => 'seese-team-col-2',
            esc_html__( 'Column Three', 'seese-core' ) => 'seese-team-col-3',
          ),
          'admin_label'      => true,
          'param_name'       => 'team_columns',
          'description'      => esc_html__( 'Select your team column.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Limit', 'seese-core'),
          'param_name'       => 'team_limit',
          'value'            => '',
          'admin_label'      => true,
          'description'      => esc_html__( 'Enter the number of members to show.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Enable/Disable', 'seese-core' ),
          'param_name'       => 'ed_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Member Details', 'seese-core'),
          'param_name'       => 'team_member_details',
          'value'            => '',
          'std'              => true,
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Member Job Position', 'seese-core'),
          'param_name'       => 'team_member_job',
          'value'            => '',
          'std'              => true,
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Listing', 'seese-core' ),
          'param_name'       => 'lsng_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'dropdown',
          'heading'          => esc_html__( 'Order', 'seese-core' ),
          'value'            => array(
            esc_html__('Select Team Order', 'seese-core')   => '',
            esc_html__('Asending', 'seese-core')            => 'ASC',
            esc_html__('Desending', 'seese-core')           => 'DESC',
          ),
          'param_name'       => 'team_order',
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          'type'             => 'dropdown',
          'heading'          => esc_html__( 'Order By', 'seese-core' ),
          'value'            => array(
            esc_html__('None', 'seese-core')   => 'none',
            esc_html__('ID', 'seese-core')     => 'ID',
            esc_html__('Title', 'seese-core')  => 'title',
            esc_html__('Date', 'seese-core')   => 'date',
          ),
          'param_name'       => 'team_orderby',
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),

        VictorLib::seese_class_option(),

      )
    ) );

  }
}
