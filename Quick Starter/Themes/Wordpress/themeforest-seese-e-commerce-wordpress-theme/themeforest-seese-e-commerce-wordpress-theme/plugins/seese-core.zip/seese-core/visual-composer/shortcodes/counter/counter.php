<?php
/* ==========================================================
  Counter
=========================================================== */
if ( !function_exists('vcts_cntr_function')) {
  function vcts_cntr_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'cntr_value'         => '',
      'cntr_prefix'        => '',
      'cntr_suffix'        => '',
      'cntr_super'         => '',
      'cntr_value_size'    => '',
      'cntr_value_color'   => '',
      'cntr_duration'      => '',
      'cntr_title'         => '',
      'cntr_title_size'    => '',
      'cntr_title_color'   => '',
      'cntr_details'       => '',
      'cntr_details_size'  => '',
      'cntr_details_color' => '',
      // Custom Class
      'class'  => '',
    ), $atts));

    // Shortcode Style CSS
    $e_uniqid      = uniqid();
    $inline_style  = '';

    if ( $cntr_value_size || $cntr_value_color ) {
      $inline_style .= '.seese-cntr-'. $e_uniqid .' .cntr-value {';
      $inline_style .= ( $cntr_value_size ) ? 'font-size:'. seese_check_px($cntr_value_size) .';' : '';
      $inline_style .= ( $cntr_value_color ) ? 'color:'. $cntr_value_color .';' : '';
      $inline_style .= '}';
    }

    if ( $cntr_title_size || $cntr_title_color ) {
      $inline_style .= '.seese-cntr-'. $e_uniqid .' .cntr-title {';
      $inline_style .= ( $cntr_title_size ) ? 'font-size:'. seese_check_px($cntr_title_size) .';' : '';
      $inline_style .= ( $cntr_title_color ) ? 'color:'. $cntr_title_color .';' : '';
      $inline_style .= '}';
    }

    if ( $cntr_details_size || $cntr_details_color ) {
      $inline_style .= '.seese-cntr-'. $e_uniqid .' .cntr-details {';
      $inline_style .= ( $cntr_details_size ) ? 'font-size:'. seese_check_px($cntr_details_size) .';' : '';
      $inline_style .= ( $cntr_details_color ) ? 'color:'. $cntr_details_color .';' : '';
      $inline_style .= '}';
    }

    // add inline style
    seese_add_inline_style( $inline_style );
    $styled_class = ' seese-cntr-'. $e_uniqid;

    $cntr_duration = ($cntr_duration) ? $cntr_duration : '1000';

    wp_enqueue_script( 'vtheme-waypoint', VCTS_PLUGIN_ASTS . '/js/waypoint.js', array( 'jquery' ), '4.0.1', true );
    wp_enqueue_script( 'vtheme-counter', VCTS_PLUGIN_ASTS . '/js/jquery.counterup.js', array( 'jquery' ), '1.0', true );

    // Turn output buffer on
    ob_start();

    ?>
    <div class="seese-cntr-box <?php echo esc_attr($class . $styled_class); ?>">
      <div class="cntr-value">
        <?php if($cntr_prefix) { ?><span class="cntr-prefix"><?php echo esc_attr($cntr_prefix); ?></span><?php } ?>
        <span id="cntr-<?php echo esc_attr($e_uniqid); ?>"><?php echo esc_attr($cntr_value); ?></span>
        <?php if($cntr_super) { ?><span class="cntr-super"><?php echo esc_attr($cntr_super); ?></span><?php } ?>
        <?php if($cntr_suffix) { ?><span class="cntr-suffix"><?php echo esc_attr($cntr_suffix); ?></span><?php } ?>
      </div>
      <div class="cntr-title"><?php echo esc_attr($cntr_title); ?></div>
      <div class="cntr-details"><?php echo esc_attr($cntr_details); ?></div>
    </div>

    <script type="text/javascript">
      jQuery(document).ready(function($) {
        $('#cntr-<?php echo esc_js($e_uniqid); ?>').counterUp({
          delay: 10,
          time: <?php echo esc_js($cntr_duration); ?>
        });
      });
    </script>

    <?php
    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'vcts_counter', 'vcts_cntr_function' );
