<?php
/* ==========================================================
  Banner Slider
=========================================================== */

if ( class_exists( 'WooCommerce' ) ) {

  if ( !function_exists('vcts_product_slider_function')) {

    function vcts_product_slider_function( $atts, $content = NULL ) {

		 	extract( shortcode_atts( array(
				//Slider Options
				'adaptive_height'	  => '',
				'infinite_loop'		  => '',
				'arrows' 			      => '',
				'pagination'		    => '',
				'autoplay'			    => '',
				'pause_hover'			  => '',
				'pagination_color'	=> 'gray',
				'autoplay_speed'	  => '',
				'background_color'	=> '',
				'animation'			    => 'slide',
				'anim_speed'		    => '',
				//Product Settings
				'prlists' 	        => '',
				'class'             => '',
			), $atts ) );

	    // Shortcode Style CSS
	    $e_uniqid         = uniqid();
	    $styled_class     = 'seese-product-slider-'. $e_uniqid;

	    // Slider Options //
		  $adaptive_height  = ($adaptive_height)      ? 'true' : 'false';
	    $infinite_loop    = ($infinite_loop)        ? 'true' : 'false';
	    $arrows           = ($arrows)               ? 'true' : 'false';
	    $pagination       = ($pagination)           ? 'true' : 'false';
	    $autoplay         = ($autoplay)             ? 'true' : 'false';
	    $pause_hover      = ($pause_hover)          ? 'true' : 'false';
	    $autoplay_speed   = ($autoplay_speed)       ? intval( $autoplay_speed ) : 3000;
	    $animation        = ($animation != 'slide') ? 'true' : 'false';
	    $anim_speed       = ($anim_speed)           ? intval( $anim_speed ) : 300;

	    if ($pagination) {
	      $pagination_class = 'seese-slick-controls-' .esc_attr( $pagination_color );
			} else {
			  $pagination_class = '';
			}

		  $background_color_style = ( strlen( $background_color ) > 0 ) ? 'style="background-color: ' . esc_attr( $background_color ) . '"' : '';
	    $adaptive_height_class  = ($adaptive_height === 'true') ? 'seese-prslr-height-adaptive' : 'seese-prslr-height-fixed';

	    // Turn output buffer on
	    ob_start();

	    $output  = '';
	    $output .= '<div class="seese-prslr '.$styled_class.' '.$pagination_class.' '.$adaptive_height_class.' '.$class.'">';

	    $slider_products = (array) vc_param_group_parse_atts($prlists);

	    foreach ($slider_products as $slider_product) {
	      $pr_img              = isset($slider_product['pr_img'])             ? $slider_product['pr_img']             : '';
	      $pr_title_text_one   = isset($slider_product['pr_title_text_one'])  ? $slider_product['pr_title_text_one']  : '';
	      $pr_title_text_two   = isset($slider_product['pr_title_text_two'])  ? $slider_product['pr_title_text_two']  : '';
	      $pr_title_link       = isset($slider_product['pr_title_link'])      ? $slider_product['pr_title_link']      : '';
	      $pr_price            = isset($slider_product['pr_price'])           ? $slider_product['pr_price']           : '';
	      $pr_details          = isset($slider_product['pr_details'])         ? $slider_product['pr_details']         : '';
	      $shop_now_title      = isset($slider_product['shop_now_title'])     ? $slider_product['shop_now_title']     : '';
	      $shop_now_link       = isset($slider_product['shop_now_link'])      ? $slider_product['shop_now_link']      : '';
	      $title_text_color    = isset($slider_product['title_text_color'])   ? $slider_product['title_text_color']   : '';
	      $price_text_color    = isset($slider_product['price_text_color'])   ? $slider_product['price_text_color']   : '';
	      $details_text_color  = isset($slider_product['details_text_color']) ? $slider_product['details_text_color'] : '';
	      $shopnow_text_color  = isset($slider_product['shopnow_text_color']) ? $slider_product['shopnow_text_color'] : '';
	      $text_position       = isset($slider_product['text_position'])      ? $slider_product['text_position']      : 'h_left-v_center';
	      $text_alignment      = isset($slider_product['text_alignment'])     ? $slider_product['text_alignment']     : 'align_left';
	      $text_padding        = isset($slider_product['text_padding'])       ? $slider_product['text_padding']       : '';
	      $text_animation      = isset($slider_product['text_animation'])     ? $slider_product['text_animation']     : '';

	      $e_uniqid_box    = uniqid();
	      $inline_style    = '';

	      if($title_text_color) {
	        if($pr_title_link) {
	            $inline_style .= '.seese-prslr-box-'.$e_uniqid_box .' .seese-prslr-title a, .seese-prslr-box-'.$e_uniqid_box .' .seese-prslr-intro span {';
	        } else {
	            $inline_style .= '.seese-prslr-box-'.$e_uniqid_box .' .seese-prslr-title, .seese-prslr-box-'.$e_uniqid_box .' .seese-prslr-intro span {';
	        }
	        $inline_style .= 'color:'.$title_text_color.' !important;';
	        $inline_style .= '}';
	      }

				if($price_text_color) {
	        $inline_style .= '.seese-prslr-box-'.$e_uniqid_box .' .seese-prslr-content .seese-prslr-price {';
	        $inline_style .= 'color:'.$price_text_color.' !important;';
	        $inline_style .= '}';
	      }

	      if($details_text_color) {
	        $inline_style .= '.seese-prslr-box-'.$e_uniqid_box .' .seese-prslr-content .seese-prslr-desc {';
	        $inline_style .= 'color:'.$details_text_color.' !important;';
	        $inline_style .= '}';
	      }

	      if($shopnow_text_color) {
	        if($shop_now_link) {
	            $inline_style .= '.seese-prslr-box-'.$e_uniqid_box .' .seese-prslr-content .seese-prslr-shopNow-title a {';
	        } else {
	            $inline_style .= '.seese-prslr-box-'.$e_uniqid_box .' .seese-prslr-content .seese-prslr-shopNow-title {';
	        }
	        $inline_style .= 'color:'.$shopnow_text_color.' !important;';
	        $inline_style .= '}';
	      }

	      $inline_style .= '.seese-prslr-box-'.$e_uniqid_box .' .seese-prslr-content .animated {';
	      $inline_style .= 'opacity: 0;';
	      $inline_style .= '}';

	      // Product Options //
	      $text_position  = explode( '-', $text_position );
	      $text_styles    = '';

	      if($text_padding) {
	        $padding        = intval( $text_padding ) . '% ';
	        $padding_top    = '0 ';
	        $padding_bottom = '0 ';

	        if ( $text_position[1] === 'v_top' ) {
	          $padding_top    = $padding;
	        } else if ( $text_position[1] === 'v_bottom' ) {
	          $padding_bottom = $padding;
	        }
	        $text_styles .= 'padding: ' . $padding_top . $padding . $padding_bottom . $padding . ';';
	      }

	      // Add Inline Style
	      seese_add_inline_style( $inline_style );
	      $styled_box_class = 'seese-prslr-box-'.$e_uniqid_box;

	      $product_image  = '';
	      $product_image  = wp_get_attachment_image_src( $pr_img, 'fullsize', false, '' );
	      $product_image  = $product_image[0];

	      if($product_image) {

	        $output .= '<div class="seese-prslr-box '.$styled_box_class.'" '.$background_color_style.'>';
	        $output .= '<div class="seese-prslr-img">';
	        $output .= '<img src="'.esc_url($product_image).'" class="seese-prslr-image"></div>';
	        $output .= '<div class="seese-prslr-content '.$text_position[0].' '.$text_position[1].' '.$text_alignment.'" style="'.$text_styles.'">';
	        $output .= '<div class="seese-prslr-text">';

	        if($pr_title_text_one || $pr_title_text_two || $pr_price) {	          
	         
	          $output .= '<div class="seese-prslr-intro">';
		 
		        if($pr_title_text_one || $pr_title_text_two) {	        	
		        	$output .= '<div class="seese-prslr-title seese-animate animated" data-animate="'.esc_attr($text_animation).'">';
		        	$output .= ($pr_title_link) ? '<a href="'.esc_url($pr_title_link).'">' : '';
		        	$output .= ($pr_title_text_one) ? esc_attr($pr_title_text_one) : '';
		        	$output .= ($pr_title_text_one && $pr_title_text_two) ? '<br/>' : '';
		        	$output .= ($pr_title_text_two) ? esc_attr($pr_title_text_two) : '';
		        	$output .= ($pr_title_link) ? '</a>' : '';
		        	$output .= ($pr_price) ? '<span> - </span>' : '';
		        	$output .= '</div>';
		        }

		        if($pr_price) {
		        	$output .= ($pr_title_text_one || $pr_title_text_two) ? ' ' : '';
		          $output .= '<div class="seese-prslr-price seese-animate animated" data-animate="'.esc_attr($text_animation).'">'.$pr_price.'</div>';
		        }

		        $output .= '</div>';
		      } 

	        if($pr_details) {
	            $output .= '<div class="seese-prslr-desc seese-animate animated" data-animate="'.esc_attr($text_animation).'">'.esc_attr($pr_details).'</div>';
	        }

	        if($shop_now_title) {
	          if($shop_now_link) {
	            $output .= '<div class="seese-prslr-shopNow-title seese-animate animated" data-animate="'.esc_attr($text_animation).'"><a href="'.esc_url($shop_now_link).'">'.esc_attr($shop_now_title).'</a></div>';
	          } else {
	            $output .= '<div class="seese-prslr-shopNow-title seese-animate animated" data-animate="'.esc_attr($text_animation).'">'.esc_attr($shop_now_title).'</div>';
	          }
	        }

	        $output .= '</div></div></div>';

	      }
	    }

	    $output .= '</div>';

	    echo $output; ?>

	    <script type="text/javascript">

	    	jQuery(window).load(function() {

	    		var $sliderGrid = jQuery('.<?php echo esc_js($styled_class); ?>');

	    		$sliderGrid.on('init', function(event, slick) {
	    			jQuery(document).trigger('banner-slider-loaded');
    		    var $slideActive   = $sliderGrid.find('.slick-track .slick-active');
    		    var $bannerContent = $slideActive.find('.seese-animate');
    		    $sliderGrid.find('.seese-prslr-price').css('visibility', 'visible');
						if ($bannerContent.length) {
							$bannerContent.css('opacity', '1');
							$bannerAnimation = $bannerContent.data('animate');
							$bannerContent.addClass($bannerAnimation);
						}
			    });

      		$sliderGrid.slick({
		        rows:           1,
		        slidesPerRow:   1,
		        slidesToShow:   1,
		        adaptiveHeight: <?php echo esc_js($adaptive_height); ?>,
		        arrows:         <?php echo esc_js($arrows); ?>,
		        autoplay:       <?php echo esc_js($autoplay); ?>,
		        autoplaySpeed:  <?php echo esc_js($autoplay_speed); ?>,
		        dots:           <?php echo esc_js($pagination); ?>,
		        fade:           <?php echo esc_js($animation); ?>,
		        infinite:       <?php echo esc_js($infinite_loop); ?>,
		        pauseOnHover:   <?php echo esc_js($pause_hover); ?>,
		        prevArrow:      "<div class='seese-prslr-nav prslr-prev'><i class='fa fa-angle-left' aria-hidden='true'></i></div>",
		        nextArrow:      "<div class='seese-prslr-nav prslr-next'><i class='fa fa-angle-right' aria-hidden='true'></i></div>",
		        speed:          <?php echo esc_js($anim_speed); ?>,
	        });

	        $sliderGrid.on('beforeChange', function(event, slick, currentSlide, nextSlide) {
	        	var $currentSlide  = jQuery(slick.$slides[slick.currentSlide]);
	        	var $bannerContent = $currentSlide.find('.seese-animate');
	        	if ($bannerContent.length) {
	        		$bannerContent.css('opacity', '0');
							$bannerAnimation = $bannerContent.data('animate');
							$bannerContent.removeClass($bannerAnimation);
						}
					});

	        $sliderGrid.on('afterChange', function(event, slick, currentSlide, nextSlide) {
	        	var $currentSlide  = jQuery(slick.$slides[slick.currentSlide]);
	        	var $bannerContent = $currentSlide.find('.seese-animate');
	        	if ($bannerContent.length) {
	        		$bannerContent.css('opacity', '1');
							$bannerAnimation = $bannerContent.data('animate');
							$bannerContent.addClass($bannerAnimation);
						}
	        });

	      });
	      
	    </script>

    <?php
	  // Return outbut buffer
    return ob_get_clean();

    }
  }

  add_shortcode( 'vcts_product_slider', 'vcts_product_slider_function' );

}
