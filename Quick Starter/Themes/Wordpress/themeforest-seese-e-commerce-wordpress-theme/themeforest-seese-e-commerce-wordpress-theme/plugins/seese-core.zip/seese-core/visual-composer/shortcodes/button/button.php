<?php
/* ===========================================================
    Button
=========================================================== */
if ( !function_exists('vcts_button_function')) {
  function vcts_button_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'button_text'      => '',
      'button_link'      => '',
      'open_link'        => '',
      'simple_hover'     => '',
      // Styling
      'text_size'        => '',
      'button_align'     => '',
      'text_color'       => '',
      'text_hover_color' => '',
      'bg_hover_color'   => '',
      'br_hover_color'   => '',
      'class'            => '',
      // Design
      'css' => ''
    ), $atts));

    // Design Tab
    $custom_css = ( function_exists( 'vc_shortcode_custom_css_class' ) ) ? vc_shortcode_custom_css_class( $css, ' ' ) : '';

    $style = (!empty($button_align)) ? 'style="text-align:'. $button_align .';"' : '';

    // Shortcode Style CSS
    $e_uniqid      = uniqid();
    $inline_style  = '';

    // Text Size
    if ( $text_size ) {
      $inline_style .= '.seese-btn-'. $e_uniqid .' {';
      $inline_style .= ( $text_size ) ? 'font-size:'. seese_check_px($text_size) .';' : '';
      $inline_style .= '}';
    }
    // Button Color
    if ( $text_color ) {
      $inline_style .= '.seese-btn-'. $e_uniqid .' .btn-text {';
      $inline_style .= ( $text_color ) ? 'color:'. $text_color .';' : '';
      $inline_style .= '}';
    }

    if ( $text_hover_color ) {
      $inline_style .= '.seese-btn-'. $e_uniqid .':hover .btn-text, .seese-btn-'. $e_uniqid .':focus .btn-text, .seese-btn-'. $e_uniqid .':active .btn-text {';
      $inline_style .= ( $text_hover_color ) ? 'color:'. $text_hover_color .' !important;' : '';
      $inline_style .= '}';
    }

    if ( $bg_hover_color || $br_hover_color ) {
      $inline_style .= '.seese-btn-'. $e_uniqid .':hover, .seese-btn-'. $e_uniqid .':focus, .seese-btn-'. $e_uniqid .':active {';
      $inline_style .= ( $bg_hover_color ) ? 'background: '. $bg_hover_color .' !important;' : '';
      $inline_style .= ( $br_hover_color ) ? 'border: 1px solid '. $br_hover_color .' !important;' : '';
      $inline_style .= '}';
    }

    // add inline style
    seese_add_inline_style( $inline_style );
    $styled_class = ' seese-btn-'. $e_uniqid;

    // Styling
    $button_text  = ($button_text) ? '<span class="btn-text">'. $button_text .'</span>' : '';
    $button_link  = ($button_link) ? 'href="'. esc_url($button_link) .'"' : '';
    $open_link    = ($open_link) ? ' target="_blank"' : '';
    $simple_hover = ($simple_hover) ? '' : ' btn-hover-one';
    $output = '<div '.$style.'><a class="seese-btn btn-secondary'. $custom_css . $styled_class . $simple_hover .' '. $class .'" '. $button_link . $open_link .'>'. $button_text .'</a></div>';

    return $output;

  }
}

add_shortcode( 'vcts_button', 'vcts_button_function' );
