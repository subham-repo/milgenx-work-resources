<?php
/**
 * Product Slider - Shortcode Options
 */

if (class_exists('WooCommerce')) {

  add_action( 'init', 'vcts_product_slider_vc_map' );

  if ( ! function_exists( 'vcts_product_slider_vc_map' ) ) {

	  function vcts_product_slider_vc_map() {

	    vc_map( array(
	      'name'                 => esc_html__('Product Slider', 'seese-core'),
	      'base'                 => 'vcts_product_slider',
	      'description'          => esc_html__('Product Banner Slider', 'seese-core'),
	      'icon'                 => 'fa fa-picture-o color-olive',
	      'category'             => VictorLib::vcts_cat_name(),
	      'params'               => array(
	        // Slider Settings
	        array(
	          'type'             => 'notice',
	          'heading'          => esc_html__('Slider Settings', 'seese-core'),
	          'param_name'       => 'slst_opt',
	          'class'            => 'cs-info',
	          'value'            => '',
	        ),
					array(
	          'type' 			 			 => 'switcher',
	          'heading' 		 		 => esc_html__('Adaptive Height', 'seese-core'),
	          'param_name' 	     => 'adaptive_height',
	          'description'	     => esc_html__('Enable adaptive height for each slide.', 'seese-core'),
	          'value'            => '',
	          'std'              => false,
	          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
					),
        	array(
				  	'type' 			 			 => 'switcher',
					  'heading' 		 		 => esc_html__('Infinite Loop', 'seese-core'),
					  'param_name' 	     => 'infinite_loop',
					  'description'	     => esc_html__('Infinite loop sliding.', 'seese-core'),
	          'value'            => '',
	          'std'              => true,
	          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
					),
					array(
			      'type' 			 		   => 'switcher',
					  'heading' 		     => esc_html__('Arrows', 'seese-core'),
					  'param_name' 	     => 'arrows',
					  'description'	     => esc_html__('Show "prev" and "next" arrows.', 'seese-core'),
	          'value'            => '',
	          'std'              => true,
	          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
					),
					array(
					  'type' 			 			 => 'switcher',
					  'heading' 		 		 => esc_html__('Dots Pagination', 'seese-core'),
					  'param_name' 	     => 'pagination',
					  'description'	     => esc_html__('Show dots pagination.', 'seese-core'),
					  'value'            => '',
	          'std'              => true,
	          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
					),
        	array(
					  'type' 			 		   => 'switcher',
					  'heading' 		 	   => esc_html__('Autoplay', 'seese-core'),
					  'param_name' 	     => 'autoplay',
					  'description'	     => esc_html__('Enable autoplay.', 'seese-core'),
					  'value'            => '',
	          'std'              => false,
	          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
					),
	        array(
					  'type' 			 			 => 'switcher',
					  'heading' 		 		 => esc_html__('Pause On Hover', 'seese-core'),
					  'param_name' 	     => 'pause_hover',
					  'description'	     => esc_html__('Enable pause on hover.', 'seese-core'),
					  'value'            => '',
	          'std'              => true,
	          'dependency'       => array(
	            'element'        => 'autoplay',
	            'value'          => 'true',
	          ),
            'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
					),
          array(
					  'type' 			       => 'dropdown',
					  'heading' 		     => esc_html__('Pagination Color', 'seese-core'),
					  'param_name' 	     => 'pagination_color',
					  'description'	     => esc_html__('Select pagination color.', 'seese-core'),
					  'value' 		       => array(
					    esc_html__('Light', 'seese-core') => 'light',
					    esc_html__('Gray', 'seese-core') => 'gray',
					    esc_html__('Dark', 'seese-core') => 'dark'
					  ),
	          'dependency'       => array(
	            'element'        => 'pagination',
	            'value'          => 'true',
	          ),
	          'std'              => 'gray',
	          'admin_label'      => true,
	          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
					),
        	array(
					  'type' 			       => 'textfield',
					  'heading' 		     => esc_html__('Autoplay Speed', 'seese-core'),
					  'param_name' 	     => 'autoplay_speed',
					  'description'	     => esc_html__('Enter autoplay interval in milliseconds.', 'seese-core'),
			          'dependency'   => array(
			            'element'    => 'autoplay',
			            'value'      => 'true',
			          ),
			      'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
					),

	        // Slider Styling
	        array(
	          'type'             => 'notice',
	          'heading'          => esc_html__('Slider Styling', 'seese-core'),
	          'param_name'       => 'slslng_opt',
	          'class'            => 'cs-info',
	          'value'            => '',
	        ),
       		array(
					  'type' 			 		   => 'colorpicker',
					  'heading' 		 		 => esc_html__('Background Color', 'seese-core'),
					  'param_name' 	     => 'background_color',
					  'description'	     => esc_html__('Set a background color.', 'seese-core'),
			      'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
					),
        	array(
					  'type' 			 			 => 'dropdown',
					  'heading' 		 		 => esc_html__('Animation Type', 'seese-core'),
					  'param_name' 	     => 'animation',
					  'description'	     => esc_html__('Select animation type.', 'seese-core'),
				      'value' 		     => array(
					    esc_html__('Fade', 'seese-core')   => 'fade',
					    esc_html__('Slide', 'seese-core')  => 'slide'
					  ),
					  'std' 			 			 => 'slide',
	          'admin_label'      => true,
	          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
					),
					array(
					  'type' 			       => 'textfield',
					  'heading' 		     => esc_html__('Animation Speed', 'seese-core'),
					  'param_name' 	     => 'anim_speed',
					  'description'	     => esc_html__('Enter animation speed in milliseconds.', 'seese-core'),
			      'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
					),

          // Product Listing
	        array(
					  'type'             => 'notice',
					  'heading'          => esc_html__('Product Listing', 'seese-core'),
					  'param_name'       => 'pr_lsng_opt',
					  'class'            => 'cs-info',
					  'value'            => '',
					),
	        array(
	          'type'             => 'param_group',
	          'value'            => '',
	          'heading'          => esc_html__('Products', 'seese-core'),
	          'param_name'       => 'prlists',
	          'params'           => array(
		          array(
		            'type'             => 'attach_image',
		            'value'            => '',
		            'heading'          => esc_html__( 'Product Image', 'seese-core' ),
		            'param_name'       => 'pr_img',
		            'description'      => esc_html__( 'Upload product image.', 'seese-core'),
		          ),
		          array(
		            'type'             => 'textfield',
		            'value'            => '',
		            'heading'          => esc_html__( 'Title Text One', 'seese-core' ),
		            'param_name'       => 'pr_title_text_one',
		            'description'	     => esc_html__( 'Enter product title one.', 'seese-core' ),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		          ),
		          array(
		            'type'             => 'textfield',
		            'value'            => '',
		            'heading'          => esc_html__( 'Title Text Two', 'seese-core' ),
		            'param_name'       => 'pr_title_text_two',
		            'description'	     => esc_html__( 'Enter product title two.', 'seese-core' ),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		          ),
		          array(
		            'type'             => 'textfield',
		            'value'            => '',
		            'heading'          => esc_html__( 'Title Link', 'seese-core' ),
		            'param_name'       => 'pr_title_link',
		            'description'	     => esc_html__( 'Enter a valid title link.', 'seese-core' ),
		            'edit_field_class' => 'vc_col-md-12 vc_column seese_field_space',
		          ),
		          array(
		            'type'             => 'textfield',
		            'value'            => '',
		            'heading'          => esc_html__( 'Price', 'seese-core' ),
		            'param_name'       => 'pr_price',
		            'description'	     => esc_html__( 'Enter product price.', 'seese-core' ),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		          ),
		          array(
		            'type'             => 'textarea',
		            'value'            => '',
		            'heading'          => esc_html__( 'Product Details', 'seese-core' ),
		            'param_name'       => 'pr_details',
		            'description'	     => esc_html__( 'Enter product details.', 'seese-core' ),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		          ),
		          array(
			    		  'type' 			 			 => 'textfield',
			    		  'heading' 		 		 => esc_html__('Shop Now Text', 'seese-core'),
			    		  'param_name' 	     => 'shop_now_title',
		            'description'	     => esc_html__('Enter a shop now title.', 'seese-core'),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		    		  ),
			    		array(
			    		  'type' 			 			 => 'textfield',
			    		  'heading' 		 		 => esc_html__('Shop Now Link', 'seese-core'),
			    		  'param_name' 	     => 'shop_now_link',
		            'description'	     => esc_html__('Enter a valid shop link.', 'seese-core'),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
			    		),
		          array(
		    		  	'type' 			       => 'dropdown',
		            'heading' 		     => esc_html__('Text Position', 'seese-core' ),
		            'param_name' 	     => 'text_position',
		            'value' 		       => array(
				           	esc_html__('Top Left', 'seese-core')      => 'h_left-v_top',
				           	esc_html__('Top Center', 'seese-core')    => 'h_center-v_top',
				           	esc_html__('Top Right', 'seese-core')     => 'h_right-v_top',
				           	esc_html__('Center Left', 'seese-core')   => 'h_left-v_center',
				            esc_html__('Center Center', 'seese-core') => 'h_center-v_center',
				           	esc_html__('Center Right', 'seese-core')  => 'h_right-v_center',
				           	esc_html__('Bottom Left', 'seese-core')   => 'h_left-v_bottom',
				           	esc_html__('Bottom Center', 'seese-core') => 'h_center-v_bottom',
				           	esc_html__('Bottom Right', 'seese-core')  => 'h_right-v_bottom'
		            ),
		  		  		'std' 			       => 'h_left-v_center',
		            'description'	     => esc_html__('Select text position.', 'seese-core'),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		    			),
		          array(
			    		  'type' 			       => 'dropdown',
			    		  'heading' 		     => esc_html__('Text Alignment', 'seese-core'),
			          'param_name' 	     => 'text_alignment',
			    		  'description'	     => esc_html__('Select text alignment.', 'seese-core'),
			    		  'value' 		       => array(
			    		    esc_html__('Left', 'seese-core')   => 'align_left',
			    		    esc_html__('Center', 'seese-core') => 'align_center',
			    		    esc_html__('Right', 'seese-core')  => 'align_right'
			    		  ),
			    		  'std' 			       => 'align_left',
			          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
			    		),
			    		array(
			    		  'type' 			       => 'textfield',
			    		  'heading' 		     => esc_html__('Text Padding', 'seese-core'),
			    		  'param_name' 	     => 'text_padding',
			    		  'description'	     => esc_html__('Enter text padding (value is in percent (%), enter numbers only).', 'seese-core'),
			          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
			        ),
			    		array(
			    		  'type' 			       => 'dropdown',
			    		  'heading' 		     => esc_html__( 'Text Animation', 'seese-core' ),
			          'param_name' 	     => 'text_animation',
			    		  'description'	     => esc_html__( 'Select slider text animation.', 'seese-core' ),
			    		  'value' 		       => array(
			    		    esc_html__('Flash', 'seese-core')              => 'flash',
			    		    esc_html__('Bounce', 'seese-core')             => 'bounce',
			    		    esc_html__('Shake', 'seese-core')              => 'shake',
			    		    esc_html__('Tada', 'seese-core')               => 'tada',
			    		    esc_html__('Swing', 'seese-core')              => 'swing',
			    		    esc_html__('Wobble', 'seese-core')             => 'wobble',
			    		    esc_html__('Pulse', 'seese-core')              => 'pulse',
			    		    esc_html__('Flip', 'seese-core')               => 'flip',
			    		    esc_html__('FlipInX', 'seese-core')            => 'flipInX',
			    		    esc_html__('FlipInY', 'seese-core')            => 'flipInY',
			    		    esc_html__('FadeIn', 'seese-core')             => 'fadeIn',
			    		    esc_html__('FadeInUp', 'seese-core')           => 'fadeInUp',
			    		    esc_html__('FadeInDown', 'seese-core')         => 'fadeInDown',
			    		    esc_html__('FadeInLeft', 'seese-core')         => 'fadeInLeft',
			    		    esc_html__('FadeInRight', 'seese-core')        => 'fadeInRight',
			    		    esc_html__('FadeInUpBig', 'seese-core')        => 'fadeInUpBig',
			    		    esc_html__('FadeInDownBig', 'seese-core')      => 'fadeInDownBig',
			    		    esc_html__('FadeInLeftBig', 'seese-core')      => 'fadeInLeftBig',
			    		    esc_html__('FadeInRightBig', 'seese-core')     => 'fadeInRightBig',
			    		    esc_html__('BounceIn', 'seese-core')           => 'bounceIn',
			    		    esc_html__('BounceInDown', 'seese-core')       => 'bounceInDown',
			    		    esc_html__('BounceInUp', 'seese-core')         => 'bounceInUp',
			    		    esc_html__('BounceInLeft', 'seese-core')       => 'bounceInLeft',
			    		    esc_html__('BounceInRight', 'seese-core')      => 'bounceInRight',
			    		    esc_html__('RotateIn', 'seese-core')           => 'rotateIn',
			    		    esc_html__('RotateInDownLeft', 'seese-core')   => 'rotateInDownLeft',
			    		    esc_html__('RotateInDownRight', 'seese-core')  => 'rotateInDownRight',
			    		    esc_html__('RotateInUpLeft', 'seese-core')     => 'rotateInUpLeft',
			    		    esc_html__('RotateInUpRight', 'seese-core')    => 'rotateInUpRight',
			    		    esc_html__('RollIn', 'seese-core')             => 'rollIn',
			    		  ),
			    		  'std' 			       => 'align_left',
			          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
			    		),
			    		array(
		            'type'             => 'colorpicker',
		            'heading'          => esc_html__( 'Title Text Color', 'seese-core' ),
		            'param_name'       => 'title_text_color',
		            'value'            => '',
		            'description'      => esc_html__( 'Select title text color.', 'seese-core'),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		          ),
		          array(
		            'type'             => 'colorpicker',
		            'heading'          => esc_html__( 'Price Text Color', 'seese-core' ),
		            'param_name'       => 'price_text_color',
		            'value'            => '',
		            'description'      => esc_html__( 'Select price text color.', 'seese-core'),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		          ),
		          array(
		            'type'             => 'colorpicker',
		            'heading'          => esc_html__( 'Product Details Text Color', 'seese-core' ),
		            'param_name'       => 'details_text_color',
		            'value'            => '',
		            'description'      => esc_html__( 'Select product details text color.', 'seese-core'),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		          ),
		          array(
		            'type'             => 'colorpicker',
		            'heading'          => esc_html__( 'Shop Now Text Color', 'seese-core' ),
		            'param_name'       => 'shopnow_text_color',
		            'value'            => '',
		            'description'      => esc_html__( 'Select shop now text color.', 'seese-core'),
		            'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		          ),
        		),
        	),

          VictorLib::seese_class_option(),

        )
      ) );
		}
  }
}
