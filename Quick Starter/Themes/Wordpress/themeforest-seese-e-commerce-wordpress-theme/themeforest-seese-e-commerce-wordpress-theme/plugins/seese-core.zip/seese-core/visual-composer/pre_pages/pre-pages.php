<?php
/* ==============================================
  Try to remove default template
=============================================== */
add_filter( 'vc_load_default_templates', 'seese_template_modify_array' );
function seese_template_modify_array($data) {
    return array(); // This will remove all default templates
}

/* ==============================================
  Create Custom Template in Visual Composer
=============================================== */

/* Home Page */
add_filter( 'vc_load_default_templates', 'vc_home_page' );
function vc_home_page($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Home Page - Example', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_product_slider slst_opt="" adaptive_height="true" infinite_loop="true" arrows="" pagination="true" autoplay="" pagination_color="light" slslng_opt="" animation="fade" pr_lsng_opt="" prlists="%5B%7B%22pr_title_text_one%22%3A%22Fitting%20Socket%22%2C%22pr_title_text_two%22%3A%22Matte%20Camel%22%2C%22pr_price%22%3A%22%2437.00%22%2C%22pr_details%22%3A%22Best%20Selling%20Product%20-%20April%22%2C%22shop_now_title%22%3A%22Shop%20Now%22%2C%22shop_now_link%22%3A%22http%3A%2F%2Fvictorthemes.com%2Fthemes%2Foutlet%2Fproduct%2Fstarwar-sports-bicycle%2F%22%2C%22text_position%22%3A%22h_left-v_center%22%2C%22text_alignment%22%3A%22align_left%22%2C%22text_animation%22%3A%22fadeInRight%22%2C%22title_text_color%22%3A%22%23252525%22%2C%22details_text_color%22%3A%22%23252525%22%2C%22shopnow_text_color%22%3A%22%23232323%22%7D%2C%7B%22pr_title_text_one%22%3A%22Organic%20Sand%22%2C%22pr_title_text_two%22%3A%22Dinner%20Party%20Set%22%2C%22pr_title_link%22%3A%22%23%22%2C%22pr_price%22%3A%22%2499.00%22%2C%22pr_details%22%3A%22Stainless%20material%22%2C%22shop_now_title%22%3A%22Shop%20Now%22%2C%22shop_now_link%22%3A%22http%3A%2F%2Fvictorthemes.com%2Fthemes%2Foutlet%2Fproduct%2Ftote-mens-backbag%2F%22%2C%22text_position%22%3A%22h_right-v_center%22%2C%22text_alignment%22%3A%22align_left%22%2C%22text_animation%22%3A%22fadeInRight%22%2C%22title_text_color%22%3A%22%23ffffff%22%2C%22price_text_color%22%3A%22%23ffffff%22%2C%22details_text_color%22%3A%22%23ffffff%22%2C%22shopnow_text_color%22%3A%22%23ffffff%22%7D%2C%7B%22pr_title_text_one%22%3A%22Vase%20Josh%22%2C%22pr_title_text_two%22%3A%22Herman%20Ceramics%22%2C%22pr_title_link%22%3A%22%23%22%2C%22pr_price%22%3A%22%2437.00%22%2C%22pr_details%22%3A%22Handmade%20Plastic%22%2C%22shop_now_title%22%3A%22Shop%20Now%22%2C%22shop_now_link%22%3A%22http%3A%2F%2Fvictorthemes.com%2Fthemes%2Foutlet%2Fproduct%2Ftote-mens-backbag%2F%22%2C%22text_position%22%3A%22h_left-v_center%22%2C%22text_alignment%22%3A%22align_left%22%2C%22text_animation%22%3A%22fadeInRight%22%2C%22title_text_color%22%3A%22%23232323%22%2C%22shopnow_text_color%22%3A%22%23232323%22%7D%5D"][vcts_product_categories cat_pr_count="true" cat_des="true" cat_hide_empty="" cat_parent="" cat_hover_anim="true" cat_order="DESC" cat_orderby="count" cat_ids="17,19,21" cat_bg_color="#eeeeee"][vcts_product pr_column="shop_col_4" pr_limit="20" pr_cat_fltr="true" pr_widget_fltr="true" pr_fltr_mode="true" pr_nav="true" pr_order="DESC" pr_orderby="date"][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}


/* Home Page Masonry */
add_filter( 'vc_load_default_templates', 'vc_home_masonry' );
function vc_home_masonry($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Home Masonry', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_product_slider slst_opt="" adaptive_height="true" infinite_loop="true" arrows="" pagination="true" autoplay="" pagination_color="dark" slslng_opt="" animation="fade" pr_lsng_opt="" prlists="%5B%7B%22pr_title_link%22%3A%22%23%22%2C%22pr_price%22%3A%22%24180.50%22%2C%22pr_details%22%3A%22Handmade%20Chairs%22%2C%22shop_now_title%22%3A%22Shop%20Now%22%2C%22shop_now_link%22%3A%22http%3A%2F%2Fvictorthemes.com%2Fthemes%2Foutlet%2Fproduct%2Fproduct-number-one%2F%22%2C%22text_position%22%3A%22h_left-v_center%22%2C%22text_alignment%22%3A%22align_left%22%2C%22text_animation%22%3A%22fadeInLeft%22%2C%22title_text_color%22%3A%22%23232323%22%2C%22shopnow_text_color%22%3A%22%23232323%22%7D%2C%7B%22pr_price%22%3A%22%24180.50%22%2C%22pr_details%22%3A%22Handmade%20Bags%22%2C%22shop_now_title%22%3A%22Shop%20Now%22%2C%22shop_now_link%22%3A%22http%3A%2F%2Fvictorthemes.com%2Fthemes%2Foutlet%2Fproduct%2Ftote-mens-backbag%2F%22%2C%22text_position%22%3A%22h_right-v_center%22%2C%22text_alignment%22%3A%22align_left%22%2C%22text_animation%22%3A%22fadeInLeft%22%2C%22title_text_color%22%3A%22%23232323%22%2C%22shopnow_text_color%22%3A%22%23232323%22%7D%2C%7B%22pr_title_text_one%22%3A%22Tote%20men%E2%80%99s%20backbag%22%2C%22pr_price%22%3A%22%24180.50%22%2C%22pr_details%22%3A%22Handmade%20Bags%22%2C%22shop_now_title%22%3A%22Shop%20Now%22%2C%22shop_now_link%22%3A%22http%3A%2F%2Fvictorthemes.com%2Fthemes%2Foutlet%2Fproduct%2Ftote-mens-backbag%2F%22%2C%22text_position%22%3A%22h_left-v_center%22%2C%22text_alignment%22%3A%22align_left%22%2C%22text_animation%22%3A%22fadeInLeft%22%2C%22title_text_color%22%3A%22%23232323%22%2C%22shopnow_text_color%22%3A%22%23232323%22%7D%5D"][vcts_product pr_style="shop-masonry" pr_limit="14" pr_cat_fltr="true" pr_widget_fltr="true" pr_fltr_mode="true" pr_nav="true" pr_order="ASC" pr_orderby="date"][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}


/* Home Sidebar */
add_filter( 'vc_load_default_templates', 'vc_home_sidebar' );
function vc_home_sidebar($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Home Sidebar - Example', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_product layout_opt="" pr_limit="15" enable_opt="" pr_cat_fltr="" pr_widget_fltr="" pr_fltr_mode="" pr_nav="true" lsng_opt="" pr_order="ASC" pr_orderby="date"][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}


/* Home Category */
add_filter( 'vc_load_default_templates', 'vc_home_category' );
function vc_home_category($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Home Category', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_product_categories cat_style="cats_slider" loop="true" nav="true" dots="" autoplay="" cat_pr_count="true" cat_des="true" cat_hide_empty="" cat_parent="" cat_hover_anim="true" cat_order="DESC" cat_orderby="ID" cat_bg_color="#eeeeee"][vcts_product layout_opt="" pr_column="shop_col_4" pr_limit="16" enable_opt="" pr_cat_fltr="true" pr_widget_fltr="true" pr_fltr_mode="" pr_nav="true" pr_nav_style="seese-pagination-three" lsng_opt="" pr_order="ASC" pr_orderby="date"][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}


/* Home Full Width */
add_filter( 'vc_load_default_templates', 'vc_home_fullwidth' );
function vc_home_fullwidth($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Home Fullwidth', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_product layout_opt="" pr_style="shop-fullwidth" pr_limit="12" enable_opt="" pr_cat_fltr="" pr_widget_fltr="" pr_fltr_mode="" pr_nav="" lsng_opt="" pr_order="ASC" pr_orderby="date"][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}


/* Shop Category */
add_filter( 'vc_load_default_templates', 'vc_shop_category' );
function vc_shop_category($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Shop Category', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_product_categories cat_lt_opt="" cat_style="cats_masonry" cat_ed_opt="" cat_pr_count="true" cat_des="true" cat_hide_empty="" cat_parent="" cat_hover_anim="true" cat_stl_opt="" cat_lst_opt="" cat_order="DESC" cat_limit="6" cat_ids="49,38,48,47,24,16" cat_bg_color="#eeeeee"][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}


/* Shop Carousel */
add_filter( 'vc_load_default_templates', 'vc_shop_carousel' );
function vc_shop_carousel($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Shop Carousel', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_product layout_opt="" pr_style="shop-carousel" pr_column="shop_col_5" pr_limit="25" pr_sl_loop="" pr_sl_nav="" pr_sl_dots="true" pr_sl_autoplay="" enable_opt="" pr_cat_fltr="true" pr_widget_fltr="true" lsng_opt=""][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}



/* About Page */
add_filter( 'vc_load_default_templates', 'vc_about_page' );
function vc_about_page($data) {
    $template               = array();
    $template['name']       = esc_html__( 'About Page', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row full_width="stretch_row_content_no_spaces" overlay_dotted="" css=".vc_custom_1486222925298{margin-bottom: 60px !important;}"][vc_column][vc_single_image source="featured_image" img_size="full" alignment="center"][/vc_column][/vc_row][vc_row overlay_dotted="" css=".vc_custom_1480087157667{margin-bottom: 80px !important;}"][vc_column][vc_column_text css=".vc_custom_1492434089927{margin-bottom: 16px !important;}"]
<h1 style="text-align: center; line-height: 42px; margin-bottom: 18px;"><strong><span style="font-size: 38px;">Hello, We are Seese.
Established in 2001 – Spain.</span></strong></h1>
<p style="max-width: 957px; margin: 0 auto; text-align: center; font-family: 'Lora', Arial, sans-serif; font-style: italic; font-size: 18px; color: #999; line-height: 32px;">Seese was founded in 2001 by Jack Sparrow and Will Turner, both alumni of the Oxford University. They worked for ebay.com, and left to create their new company incorporated in October 2001 as Seese Online Services Pvt. Ltd. in Spain that mainly focused in online shopping.</p>

[/vc_column_text][vcts_button button_text="SHOP NOW" button_link="http://victorthemes.com/themes/outlet/shop/" open_link="" simple_hover="" button_align="center" button_size="btn-large"][/vc_column][/vc_row][vc_row overlay_dotted="" css=".vc_custom_1480523217711{margin-bottom: 4px !important;}"][vc_column][vcts_video video_btn_img="692" video_iframe_link="https://player.vimeo.com/video/31050469" video_style="certain-width" video_link="https://www.youtube.com/embed/t_YXSHkAahE"][/vc_column][/vc_row][vc_row overlay_dotted="" css=".vc_custom_1487425049694{margin-bottom: 0px !important;border-bottom-width: 0px !important;padding-bottom: 0px !important;border-bottom-style: solid !important;}"][vc_column width="1/3"][vcts_counter cntr_value="75" cntr_suffix="K" cntr_title="Customers" cntr_details="Worldwide Satisfied Clients"][/vc_column][vc_column width="1/3"][vcts_counter cntr_value="10" cntr_super="+" cntr_title="Years of Service" cntr_details="Established on April 2011"][/vc_column][vc_column width="1/3"][vcts_counter cntr_value="43" cntr_title="Stores worldwide" cntr_details="Delivery Within 3 Days"][/vc_column][/vc_row][vc_row overlay_dotted="" css=".vc_custom_1487424708246{margin-bottom: 0px !important;border-bottom-width: 0px !important;padding-bottom: 15px !important;border-bottom-style: solid !important;}"][vc_column][vc_separator css=".vc_custom_1487425139518{margin-top: 0px !important;margin-right: 0px !important;margin-bottom: 0px !important;margin-left: 0px !important;border-bottom-width: 1px !important;padding-top: 17px !important;padding-right: 0px !important;padding-bottom: 97px !important;padding-left: 0px !important;border-bottom-color: #f0f0f0 !important;}"][vc_column_text css=".vc_custom_1480528081032{margin-bottom: 71px !important;}"]
<h2 style="text-align: center;"><strong><span style="font-size: 35px;">Team Members</span></strong></h2>
[/vc_column_text][vcts_team team_columns="seese-team-col-3" team_limit="3" team_member_details="true" team_member_job="true" team_order="ASC" team_orderby="date" cv_opt="" sh_opt="" team_text="true" team_popup="true" blog_date="true" blog_author="true" blog_popup="true" blog_excerpt="true" blog_read_more="true"][/vc_column][/vc_row][vc_row overlay_dotted="" css=".vc_custom_1480529273671{margin-bottom: 92px !important;}"][vc_column][vc_separator css=".vc_custom_1487424899987{margin-top: 0px !important;margin-right: 0px !important;margin-bottom: 0px !important;margin-left: 0px !important;border-bottom-width: 1px !important;padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 80px !important;padding-left: 0px !important;border-bottom-color: #f0f0f0 !important;}"][vcts_testimonial testi_image="true" testi_name="true" testi_profession="true" testi_nav="" testi_dots="true" testi_autoplay="" testi_order="ASC" testi_orderby="date" cv_opt="" nav="true" dots="" autoplay=""][/vc_column][/vc_row][vc_row overlay_dotted=""][vc_column][vcts_image_slider layout_opt="" items_cnt="6" style_opt="" loop="true" nav="" dots="" autoplay=""][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}


/*Blog Standard Full Width */
add_filter( 'vc_load_default_templates', 'vc_blog_standard_fullwidth' );
function vc_blog_standard_fullwidth($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Blog Standard Fullwidth', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_blog blog_limit="5" ed_opt="" blog_category="true" blog_date="true" blog_author="true" blog_popup="true" blog_excerpt="true" blog_read_more="true" blog_pagination="true" blog_pagination_style="seese-pagination-two" lsng_opt="" blog_order="DESC" blog_orderby="date" sh_opt=""][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}

/* Blog Standard Two Column */
add_filter( 'vc_load_default_templates', 'vc_blog_standard_twocolumn' );
function vc_blog_standard_twocolumn($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Blog Standard - Two Column', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_blog blog_columns="seese-blog-col-2" ed_opt="" blog_category="true" blog_date="true" blog_author="true" blog_popup="true" blog_excerpt="true" blog_read_more="true" blog_pagination="true" blog_pagination_style="seese-pagination-three" lsng_opt="" blog_order="DESC" blog_orderby="date" sh_opt=""][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}


/* Blog Standard Three Column  */
add_filter( 'vc_load_default_templates', 'vc_blog_standard_threecolumn' );
function vc_blog_standard_threecolumn($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Blog Standard - Three Column', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_blog blog_columns="seese-blog-col-3" ed_opt="" blog_category="true" blog_date="true" blog_author="true" blog_popup="true" blog_excerpt="true" blog_read_more="true" blog_pagination="true" lsng_opt="" blog_order="DESC" blog_orderby="title" sh_opt=""][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}


/*  Blog Standard Side Bar  */
add_filter( 'vc_load_default_templates', 'vc_blog_standard_sidebar' );
function vc_blog_standard_sidebar($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Blog Standard - Sidebar', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_blog blog_limit="5" ed_opt="" blog_category="true" blog_date="true" blog_author="true" blog_popup="true" blog_excerpt="true" blog_read_more="true" blog_pagination="true" blog_excerpt_length="34" read_more_text="Continue Reading" lsng_opt="" blog_order="DESC" blog_orderby="date" sh_opt=""][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}

/* Blog Masonry Full Width */
add_filter( 'vc_load_default_templates', 'vc_blog_masonry_fullwidth' );
function vc_blog_masonry_fullwidth($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Blog Masonry - Full Width', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_blog blog_style="seese-blog-two" ed_opt="" blog_category="true" blog_date="true" blog_author="true" blog_popup="true" blog_excerpt="true" blog_read_more="true" blog_pagination="true" blog_pagination_style="seese-pagination-two" lsng_opt="" blog_order="ASC" blog_orderby="ID" sh_opt=""][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}

/* Blog Masonry Two Column */
add_filter( 'vc_load_default_templates', 'vc_blog_masonry_twocolumn' );
function vc_blog_masonry_twocolumn($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Blog Masonry - Two Column', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_blog blog_style="seese-blog-two" blog_columns="seese-blog-col-2" ed_opt="" blog_category="true" blog_date="true" blog_author="true" blog_popup="true" blog_excerpt="true" blog_read_more="true" blog_pagination="true" lsng_opt="" blog_order="DESC" blog_orderby="date" sh_opt=""][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}

/* Blog Masonry Three Column */
add_filter( 'vc_load_default_templates', 'vc_blog_masonry_threecolumn' );
function vc_blog_masonry_threecolumn($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Blog Masonry - Three Column - Example', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_blog blog_style="seese-blog-two" blog_columns="seese-blog-col-3" blog_limit="9" ed_opt="" blog_category="true" blog_date="true" blog_author="" blog_popup="" blog_excerpt="true" blog_read_more="true" blog_pagination="true" blog_excerpt_length="34" read_more_text="Continue Reading" lsng_opt="" blog_order="ASC" blog_orderby="ID" sh_opt=""][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}

/* Blog Masonry With Sidebar */
add_filter( 'vc_load_default_templates', 'vc_blog_masonry_sidebar' );
function vc_blog_masonry_sidebar($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Blog Masonry - Sidebar', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vcts_blog blog_style="seese-blog-two" blog_limit="5" ed_opt="" blog_category="true" blog_date="true" blog_author="true" blog_popup="true" blog_excerpt="true" blog_read_more="true" blog_pagination="true" blog_pagination_style="seese-pagination-three" lsng_opt="" blog_order="DESC" blog_orderby="date" sh_opt=""][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}

/* Blog Single Post */
add_filter( 'vc_load_default_templates', 'vc_blog_single_post' );
function vc_blog_single_post($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Blog Single Post', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vc_column_text][seese_dropcap]A[/seese_dropcap] Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps. Nanotechnology immersion along the information highway will close the loop on focusing solely on the bottom line.Podcasting operational change management inside of workflows to establish a framework. Taking seamless key performance indicators offline to maximise the long tail. Keeping your eye on the ball while performing a deep dive on the start-up mentality to derive convergence on cross-platform integration.
<h5>A perfect fit.</h5>
Once I gave the headphones a thorough once-over exam, I tried them on. As I mentioned, they have a classic over-the-ear style and just looking at them, the padding <strong><em><u>on the ear pieces</u></em></strong> seem adequate and the the product. So, I slipped the headphones on and found them to be exquisitely comfortable.
<blockquote>“User engagement and experience has become a major focus for any web-based service in recent years”</blockquote>
<h5></h5>
&nbsp;
<h5>Quality First Impressions.</h5>
Now that I had the headphones on my head, I was finally ready to plug and play some music. I plugged the provided cable into the jack on the headphones and then the one on my iPhone 6. Then I called up Pandora. I tend to have a very eclectic music purview and have many stations set up for different moods. From <strong>John Williams to Fallout Boy</strong>, the sound quality of these headphones was remarkable. There is an amazing depth of sound and incredible highs and lows that make listening to music a truly breathtaking experience.

Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation streamlined cloud solution for offshoring.

<em>I would highly recommend these to any sound mixing specialist.</em>[/vc_column_text][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}



/* Contact Page */
add_filter( 'vc_load_default_templates', 'vc_contact_page' );
function vc_contact_page($data) {
    $template               = array();
    $template['name']       = esc_html__( 'Contact Page', 'seese-core' );
    $template['content']    = <<<CONTENT
[vc_row][vc_column][vc_empty_space height="94px"][vc_column_text]
<h3 style="text-align: center; margin-bottom: 0;"><strong><span style="font-size: 35px;">Get In Touch</span></strong></h3>
<p style="text-align: center; padding-bottom: 13px; padding-top: 2px; letter-spacing: .9px;"><span style="font-size: 15px;">Don’t hesitate to chat with me, just drop a line</span></p>
[/vc_column_text][/vc_column][/vc_row][vc_row overlay_dotted="" css=".vc_custom_1480491358682{margin-top: 0px !important;margin-right: 0px !important;margin-bottom: 25px !important;margin-left: 0px !important;border-top-width: 0px !important;border-right-width: 0px !important;border-bottom-width: 0px !important;border-left-width: 0px !important;padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;}"][vc_column css=".vc_custom_1478579926524{margin: 0px !important;border-width: 0px !important;padding: 0px !important;}"][otlt_gmap gmap_api="AIzaSyAKPMpRTK6Ov61NrSFLBRkGuwjLY6NhD2U" gmap_type="ROADMAP" gmap_style="shades-grey" gmap_zoom="" gmap_height="580" gmap_scroll_wheel="" gmap_street_view="" gmap_maptype_control="" locations="%5B%7B%22latitude%22%3A%2241.041541%22%2C%22longitude%22%3A%22-73.769744%22%7D%5D"][/vc_column][/vc_row][vc_row][vc_column width="2/3"][contact-form-7 id="12"][/vc_column][vc_column width="1/3"][vc_column_text]Love it, or leave it. snap into a slim jim! hangman yeah! the mad ness is runnin' wild! hangman freak out! freak out! hangman and your neck could be broken! bonesaw's ready! diamond dallas page vertical suplex oooooh yeeeah!
<h6>ADDRESS</h6>
44 New Design Street, Melbourne 005
Australia 300

<hr />

<h6>CONTACT INFO</h6>
E: <a style="color: #666;" href="mailto:info@victorthemes.com">info@victorthemes.com</a>
<a style="color: #666;" href="tel:01 (800) 433 633">01 (800) 433 633</a>

<hr />

<h6>SOCIAL SHARE</h6>
[seese_socials social_select="style-two" icon_size="16px" icon_color="#888888" icon_hover_color="#35373e"][seese_social social_link="#" social_icon="fa fa-twitter"][seese_social social_link="#" social_icon="fa fa-facebook"][seese_social social_link="#" social_icon="fa fa-google-plus"][seese_social social_link="#" social_icon="fa fa-linkedin"][seese_social social_link="#" social_icon="fa fa-youtube-play"][seese_social social_link="#" social_icon="fa fa-instagram"][/seese_socials]

<hr />

[/vc_column_text][/vc_column][/vc_row]
CONTENT;
    array_unshift($data, $template);
    return $data;
}
