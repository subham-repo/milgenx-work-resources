<?php

/* Spacer */
function seese_spacer_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "height" => '',
  ), $atts));

  $result = do_shortcode('[vc_empty_space height="'. $height .'"]');
  return $result;

}
add_shortcode("seese_spacer", "seese_spacer_function");

/* Social Icons */
function seese_socials_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "social_select" => '',
    "custom_class" => '',
    // Colors
    "icon_color" => '',
    "icon_hover_color" => '',
    "bg_color" => '',
    "bg_hover_color" => '',
    "border_color" => '',
    "icon_size" => '',
    "top_space" => '',
    "bottom_space" => '',
  ), $atts));

  // Atts
  if($social_select === 'style-one') {
    $social_style = 'seese-social-one ';
    $social_open = '';
    $social_close = '';
  } elseif($social_select === 'style-two') {
    $social_style = 'seese-social-two ';
    $social_open = '';
    $social_close = '';
  } else {
    $social_style = 'seese-social ';
    $social_open = '';
  }

  // Shortcode Style CSS
  $e_uniqid       = uniqid();
  $inline_style   = '';

  if ( $top_space || $bottom_space ) {
    $inline_style .= '.seese-socials-'. $e_uniqid .'.seese-social, .seese-socials-'. $e_uniqid .'.seese-social-one, .seese-socials-'. $e_uniqid .'.seese-social-two{';
    $inline_style .= ( $top_space ) ? 'padding-top:'. seese_check_px($top_space) .';' : '';
    $inline_style .= ( $bottom_space ) ? 'padding-bottom:'. seese_check_px($bottom_space) .';' : '';
    $inline_style .= '}';
  }

  if( $social_select === 'style-one' ) {
    if ( isset($icon_color) || isset($icon_size) ) {
      $inline_style .= '.seese-socials-'. $e_uniqid .'.seese-social-one li a{';
      $inline_style .= ( $icon_color ) ? 'color:'. $icon_color .';' : '';
      $inline_style .= ( $icon_size ) ? 'font-size:'. seese_check_px($icon_size) .';' : '';
      $inline_style .= '}';
    }

    if ( $bg_color ) {
      $inline_style .= '.seese-socials-'. $e_uniqid .'.seese-social-one li a{';
      $inline_style .= ( $bg_color ) ? 'background-color:'. $bg_color .';' : '';
      $inline_style .= '}';
    }
    if ( $bg_hover_color ) {
      $inline_style .= '.seese-socials-'. $e_uniqid .'.seese-social-one li a:hover{';
      $inline_style .= ( $bg_hover_color ) ? 'background-color:'. $bg_hover_color .';' : '';
      $inline_style .= ( $icon_hover_color ) ? 'color:'. $icon_hover_color .';' : '';
      $inline_style .= '}';
    }
    if ( $border_color ) {
      $inline_style .= '.seese-socials-'. $e_uniqid .'.seese-social-one li a{';
      $inline_style .= ( $border_color ) ? 'border-color:'. $border_color .';' : '';
      $inline_style .= '}';
    }
  }

  if( $social_select === 'style-two' ) {
    if ( isset($icon_color) || isset($icon_size) ) {
      $inline_style .= '.seese-socials-'. $e_uniqid .'.seese-social-two li a{';
      $inline_style .= ( $icon_color ) ? 'color:'. $icon_color .';' : '';
      $inline_style .= ( $icon_size ) ? 'font-size:'. seese_check_px($icon_size) .';' : '';
      $inline_style .= '}';
    }
    if ( isset($icon_hover_color )) {
      $inline_style .= '.seese-socials-'. $e_uniqid .'.seese-social-two li a:hover{';
      $inline_style .= ( $icon_hover_color ) ? 'color:'. $icon_hover_color .';' : '';
      $inline_style .= '}';
    }
  }

  // add inline style
  seese_add_inline_style( $inline_style );
  $styled_class  = ' seese-socials-'. $e_uniqid;

  $result = $social_open .'<ul class="clearfix '. $social_style . $custom_class . $styled_class .'">'. do_shortcode($content) .'</ul>'. $social_close;
  return $result;

}
add_shortcode("seese_socials", "seese_socials_function");

/* Social Icon */
function seese_social_function($atts, $content = NULL) {
   extract(shortcode_atts(array(
      "social_link" => '',
      "social_icon" => '',
      "social_text" => '',
      "target_tab" => ''
   ), $atts));

   $social_link = ( isset( $social_link ) ) ? 'href="'. $social_link . '"' : '';
   $social_text = ( isset( $social_text ) ) ? $social_text : '';
   $target_tab = ( $target_tab === '1' ) ? ' target="_blank"' : '';

   $result = '<li><a '. $social_link . $target_tab .' class="'. str_replace('fa ', 'icon-', $social_icon) .'"><i class="'. $social_icon .'"></i>'. $social_text .'</a></li>';
   return $result;

}
add_shortcode("seese_social", "seese_social_function");

/* Dropcap */
function seese_dropcap_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "custom_class" => '',
    "size" => '',
    "color" => '',
  ), $atts));

  // Shortcode Style CSS
  $e_uniqid = uniqid();
  $inline_style  = '';

  // Text Color
  $inline_style .= '.seese-dropcap-'. $e_uniqid .'{';
  $inline_style .= ($size) ? 'font-size:'. seese_check_px($size) .';' : '';
  $inline_style .= ($color) ? 'color:'. $color .';' : '';
  $inline_style .= '}';

  // add inline style
  seese_add_inline_style( $inline_style );
  $styled_class  = ' seese-dropcap-'. $e_uniqid;

  $result = '<span class="seese-dropcap '.$custom_class . $styled_class .'">'. do_shortcode($content) .'</span>';
  return $result;

}
add_shortcode("seese_dropcap", "seese_dropcap_function");

/* List Styles Lists */
function seese_lists_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "list_select" => '',
    "custom_class" => '',
    // Colors
    "text_color" => '',
    "text_size" => '',
  ), $atts));

  // Shortcode Style CSS
  $e_uniqid       = uniqid();
  $inline_style   = '';

  if ( $text_color || $text_size ) {
    $inline_style .= '.seese-list-'. $e_uniqid .' li {';
    $inline_style .= ( $text_color ) ? 'color:'. $text_color .';' : '';
    $inline_style .= ( $text_size ) ? 'font-size:'. seese_check_px($text_size) .';' : '';
    $inline_style .= '}';
  }
  // add inline style
  seese_add_inline_style( $inline_style );
  $styled_class  = ' seese-list-'. $e_uniqid;

  // Output
  $output = '';

  if($list_select === 'unordered-list'){
    $output .= '<ul class="'. $custom_class . $styled_class .'">';
    $output .= do_shortcode($content);
    $output .= '</ul>';
  } else {
    $output .= '<ol class="'. $custom_class . $styled_class .'">';
    $output .= do_shortcode($content);
    $output .= '</ol>';
  }

  return $output;

}
add_shortcode("seese_lists", "seese_lists_function");

/* List Styles List */
function seese_list_function($atts, $content = NULL) {
  extract(shortcode_atts(array(
    "list_text" => '',
  ), $atts));

  // Atts
  $list_text = $list_text ? $list_text : '';

  $result = '<li>'. $list_text .'</li>';
  return $result;

}
add_shortcode("seese_list", "seese_list_function");

/* WPML */
function seese_wpml_function($atts, $content = NULL) {
  extract(shortcode_atts(array(
    "custom_class" => '',
    "wpml_flag" => '',
    'wpml_lang' => ''
  ), $atts));

  $output   = '';

  if ( is_wpml_activated() ) {
    global $sitepress;
    $sitepress_settings = $sitepress->get_settings();
    $icl_get_languages  = icl_get_languages();

    if ( ! empty( $icl_get_languages ) ) {
        // Dropdown View
      $languages = icl_get_languages('skip_missing=0&orderby=code');
        $output .= '<div class="seese-tr-element '. $custom_class .'"><div class="seese-top-dropdown seese-wpml-dropdown">';
          if (!$wpml_lang && !$wpml_flag )  {
            $align_cls = 'both-flag-lang';
          } elseif (!$wpml_lang)  {
            $align_cls = 'only-lang';
          } elseif (!$wpml_flag)  {
            $align_cls = 'only-flag';
          } else {
            $align_cls = '';
          }

          // current language
          $output .= '<a href="#" class="seese-top-active '.$align_cls.'">';
          foreach ( $languages as $current_lang ) {

                if ( $current_lang['active'] ) {
                  if (!$wpml_flag)  {
                    $output .= '<img src="'.$current_lang['country_flag_url'].'" height="12" alt="'.$current_lang['language_code'].'" width="18" />';
                  }
                  if(!$wpml_lang) {
                    $output .= $current_lang['language_code'];
                  }
                    $output .= '<i class="fa fa-angle-down"></i>';
                }
          }
          $output .= '</a>';

          // list languages
          $output .= '<ul class="seese-topdd-content '.$align_cls.'">';
          foreach ( $languages as $language ) {
            if ( ! $language['active'] ) {

                $output .= '<li>';
                $output .= '<a href="'. $language['url'] .'">';
              if (!$wpml_flag)  {
                $output .= '<img src="'.$language['country_flag_url'].'" height="12" alt="'.$language['language_code'].'" width="18" />';
              }
              if(!$wpml_lang) {
                $output .= $language['language_code'];
              }
                $output .= '</a>';
                $output .= '</li>';
            }
            // print_r($language);
          }
          $output .= '</ul>';
          $output .= '</div>';
          $output .= '</div>';

  }

  } else {
    $output .= '<p class="wpml-not-active">Please Activate WPML Plugin</p>';
  }

  return $output;

}
add_shortcode("seese_wpml", "seese_wpml_function");

/* Current Year - Shortcode */
if( ! function_exists( 'seese_current_year' ) ) {
  function seese_current_year() {
    return date('Y');
  }
  add_shortcode( 'seese_current_year', 'seese_current_year' );
}

/* Get Home Page URL - Via Shortcode */
if( ! function_exists( 'seese_home_url' ) ) {
  function seese_home_url() {
    return esc_url( home_url( '/' ) );
  }
  add_shortcode( 'seese_home_url', 'seese_home_url' );
}