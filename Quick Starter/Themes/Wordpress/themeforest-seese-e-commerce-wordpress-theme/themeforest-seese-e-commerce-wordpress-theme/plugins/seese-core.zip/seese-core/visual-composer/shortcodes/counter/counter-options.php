<?php
/**
 * Counter - Shortcode Options
 */
add_action( 'init', 'vcts_cntr_vc_map' );

if ( ! function_exists( 'vcts_cntr_vc_map' ) ) {

  function vcts_cntr_vc_map() {

    vc_map( array(
      'name'        => esc_html__( 'Counter', 'seese-core'),
      'base'        => 'vcts_counter',
      'description' => esc_html__( 'Counter Styles', 'seese-core'),
      'icon'        => 'fa fa-clock-o color-blue',
      'category'    => VictorLib::vcts_cat_name(),
      'params'      => array(

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Value', 'seese-core' ),
          'param_name'       => 'cv_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Value', 'seese-core'),
          'param_name'       => 'cntr_value',
          'value'            => '',
          'admin_label'      => true,
          'description'      => esc_html__( 'Enter the value for counter (integers, floats or formatted numbers).', 'seese-core'),
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Value Prefix', 'seese-core'),
          'param_name'       => 'cntr_prefix',
          'value'            => '',
          'description'      => esc_html__( 'Enter prefix for counter value.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Value Suffix', 'seese-core'),
          'param_name'       => 'cntr_suffix',
          'value'            => '',
          'description'      => esc_html__( 'Enter suffix for counter value.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Value Super Script', 'seese-core'),
          'param_name'       => 'cntr_super',
          'value'            => '',
          'description'      => esc_html__( 'Enter super script for counter value.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__( 'Text Size', 'seese-core' ),
          'param_name'       => 'cntr_value_size',
          'value'            => '',
          'description'      => esc_html__( 'Enter text size for counter value in px.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'colorpicker',
          'heading'          => esc_html__( 'Text Color', 'seese-core' ),
          'param_name'       => 'cntr_value_color',
          'value'            => '',
          'description'      => esc_html__( 'Choose color for counter value.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__( 'Count Duration', 'seese-core' ),
          'param_name'       => 'cntr_duration',
          'value'            => '',
          'description'      => esc_html__( 'Enter total duration time in ms.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Title', 'seese-core' ),
          'param_name'       => 'ct_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Title', 'seese-core'),
          'param_name'       => 'cntr_title',
          'value'            => '',
          'admin_label'      => true,
          'description'      => esc_html__( 'Enter the title for counter.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__( 'Text Size', 'seese-core' ),
          'param_name'       => 'cntr_title_size',
          'value'            => '',
          'description'      => esc_html__( 'Enter text size for counter title in px.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'colorpicker',
          'heading'          => esc_html__( 'Text Color', 'seese-core' ),
          'param_name'       => 'cntr_title_color',
          'value'            => '',
          'description'      => esc_html__( 'Choose color for counter title.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Details', 'seese-core' ),
          'param_name'       => 'cd_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Details', 'seese-core'),
          'param_name'       => 'cntr_details',
          'value'            => '',
          'description'      => esc_html__( 'Enter the details for counter.', 'seese-core'),
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__( 'Text Size', 'seese-core' ),
          'param_name'       => 'cntr_details_size',
          'value'            => '',
          'description'      => esc_html__( 'Enter text size for the counter details in px.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          'type'             => 'colorpicker',
          'heading'          => esc_html__( 'Text Color', 'seese-core' ),
          'param_name'       => 'cntr_details_color',
          'value'            => '',
          'description'      => esc_html__( 'Choose color for counter details.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),

        VictorLib::seese_class_option(),

      )
    ) );
  }
}
