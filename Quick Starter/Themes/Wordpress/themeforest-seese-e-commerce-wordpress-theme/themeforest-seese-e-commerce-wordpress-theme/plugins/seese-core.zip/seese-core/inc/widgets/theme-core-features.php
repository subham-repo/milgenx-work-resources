<?php
/*
 * Core Features Widget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

class seese_core_feature extends WP_Widget {

  /**
   * Specifies the widget name, description, class name and instatiates it
   */
  public function __construct() {
    parent::__construct(
      'seese-core-feature',
      VTHEME_NAME_P . esc_html__( ' : Core Features', 'seese' ),
      array(
        'classname'   => 'seese-core-feature',
        'description' => VTHEME_NAME_P . esc_html__( ' widget that displays core feature.', 'seese' )
      )
    );
  }

  /**
   * Generates the back-end layout for the widget
   */
  public function form( $instance ) {

    // Default Values
    $instance = wp_parse_args( $instance, array(
      'feature_heading'    => '',
      'feature_content'    => '',
      'feature_icon_type'  => '',
      'feature_image_icon' => '',
      'feature_font_icon'  => '',
      'feature_link'       => '',
    ));

    // Core Feature Heading
    $feature_heading_value = $instance['feature_heading'];
    $feature_heading_field = array(
      'id'           => $this->get_field_name('feature_heading'),
      'name'         => $this->get_field_name('feature_heading'),
      'type'         => 'text',
      'title'        => esc_html__( 'Heading', 'seese' ),
      'wrap_class'   => 'seese-cs-widget-fields',
    );
    echo cs_add_element( $feature_heading_field, $feature_heading_value );

    // Core Feature Content
    $feature_content_value = $instance['feature_content'];
    $feature_content_field = array(
      'id'           => $this->get_field_name('feature_content'),
      'name'         => $this->get_field_name('feature_content'),
      'type'         => 'textarea',
      'title'        => esc_html__( 'Content', 'seese' ),
      'wrap_class'   => 'seese-cs-widget-fields',
    );
    echo cs_add_element( $feature_content_field, $feature_content_value );

    // Core Feature Image type
    $feature_icon_type_value = esc_attr( $instance['feature_icon_type'] );
    $feature_icon_type_field = array(
      'id'              => $this->get_field_name('feature_icon_type'),
      'name'            => $this->get_field_name('feature_icon_type'),
      'type'            => 'select',
      'options'         => array(
        'image_icon'    => 'Image Icon',
        'font_icon'     => 'Font Icon',
      ),
      'default_option'  => esc_html__( 'Select Icon Type', 'seese' ),
      'title'           => esc_html__( 'Icon Type', 'seese' ),
    );
    echo cs_add_element( $feature_icon_type_field, $feature_icon_type_value );

    // Core Feature Image
    $feature_image_icon_value = $instance['feature_image_icon'];
    $feature_image_icon_field = array(
      'id'           => $this->get_field_name('feature_image_icon'),
      'name'         => $this->get_field_name('feature_image_icon'),
      'type'         => 'image',
      'title'        => esc_html__( 'Image', 'seese' ),
      'wrap_class'   => 'seese-cs-widget-fields',
      'dependency'   => array( $this->get_field_name('feature_icon_type'), '==', 'image_icon'),
    );
    echo cs_add_element( $feature_image_icon_field, $feature_image_icon_value );

    // Core Feature Icon
    $feature_font_icon_value = $instance['feature_font_icon'];
    $feature_font_icon_field = array(
      'id'           => $this->get_field_name('feature_font_icon'),
      'name'         => $this->get_field_name('feature_font_icon'),
      'type'         => 'icon',
      'title'        => esc_html__( 'Font Icon', 'seese' ),
      'wrap_class'   => 'seese-cs-widget-fields',
      'dependency'   => array( $this->get_field_name('feature_icon_type'), '==', 'font_icon'),
    );
    echo cs_add_element( $feature_font_icon_field, $feature_font_icon_value );

    // Core Feature Link
    $feature_link_value = $instance['feature_link'];
    $feature_link_field = array(
      'id'           => $this->get_field_name('feature_link'),
      'name'         => $this->get_field_name('feature_link'),
      'type'         => 'text',
      'title'        => esc_html__( 'Link', 'seese' ),
      'wrap_class'   => 'seese-cs-widget-fields',
    );
    echo cs_add_element( $feature_link_field, $feature_link_value );
  }

  /**
   * Processes the widget's values
   */
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;

    // Update values
    $instance['feature_heading']    = $new_instance['feature_heading'];
    $instance['feature_content']    = $new_instance['feature_content'];
    $instance['feature_icon_type']  = $new_instance['feature_icon_type'];
    $instance['feature_image_icon'] = $new_instance['feature_image_icon'];
    $instance['feature_font_icon']  = $new_instance['feature_font_icon'];
    $instance['feature_link']       = $new_instance['feature_link'];

    return $instance;
  }

  /**
   * Output the contents of the widget
   */
  public function widget( $args, $instance ) {
    // Extract the arguments
    extract( $args );

    $feature_heading     = $instance['feature_heading'];
    $feature_content     = $instance['feature_content'];
    $feature_icon_type   = $instance['feature_icon_type'];
    $feature_image_icon  = $instance['feature_image_icon'];
    $feature_font_icon   = $instance['feature_font_icon'];
    $feature_link        = ($instance['feature_link']) ? $instance['feature_link'] : '';

    $icon = '';
    if($feature_icon_type === 'image_icon'){
      $image_url = wp_get_attachment_image_src( $feature_image_icon, 'fullsize', false, '' );
      if($image_url){
        $icon = '<img src="'.esc_url($image_url[0]).'" alt="icon_img">';
      } else {
        $icon = '';
      }
    } elseif ($feature_icon_type === 'font_icon'){
      $icon = '<i class="'.$feature_font_icon.'" aria-hidden="true"></i>';
    }

    // Display the markup before the widget
    echo $before_widget;

    $output  = '';
    $output .= '<div class="seese-core-feature">';
    if(!empty($feature_link)){
      $output .= '<a href="'.$feature_link.'" class="seese-boxlink"></a>';
    }
    $output .= '<div class="seese-boxcontent">';
    $output .= $icon;
    $output .= '<h4>'.$feature_heading.'</h4>';
    $output .= '<div class="subtitle">'.$feature_content.'</div>';
    $output .= '</div></div>';

    echo $output;

    // Display the markup after the widget
    echo $after_widget;
  }
}

// Register the widget using an annonymous function
add_action( 'widgets_init', create_function( '', 'register_widget( "seese_core_feature" );' ) );
