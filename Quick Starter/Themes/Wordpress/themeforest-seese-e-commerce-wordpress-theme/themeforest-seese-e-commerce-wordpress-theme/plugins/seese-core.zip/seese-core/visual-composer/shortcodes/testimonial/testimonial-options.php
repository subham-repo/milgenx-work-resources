<?php
/**
 * Testimonial - Shortcode Options
 */

add_action( 'init', 'vcts_testi_vc_map' );

if ( ! function_exists( 'vcts_testi_vc_map' ) ) {

  function vcts_testi_vc_map() {

    vc_map( array(
      'name'        => esc_html__( 'Testimonial Slider', 'seese-core'),
      'base'        => 'vcts_testimonial',
      'description' => esc_html__( 'Testimonial Slider', 'seese-core'),
      'icon'        => 'fa fa-bookmark-o color-purple',
      'category'    => VictorLib::vcts_cat_name(),
      'params'      => array(

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Layout', 'seese-core' ),
          'param_name'       => 'layout_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Limit', 'seese-core'),
          'param_name'       => 'testi_limit',
          'value'            => '',
          'admin_label'      => true,
          'description'      => esc_html__( 'Enter the number of testimonials to show.', 'seese-core'),
        ),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Show/Hide', 'seese-core' ),
          'param_name'       => 'sh_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Image', 'seese-core'),
          'param_name'       => 'testi_image',
          'value'            => '',
          'std'              => true,
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Name', 'seese-core'),
          'param_name'       => 'testi_name',
          'value'            => '',
          'std'              => true,
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Profession', 'seese-core'),
          'param_name'       => 'testi_profession',
          'value'            => '',
          'std'              => true,
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Navigation', 'seese-core'),
          'param_name'       => 'testi_nav',
          'value'            => '',
          'std'              => false,
          'description'      => esc_html__( 'Show next/prev buttons.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Dots', 'seese-core'),
          'param_name'       => 'testi_dots',
          'value'            => '',
          'std'              => true,
          'description'      => esc_html__( 'Show dots navigation.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Autoplay', 'seese-core'),
          'param_name'       => 'testi_autoplay',
          'value'            => '',
          'std'              => false,
          'description'      => esc_html__( 'Start Autoplay.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Listing', 'seese-core' ),
          'param_name'       => 'lsng_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'dropdown',
          'heading'          => esc_html__( 'Order', 'seese-core' ),
          'value'            => array(
            esc_html__('Select Testimonial Order', 'seese-core') => '',
            esc_html__('Asending', 'seese-core')  => 'ASC',
            esc_html__('Desending', 'seese-core') => 'DESC',
          ),
          'param_name'       => 'testi_order',
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          'type'             => 'dropdown',
          'heading'          => esc_html__( 'Order By', 'seese-core' ),
          'value'            => array(
            esc_html__('None', 'seese-core')  => 'none',
            esc_html__('ID', 'seese-core')    => 'ID',
            esc_html__('Title', 'seese-core') => 'title',
            esc_html__('Date', 'seese-core')  => 'date',
          ),
          'param_name'       => 'testi_orderby',
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),

        VictorLib::seese_class_option(),

      )
    ) );
  }
}
