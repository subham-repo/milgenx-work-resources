<?php
/* ==========================================================
  Video
=========================================================== */

if ( !function_exists('vcts_video_function')) {
  function vcts_video_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'image_source'      => '',    
      'video_img_url'     => '',
      'video_img_id'      => '',
      'video_btn_img'     => '',
      'video_type'        => '',
      'video_html5_link'  => '', 
      'video_iframe_link' => '',    
      'class'             => '',
    ), $atts));
    
    if ($image_source === 'from_url') {
      $cover_image = $video_img_url;
    } else {
      $cover_image = wp_get_attachment_image_src( $video_img_id, 'fullsize', false, '' );
      $cover_image = $cover_image[0];
    } 
      
    $cover_image   = ($cover_image) ? $cover_image : VCTS_PLUGIN_ASTS . '/images/video_cover.jpg';
    $cover_resize  = aq_resize( $cover_image[0], '1170', '480', true );
    $cover_image   = ($cover_resize) ? $cover_resize : $cover_image;
    
    $play_image    = wp_get_attachment_image_src( $video_btn_img, 'fullsize', false, '' );
    $play_image    = ($play_image) ? $play_image : VCTS_PLUGIN_ASTS . '/images/play_button.jpg';
    $img_resize    = aq_resize( $play_image[0], '80', '45', true );
    $play_image    = ($img_resize) ? $img_resize : $play_image;
    
    $e_uniqid      = uniqid();
    $inline_style  = '';

    $inline_style .= '.seese-video-'.$e_uniqid.'.active .video-view, .seese-video-'. $e_uniqid .' .video-poster {';
    $inline_style .= 'width:100%;';
    $inline_style .= '}';        
  
    seese_add_inline_style($inline_style);
    $styled_class = 'seese-video-'.$e_uniqid;
    
    // Turn output buffer on
    ob_start();
?>
    <div class="seese-media-wrap <?php echo esc_attr($styled_class.' '.$class); ?>">
      <div class="img-wrap">
        <a href="javascript:void(0);" class="play-btn" id="play-btn">
          <img src="<?php echo esc_url($play_image); ?>" alt="video-play" class="video-play"/>
        </a>
        <img src="<?php echo esc_url($cover_image); ?>" alt="video-poster" class="video-poster" />
      </div>
      <div class="video-wrap">    
        <?php 
        if(!empty($video_html5_link) || !empty($video_iframe_link)) {
          if($video_type === 'html5_video') { ?> 
            <video class="video-html video-view" src="<?php echo esc_url($video_html5_link); ?>" controls="false"><?php echo esc_html__('Your browser does not support the video tag.', 'seese-core') ?></video>
          <?php } else { ?>
            <iframe class="video-iframe video-view" src="<?php echo esc_url($video_iframe_link); ?>"  frameborder="0"></iframe>
          <?php 
          } 
        } ?> 
      </div>
    </div>
    
    <script type="text/javascript">    
      jQuery('.<?php echo esc_js($styled_class); ?> #play-btn').click(function(event){
        event.preventDefault();
        if(jQuery('.<?php echo esc_js($styled_class); ?> .video-view').hasClass('video-html')) {
          jQuery('.<?php echo esc_js($styled_class); ?> .video-html')[0].play();   
          jQuery('.<?php echo esc_js($styled_class); ?> .video-html').attr({'controls':'true'});                  
        }
        if(jQuery('.<?php echo esc_js($styled_class); ?> .video-view').hasClass('video-iframe')) {           
          var iframeSrc = jQuery('.<?php echo esc_js($styled_class); ?> .video-iframe').attr("src");
          if (iframeSrc.indexOf("?") >= 0) {
            jQuery('.<?php echo esc_js($styled_class); ?> .video-iframe')[0].src += "&autoplay=1";
          } else {
            jQuery('.<?php echo esc_js($styled_class); ?> .video-iframe')[0].src += "?autoplay=1";
          }
        }
        jQuery(this).unbind('click');
        jQuery('.<?php echo esc_js($styled_class); ?>').addClass('active');
      });    
    </script>
        
<?php     
    // Return outbut buffer
    return ob_get_clean();
  }
}

add_shortcode( 'vcts_video', 'vcts_video_function' );
