<?php
/**
 * Product - Shortcode Options
 */
if (class_exists('WooCommerce')) {

  add_action( 'init', 'vcts_product_vc_map' );

  if ( ! function_exists( 'vcts_product_vc_map' ) ) {

  	function vcts_product_vc_map() {

	    vc_map( array(
	      "name"        => esc_html__("Products", 'seese-core'),
	      "base"        => "vcts_product",
	      "description" => esc_html__("WooCommerce Products", 'seese-core'),
	      "icon"        => "fa fa-shopping-cart color-slate-blue",
	      "category"    => VictorLib::vcts_cat_name(),
	      "params"      => array(

	        array(
					  'type'             => 'notice',
					  'heading'          => esc_html__('Layout', 'seese-core'),
					  'param_name'       => 'layout_opt',
					  'class'            => 'cs-info',
					  'value'            => '',
					),
	        array(
	          'type'             => 'dropdown',
	          'heading'          => esc_html__('Product Style', 'seese-core'),
	          'value'            => array(
	            esc_html__( 'Default Grid', 'seese-core' ) 		=> 'shop-default',
	            esc_html__( 'Full Width Grid', 'seese-core' ) => 'shop-fullwidth',
	            esc_html__( 'Masonry', 'seese-core' ) 				=> 'shop-masonry',
	            esc_html__( 'Carousel', 'seese-core' ) 				=> 'shop-carousel',
	          ),
	          'admin_label'      => true,
	          'param_name'       => 'pr_style',
	          'description'      => esc_html__('Select your product layout.', 'seese-core'),
	        ),
	        array(
	          'type'             => 'dropdown',
	          'heading'          => esc_html__('Product Column', 'seese-core'),
	          'value'            => array(
	            esc_html__( 'Three', 'seese-core' ) => 'shop_col_3',
	            esc_html__( 'Four', 'seese-core' ) 	=> 'shop_col_4',
	            esc_html__( 'Five', 'seese-core' ) 	=> 'shop_col_5',
	          ),
	          'admin_label'      => true,
	          'param_name'       => 'pr_column',
	          'dependency'       => array(
	            'element'        => 'pr_style',
	            'value'          => array('shop-default', 'shop-fullwidth', 'shop-carousel'),
	          ),
	          'description'      => esc_html__('Select your product column.', 'seese-core'),
	        ),
	        array(
	          'type'             => 'textfield',
	          'heading'          => esc_html__('Limit', 'seese-core'),
	          'param_name'       => 'pr_limit',
	          'value'            => '',
	          'admin_label'      => true,
	          'description'      => esc_html__('Enter the number of products to show.', 'seese-core'),
	        ),
	        array(
	          'type'             => 'switcher',
	          'heading'          => esc_html__('Loop', 'seese-core'),
	          'param_name'       => 'pr_sl_loop',
	          'value'            => '',
	          'std'              => false,
	          'dependency'       => array(
	            'element'        => 'pr_style',
	            'value'          => 'shop-carousel',
	          ),
	          'description'      => esc_html__( 'Inifnity loop.', 'seese-core'),
	          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
	        ),
	        array(
	          'type'             => 'switcher',
	          'heading'          => esc_html__('Navigation', 'seese-core'),
	          'param_name'       => 'pr_sl_nav',
	          'value'            => '',
	          'std'              => true,
	          'dependency'       => array(
	            'element'        => 'pr_style',
	            'value'          => 'shop-carousel',
	          ),
	          'description'      => esc_html__('Show next/prev buttons.', 'seese-core'),
	          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
	        ),
	        array(
	          'type'             => 'switcher',
	          'heading'          => esc_html__('Dots', 'seese-core'),
	          'param_name'       => 'pr_sl_dots',
	          'value'            => '',
	          'std'              => true,
	          'dependency'       => array(
	            'element'        => 'pr_style',
	            'value'          => 'shop-carousel',
	          ),
	          'description'      => esc_html__('Show dots navigation.', 'seese-core'),
	          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
	        ),
	        array(
	          'type'             => 'switcher',
	          'heading'          => esc_html__('Autoplay', 'seese-core'),
	          'param_name'       => 'pr_sl_autoplay',
	          'value'            => '',
	          'std'              => true,
	          'dependency'       => array(
	            'element'        => 'pr_style',
	            'value'          => 'shop-carousel',
	          ),
	          'description'      => esc_html__( 'Start Autoplay.', 'seese-core'),
	          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
	        ),
	        array(
					  'type'             => 'textfield',
					  'heading'          => esc_html__( 'Navigation Speed', 'seese-core' ),
					  'param_name'       => 'pr_sl_nav_speed',
					  'description'      => esc_html__( 'Enter navigation speed (value is in ms, enter numbers only).', 'seese-core' ),
			          'dependency'   => array(
			            'element'    => 'pr_style',
			            'value'      => 'shop-carousel',
			          ),
					  'edit_field_class' => 'vc_col-sm-4 vc_column seese_field_space',
					),
	        array(
					  'type'             => 'textfield',
					  'heading'          => esc_html__( 'Dots Speed', 'seese-core' ),
					  'param_name'       => 'pr_sl_dots_speed',
					  'description'      => esc_html__( 'Enter dots speed (value is in ms, enter numbers only).', 'seese-core' ),
			          'dependency'   => array(
			            'element'    => 'pr_style',
			            'value'      => 'shop-carousel',
			          ),
					  'edit_field_class' => 'vc_col-sm-4 vc_column seese_field_space',
					),
        	array(
					  'type'             => 'textfield',
	          'heading'          => esc_html__( 'Autoplay Speed', 'seese-core' ),
	          'param_name'       => 'pr_sl_autoplay_speed',
	          'description'      => esc_html__( 'Enter autoplay speed (value is in ms, enter numbers only).', 'seese-core' ),
	          'dependency'       => array(
	            'element'        => 'pr_style',
	            'value'          => 'shop-carousel',
	          ),
		        'edit_field_class' => 'vc_col-sm-4 vc_column seese_field_space',
					),
        	array(
					  'type'             => 'notice',
					  'heading'          => esc_html__('Enable/Disable', 'seese-core'),
					  'param_name'       => 'enable_opt',
					  'class'            => 'cs-info',
					  'value'            => '',
					),
	        array(
	          'type'             => 'switcher',
	          'heading'          => esc_html__('Category Filter', 'seese-core'),
	          'param_name'       => 'pr_cat_fltr',
	          'value'            => '',
	          'std'              => true,
	          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
	        ),
	        array(
	          'type'             => 'switcher',
	          'heading'          => esc_html__('Shop Filter Top Widget', 'seese-core'),
	          'param_name'       => 'pr_widget_fltr',
	          'value'            => '',
	          'std'              => true,
	          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
	        ),
	        array(
	          'type'             => 'switcher',
	          'heading'          => esc_html__('Filter Details Visible', 'seese-core'),
	          'param_name'       => 'pr_fltr_mode',
	          'value'            => '',
	          'std'              => false,
	          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
	        ),
	        array(
	          'type'             => 'switcher',
	          'heading'          => esc_html__('Pagination', 'seese-core'),
	          'param_name'       => 'pr_nav',
	          'value'            => '',
	          'std'              => true,
	          'dependency'       => array(
	            'element'        => 'pr_style',
	            'value'          => array('shop-default', 'shop-fullwidth', 'shop-masonry'),
	          ),
	          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
	        ),
	        array(
	          'type'             => 'dropdown',
	          'heading'          => esc_html__('Pagination Style', 'seese-core'),
	          'value'            => array(
	            esc_html__( 'Load More', 'seese-core' )     => 'seese-pagination-one',
	            esc_html__( 'Next/Previous', 'seese-core' ) => 'seese-pagination-two',
	            esc_html__( 'Page Numbers', 'seese-core' )  => 'seese-pagination-three',
	          ),
	          'param_name'       => 'pr_nav_style',
	          'description'      => esc_html__('Select product pagination style.', 'seese-core'),
	          'dependency'       => array(
	            'element'        => 'pr_nav',
	            'value'          => array('true'),
	          ),
	          'edit_field_class' => 'vc_col-md-12 vc_column seese_field_space',
	        ),
	        array(
					  'type'             => 'notice',
					  'heading'          => esc_html__('Listing', 'seese-core'),
					  'param_name'       => 'lsng_opt',
					  'class'            => 'cs-info',
					  'value'            => '',
					),
	        array(
	          'type'             => 'dropdown',
	          'heading'          => esc_html__('Order', 'seese-core'),
	          'value'            => array(
	            esc_html__('Select Product Order', 'seese-core') => '',
	            esc_html__('Asending',             'seese-core') => 'ASC',
	            esc_html__('Desending',            'seese-core') => 'DESC',
	          ),
	          'param_name'       => 'pr_order',
	          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
	        ),
	        array(
	          'type'             => 'dropdown',
	          'heading'          => esc_html__('Order By', 'seese-core'),
	          'value'            => array(
	            esc_html__('None', 'seese-core')     => 'none',
	            esc_html__('ID', 'seese-core')       => 'ID',
	            esc_html__('Author', 'seese-core')   => 'author',
	            esc_html__('Title', 'seese-core')    => 'title',
	            esc_html__('Type', 'seese-core')     => 'type',
	            esc_html__('Date', 'seese-core')     => 'date',
	            esc_html__('Modified', 'seese-core') => 'modified',
	            esc_html__('Random', 'seese-core')   => 'rand',
	          ),
	          'param_name'       => 'pr_orderby',
	          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
	        ),
	        array(
	          'type'             => 'textfield',
	          'heading'          => esc_html__('Show only products of certain categories?', 'seese-core'),
	          'param_name'       => 'pr_show_cat',
	          'value'            => '',
	          'description'      => esc_html__('Enter category SLUGS (comma separated).', 'seese-core'),
	          'admin_label'      => true,
	        ),

        	VictorLib::seese_class_option(),
	      )
	    ) );

		}
  }
}
