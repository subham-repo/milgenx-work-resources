<?php
/*
 * All Custom Shortcode for Seese theme.
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

if( ! function_exists( 'seese_framework_shortcodes' ) ) {
  function seese_framework_shortcodes( $options ) {

    $options       = array();

    /* Shortcodes */
    $options[]     = array(
      'title'      => esc_html__('Shortcodes', 'seese'),
      'shortcodes' => array(

        // Spacer
        array(
          'name'   => 'vc_empty_space',
          'title'  => esc_html__('Spacer', 'seese'),
          'fields' => array(

            array(
              'id'             => 'height',
              'type'           => 'text',
              'title'          => esc_html__('Height', 'seese'),
              'attributes'     => array(
                'placeholder'  => '20px',
              ),
            ),

          ),
        ),
        // Spacer

        // Social Icons
        array(
          'name'          => 'seese_socials',
          'title'         => esc_html__('Social Icons', 'seese'),
          'view'          => 'clone',
          'clone_id'      => 'seese_social',
          'clone_title'   => esc_html__('Add New', 'seese'),
          'fields'        => array(

            array(
              'id'            => 'social_select',
              'type'          => 'select',
              'options'       => array(
                'style-one'   => esc_html__('Style One (Footer)', 'seese'),
                'style-two'   => esc_html__('Style Two', 'seese'),
              ),
              'title'         => esc_html__('Social Icons Style', 'seese'),
            ),
            array(
              'id'            => 'icon_size',
              'type'          => 'text',
              'title'         => esc_html__('Icon Size', 'seese'),
              'attributes'    => array(
                'placeholder' => '14px',
              ),
            ),
            array(
              'id'            => 'top_space',
              'type'          => 'text',
              'title'         => esc_html__('Top Space', 'seese'),
              'wrap_class'    => 'column_half',
            ),
            array(
              'id'            => 'bottom_space',
              'type'          => 'text',
              'title'         => esc_html__('Bottom Space', 'seese'),
              'wrap_class'    => 'column_half',
            ),

            // Colors
            array(
              'type'          => 'notice',
              'class'         => 'info',
              'content'       => esc_html__('Colors', 'seese')
            ),
            array(
              'id'            => 'icon_color',
              'type'          => 'color_picker',
              'title'         => esc_html__('Icon Color', 'seese'),
              'wrap_class'    => 'column_third',
            ),
            array(
              'id'            => 'icon_hover_color',
              'type'          => 'color_picker',
              'title'         => esc_html__('Icon Hover Color', 'seese'),
              'wrap_class'    => 'column_third',
            ),
            array(
              'id'            => 'border_color',
              'type'          => 'color_picker',
              'title'         => esc_html__('Border Color', 'seese'),
              'wrap_class'    => 'column_third',
              'dependency'    => array('social_select', '!=', 'style-two'),
            ),
            array(
              'id'            => 'bg_color',
              'type'          => 'color_picker',
              'title'         => esc_html__('Backrgound Color', 'seese'),
              'wrap_class'    => 'column_half',
              'dependency'    => array('social_select', '!=', 'style-two'),
            ),
            array(
              'id'            => 'bg_hover_color',
              'type'          => 'color_picker',
              'title'         => esc_html__('Backrgound Hover Color', 'seese'),
              'wrap_class'    => 'column_half',
              'dependency'    => array('social_select', '!=', 'style-two'),
            ),

            array(
              'id'            => 'custom_class',
              'type'          => 'text',
              'title'         => esc_html__('Custom Class', 'seese'),
              'wrap_class'    => 'column_full',
            ),
          ),
          'clone_fields'      => array(

            array(
              'id'            => 'social_link',
              'type'          => 'text',
              'attributes'    => array(
                'placeholder' => 'http://',
              ),
              'title'         => esc_html__('Link', 'seese')
            ),
            array(
              'id'            => 'social_icon',
              'type'          => 'icon',
              'title'         => esc_html__('Social Icon', 'seese')
            ),
            array(
              'id'            => 'target_tab',
              'type'          => 'switcher',
              'title'         => esc_html__('Open New Tab?', 'seese'),
              'on_text'       => esc_html__('Yes', 'seese'),
              'off_text'      => esc_html__('No', 'seese'),
            ),

          ),

        ),
        // Social Icons

        // Dropcap
        array(
          'name'              => 'seese_dropcap',
          'title'             => esc_html__('Dropcap', 'seese'),
          'fields'            => array(

            array(
              'id'            => 'size',
              'type'          => 'text',
              'title'         => esc_html__('Size', 'seese'),
              'attributes'    => array(
                'placeholder' => '30px',
              ),
              'wrap_class'    => 'column_half',
            ),
            array(
              'id'            => 'color',
              'type'          => 'color_picker',
              'title'         => esc_html__('Color', 'seese'),
              'wrap_class'    => 'column_half',
            ),
            array(
              'id'            => 'custom_class',
              'type'          => 'text',
              'title'         => esc_html__('Custom Class', 'seese'),
              'wrap_class'    => 'column_half',
            ),
            array(
              'id'            => 'content',
              'type'          => 'text',
              'title'         => esc_html__('Letter', 'seese'),
              'wrap_class'    => 'column_half',
            ),
          ),
        ),
        // Drop Cap

        // List Styles
        array(
          'name'              => 'seese_lists',
          'title'             => esc_html__('List', 'seese'),
          'view'              => 'clone',
          'clone_id'          => 'seese_list',
          'clone_title'       => esc_html__('Add New', 'seese'),
          'fields'            => array(

            array(
              'id'            => 'list_select',
              'type'          => 'select',
              'options'       => array(
                'ordered-list'   => esc_html__('Ordered List', 'seese'),
                'unordered-list' => esc_html__('Unordered List', 'seese'),
              ),
              'title'         => esc_html__('Social Icons Style', 'seese'),
            ),

            // Colors
            array(
              'type'          => 'notice',
              'class'         => 'info',
              'content'       => esc_html__('Colors', 'seese')
            ),
            array(
              'id'            => 'text_size',
              'type'          => 'text',
              'title'         => esc_html__('Text Size', 'seese'),
              'attributes'    => array(
                'placeholder' => '14px',
              ),
            ),
            array(
              'id'            => 'text_color',
              'type'          => 'color_picker',
              'title'         => esc_html__('Text Color', 'seese'),
            ),
            array(
              'id'            => 'custom_class',
              'type'          => 'text',
              'title'         => esc_html__('Custom Class', 'seese'),
            ),

          ),
          'clone_fields'      => array(

            array(
              'id'            => 'list_text',
              'type'          => 'textarea',
              'title'         => esc_html__('Text', 'seese')
            ),

          ),

        ),
        // List Styles

        // WPML 
        array(
          'name'          => 'seese_wpml',
          'title'         => esc_html__('Seese WPML', 'seese'),
          'fields'        => array(

            array(
            'id'        => 'custom_class',
            'type'      => 'text',
            'title'     => esc_html__('Custom Class', 'seese'),
            ),
            array(
              'id'        => 'wpml_flag',
              'type'      => 'switcher',
              'title'     => esc_html__('Remove Flag', 'seese'),
              'info'      => 'Remove Flag from Language'
            ),
            array(
              'id'        => 'wpml_lang',
              'type'      => 'switcher',
              'title'     => esc_html__('Remove Language', 'seese'),
              'info'      => 'Remove Language'
            ),
          ),
        ), // WPML 

      ),
    );

  return $options;

  }
  add_filter( 'cs_shortcode_options', 'seese_framework_shortcodes' );
}
