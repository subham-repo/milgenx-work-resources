<?php
/* ==========================================================
  Product
=========================================================== */

if ( class_exists( 'WooCommerce' ) ) {

  if ( !function_exists('vcts_product_function')) {

    function vcts_product_function( $atts, $content = NULL ) {

	    extract(shortcode_atts(array(
	      'pr_style'             => '',
	      'pr_column'            => '',
	      'pr_limit'             => '',
	      'pr_cat_fltr'          => '',
	      'pr_widget_fltr'       => '',
        'pr_fltr_mode'         => '',
	      // Enable & Disable
	      'pr_nav'               => '',
	      'pr_nav_style'         => '',
	      'pr_sl_loop'           => '',
	      'pr_sl_nav'            => '',
	      'pr_sl_dots'           => '',
	      'pr_sl_autoplay'       => '',
	      'pr_sl_nav_speed'      => '',
	      'pr_sl_dots_speed'     => '',
	      'pr_sl_autoplay_speed' => '',
	      // Listing
	      'pr_order'             => 'ASC',
	      'pr_orderby'           => 'title',
	      'pr_show_cat'          => '',
	      'class'                => '',
	    ), $atts));

	    if($pr_column === 'shop_col_5') {
	      $col_number = 5;
	    } else if($pr_column === 'shop_col_4') {
	      $col_number = 4;
	    } else {
	      $col_number = 3;
	    }

	    if ($pr_style === 'shop-fullwidth') {
	      $pr_style_class = 'seese-prsc-shop-fullwidth seese-pr-fullgrid';
	      $carousel_class = '';
	      $data_attr_value = '';
	    } elseif ($pr_style === 'shop-masonry') {
	      $pr_style_class = 'seese-prsc-shop-masonry seese-pr-fullgrid';
	      $carousel_class = '';
	      $data_attr_value = '';
	    } elseif ($pr_style === 'shop-carousel') {
	      $pr_style_class = 'seese-prsc-shop-carousel';
	      $carousel_class = 'owl-carousel';

	      $pr_sl_loop = $pr_sl_loop ? 'true' : 'false';
	      $pr_sl_nav  = $pr_sl_nav ? 'true' : 'false';
	      $pr_sl_dots = $pr_sl_dots ? 'true' : 'false';
	      $pr_sl_autoplay   = $pr_sl_autoplay ? 'true' : 'false';
	      $pr_sl_nav_speed  = $pr_sl_nav_speed ? (int)$pr_sl_nav_speed : '500';
	      $pr_sl_dots_speed = $pr_sl_dots_speed ? (int)$pr_sl_dots_speed : '500';
	      $pr_sl_autoplay_speed = $pr_sl_autoplay_speed ? (int)$pr_sl_autoplay_speed : '500';

	      $data_attr_value = 'data-loop='.$pr_sl_loop;
	      $data_attr_value.= ' data-nav='.$pr_sl_nav;
	      $data_attr_value.= ' data-dots='.$pr_sl_dots;
	      $data_attr_value.= ' data-autoplay='.$pr_sl_autoplay;
	      $data_attr_value.= ' data-navspeed='.$pr_sl_nav_speed;
	      $data_attr_value.= ' data-dotspeed='.$pr_sl_dots_speed;
	      $data_attr_value.= ' data-autospeed='.$pr_sl_autoplay_speed;
	      $data_attr_value.= ' data-items='.$col_number;
	    } else {
	      $pr_style_class  = 'seese-prsc-shop-default';
	      $carousel_class  = '';
	      $data_attr_value = '';
	    }

	    if (is_cs_framework_active()) {
	    	$woo_lazy_load  = cs_get_option('woo_lazy_load');
				$woo_dload_size = cs_get_option('woo_dload_size');
				$woo_lazy_url   = SEESE_THEMEROOT_URI.'/inc/plugins/woocommerce/images/lazy-load.jpg';
		    if ( $woo_lazy_load === 'seese-dload-small' ) {
					$data_attr_value.= 'data-dload=seese-dload-small';
					$data_attr_value.= ( !empty($woo_dload_size) ) ? ' data-sload='.esc_attr($woo_dload_size).' ' : ' data-sload=767';
					$data_attr_value.= ' data-ldurl='.$woo_lazy_url;
				}
		  }

	    if ($pr_nav_style === 'seese-pagination-three' || $pr_nav_style === 'seese-pagination-two') {
	        $pagination_class = 'seese-no-ajax';
	    } else {
	        $pagination_class = 'seese-ajax';
	    }

      if ($pr_fltr_mode) {
          $filter_mode_class = 'seese-filter-active';
      } else {
          $filter_mode_class = '';
      }

	    $e_uniqid      = uniqid();
	    $styled_class  = 'seese-products-'. $e_uniqid;
	    $slider_id     = 'products-'. $e_uniqid;
	    $shop_page_url = get_permalink(wc_get_page_id('shop'));

	    if ($pr_cat_fltr && $pr_widget_fltr) {
	      $cat_filter_class    = 'col-lg-10 col-md-10 col-sm-12 col-xs-12';
	      $widget_filter_class = 'col-lg-2 col-md-2 col-sm-12 col-xs-12';
	    } else if ($pr_cat_fltr || $pr_widget_fltr) {
	      $cat_filter_class    = 'col-lg-12 col-md-12 col-sm-12 col-xs-12';
	      $widget_filter_class = 'col-lg-12 col-md-12 col-sm-12 col-xs-12';
	    } else {
	      $cat_filter_class    = '';
	      $widget_filter_class = '';
	    }

	    global $paged;
	    if( get_query_var( 'paged' ) )
	      $my_page = get_query_var( 'paged' );
	    else {
	      if( get_query_var( 'page' ) )
	        $my_page = get_query_var( 'page' );
	      else
	        $my_page = 1;
	      set_query_var( 'paged', $my_page );
	      $paged = $my_page;
	    }

	    $args = array(
        'paged'          => (int)$my_page,
        'post_type'      => 'product',
	      'posts_per_page' => (int)$pr_limit,
        'order'          => $pr_order,
        'orderby'        => $pr_orderby,
        'tax_query'      => array(
                              array(
                                    'taxonomy' => 'product_visibility',
                                    'field'    => 'name',
                                    'terms'    => 'exclude-from-catalog',
                                    'operator' => 'NOT IN',

                              )
                            ),
	    );

	    if($pr_show_cat !== '') {
	      $args['product_cat'] = esc_attr($pr_show_cat);
	    }

	    $vcts_products = new WP_Query($args);

	    // Turn output buffer on
	    ob_start();
    ?>

    <div class="woocommerce <?php echo esc_attr($styled_class.' '.$class); ?>">
      <div class="seese-shop-wrapper woo-col-<?php echo esc_attr($col_number.' '.$pagination_class); ?>">

        <?php if ($pr_cat_fltr || $pr_widget_fltr) { ?>
          <div class="seese-filterWrap <?php echo esc_attr($filter_mode_class); ?>">
            <div class="seese-filterTabs seese-prsc-filter row">
              <?php if ($pr_cat_fltr) { ?>
                <div class="<?php echo esc_attr($cat_filter_class); ?>">
                  <?php if (function_exists('seese_category_list')) { echo seese_category_list(); } ?>
                </div>
              <?php } if ($pr_widget_fltr) { ?>
                <div class="<?php echo esc_attr($widget_filter_class); ?> seese-widget-filter">
                  <ul class="seese-filterAll">
                    <li>
                      <a role="button" data-toggle="collapse" href=".seese-filter-<?php echo esc_attr($e_uniqid); ?>" aria-expanded="false" aria-controls="seese-filter-<?php echo esc_attr($e_uniqid); ?>">
                        <span class="seese-filter-text"><?php echo esc_html__('Filter', 'seese-core'); ?></span>
                        <span class="seese-hide-filter-text"><?php echo esc_html__('Hide Filter', 'seese-core'); ?></span>
                      </a>
                    </li>
                  </ul>
                </div>
              <?php } ?>
            </div>
        <?php } if ($pr_widget_fltr) { ?>
            <div class="seese-filterOptions">
              <div class="collapse seese-filter-<?php echo esc_attr($e_uniqid); ?>" id="seese-filter">
                <div class="row">
                  <?php if ( is_active_sidebar( 'sidebar-shop-filter' ) ) { dynamic_sidebar( 'sidebar-shop-filter' ); } ?>
                </div>
              </div>
            </div>
        <?php } if ($pr_cat_fltr || $pr_widget_fltr) { ?>
          </div>
        <?php } ?>

        <div class="seese-shop-load-anim">
          <div class="line-scale-pulse-out">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
          </div>
        </div>

        <div class="seese-products-full-wrap <?php echo esc_attr($pr_style_class); ?>" data-shopurl="<?php echo esc_url($shop_page_url); ?>">
          <ul class="products <?php echo esc_attr($carousel_class); ?>" id="<?php echo esc_attr($slider_id); ?>" <?php echo esc_attr($data_attr_value); ?>>

            <?php if ($pr_style === 'shop-masonry') { echo '<li class="seese-pr-gutter-sizer"></li><li class="seese-pr-masonry-sizer"></li>'; }
              if ($vcts_products->have_posts()) : while ($vcts_products->have_posts()) : $vcts_products->the_post();

                global $product;
                $hover_image         = (cs_get_option('woo_hover_image')) ? true : false;
                $product_options     = get_post_meta( $product->get_id(), 'product_options', true );
                $masonry_size_class  = (isset($product_options['product_masonry_size'])) ? $product_options['product_masonry_size'] : 'pd-wh';
                $product_bg_color    = (!empty($product_options['product_single_bg'])) ? 'style="background:'.$product_options['product_single_bg'].'"' : '';
                $product_hover_image = (isset($product_options['product_hover_image_change'])) ? $product_options['product_hover_image_change'] : true;
                $single_custom_badge = get_post_meta( get_the_ID(), 'badge_input', true );

                if ($pr_style === 'shop-masonry') { ?>
                  <li <?php post_class($masonry_size_class); ?>>
                <?php } else { ?>
                  <li <?php post_class(); ?>>
                <?php } ?>

                  <div class="seese-product-img" <?php echo $product_bg_color; ?>>
                    <a href="<?php echo get_the_permalink($product->get_id()); ?>" class="woocommerce-LoopProduct-link"></a>

                    <?php
                    if ( defined( 'YITH_WCWL' ) ) {
                      echo do_shortcode('[yith_wcwl_add_to_wishlist icon="fa-heart-o"]');
                    }
                    echo '<span class="seese-custom-badge">'. esc_attr( $single_custom_badge ) .'</span>';

                    $html = '';

                    if ($hover_image && $product_hover_image) {
                      $product_gallery_thumbnail_ids = $product->get_gallery_image_ids();
                      $product_thumbnail_alt_id      = ($product_gallery_thumbnail_ids) ? reset($product_gallery_thumbnail_ids) : null;
                      if ($product_thumbnail_alt_id) {
                        $product_thumbnail_alt_title = get_the_title($product_thumbnail_alt_id);
                        $product_thumbnail_alt_src   = wp_get_attachment_image_src( $product_thumbnail_alt_id, 'shop_catalog' );
                        $hover_parent_class          = ($product_thumbnail_alt_src) ? 'seese-loop-thumb-has-hover' : '';
                      } else {
                        $hover_parent_class = '';
                      }
                    } else {
                      $hover_parent_class = '';
                    }

                    $html .= '<div class="seese-loop-thumb '.esc_attr($hover_parent_class).'">';

                    if (has_post_thumbnail($product->get_id())) {
                      $lazy_load_image_url     = SEESE_THEMEROOT_URI.'/inc/plugins/woocommerce/images/lazy-load.jpg';
                      $product_thumbnail_id    = get_post_thumbnail_id();
                      $product_thumbnail_title = get_the_title($product_thumbnail_id);
                      $product_thumbnail_clog  = wp_get_attachment_image_src($product_thumbnail_id, 'shop_catalog');
                      $product_thumbnail_full  = wp_get_attachment_image_src($product_thumbnail_id, 'full');

                      if ($pr_style === 'shop-masonry') {
                        $product_thumbnail = ($masonry_size_class === 'pd-2wh') ? $product_thumbnail_full : $product_thumbnail_clog;
                      } else {
                        $product_thumbnail = $product_thumbnail_clog;
                      }

                      if ( $woo_lazy_load === 'seese-dload-full' ) {
                      	$html .= '<img width="'.esc_attr($product_thumbnail[1]).'" height="'.esc_attr($product_thumbnail[2]).'" src="'.esc_url($product_thumbnail[0]).'" alt="'.esc_attr($product_thumbnail_title).'" class="attachment-shop_catalog size-shop_catalog wp-post-image" />';
                      } else {
                      	$html .= '<img width="'.esc_attr($product_thumbnail[1]).'" height="'.esc_attr($product_thumbnail[2]).'" data-src="'.esc_url($product_thumbnail[0]).'" src="'.esc_url($lazy_load_image_url).'" alt="'.esc_attr($product_thumbnail_title).'" class="attachment-shop_catalog size-shop_catalog wp-post-image seese-unveil-image" />';
                        $html .= '<div class="seese-unveil-loader ball-beat"><div></div></div>';
                      }

                    } else {
                      $image_url = SEESE_THEMEROOT_URI.'/inc/plugins/woocommerce/images/shop-sample.jpg';
                      $html .= '<img src="'.esc_url($image_url).'" class="attachment-shop-catalog size-shop_catalog" />';
                    }

                    if ($hover_image && $product_hover_image) {
                      $product_gallery_thumbnail_ids = $product->get_gallery_image_ids();
                      $product_thumbnail_alt_id = ($product_gallery_thumbnail_ids) ? reset($product_gallery_thumbnail_ids) : null;

                      if ($product_thumbnail_alt_id) {
                        $product_thumbnail_alt_title = get_the_title($product_thumbnail_alt_id);
                        $product_thumbnail_alt_clog  = wp_get_attachment_image_src($product_thumbnail_alt_id, 'shop_catalog');
                        $product_thumbnail_alt_full  = wp_get_attachment_image_src($product_thumbnail_alt_id, 'full');

                        if ($pr_style === 'shop-masonry') {
                          $product_thumbnail_alt_src = ($masonry_size_class === 'pd-2wh') ? $product_thumbnail_alt_full : $product_thumbnail_alt_clog;
                        } else {
                          $product_thumbnail_alt_src = $product_thumbnail_alt_clog;
                        }

                        if ($product_thumbnail_alt_src) {
                          $html .= '<div class="seese-hover-image-wrap"><img width="'.esc_attr($product_thumbnail_alt_src[1]).'" height="'.esc_attr($product_thumbnail_alt_src[2]).'" src="'.esc_url($product_thumbnail_alt_src[0]).'" alt="'.esc_attr($product_thumbnail_alt_title).'" class="attachment-shop_catalog size-shop_catalog seese-pr-hover-image" /></div>';
                        }
                      }
                    }

                    $html .= '</div>';
                    echo $html; ?>
                  </div>

                  <div class="seese-product-cnt">
                    <div class="seese-product-text">
                      <h3><?php echo esc_attr(get_the_title($product->get_id())); ?></h3>
                      <span class="price"><?php echo $product->get_price_html(); ?></span>
                    </div>
                    <div class="seese-atc-wrap">
                      <?php woocommerce_template_loop_add_to_cart( $vcts_products->post, $product ); ?>
                    </div>
                    <?php echo get_the_term_list($product->get_id(), 'product_cat', '<div class="seese-posted-in-cats"><div class="seese-single-cat">', ', ', '</div></div>'); ?>
                  </div>

                </li>
              <?php
              endwhile;
            endif;
            wp_reset_postdata();
            ?>
          </ul>
        </div>

        <?php
        if ($pr_nav) {
          $lmore_shop_text  = cs_get_option('lmore_shop_text');
          $older_shop_text  = cs_get_option('older_shop_text');
          $newer_shop_text  = cs_get_option('newer_shop_text');
          if ($pr_nav_style === 'seese-pagination-three') {
            if (function_exists('wp_pagenavi')) {
              wp_pagenavi(array( 'query' => $vcts_products ) );
            } else {
              $older_shop_text = $older_shop_text ? $older_shop_text : '<i class="fa fa-angle-double-left"></i>';
              $newer_shop_text = $newer_shop_text ? $newer_shop_text : '<i class="fa fa-angle-double-right"></i>';
              $big = 999999999;
              echo paginate_links( array(
                'base'      => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
                'format'    => '?paged=%#%',
                'total'     => $vcts_products->max_num_pages,
                'show_all'  => false,
                'current'   => max( 1, $my_page ),
                'prev_text' => $older_shop_text,
                'next_text' => $newer_shop_text,
           	    'mid_size'  => 1,
                'type'      => 'list'
              ) );
            }
          } elseif ($pr_nav_style === 'seese-pagination-two') {
            $older_shop_text = $older_shop_text ? $older_shop_text : esc_html__( 'Older Products', 'seese-core' );
            $newer_shop_text = $newer_shop_text ? $newer_shop_text : esc_html__( 'Newer Products', 'seese-core' ); ?>
            <div class="seese-prev-next-pagination seese-shop-pagination row">
              <div class=" col-lg-6 col-md-6 col-sm-6 col-xs-12 newer">
                <?php next_posts_link( '<i class="fa fa-angle-double-left" aria-hidden="true"></i> '. $older_shop_text, $vcts_products->max_num_pages ); ?>
              </div>
              <div class=" col-lg-6 col-md-6 col-sm-6 col-xs-12 older">
                <?php previous_posts_link( $newer_shop_text . ' <i class="fa fa-angle-double-right" aria-hidden="true"></i>', $vcts_products->max_num_pages ); ?>
              </div>
            </div><?php
          } else {
            $lmore_shop_text = $lmore_shop_text ? $lmore_shop_text : esc_html__( 'Load More', 'seese-core' ); ?>
            <div class="seese-load-more-box seese-shop-load-more-box">
              <div class="seese-load-more-link seese-shop-load-more-link">
                <?php next_posts_link( '&nbsp;', $vcts_products->max_num_pages ); ?>
              </div>
              <div class="seese-load-more-controls seese-shop-load-more-controls seese-btn-mode">
                <div class="line-scale-pulse-out">
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                </div>
                <a href="javascript:void(0);" id="seese-shop-load-more-btn" class="seese-btn"><?php echo esc_attr($lmore_shop_text); ?></a>
                <a href="javascript:void(0);" id="seese-loaded" class="seese-btn"><?php echo esc_html__( 'All Loaded', 'seese-core' ); ?></a>
              </div>
            </div><?php
          }
        }
      ?>
      </div>
    </div>

    <?php
    // Return outbut buffer
    return ob_get_clean();

    }
  }

  add_shortcode( 'vcts_product', 'vcts_product_function' );
}
