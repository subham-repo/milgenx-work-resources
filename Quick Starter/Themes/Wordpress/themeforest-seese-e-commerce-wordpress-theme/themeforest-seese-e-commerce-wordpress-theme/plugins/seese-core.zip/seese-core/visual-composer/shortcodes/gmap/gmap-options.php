<?php
/**
 * Gmap - Shortcode Options
 */
add_action( 'init', 'otlt_gmap_vc_map' );

if ( ! function_exists( 'otlt_gmap_vc_map' ) ) {
    
  function otlt_gmap_vc_map() {
    
    vc_map( array(
      'name'        => esc_html__( 'Google Map', 'seese-core'),
      'base'        => 'otlt_gmap',
      'description' => esc_html__( 'Google Map Styles', 'seese-core'),
      'icon'        => 'fa fa-map color-cadetblue',
      'category'    => VictorLib::vcts_cat_name(),
      'params'      => array(

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'API KEY', 'seese-core' ),
          'param_name'       => 'api_key',
          'class'            => 'cs-info',
          'value'            => '',
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Enter Map ID', 'seese-core'),
          'param_name'       => 'gmap_id',
          'value'            => '',
          'description'      => __( 'Enter google map ID. If you\'re using this in <strong>Map Tab</strong> shortcode, enter unique ID for each map tabs. Else leave it as blank. <strong>Note : This should same as Tab ID in Map Tabs shortcode.</strong>', 'seese-core'),
          'admin_label'      => true,
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Enter your Google Map API Key', 'seese-core'),
          'param_name'       => 'gmap_api',
          'value'            => '',
          'description'      => __( 'New Google Maps usage policy dictates that everyone using the maps should register for a free API key. <br />Please create a key for "Google Static Maps API" and "Google Maps Embed API" using the <a href="https://console.developers.google.com/project" target="_blank">Google Developers Console</a>.<br /> Or follow this step links : <br /><a href="https://console.developers.google.com/flows/enableapi?apiid=maps_embed_backend&keyType=CLIENT_SIDE&reusekey=true" target="_blank">1. Step One</a> <br /><a href="https://console.developers.google.com/flows/enableapi?apiid=static_maps_backend&keyType=CLIENT_SIDE&reusekey=true" target="_blank">2. Step Two</a><br /> If you still receive errors, please check following link : <a href="https://churchthemes.com/2016/07/15/page-didnt-load-google-maps-correctly/" target="_blank">How to Fix?</a>', 'seese-core'),
        ),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Map Settings', 'seese-core' ),
          'param_name'       => 'map_settings',
          'class'            => 'cs-info',
          'value'            => '',
        ),
        array(
          'type'             => 'dropdown',
          'heading'          => esc_html__( 'Google Map Type', 'seese-core' ),
          'value'            => array(
            esc_html__( 'Select Type', 'seese-core' ) => '',
            esc_html__( 'ROADMAP', 'seese-core' )     => 'ROADMAP',
            esc_html__( 'SATELLITE', 'seese-core' )   => 'SATELLITE',
            esc_html__( 'HYBRID', 'seese-core' )      => 'HYBRID',
            esc_html__( 'TERRAIN', 'seese-core' )     => 'TERRAIN',
          ),
          'admin_label'      => true,
          'param_name'       => 'gmap_type',
          'description'      => esc_html__( 'Select your google map type.', 'seese-core' ),
        ),
        array(
          'type'             => 'dropdown',
          'heading'          => esc_html__( 'Google Map Style', 'seese-core' ),
          'value'            => array(
            esc_html__( 'Select Style', 'seese-core' )            => '',
            esc_html__( 'Gray Scale', 'seese-core' )              => 'gray-scale',
            esc_html__( 'Mid Night', 'seese-core' )               => 'mid-night',
            esc_html__( 'Blue Water', 'seese-core' )              => 'blue-water',
            esc_html__( 'Light Dream', 'seese-core' )             => 'light-dream',
            esc_html__( 'Pale Dawn', 'seese-core' )               => 'pale-dawn',
            esc_html__( 'Apple Maps-esque', 'seese-core' )        => 'apple-maps',
            esc_html__( 'Blue Essence', 'seese-core' )            => 'blue-essence',
            esc_html__( 'Unsaturated Browns', 'seese-core' )      => 'unsaturated-browns',
            esc_html__( 'Paper', 'seese-core' )                   => 'paper',
            esc_html__( 'Midnight Commander', 'seese-core' )      => 'midnight-commander',
            esc_html__( 'Light Monochrome', 'seese-core' )        => 'light-monochrome',
            esc_html__( 'Flat Map', 'seese-core' )                => 'flat-map',
            esc_html__( 'Retro', 'seese-core' )                   => 'retro',
            esc_html__( 'becomeadinosaur', 'seese-core' )         => 'becomeadinosaur',
            esc_html__( 'Neutral Blue', 'seese-core' )            => 'neutral-blue',
            esc_html__( 'Subtle Grayscale', 'seese-core' )        => 'subtle-grayscale',
            esc_html__( 'Ultra Light with Labels', 'seese-core' ) => 'ultra-light-labels',
            esc_html__( 'Shades of Grey', 'seese-core' )          => 'shades-grey',
          ),
          'admin_label'      => true,
          'param_name'       => 'gmap_style',
          'description'      => esc_html__( 'Select your google map style.', 'seese-core' ),
          'dependency'       => array(
            'element'        => 'gmap_type',
            'value'          => 'ROADMAP',
          ),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          'type'             => 'dropdown',
          'heading'          =>esc_html__('Zoom Level', 'seese-core'),
          'param_name'       => 'gmap_zoom',
          'value'            => array(
            esc_html__( 'Select Zoom', 'seese-core' )  => '',
            esc_html__( '1', 'seese-core' )            => '1',
            esc_html__( '2', 'seese-core' )            => '2',
            esc_html__( '3', 'seese-core' )            => '3',
            esc_html__( '4', 'seese-core' )            => '4',
            esc_html__( '5', 'seese-core' )            => '5',
            esc_html__( '6', 'seese-core' )            => '6',
            esc_html__( '7', 'seese-core' )            => '7',
            esc_html__( '8', 'seese-core' )            => '8',
            esc_html__( '9', 'seese-core' )            => '9',
            esc_html__( '10', 'seese-core' )           => '10',
            esc_html__( '11', 'seese-core' )           => '11',
            esc_html__( '12', 'seese-core' )           => '12',
            esc_html__( '13', 'seese-core' )           => '13',
            esc_html__( '14', 'seese-core' )           => '14',
            esc_html__( '15', 'seese-core' )           => '15',
            esc_html__( '16', 'seese-core' )           => '16',
            esc_html__( '17', 'seese-core' )           => '17',
            esc_html__( '18', 'seese-core' )           => '18',
          ),
          'description'      => esc_html__( 'Select your google map zoom level.', 'seese-core'),
          'dependency'       => array(
            'element'        => 'gmap_type',
            'value'          => 'ROADMAP',
          ),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          'type'             =>'textfield',
          'heading'          =>esc_html__('Height', 'seese-core'),
          'param_name'       => 'gmap_height',
          'value'            => '',
          'description'      => esc_html__( 'Enter the px value for map height. This will not work if you add this shortcode into the Map Tab shortcode.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),    
        array(
          'type'             => 'attach_image',
          'heading'          => esc_html__('Common Marker', 'seese-core'),
          'param_name'       => 'gmap_common_marker',
          'value'            => '',
          'description'      => esc_html__( 'Upload your custom marker.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Enable & Disable', 'seese-core' ),
          'param_name'       => 'enb_disb',
          'class'            => 'cs-info',
          'value'            => '',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Scroll Wheel', 'seese-core'),
          'param_name'       => 'gmap_scroll_wheel',
          'value'            => '',
          'std'              => false,
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Street View Control', 'seese-core'),
          'param_name'       => 'gmap_street_view',
          'value'            => '',
          'std'              => false,
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Map Type Control', 'seese-core'),
          'param_name'       => 'gmap_maptype_control',
          'value'            => '',
          'std'              => false,
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),

        // Map Markers
        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Map Pins', 'seese-core' ),
          'param_name'       => 'map_pins',
          'class'            => 'cs-info',
          'value'            => '',
        ),
        array(
          'type'             => 'param_group',
          'value'            => '',
          'heading'          => esc_html__( 'Map Locations', 'seese-core' ),
          'param_name'       => 'locations',
          'params'           => array(
            array(
              'type'             => 'textfield',
              'value'            => '',
              'heading'          => esc_html__( 'Latitude', 'seese-core' ),
              'param_name'       => 'latitude',           
              'admin_label'      => true,
              'description'      => __( 'Find Latitude : <a href="http://www.latlong.net/" target="_blank">latlong.net</a>', 'seese-core' ),
              'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
            ),
            array(
              'type'             => 'textfield',
              'value'            => '',
              'heading'          => esc_html__( 'Longitude', 'seese-core' ),
              'param_name'       => 'longitude',            
              'admin_label'      => true,
              'description'      => __( 'Find Longitude : <a href="http://www.latlong.net/" target="_blank">latlong.net</a>', 'seese-core' ),
              'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
            ),
            array(
              'type'             => 'attach_image',
              'value'            => '',
              'heading'          => esc_html__( 'Custom Marker', 'seese-core' ),
              'param_name'       => 'custom_marker',
              'description'      => esc_html__( 'Upload your unique map marker if your want to differentiate from others.', 'seese-core'),
            ),
            array(
              'type'             => 'textfield',
              'value'            => '',
              'heading'          => esc_html__( 'Heading', 'seese-core' ),
              'param_name'       => 'location_heading',
            ),
            array(
              'type'             => 'textarea',
              'value'            => '',
              'heading'          => esc_html__( 'Content', 'seese-core' ),
              'param_name'       => 'location_text',
            ),

          )
        ),

        VictorLib::seese_class_option(),

        // Design Tab
        array(
          'type'                => 'css_editor',
          'heading'             => esc_html__( 'Text Size', 'seese-core' ),
          'param_name'          => 'css',
          'group'               => esc_html__( 'Design', 'seese-core'),
        ),

      )
    ) );
  }
}
