<?php
/**
 * Image Slider - Shortcode Options
 */
 
add_action( 'init', 'vcts_image_slider_vc_map' );

if ( ! function_exists( 'vcts_image_slider_vc_map' ) ) {
    
  function vcts_image_slider_vc_map() {
    
    vc_map( array(
      'name'        => esc_html__( 'Image Slider', 'seese-core'),
      'base'        => 'vcts_image_slider',
      'description' => esc_html__( 'Image Slider Styles', 'seese-core'),
      'icon'        => 'fa fa-sliders color-pink',
      'category'    => VictorLib::vcts_cat_name(),
      'params'      => array(
      
        array(
          'type'             => 'notice',
          'heading'          => esc_html__('Layout', 'seese-core'),
          'param_name'       => 'layout_opt',
          'class'            => 'cs-info',
          'value'            => '',
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__('Items', 'seese-core'),
          'param_name'       => 'items_cnt',
          'value'            => '',
          'admin_label'      => true,
          'description'      => esc_html__( 'Enter the number of items you want to see on the screen.', 'seese-core'),
        ),    
        array(
          'type'             => 'attach_images',
          'heading'          => esc_html__( 'Images', 'seese-core' ),
          'param_name'       => 'images',         
          'value'            => '',
          'description'      => esc_html__( 'Choose images for this slider.', 'seese-core' ),
		),
		array(
          'type'             => 'exploded_textarea',
          'heading'          => esc_html__( 'Images Links', 'seese-core' ),
          'param_name'       => 'images_links',
          'description'      => esc_html__( 'Define custom links for slider images. Each new line will be a separate link. Leave empty line to skip an image.', 'seese-core' ),
		),
        
        array(
		  'type'             => 'notice',
		  'heading'          => esc_html__( 'Style', 'seese-core' ),
		  'param_name'       => 'style_opt',
		  'class'            => 'cs-info',
		  'value'            => '',
		),       
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__( 'Gap', 'seese-core' ),
          'param_name'       => 'gap',
          'description'      => esc_html__( 'Enter gap between images(value is in px, enter numbers only).', 'seese-core' ),
          'edit_field_class' => 'vc_col-sm-4 vc_column seese_field_space',
		),
        array(
          'type'             => 'colorpicker',
          'heading'          => esc_html__( 'Background Color', 'seese-core' ),
          'param_name'       => 'bg_color',
          'value'            => '',
          'description'      => esc_html__( 'Select background color.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Loop', 'seese-core'),
          'param_name'       => 'loop',
          'value'            => '',
          'std'              => true,
          'description'      => esc_html__( 'Inifnity loop.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
                       
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Navigation', 'seese-core'),
          'param_name'       => 'nav',
          'value'            => '',
          'std'              => true,
          'description'      => esc_html__( 'Show next/prev buttons.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Dots', 'seese-core'),
          'param_name'       => 'dots',
          'value'            => '',
          'std'              => false,
          'description'      => esc_html__( 'Show dots navigation.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),                       
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Autoplay', 'seese-core'),
          'param_name'       => 'autoplay',
          'value'            => '',
          'std'              => false,
          'description'      => esc_html__( 'Start Autoplay.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        
        array(
		  'type'             => 'textfield',
		  'heading'          => esc_html__( 'Navigation Speed', 'seese-core' ),
		  'param_name'       => 'nav_speed',
		  'description'      => esc_html__( 'Enter navigation speed(value is in ms, enter numbers only).', 'seese-core' ),
          'dependency'       => array(
            'element'        => 'nav',
            'value'          => 'true',
          ),
		  'edit_field_class' => 'vc_col-sm-4 vc_column seese_field_space',
		),
        array(
		  'type'             => 'textfield',
		  'heading'          => esc_html__( 'Dots Speed', 'seese-core' ),
		  'param_name'       => 'dots_speed',
		  'description'      => esc_html__( 'Enter dots speed(value is in ms, enter numbers only).', 'seese-core' ),
          'dependency'       => array(
            'element'        => 'dots',
            'value'          => 'true',
          ),
		  'edit_field_class' => 'vc_col-sm-4 vc_column seese_field_space',
		),        
        array(
		  'type'             => 'textfield',
          'heading'          => esc_html__( 'Autoplay Speed', 'seese-core' ),
          'param_name'       => 'autoplay_speed',
          'description'      => esc_html__( 'Enter autoplay speed(value is in ms, enter numbers only).', 'seese-core' ),
          'dependency'       => array(
            'element'        => 'autoplay',
            'value'          => 'true',
          ),
          'edit_field_class' => 'vc_col-sm-4 vc_column seese_field_space',
		),
               
        VictorLib::seese_class_option(),
              
      )
    ) );
  }
}
