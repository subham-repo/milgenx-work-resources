<?php
/**
 * Video - Shortcode Options
 */

add_action( 'init', 'vcts_video_vc_map' );

if ( ! function_exists( 'vcts_video_vc_map' ) ) {

  function vcts_video_vc_map() {

    vc_map( array(
      'name'        => esc_html__( 'Video', 'seese-core'),
      'base'        => 'vcts_video',
      'description' => esc_html__( 'Video Styles', 'seese-core'),
      'icon'        => 'fa fa-video-camera color-green',
      'category'    => VictorLib::vcts_cat_name(),
      'params'      => array(

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Settings', 'seese-core' ),
          'param_name'       => 'set_opt',
          'class'            => 'cs-info',
          'value'            => '',
		    ),
        array(
          'type'             => 'dropdown',
          'heading'          => esc_html__('Cover Image Source', 'seese-core'),
          'param_name'       => 'image_source',
          'admin_label'      => true,
          'value'            => array(
            esc_html__( 'From media', 'seese-core' ) => 'from_media_image',
            esc_html__( 'From url', 'seese-core' )   => 'from_url',
          ),
          'description'      => esc_html__( 'Select video cover image source.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
    		),
    		array(
    		  'type'             => 'textfield',
    		  'heading'          => esc_html__('Image URL', 'seese-core'),
    		  'param_name'       => 'video_img_url',
    		  'value'            => '',
    		  'description'      => 'Enter video cover image link (URL).',
    		  'dependency'       => array(
    		    'element'        => 'image_source',
                'value'          => array( 'from_url' )
    		  ),
              'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
    		),
        array(
          'type'             => 'attach_image',
          'heading'          => esc_html__('Cover Image', 'seese-core'),
          'param_name'       => 'video_img_id',
          'value'            => '',
          'dependency'       => array(
            'element'        => 'image_source',
        	'value'          => array( 'from_media_image' )
          ),
          'description'      => 'Select video cover image.',
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
		    ),
        array(
          'type'             => 'attach_image',
          'heading'          => esc_html__('Play Button Image', 'seese-core'),
          'param_name'       => 'video_btn_img',
          'value'            => '',
          'description'      => 'Select video play button image.',
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
		    ),
        array(
          'type'             => 'dropdown',
          'heading'          => esc_html__('Video Embed Type', 'seese-core'),
          'param_name'       => 'video_type',
          'value'            => array(
            esc_html__( 'iframe', 'seese-core' ) => 'iframe_video',
            esc_html__( 'HTML5', 'seese-core' )  => 'html5_video',
          ),
          'std'              => 'iframe_video',
          'description'      => esc_html__( 'Select video embed type.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
    		),
            array(
    		  'type'             => 'textfield',
    		  'heading'          => esc_html__('Video Link', 'seese-core'),
    		  'param_name'       => 'video_html5_link',
    		  'value'            => '',
    		  'description'      => 'Enter HTML5 video file link.',
              'dependency'       => array(
    		    'element'        => 'video_type',
                'value'          => array( 'html5_video' )
    		  ),
              'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
    		),
    		array(
    		  'type'             => 'textfield',
    		  'heading'          => esc_html__('Video Link', 'seese-core'),
    		  'param_name'       => 'video_iframe_link',
    		  'value'            => '',
    		  'description'      => 'Enter iframe video file link.',
              'dependency'       => array(
    		    'element'        => 'video_type',
                'value'          => array( 'iframe_video' )
    		  ),
              'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
    		),

        VictorLib::seese_class_option(),

      )
    ) );
  }
}
