<?php
/* ==========================================================
  Blog
=========================================================== */
if (!function_exists('vcts_blog_function')) {

  function vcts_blog_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'blog_style'              => '',
      'blog_columns'            => '',
      'blog_limit'              => '',
      // Enable & Disable
      'blog_category'           => '',
      'blog_date'               => '',
      'blog_author'             => '',
      'blog_popup'              => '',
      'blog_excerpt'            => '',
      'blog_read_more'          => '',
      'blog_pagination'         => '',
      'blog_pagination_style'   => '',
      'blog_excerpt_length'     => '',
      // Translation Text
      'read_more_text'          => '',
      // Listing
      'blog_order'              => '',
      'blog_orderby'            => '',
      'blog_category_slugs'     => '',
      // Custom Class
      'class'                   => '',
    ), $atts));

    $e_uniqid     = uniqid();
    $styled_class = 'seese-blog-'. $e_uniqid;

    // Blog Style
    if ($blog_style === 'seese-blog-two') {
      $blog_style_class = 'seese-masonry-blog';
      $blog_msnry_class = 'seese-blog-msnry';
      $blog_msnry_item_class = 'seese-blog-msnry-item';
    } else {
      $blog_style_class = 'seese-standard-blog';
      $blog_msnry_class = '';
      $blog_msnry_item_class = '';
    }

    // Column Style
    if ($blog_columns === 'seese-blog-col-2') {
      $grid_number = 2;
      $blog_column_class = 'col-lg-6 col-md-6 col-sm-6 col-xs-12';
    } else if ($blog_columns === 'seese-blog-col-3') {
      $grid_number = 3;
      $blog_column_class = 'col-lg-4 col-md-4 col-sm-4 col-xs-12';
    } else {
      $grid_number = 1;
      $blog_column_class = 'col-lg-12 col-md-12 col-sm-12 col-xs-12';
    }

    // Translation Text
    if (is_cs_framework_active()) {
      $read_more_to = cs_get_option('read_more_text');
      if ($read_more_text) {
        $read_more_text = $read_more_text;
      } elseif ($read_more_to) {
        $read_more_text = $read_more_to;
      } else {
        $read_more_text = esc_html__( 'Read More', 'seese_framework' );
      }
      $excerpt_length = cs_get_option('blog_excerpt_length');
      if ($blog_excerpt_length) {
        $blog_excerpt_length = $blog_excerpt_length;
      } elseif ($excerpt_length) {
        $blog_excerpt_length = $excerpt_length;
      } else {
        $blog_excerpt_length = '55';
      }
    } else {
      $blog_excerpt_length = $blog_excerpt_length ? $blog_excerpt_length : '55';
      $read_more_text      = $read_more_text ? $read_more_text : esc_html__( 'Read More', 'seese_framework' );
    }

    // Turn output buffer on
    ob_start();

    // Pagination
    global $paged;
    if (get_query_var('paged'))
      $my_page = get_query_var( 'paged' );
    else {
      if (get_query_var('page'))
        $my_page = get_query_var('page');
      else
        $my_page = 1;
      set_query_var('paged', $my_page);
      $paged = $my_page;
    }

    // other query params here,
    $args = array(
      'paged'          => $my_page,
      'post_type'      => 'post',
      'posts_per_page' => (int)$blog_limit,
      'category_name'  => esc_attr($blog_category_slugs),
      'orderby'        => $blog_orderby,
      'order'          => $blog_order
    );
    $vcts_post = new WP_Query( $args ); ?>

    <!-- Blog Start -->
    <div class="seese-blog-wrapper <?php echo esc_attr($blog_style_class.' '.$styled_class.' '.$class); ?>">
      <div class="seese-blogs <?php echo esc_attr($blog_msnry_class); ?>">

        <?php
        if ($vcts_post->have_posts()) :
          $count_all_post = $vcts_post->post_count;
          $count = 0;

          while ($vcts_post->have_posts()) : $vcts_post->the_post();
            $count++;

            if ($blog_style === 'seese-blog-two') {
              if ($count === 1) {
                echo '<div class="seese-blog-msnry-gutter"></div>';
                echo '<div class="'.esc_attr($blog_column_class).' seese-blog-msnry-sizer"></div>';
              }
            } else {
              if ($grid_number === 1) {
                echo '<div class="row">';
              } else {
                if ($count === 1) {
                  echo '<div class="row">';
                } else if(( $count % $grid_number ) === 1 ) {
                  echo '<div class="row">';
                }
              }
            }

            echo '<div class="'.esc_attr($blog_column_class.' '.$blog_msnry_item_class).'">';

              if (is_sticky(get_the_ID())) {
                $sclass = 'sticky';
              } else {
                $sclass = '';
              } ?>

              <div class="seese-latestBlog">
                <div id="post-<?php the_ID(); ?>" <?php post_class('seese-blog-post '.$sclass); ?>>
                  <?php
                  $large_image  = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
                  $large_image  = $large_image[0];
                  $post_type    = get_post_meta( get_the_ID(), 'post_type_metabox', true );

                  if (('gallery' == get_post_format()) && !empty($post_type['gallery_post_format'])) {
                    $images = [];
                    $ids = explode( ',', $post_type['gallery_post_format'] );
                    foreach ( $ids as $id ) {
                      $attachment = wp_get_attachment_image_src( $id, 'full' );
                      if ( isset($attachment[0]) ) {
                        array_push($images, $attachment[0]);
                      }
                    }
                    if ( count($images) > 0 ) { ?>
                      <div class="seese-sliderBox">
                        <ul class="owl-carousel seese-featureImg-carousel">
                          <?php
                          $ids = explode( ',', $post_type['gallery_post_format'] );
                          foreach ( $ids as $id ) {
                            $attachment = wp_get_attachment_image_src($id, 'full');
                            $alt        = get_post_meta($id, '_wp_attachment_image_alt', true);
                            $alt        = $alt ? esc_attr($alt) : esc_attr(get_the_title());
                            $g_img      = $attachment[0];

                            if($blog_style === 'seese-blog-two') {
                              $post_img = ($g_img) ? $g_img : '';
                            } else {
                              if($blog_columns === 'seese-blog-col-3') {
                                if($g_img){
                                  if(class_exists('Aq_Resize')) {
                                    $featured_img = aq_resize( $g_img, '370', '235', true );
                                    $post_img = ($featured_img) ? $featured_img : VCTS_PLUGIN_ASTS . '/images/370x235.jpg';
                                  } else {
                                    $post_img = $g_img;
                                  }
                                } else {
                                  $post_img = '';
                                }
                              } else if($blog_columns === 'seese-blog-col-2') {
                                if($g_img){
                                  if(class_exists('Aq_Resize')) {
                                    $featured_img = aq_resize( $g_img, '570', '355', true );
                                    $post_img = ($featured_img) ? $featured_img : VCTS_PLUGIN_ASTS . '/images/570x355.jpg';
                                  } else {
                                    $post_img = $g_img;
                                  }
                                } else {
                                  $post_img = '';
                                }
                              } else {
                                if($g_img){
                                  $post_img = $g_img;
                                } else {
                                  $post_img = '';
                                }
                              }
                            }
                            if ($blog_popup) {
                              $popup_class = 'seese-img-popup';
                              $link_to = ($g_img) ? $g_img : get_the_permalink();
                            } else {
                              $popup_class = '';
                              $link_to = get_the_permalink();
                            }
                            if ($post_img) {
                              echo '<li><a href='.esc_url($link_to).' class="'.esc_attr($popup_class).'"><img src="'.esc_url($post_img).'" alt="'.$alt.'" /></a></li>';
                            } else {
                              echo '';
                            }
                          } ?>
                        </ul>
                      </div>
                    <?php
                    }
                  } elseif (('audio' == get_post_format()) && ! empty( $post_type['audio_post_format'])) { ?>
                    <div class="seese-music">
                      <?php echo $post_type['audio_post_format']; ?>
                    </div>
                  <?php
                  } elseif (('video' == get_post_format()) && ! empty( $post_type['video_post_format'])) { ?>
                    <div class="seese-video">
                      <?php echo $post_type['video_post_format']; ?>
                    </div>
                  <?php
                  } elseif ($large_image) {
                    if ($blog_style === 'seese-blog-two') {
                      $post_img = ($large_image) ? $large_image : VCTS_PLUGIN_ASTS . '/images/1170x705.jpg';
                    } else {
                      if ($blog_columns === 'seese-blog-col-3') {
                        if (class_exists('Aq_Resize')) {
                          $post_img = aq_resize( $large_image, '370', '235', true );
                          $post_img = ($post_img) ? $post_img : VCTS_PLUGIN_ASTS . '/images/370x235.jpg';
                        } else {
                          $post_img = $large_image;
                        }
                      } else if ($blog_columns === 'seese-blog-col-2') {
                        if (class_exists('Aq_Resize')) {
                          $post_img = aq_resize( $large_image, '570', '355', true );
                          $post_img = ($post_img) ? $post_img : VCTS_PLUGIN_ASTS . '/images/570x355.jpg';
                        } else {
                          $post_img = $large_image;
                        }
                      } else {
                        $post_img = $large_image;
                      }
                    }
                    if ($blog_popup) {
                      $popup_class = 'seese-img-popup';
                      $link_to = $large_image;
                    } else {
                      $popup_class = '';
                      $link_to = get_the_permalink();
                    } ?>
                    <div class="seese-featureImg">
                      <a href="<?php echo esc_url($link_to); ?>" class="<?php echo esc_attr($popup_class); ?>"><img src="<?php echo esc_url($post_img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"/></a>
                    </div>
                  <?php
                  } else {
                    echo '';
                  } // Featured Image ?>

                  <div class="seese-blog-excerpt">

                    <?php  if ($blog_date || $blog_author || $blog_category) { // Meta's Hide ?>
                      <div class="seese-publish">
                        <ul>
	                        <?php
	                        if ($blog_author) { // Author Hide ?>
	                          <li><span>by</span></li>
	                          <li><?php printf('<a href="%1$s" rel="author">%2$s</a>', esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ), get_the_author()); ?></li><?php
	                        }
	                        if ($blog_date) { // Date Hide
	                          if ($blog_author) { ?>
	                            <li><span>-</span></li><?php
	                          } ?>
	                          <li><?php the_time('F d, Y'); ?></li><?php
	                        }
	                        if ($blog_category) { // Category Hide
	                          if ($blog_date || $blog_author) { ?>
	                            <li><span>-</span></li><?php
	                          } ?>
	                          <li>
	                            <div class="seese-blog-cat"><?php
	                              $categories = get_the_category();
	                              if ($categories) {
	                                the_category( '<span>&nbsp;&amp;&nbsp;</span>' );
	                              } ?>
	                            </div>
	                          </li><?php
	                        } ?>
                        </ul>
                      </div><?php
                    } ?>

                    <h3 class="blog-heading">
                      <a href="<?php echo esc_url( get_permalink() ); ?>">
                        <?php echo esc_attr(get_the_title()); ?>
                      </a>
                    </h3>

                    <?php if($blog_excerpt) { ?>
                      <div class="seese-article">
                        <?php
                          if ( function_exists( 'seese_excerpt' ) ) {
                            seese_excerpt($blog_excerpt_length);
                          }
                          if ( function_exists( 'seese_wp_link_pages' ) ) {
                            echo seese_wp_link_pages();
                          }
                        ?>
                      </div>
                    <?php } ?>

                    <?php if($blog_read_more){ ?>
                      <div class="seese-readmore">
                        <a href="<?php echo esc_url(get_permalink()); ?>">
                          <?php echo esc_attr($read_more_text). ' <i class="fa fa-angle-right"></i>'; ?>
                        </a>
                      </div>
                    <?php } ?>

                  </div>
                </div>
              </div>
            <?php
            if ($blog_style === 'seese-blog-two') {
              echo '</div>';
            } else {
              if ( $grid_number === 1 ) {
                echo '</div></div>';
              } else {
                echo '</div>';
                if((($count % $grid_number) === 0) || ($count === ($count_all_post))) {
                  echo '</div>';
                }
              }
            }
          endwhile;
        endif;
        ?>
      </div>

      <?php
      if ($blog_pagination) {
        $lmore_post_text = cs_get_option('lmore_post_text');
        $older_post_text = cs_get_option('older_post_text');
        $newer_post_text = cs_get_option('newer_post_text');

        if ( $blog_pagination_style === 'seese-pagination-three') {
          $lmore_post_text = $lmore_post_text ? $lmore_post_text : esc_html__( 'Load More', 'seese-core' ); ?>
          <div class="seese-load-more-box seese-blog-load-more-box">
            <div class="seese-load-more-link seese-blog-load-more-link">
              <?php next_posts_link( '&nbsp;', $vcts_post->max_num_pages ); ?>
            </div>
            <div class="seese-load-more-controls seese-blog-load-more-controls seese-btn-mode">
              <div class="line-scale-pulse-out">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
              <a href="javascript:void(0);" id="seese-blog-load-more-btn" class="seese-btn"><?php echo $lmore_post_text; ?></a>
              <a href="javascript:void(0);" id="seese-loaded" class="seese-btn"><?php echo __( 'All Loaded', 'seese-core' ); ?></a>
            </div>
          </div>
        <?php
        } elseif ($blog_pagination_style === 'seese-pagination-two') {
          $older_post_text = $older_post_text ? $older_post_text : esc_html__( 'Older Posts', 'seese-core' );
          $newer_post_text = $newer_post_text ? $newer_post_text : esc_html__( 'Newer Posts', 'seese-core' ); ?>
          <div class="seese-prev-next-pagination seese-blog-pagination row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 newer">
              <?php next_posts_link('<i class="fa fa-angle-double-left" aria-hidden="true"></i> '. $older_post_text, $vcts_post->max_num_pages); ?>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 older">
              <?php previous_posts_link($newer_post_text.' <i class="fa fa-angle-double-right" aria-hidden="true"></i>', $vcts_post->max_num_pages); ?>
            </div>
          </div>
        <?php
        } else {
          if ( function_exists('wp_pagenavi')) {
            wp_pagenavi( array( 'query' => $vcts_post ) );
          } else {
            $older_post_text = $older_post_text ? $older_post_text : '<i class="fa fa-angle-double-left"></i>';
            $newer_post_text = $newer_post_text ? $newer_post_text : '<i class="fa fa-angle-double-right"></i>';
            $big = 999999999;
            echo paginate_links( array(
              'base'      => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
              'format'    => '?paged=%#%',
              'total'     => $vcts_post->max_num_pages,
              'current'   => max( 1, $my_page ),
              'show_all'  => false,
              'end_size'  => 1,
              'mid_size'  => 2,
              'prev_next' => true,
              'prev_text' => $older_post,
              'next_text' => $newer_post,
              'type'      => 'list'
            ) );
          }
        }
      }
      wp_reset_postdata();  // avoid errors further down the page
      ?>
    </div>
    <!-- Blog End -->

    <?php
    // Return outbut buffer
    return ob_get_clean();

  }
}

add_shortcode( 'vcts_blog', 'vcts_blog_function' );
