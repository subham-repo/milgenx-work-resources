<?php
/**
 * Product Categories - Shortcode Options
 */

if (class_exists('WooCommerce')) {

  add_action( 'init', 'vcts_product_categories_vc_map' );

  if ( ! function_exists( 'vcts_product_categories_vc_map' ) ) {

    function vcts_product_categories_vc_map() {

      vc_map( array(
      'name'        => esc_html__( 'Product Categories', 'seese-core'),
      'base'        => 'vcts_product_categories',
      'description' => esc_html__( 'WooCommerce Product Categories', 'seese-core'),
      'icon'        => 'fa fa-th-large color-grey',
      'category'    => VictorLib::vcts_cat_name(),
      'params'      => array(

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Layout', 'seese-core' ),
          'param_name'       => 'cat_lt_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'dropdown',
          'heading'          => esc_html__( 'Style', 'seese-core' ),
          'param_name'       => 'cat_style',
          'value'            => array(
            esc_html__( 'Default', 'seese-core' ) => 'cats_default',
            esc_html__( 'Masonry', 'seese-core' ) => 'cats_masonry',
            esc_html__( 'Slider', 'seese-core' ) => 'cats_slider',
          ),
          'admin_label'      => true,
          'description'      => esc_html__( 'Select your style.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
		array(
		  'type' 		     => 'dropdown',
		  'heading' 	     => esc_html__( 'Columns', 'seese-core' ),
		  'param_name' 	     => 'cat_columns',
		  'description'	     => esc_html__( 'Select number of columns.', 'seese-core' ),
		  'value' 		     => array(
			esc_html__( 'Two', 'seese-core' ) => 'col_2',
			esc_html__( 'Three', 'seese-core' ) => 'col_3',
			esc_html__( 'Four', 'seese-core' ) => 'col_4',
		  ),
  		  'std'			     => 'col_3',
          'admin_label'      => true,
          'dependency'       => array(
            'element'        => 'cat_style',
            'value'          => array('cats_default', 'cats_slider')
          ),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		),
        array(
		  'type' 	         => 'textfield',
		  'heading' 	     => esc_html__( 'Limit', 'seese-core' ),
		  'param_name' 	     => 'cat_limit',
          'admin_label'      => true,
		  'description'	     => esc_html__( 'Enter the number of product categories to display.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		),
        array(
		  'type' 	         => 'textfield',
		  'heading' 	     => esc_html__( 'Min Height', 'seese-core' ),
		  'param_name' 	     => 'cat_min_height',
		  'description'	     => esc_html__( 'Set minimum height for each category grid in pixel.', 'seese-core' ),
          'dependency'       => array(
            'element'        => 'cat_style',
            'value'          => array('cats_default', 'cats_slider')
          ),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		),
        // Slider Settings Option
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Loop', 'seese-core'),
          'param_name'       => 'loop',
          'value'            => '',
          'std'              => true,
          'description'      => esc_html__( 'Inifnity loop.', 'seese-core'),
          'dependency'       => array(
            'element'        => 'cat_style',
            'value'          => 'cats_slider',
          ),
          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Navigation', 'seese-core'),
          'param_name'       => 'nav',
          'value'            => '',
          'std'              => true,
          'description'      => esc_html__( 'Show next/prev buttons.', 'seese-core'),
          'dependency'       => array(
            'element'        => 'cat_style',
            'value'          => 'cats_slider',
          ),
          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Dots', 'seese-core'),
          'param_name'       => 'dots',
          'value'            => '',
          'std'              => false,
          'description'      => esc_html__( 'Show dots navigation.', 'seese-core'),
          'dependency'       => array(
            'element'        => 'cat_style',
            'value'          => 'cats_slider',
          ),
          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Autoplay', 'seese-core'),
          'param_name'       => 'autoplay',
          'value'            => '',
          'std'              => false,
          'description'      => esc_html__( 'Start Autoplay.', 'seese-core'),
          'dependency'       => array(
            'element'        => 'cat_style',
            'value'          => 'cats_slider',
          ),
          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
        ),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__( 'Gap', 'seese-core' ),
          'param_name'       => 'gap',
          'description'      => esc_html__( 'Enter gap between images(value is in px, enter numbers only).', 'seese-core' ),
          'dependency'       => array(
            'element'        => 'cat_style',
            'value'          => 'cats_slider',
          ),
          'edit_field_class' => 'vc_col-sm-6 vc_column seese_field_space',
		),
        array(
		  'type'             => 'textfield',
		  'heading'          => esc_html__( 'Navigation Speed', 'seese-core' ),
		  'param_name'       => 'nav_speed',
		  'description'      => esc_html__( 'Enter navigation speed(value is in ms, enter numbers only).', 'seese-core' ),
          'dependency'       => array(
            'element'        => 'nav',
            'value'          => 'true',
          ),
		  'edit_field_class' => 'vc_col-sm-6 vc_column seese_field_space',
		),
        array(
		  'type'             => 'textfield',
		  'heading'          => esc_html__( 'Dots Speed', 'seese-core' ),
		  'param_name'       => 'dots_speed',
		  'description'      => esc_html__( 'Enter dots speed(value is in ms, enter numbers only).', 'seese-core' ),
          'dependency'       => array(
            'element'        => 'dots',
            'value'          => 'true',
          ),
		  'edit_field_class' => 'vc_col-sm-6 vc_column seese_field_space',
		),
        array(
		  'type'             => 'textfield',
          'heading'          => esc_html__( 'Autoplay Speed', 'seese-core' ),
          'param_name'       => 'autoplay_speed',
          'description'      => esc_html__( 'Enter autoplay speed(value is in ms, enter numbers only).', 'seese-core' ),
          'dependency'       => array(
            'element'        => 'autoplay',
            'value'          => 'true',
          ),
          'edit_field_class' => 'vc_col-sm-6 vc_column seese_field_space',
		),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Enable/Disable', 'seese-core' ),
          'param_name'       => 'cat_ed_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Product Count', 'seese-core'),
          'param_name'       => 'cat_pr_count',
          'value'            => '',
          'std'              => true,
          'description'	     => esc_html__( 'Show product count of categories.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__('Description', 'seese-core'),
          'param_name'       => 'cat_des',
          'value'            => '',
          'std'              => true,
          'description'	     => esc_html__( 'Show description of categories.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading' 		 => esc_html__( 'Hide Empty', 'seese-core' ),
          'param_name'       => 'cat_hide_empty',
          'value'            => '',
          'std'              => true,
          'admin_label'      => true,
          'description'	     => esc_html__( 'Hide empty categories.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
        ),
		array(
          'type'             => 'switcher',
		  'heading' 		 => esc_html__( 'Parent', 'seese-core' ),
		  'param_name' 	     => 'cat_parent',
          'value'            => '',
          'std'              => true,
		  'description'	     => esc_html__( 'Only display top level categories.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
		),
        array(
          'type'             => 'switcher',
		  'heading' 		 => esc_html__( 'Hover Animation', 'seese-core' ),
		  'param_name' 	     => 'cat_hover_anim',
          'value'            => '',
          'std'              => true,
		  'description'	     => esc_html__( 'Show category image hover animation.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-3 vc_column seese_field_space',
		),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Styling', 'seese-core' ),
          'param_name'       => 'cat_stl_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type' 			 => 'colorpicker',
		  'heading' 		 => esc_html__( 'Background Color', 'seese-core' ),
		  'param_name' 	     => 'cat_bg_color',
		  'description'	     => esc_html__( 'Set a background color.', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'colorpicker',
          'heading'          => esc_html__( 'Title Color', 'seese-core' ),
          'param_name'       => 'cat_title_color',
          'value'            => '',
          'description'      => esc_html__( 'Set a category title text color.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
          'type'             => 'colorpicker',
          'heading'          => esc_html__( 'Description Text Color', 'seese-core' ),
          'param_name'       => 'cat_desc_color',
          'value'            => '',
          'description'      => esc_html__( 'Set a category description text color.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Listing', 'seese-core' ),
          'param_name'       => 'cat_lst_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
		array(
		  'type' 			 => 'dropdown',
		  'heading' 		 => esc_html__( 'Order', 'seese-core' ),
		  'param_name' 	     => 'cat_order',
		  'description'	     => esc_html__( 'Select categories order.', 'seese-core' ),
		  'value'			 => array(
            esc_html__('Asending', 'seese-core') => 'ASC',
            esc_html__('Desending', 'seese-core') => 'DESC',
		  ),
		  'std'			     => 'ASC',
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		),
        array(
		  'type' 		     => 'dropdown',
		  'heading'          => esc_html__( 'Order By', 'seese-core' ),
		  'param_name' 	     => 'cat_orderby',
		  'description'	     => esc_html__( 'Select categories order-by.', 'seese-core' ),
		  'value'	         => array(
		    'None'	         => 'none',
			'ID'	         => 'ID',
			'Name'	         => 'name',
			'Count'	         => 'count',
			'Slug'	         => 'slug',
		  ),
		  'std'			     => 'name',
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
		),
		array(
		  'type' 			 => 'textfield',
		  'heading' 		 => esc_html__( 'IDs', 'seese-core' ),
          'param_name' 	     => 'cat_ids',
		  'description'	     => esc_html__( 'Filter categories by entering a comma separated list of IDs.', 'seese-core' ),
          'admin_label'      => true,
		),

        VictorLib::seese_class_option(),

        )
      ) );
	}
  }
}
