<?php
/**
 * Button - Shortcode Options
 */

add_action( 'init', 'vcts_button_vc_map' );

if ( ! function_exists( 'vcts_button_vc_map' ) ) {

  function vcts_button_vc_map() {

    vc_map( array(
      'name'        => esc_html__( 'Button', 'seese-core'),
      'base'        => 'vcts_button',
      'description' => esc_html__( 'Button Styles', 'seese-core'),
      'icon'        => 'fa fa-mouse-pointer color-brown',
      'category'    => VictorLib::vcts_cat_name(),
      'params'      => array(

        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Layout', 'seese-core' ),
          'param_name'       => 'bl_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__( 'Button Text', 'seese-core' ),
          'param_name'       => 'button_text',
          'value'            => '',
          'admin_label'      => true,
          'description'      => esc_html__( 'Enter your button text.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          'type'             => 'href',
          'heading'          => esc_html__( 'Button Link', 'seese-core' ),
          'param_name'       => 'button_link',
          'value'            => '',
          'description'      => esc_html__( 'Enter your button link.', 'seese-core'),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__( 'Open New Tab?', 'seese-core' ),
          'param_name'       => 'open_link',
          'std'              => false,
          'value'            => '',
          'on_text'          => esc_html__( 'Yes', 'seese-core' ),
          'off_text'         => esc_html__( 'No', 'seese-core' ),
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),
        array(
          'type'             => 'switcher',
          'heading'          => esc_html__( 'Custom Hover', 'seese-core' ),
          'param_name'       => 'simple_hover',
          'std'              => false,
          'value'            => '',
          'edit_field_class' => 'vc_col-md-6 vc_column seese_field_space',
        ),

        // Styling
        array(
          'type'             => 'notice',
          'heading'          => esc_html__( 'Styling', 'seese-core' ),
          'param_name'       => 'bs_opt',
          'class'            => 'cs-info',
          'value'            => '',
		),
        array(
          'type'             => 'textfield',
          'heading'          => esc_html__( 'Text Size', 'seese-core' ),
          'param_name'       => 'text_size',
          'value'            => '',
          'description'      => esc_html__( 'Enter button text font size. [Eg: 14px]', 'seese-core'),
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),
        array(
		  'type'             => 'dropdown',
		  'heading'          => esc_html__('Alignment', 'seese-core'),
		  'param_name'       => 'button_align',
          'value'            => array(
            esc_html__( 'Select Button Align', 'seese-core' ) => '',
            esc_html__( 'Center', 'seese-core' )              => 'center',
            esc_html__( 'Left', 'seese-core' )                => 'left',
            esc_html__( 'Right', 'seese-core' )               => 'right',
          ),
          'description'      => 'Select button alignment.',
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
		),
        array(
          'type'             => 'colorpicker',
          'heading'          => esc_html__( 'Text Color', 'seese-core' ),
          'param_name'       => 'text_color',
          'value'            => '',
          'description'      => 'Select button color.',
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
        ),

        array(
          'type'             => 'colorpicker',
          'heading'          => esc_html__( 'Text Hover Color', 'seese-core' ),
          'param_name'       => 'text_hover_color',
          'value'            => '',
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
          'dependency'       => array(
            'element'        => 'simple_hover',
            'value'          => 'true',
          ),
        ),
        array(
          'type'             => 'colorpicker',
          'heading'          => esc_html__( 'Background Hover Color', 'seese-core' ),
          'param_name'       => 'bg_hover_color',
          'value'            => '',
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
          'dependency'       => array(
            'element'        => 'simple_hover',
            'value'          => 'true',
          ),
        ),
        array(
          'type'             => 'colorpicker',
          'heading'          => esc_html__( 'Border Hover Color', 'seese-core' ),
          'param_name'       => 'br_hover_color',
          'value'            => '',
          'edit_field_class' => 'vc_col-md-4 vc_column seese_field_space',
          'dependency'       => array(
            'element'        => 'simple_hover',
            'value'          => 'true',
          ),
        ),

        VictorLib::seese_class_option(),

        // Design Tab
        array(
          'type'             => 'css_editor',
          'heading'          => esc_html__( 'Text Size', 'seese-core' ),
          'param_name'       => 'css',
          'group'            => esc_html__( 'Design', 'seese-core'),
        ),

      )
    ) );
  }
}
