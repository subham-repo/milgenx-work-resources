<?php
/* ==========================================================
  Product Categories
=========================================================== */

if (class_exists('WooCommerce')) {

  if ( !function_exists('vcts_product_categories_function')) {

    function vcts_product_categories_function( $atts, $content = NULL ) {

	    extract(shortcode_atts(array(
	      // Layout
	      'cat_style'       => '',
	      'cat_columns'     => 'col_3',
	      'cat_limit'       => '',
	      'cat_min_height'  => '',
	      'bg_color'        => '',
	      'loop'            => '',
	      'nav'             => '',
	      'dots'            => '',
	      'gap'             => '',
	      'nav_speed'       => '',
	      'dots_speed'      => '',
	      'autoplay'        => '',
	      'autoplay_speed'  => '',
	      // Listing
	      'cat_pr_count'    => '',
	      'cat_des'         => '',
	      'cat_hide_empty'  => '',
	      'cat_parent'      => '',
	      'cat_hover_anim'  => '',
	      // Color
	      'cat_bg_color'    => '',
	      'cat_title_color' => '',
	      'cat_desc_color'  => '',
	      'cat_order'       => 'ASC',
	      'cat_orderby'     => 'title',
	      'cat_ids'         => '',
	      'class'           => '',
	    ), $atts));

	    if($cat_columns === 'col_3') {
	      $col_number   = 3;
	      $column_class = 'col-lg-4 col-md-4 col-sm-12 col-xs-12';
	    } else if($cat_columns === 'col_4') {
	      $col_number   = 4;
	      $column_class = 'col-lg-3 col-md-3 col-sm-12 col-xs-12';
	    } else {
	      $col_number   = 2;
	      $column_class = 'col-lg-6 col-md-6 col-sm-12 col-xs-12';
	    }

	    $cat_hover_anim  = ($cat_hover_anim) ? 'true' : 'false';
	    $cat_hover_class = ($cat_hover_anim == 'true') ? 'hover-effect' : '';
	    $cat_hide_empty  = ($cat_hide_empty) ? 1 : 0;

	    $args = array(
	      'order'       => $cat_order,
	      'orderby'     => $cat_orderby,
	      'hide_empty'  => $cat_hide_empty,
	    );

	    if($cat_parent) {
	      $args['parent'] = 0;
	    }
	    if($cat_limit !== '') {
	      $args['number'] = $cat_limit;
	    }
	    if($cat_ids !== '') {
	      $args['include'] = $cat_ids;
	    }

	    $pro_cats = get_terms('product_cat', $args);

	    $inline_style = '';
	    $e_uniqid     = uniqid();

	    if($cat_style === 'cats_slider'){
	      $styled_class = 'seese-catslr-slider-'. $e_uniqid;
	    } elseif ($cat_style === 'cats_masonry') {
	      $styled_class = 'seese-cat-masonry-'. $e_uniqid;
	    } else {
	      $styled_class = 'seese-cat-default-'. $e_uniqid;
	    }

	    if ($cat_title_color) {
	      $inline_style .= '.'.$styled_class.' .seese-catsc-text .seese-catsc-name {';
	      $inline_style .= 'color: '.$cat_title_color.';';
	      $inline_style .= '}';
	    }

	    if ($cat_desc_color) {
	      $inline_style .= '.'.$styled_class.' .seese-catsc-text .seese-catsc-desc {';
	      $inline_style .= 'color: '.$cat_desc_color.';';
	      $inline_style .= '}';
	    }

	    // Turn output buffer on
	    ob_start();

	    if ($cat_style === 'cats_slider') {

	      $cat_min_height  = ($cat_min_height) ? $cat_min_height : '700px';

	      if(isset($cat_min_height) || isset($cat_bg_color)){
	        $inline_style .= '.'.$styled_class.' .seese-catslr-box {';
	        $inline_style .= 'height:'.seese_check_px($cat_min_height).';';
	        $inline_style .= ($cat_bg_color) ? 'background-color: '.$cat_bg_color.'; background-image:none;' : '';
	        $inline_style .= '}';
	      }

	      seese_add_inline_style( $inline_style );

	      $loop           = $loop       ? 'true' : 'false';
	      $nav            = $nav        ? 'true' : 'false';
	      $dots           = $dots       ? 'true' : 'false';
	      $autoplay       = $autoplay   ? 'true' : 'false';
	      $gap            = $gap        ? $gap : '10';
	      $nav_speed      = $nav_speed  ? (int)$nav_speed : '500';
	      $dots_speed     = $dots_speed ? (int)$dots_speed : '500';
	      $autoplay_speed = $autoplay_speed ? (int)$autoplay_speed : '500';

	      $output_slider  = '';
	      $output_slider .= '<div class="seese-cat-slider owl-carousel '.esc_attr($styled_class.' '.$class).'">';

	      foreach ($pro_cats as $pro_cat) {
	        $thumbnail_id = get_woocommerce_term_meta( $pro_cat->term_id, 'thumbnail_id', true );
	        $cat_image    = wp_get_attachment_image_src( $thumbnail_id, 'fullsize', false, '' );
	        $cat_image    = $cat_image[0];

	        if($cat_image){
	          $cat_image  = $cat_image;
	        } else {
	          $cat_image  = '';
	        }

	        $catUrl = get_term_link($pro_cat->term_id);

	        $output_slider   .= '<div class="seese-catslr-box"><a href="'.esc_url($catUrl).'"></a>';

	        if($cat_image){
	          $output_slider .= '<div class="seese-catslr-img"><img src="'.esc_url($cat_image).'" alt="'.esc_attr($pro_cat->name).'" class="'.esc_attr($cat_hover_class).'"></div>';
	        } else {
	          $output_slider .= '<div class="seese-catslr-img"></div>';
	        }

	        $output_slider   .= '<div class="seese-catslr-text seese-catsc-text">';

	        if($pro_cat->name){
	          $output_slider .= '<div class="seese-catslr-name seese-catsc-name">'.esc_attr($pro_cat->name);
	          if($cat_pr_count){
	            $output_slider .= ' <span>['.esc_attr($pro_cat->count).']</span>';
	          }
	          $output_slider .= '</div>';
	        }

	        if($cat_des && $pro_cat->description){
	          $output_slider .= '<div class="seese-catslr-desc seese-catsc-desc">'.esc_attr($pro_cat->description).'</div>';
	        }

	        $output_slider   .= '</div></div>';
	      }

	      $output_slider     .= '</div>';

	      echo $output_slider;  ?>

	      <script type="text/javascript">
	        jQuery(document).ready(function($) {
	          var $owl = $('.<?php echo esc_js($styled_class); ?>');
	          $owl.imagesLoaded(function() {
		          $owl.owlCarousel({
		            items:         <?php echo esc_js($col_number); ?>,
		            margin:        <?php echo esc_js($gap); ?>,
		            loop:          <?php echo esc_js($loop); ?>,
		            nav:           <?php echo esc_js($nav); ?>,
		            dots:          <?php echo esc_js($dots); ?>,
		            autoplay:      <?php echo esc_js($autoplay); ?>,
		            navSpeed:      <?php echo esc_js($nav_speed); ?>,
		            dotsSpeed:     <?php echo esc_js($dots_speed); ?>,
		            autoplaySpeed: <?php echo esc_js($autoplay_speed); ?>,
		            autoHeight:    false,
		            navText:       ["<i class='fa fa-angle-left' aria-hidden='true'></i>", "<i class='fa fa-angle-right' aria-hidden='true'></i>"],
		            responsive:    {
		                              0: {
		                                items: 1
		                              },
		                              400: {
		                                items: 2
		                              },
		                              767: {
		                                items: <?php echo esc_js($col_number); ?>
		                              }
		                           }
		          });
		        });
	        });
	      </script>
	    <?php
	    } elseif ($cat_style === 'cats_masonry') {

	      if(isset($cat_bg_color)){
	        $inline_style .= '.'.$styled_class.' .seese-cat-masonry-box {';
	        $inline_style .= ($cat_bg_color) ? 'background-color: '.$cat_bg_color.'; background-image:none;' : '';
	        $inline_style .= '}';
	      }

	      seese_add_inline_style( $inline_style );

	      $output_masonry  = '';
	      $output_masonry .= '<div class="seese-cat-masonry '.esc_attr($styled_class.' '.$class).'">';
	      $output_masonry .= '<div class="seese-cat-gutter-sizer"></div>';
	      $output_masonry .= '<div class="seese-cat-masonry-sizer"></div>';

	      foreach ($pro_cats as $pro_cat) {
	        $thumbnail_id  = get_woocommerce_term_meta( $pro_cat->term_id, 'thumbnail_id', true );
	        $cat_image     = wp_get_attachment_image_src( $thumbnail_id, 'fullsize', false, '' );
	        $cat_image     = $cat_image[0];

	        if($cat_image){
	          $cat_image   = $cat_image;
	        } else {
	          $cat_image   = '';
	        }

	        $catUrl        = get_term_link($pro_cat->term_id);
	        $term_meta     = get_option("taxonomy_" . $pro_cat->term_id);
	        $grid_size     = ($term_meta['wh_meta_size']) ? esc_attr($term_meta['wh_meta_size']) : 'd-wh';

	        $output_masonry   .= '<div class="seese-cat-masonry-box '.esc_attr($grid_size).'"><a href="'.esc_url($catUrl).'"></a>';
	        if($cat_image){
	          $output_masonry .= '<div class="seese-cat-masonry-img"><img src="'.esc_url($cat_image).'" alt="'.esc_attr($pro_cat->name).'" class="'.esc_attr($cat_hover_class).'"></div>';
	        } else {
	          $output_masonry .= '<div class="seese-cat-masonry-img"></div>';
	        }

	        $output_masonry   .= '<div class="seese-cat-masonry-text seese-catsc-text">';

	        if($pro_cat->name){
	          $output_masonry .= '<div class="seese-cat-masonry-name seese-catsc-name">'.esc_attr($pro_cat->name);
	          if($cat_pr_count){
	            $output_masonry .= ' <span>['.esc_attr($pro_cat->count).']</span>';
	          }
	          $output_masonry .= '</div>';
	        }

	        if($cat_des && $pro_cat->description){
	          $output_masonry .= '<div class="seese-cat-masonry-desc seese-catsc-desc">'.esc_attr($pro_cat->description).'</div>';
	        }
	        $output_masonry   .= '</div></div>';
	      }

	      $output_masonry     .= '</div>';

	      echo $output_masonry;
	    ?>

	      <script type="text/javascript">
	        jQuery(document).ready(function($) {
	          var $catGrid = $('.<?php echo esc_js($styled_class); ?>');
	          $catGrid.imagesLoaded(function() {
		          $catGrid.isotope({
		            itemSelector: '.seese-cat-masonry-box',
		            percentPosition: true,
		            masonry: {
	    						columnWidth:  '.seese-cat-masonry-sizer',
	    						gutter: 20
	  						}
		          });
		        });
	        });
	      </script>

	    <?php
	    } else {

	      $cat_min_height  = ($cat_min_height) ? $cat_min_height : '320px';

	      if(isset($cat_min_height) || isset($cat_bg_color)){
	        $inline_style .= '.'.$styled_class.' .seese-catdt-box {';
	        $inline_style .= 'height:'.seese_check_px($cat_min_height).';';
	        $inline_style .= ($cat_bg_color) ? 'background-color: '.$cat_bg_color.'; background-image:none;' : '';
	        $inline_style .= '}';
	      }

	      seese_add_inline_style( $inline_style );

	      $output_default  = '';
	      $output_default .= '<div class="seese-cat-default '.esc_attr($styled_class.' '.$class).'">';

	      $count_all_cat   = count($pro_cats);
	      $count = 0;

	      foreach ($pro_cats as $pro_cat) {
	        $count++;
	        if( $count === 1 ) {
	          $output_default .= '<div class="row">';
	        } else if(( $count % $col_number ) === 1 ) {
	          $output_default .= '<div class="row">';
	        }
	        $output_default   .= '<div class="'. esc_attr($column_class) .'">';

	        $thumbnail_id = get_woocommerce_term_meta( $pro_cat->term_id, 'thumbnail_id', true );
	        $cat_image    = wp_get_attachment_image_src( $thumbnail_id, 'fullsize', false, '' );
	        $cat_image    = $cat_image[0];

	        if($cat_image){
	          $cat_image  = $cat_image;
	          $cat_height = '';
	        } else {
	          $cat_image  = '';
	          $cat_height = '';
	        }

	        $catUrl = get_term_link($pro_cat->term_id);

	        $output_default   .= '<div class="seese-catdt-box"><a href="'.esc_url($catUrl).'"></a>';

	        if($cat_image){
	          $output_default .= '<div class="seese-catdt-img"><img src="'.esc_url($cat_image).'" alt="'.esc_attr($pro_cat->name).'" class="'.esc_attr($cat_hover_class).'"></div>';
	        } else {
	          $output_default .= '<div class="seese-catdt-img"></div>';
	        }

	        $output_default   .= '<div class="seese-catdt-text seese-catsc-text">';

	        if($pro_cat->name){
	          $output_default .= '<div class="seese-catdt-name seese-catsc-name">'.esc_attr($pro_cat->name);
	          if($cat_pr_count){
	            $output_default .= ' <span>['.esc_attr($pro_cat->count).']</span>';
	          }
	          $output_default .= '</div>';
	        }

	        if($cat_des && $pro_cat->description){
	          $output_default .= '<div class="seese-catdt-desc seese-catsc-desc">'.esc_attr($pro_cat->description).'</div>';
	        }

	        $output_default   .= '</div></div>';

	        $output_default   .= '</div>';

	        if((($count % $col_number) === 0) || ($count === ($count_all_cat))) {
	          $output_default .= '</div>';
	        }

	      }
	      $output_default     .= '</div>';

	      echo $output_default;
	    }

      // Return outbut buffer
      return ob_get_clean();

	  }
  }

  add_shortcode( 'vcts_product_categories', 'vcts_product_categories_function' );

}
