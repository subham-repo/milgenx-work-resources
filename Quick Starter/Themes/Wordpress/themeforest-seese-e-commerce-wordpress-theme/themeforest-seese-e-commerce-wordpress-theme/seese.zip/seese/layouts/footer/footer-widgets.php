<!-- Footer Widgets Start -->
<div class="container">
  <div class="row">
    <?php echo seese_footer_widgets(); ?>
  </div>
</div>
<!-- Footer Widgets End -->