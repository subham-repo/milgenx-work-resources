<?php

include_once BOLDLAB_INC_ROOT_DIR . '/welcome/welcome.php';