<?php

include_once BOLDLAB_INC_ROOT_DIR . '/content/helper.php';