<li class="list-inline-item button-dropdown cart-dropdown">
    <a href="javascript:void(0)" class="dropdown-toggle">
        <i class="fas fa-shopping-cart"></i><span class="count bg-primary">0</span>
        <p class="mb-0">Shopping Cart<span class="c-price">0.00$</span></p>
    </a>
</li>