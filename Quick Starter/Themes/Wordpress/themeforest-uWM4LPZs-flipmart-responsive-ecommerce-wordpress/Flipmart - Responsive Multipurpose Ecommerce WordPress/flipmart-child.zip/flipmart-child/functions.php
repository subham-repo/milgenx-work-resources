<?php

/**
 * Flipmart - Responsive Multipurpose Ecommerce WordPress Child Theme - Functions
 */
 
 add_action( 'wp_enqueue_scripts', 'yog_load_child_styles', 20 );
 function yog_load_child_styles() {
    
    wp_enqueue_style( 'child-style-v1', get_stylesheet_directory_uri().'/style.css', array('yog-main-v1'), '2.7' );
    wp_enqueue_style( 'child-style-v2', get_stylesheet_directory_uri().'/style.css', array('yog-main-v2'), '2.7' );
    wp_enqueue_style( 'child-style-v3', get_stylesheet_directory_uri().'/style.css', array('yog-main-v3'), '2.7' );
    wp_enqueue_style( 'child-style-v4', get_stylesheet_directory_uri().'/style.css', array('yog-main-v4'), '2.7' );
    wp_enqueue_style( 'child-style-v5', get_stylesheet_directory_uri().'/style.css', array('yog-main-v5'), '2.7' );
    wp_enqueue_style( 'child-style-v6', get_stylesheet_directory_uri().'/style.css', array('yog-main-v6'), '2.7' );
    wp_enqueue_style( 'child-style-v7', get_stylesheet_directory_uri().'/style.css', array('yog-main-v7'), '2.7' );
    wp_enqueue_style( 'child-style-v8', get_stylesheet_directory_uri().'/style.css', array('yog-main-v8'), '2.7' );
 }