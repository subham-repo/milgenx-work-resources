<?php
include_once 'hover-animations.php';
foreach ( glob( BOLDLAB_CORE_INC_PATH . '/post-types/portfolio/shortcodes/portfolio-list/variations/info-below/hover-animations/*/include.php' ) as $animation ) {
	include_once $animation;
}