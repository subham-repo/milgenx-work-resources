<?php

include_once 'helper.php';

foreach ( glob( BOLDLAB_CORE_INC_PATH . '/post-types/*/include.php' ) as $include ) {
	include_once $include;
}