<?php

include_once 'gallery-small.php';