<?php

if ( ! function_exists( 'boldlab_core_add_fixed_header_options' ) ) {
	function boldlab_core_add_fixed_header_options( $page ) {
	
	}
	
	add_action( 'boldlab_core_action_after_header_options_map', 'boldlab_core_add_fixed_header_options' );
}