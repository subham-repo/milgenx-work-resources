<?php

include_once 'images-small.php';