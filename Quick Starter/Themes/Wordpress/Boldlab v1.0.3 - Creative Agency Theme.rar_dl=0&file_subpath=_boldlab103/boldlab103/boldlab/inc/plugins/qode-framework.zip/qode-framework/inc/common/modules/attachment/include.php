<?php

require_once 'core/options.php';
require_once 'core/page.php';