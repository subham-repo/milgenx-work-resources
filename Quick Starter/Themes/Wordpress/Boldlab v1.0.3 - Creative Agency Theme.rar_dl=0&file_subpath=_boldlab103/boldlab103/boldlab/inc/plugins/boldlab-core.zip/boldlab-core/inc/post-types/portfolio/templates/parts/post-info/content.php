<div class="qodef-e qodef-portfolio-content">
	<?php the_content(); ?>
</div>