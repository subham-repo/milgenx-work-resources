<?php

include_once BOLDLAB_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/system-info.php';