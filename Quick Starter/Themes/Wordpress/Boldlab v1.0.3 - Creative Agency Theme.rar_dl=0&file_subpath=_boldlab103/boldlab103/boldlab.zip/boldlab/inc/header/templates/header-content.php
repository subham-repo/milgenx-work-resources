<?php

// Include logo
boldlab_template_part( 'header', 'templates/parts/logo' );

// Include main navigation
boldlab_template_part( 'header', 'templates/parts/navigation' );